// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDXGIDEVICE_H__
#define __WINDXGIDEVICE_H__

#include "WinD3D11Device.h"

#include <d3d11.h>
#include <DXGI1_2.h>

class WinDxgiDevice
{
public:
  // Uses WinD3D11Device to create internal handle
  WinDxgiDevice(WinD3D11Device *winD3D11Device);
  virtual ~WinDxgiDevice();

  HRESULT getParent(REFIID riid, void **ppvObject);

private:
  IDXGIDevice *m_dxgiDevice;
};

#endif // __WINDXGIDEVICE_H__
