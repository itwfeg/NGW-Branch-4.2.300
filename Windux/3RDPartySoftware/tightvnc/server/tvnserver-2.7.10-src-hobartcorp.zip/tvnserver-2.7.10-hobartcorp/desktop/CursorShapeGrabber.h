// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CURSORSHAPEGRABBER_H__
#define __CURSORSHAPEGRABBER_H__

#include "rfb/CursorShape.h"

class CursorShapeGrabber
{
public:
  CursorShapeGrabber();
  virtual ~CursorShapeGrabber();

  virtual bool grab(const PixelFormat *pixelFormat) = 0;

  // Returns true if the cursor shape has been changed, false otherwise.
  // Calling this function resets the state back to unchanged.
  virtual bool isCursorShapeChanged() = 0;

  virtual const CursorShape *getCursorShape() const;

protected:
  CursorShape m_cursorShape;
};

#endif // __CURSORSHAPEGRABBER_H__
