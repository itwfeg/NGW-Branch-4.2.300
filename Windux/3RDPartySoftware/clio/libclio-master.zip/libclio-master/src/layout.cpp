/**
 * @file layout.cpp
 * @brief Base layout class.
 *
 * @section Copyright
 * Copyright (C) 2013 Randy Blankley
 *
 * @section License
 * This file is part of libclio.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include "layout.h"
#include "logline.h"

/// Clio namespace.
namespace clio
{

///////////////////////////////////////////////////////////////////////////////////////////////////
layout::layout() :
    _Mybase()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
layout::~layout()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
std::string layout::format( const logLine& line ) const
{
    return line.text();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
} // namespace clio


