// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CONNECTIONTIMER_H__
#define __CONNECTIONTIMER_H__

#include "thread/Thread.h"
#include "win-system/WindowsEvent.h"
#include "TimerListener.h"

// This class waits for time interval after that notifies to external listener.
// If destructor will be called early than a time interval be out then
// ConnectionTimer will not notify to external listener.
class ConnectionTimer : private Thread
{
public:
  ConnectionTimer(TimerListener *timerListener, unsigned int timeOut);
  virtual ~ConnectionTimer();

private:
  virtual void execute();
  virtual void onTerminate();

  TimerListener *m_timerListener;
  unsigned int m_timeOut;
  WindowsEvent m_timer;
  bool m_signalEnabled;
};

#endif // __CONNECTIONTIMER_H__
