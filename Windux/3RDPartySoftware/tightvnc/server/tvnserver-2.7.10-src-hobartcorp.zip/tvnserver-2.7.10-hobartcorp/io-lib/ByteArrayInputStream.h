// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _BYTE_ARRAY_INPUT_STREAM_H_
#define _BYTE_ARRAY_INPUT_STREAM_H_

#include "InputStream.h"
#include "IOException.h"

/**
 * Input stream for reading data from memory.
 */
class ByteArrayInputStream : public InputStream
{
public:
  /**
   * Creates new input stream for reading data from memory.
   * @param buffer source buffer.
   * @param bufferSize count of bytes in memory buffer.
   */
  ByteArrayInputStream(const char *buffer, size_t bufferSize);
  virtual ~ByteArrayInputStream();

  /**
   * Reads data from memory.
   * @param buffer target buffer to write data.
   * @param len count of bytes to write.
   * @throws IOException when no data left in memory buffer.
   */
  virtual size_t read(void *buffer, size_t len) throw(IOException);

protected:
  const char *m_buffer;
  size_t m_bufferSize;
  size_t m_left;
};

#endif
