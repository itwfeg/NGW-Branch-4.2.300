﻿using System;
using System.Threading.Tasks;

namespace BnWasp
{
	public class DiscoveringWaspScan
	{
		public event EventHandler<FeedbackEventArgs> Feedback = delegate {};

		private int m_foundDevices = 0;
		private readonly BTDiscoveryInterface m_cm;

		public DiscoveringWaspScan()
		{
			m_cm = BTDiscoveryInterface.Current;
		}

		public int PerformScan(DiscoveringWaspData data, WaspStats stats, int durationSecs)
		{
			m_foundDevices = 0;

			if (m_cm != null)
			{
				stats.DiscoveryStart();
				m_cm.DiscoveryTimeoutMSecs = durationSecs * 1000;
				Task t = m_cm.BeginScanningForDevices();
				t.Wait();
				m_cm.StopScanningForDevices();

				ProcessDiscoveredDevices(data, stats, m_cm.DiscoveredDevices);
				stats.DiscoveryEnd();
			}

			return m_foundDevices;
		}

		private void ProcessDiscoveredDevices(DiscoveringWaspData data, WaspStats stats, System.Collections.Generic.List<BNDevice> discoveredDevices)
		{
			if (discoveredDevices.Count > 0)
			{
				foreach (BNDevice device in discoveredDevices)
				{
					stats.AddDiscovered();
					string action;
					if (data.AddNewRecord(device))
					{
						stats.AddRecord();
						action = "Added";
					}
					else
					{
						action = "Ignored";
					}
					ShowFeedback(string.Format("{0} {1} ({2})", action, device.Name, AddressUtils.LongToHex(device.Address)));
				}
			}
			else
			{
				ShowFeedback("Nothing discovered");
			}
		}

		#region Event helpers

		private void ShowFeedback(string text, FeedbackEventType type = FeedbackEventType.Dbg)
		{
			System.Diagnostics.Debug.WriteLine(text);

			Feedback(this, new FeedbackEventArgs(type, text));
		}

		private void FeedbackHandler (object sender, FeedbackEventArgs e)
		{
			ShowFeedback(e.Message, e.FType);
		}

		#endregion

	}

}

