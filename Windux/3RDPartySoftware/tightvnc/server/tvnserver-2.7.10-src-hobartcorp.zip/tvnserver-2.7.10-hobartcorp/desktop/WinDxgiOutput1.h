// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDXGIOUTPUT1_H__
#define __WINDXGIOUTPUT1_H__

#include "region/Rect.h"

#include "WinDxgiOutput.h"

#include <d3d11.h>
#include <DXGI1_2.h>

class WinDxgiOutput1
{
public:
  WinDxgiOutput1(WinDxgiOutput *dxgiOutput);
  WinDxgiOutput1(const WinDxgiOutput1 &src);
  virtual ~WinDxgiOutput1();

  WinDxgiOutput1 &operator = (WinDxgiOutput1 const &src);

  // Return pointer to a IDXGIOutput1 object. The pointer will be valid until
  // this object destructor has been called.
  IDXGIOutput1 *getDxgiOutput1();

private:
  void copy(const WinDxgiOutput1 &src);

  IDXGIOutput1 *m_dxgiOutput1;
};

#endif // __WINDXGIOUTPUT1_H__
