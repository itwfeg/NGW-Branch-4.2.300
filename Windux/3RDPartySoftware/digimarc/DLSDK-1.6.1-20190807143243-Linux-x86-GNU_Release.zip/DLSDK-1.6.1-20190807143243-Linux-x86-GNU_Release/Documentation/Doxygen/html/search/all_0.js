var searchData=
[
  ['basiccompilername',['BasicCompilerName',['../classDigimarcLabelEmbedder_1_1Information.html#a147d5205a8977d293c73e3ddacca6896',1,'DigimarcLabelEmbedder::Information']]],
  ['buildtype',['BuildType',['../classDigimarcLabelEmbedder_1_1Information.html#a5e61d0c8d0aa013344a57c57fb362686',1,'DigimarcLabelEmbedder::Information']]],
  ['bytesperrow',['BytesPerRow',['../structDSM__DATADESC.html#a773b08561a2ce6422ed9deab5b4bd285',1,'DSM_DATADESC']]]
];
