/**
 * Created by collin on 11/12/17.
 */
/* Make a request for the basic data from the machine. */
$.get('info', function (data) {
    console.log(data);
    var metadata = JSON.parse(data);
    console.log('Name is ' + metadata.name);
    $('#device-name-label').text(metadata.name);
    $('#device-type-label').text(metadata.type);
});

var datacard_model = function (name, color) {

    return {
        index: 0,
        chartConfig: {
            type: 'line',
            data: {
                datasets: [{
                    label: name,
                    backgroundColor: color,
                    borderColor: color,
                    lineTension: 0,
                    pointStyle: 'none',
                    pointRadius: 0,
                    data: [],
                    fill: false
                }]
            },
            options: {
                responsive: false,
                title: {
                    display: false,
                    text: 'Data'
                },
                legend: {
                    display: false,
                },
                scales: {
                    xAxes: [{
                        display: false,
                        scaleLabel: {
                            display: false,
                            labelString: 'sample'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: false,
                            labelString: 'Value'
                        }
                    }]
                }
            }
        },
        push: function(datapoint) {
            var length = this.chartConfig.data.datasets[0].data.length;

            this.index = this.index + 1;
            this.chartConfig.data.labels.push(this.index);
            if(length > 60){
                this.chartConfig.data.labels.shift();
                this.chartConfig.data.datasets[0].data.shift();//shift out the oldest data first.
            }
            this.chartConfig.data.datasets[0].data.push(datapoint);
        }
    };
};

var power_datacard = new datacard_model('Power', '#3134c5');
var voltage_datacard = new datacard_model('Voltage', '#3134c5');
var current_datacard = new datacard_model('Current', '#3134c5');
var frequency_datacard = new datacard_model('Frequency', '#3134c5');

window.onload = function () {

    /* setup the charts. */
    var power_chart_ctx = document.getElementById("power-chart").getContext("2d");
    window.powerChart = new Chart(power_chart_ctx, power_datacard.chartConfig);
    power_chart_ctx.height = 200;

    var voltage_chart_ctx = document.getElementById("voltage-chart").getContext("2d");
    window.voltageChart = new Chart(voltage_chart_ctx, voltage_datacard.chartConfig);
    power_chart_ctx.height = 200;

    var current_chart_ctx = document.getElementById("current-chart").getContext("2d");
    window.currentChart = new Chart(current_chart_ctx, current_datacard.chartConfig);
    power_chart_ctx.height = 200;

    var freq_chart_ctx = document.getElementById("freq-chart").getContext("2d");
    window.freqChart = new Chart(freq_chart_ctx, frequency_datacard.chartConfig);
    power_chart_ctx.height = 200;
    // window.powerChart.update(0);


    setInterval(function () {
        console.log('Updating...');

        $.get('/livedata', function (data) {
            var live_data = JSON.parse(data);
            console.log(live_data);
            power_datacard.push(live_data.power);
            current_datacard.push(live_data.current);
            voltage_datacard.push(live_data.voltage);
            frequency_datacard.push(live_data.frequency);

            window.powerChart.update(0);
            $('#power-label').text(live_data.power.toFixed(1));

            window.voltageChart.update(0);
            $('#voltage-label').text(live_data.voltage.toFixed(1));

            window.currentChart.update(0);
            $('#current-label').text(live_data.current.toFixed(1));

            window.freqChart.update(0);
            $('#frequency-label').text(live_data.frequency.toFixed(1));

            if(live_data.inverterOn) {
                $('#label-on').text('Inverter ON');
                $('#badge-on')[0].classList.remove('badge-inactive');
                $('#badge-on')[0].classList.add('badge-success');
            } else {
                $('#label-on').text('Inverter OFF');
                $('#badge-on')[0].classList.remove('badge-success');
                $('#badge-on')[0].classList.add('badge-inactive');
            }

            if(live_data.highTempFault) {
                $('#badge-hightemp')[0].classList.remove('badge-inactive');
                $('#badge-hightemp')[0].classList.add('badge-danger');
            } else {
                $('#badge-hightemp')[0].classList.add('badge-inactive');
                $('#badge-hightemp')[0].classList.remove('badge-danger');
            }

            if(live_data.interlockFault) {
                $('#badge-interlock')[0].classList.remove('badge-inactive');
                $('#badge-interlock')[0].classList.add('badge-danger');
            } else {
                $('#badge-interlock')[0].classList.add('badge-inactive');
                $('#badge-interlock')[0].classList.remove('badge-danger');
            }

            if(live_data.currentFault) {
                $('#badge-current')[0].classList.remove('badge-inactive');
                $('#badge-current')[0].classList.add('badge-danger');
            } else {
                $('#badge-current')[0].classList.add('badge-inactive');
                $('#badge-current')[0].classList.remove('badge-danger');
            }

            if(live_data.overvoltFault) {
                $('#badge-overvolt')[0].classList.remove('badge-inactive');
                $('#badge-overvolt')[0].classList.add('badge-danger');
            } else {
                $('#badge-overvolt')[0].classList.add('badge-inactive');
                $('#badge-overvolt')[0].classList.remove('badge-danger');
            }

            if(live_data.DCBusFault) {
                $('#badge-dcbus')[0].classList.remove('badge-inactive');
                $('#badge-dcbus')[0].classList.add('badge-danger');
            } else {
                $('#badge-dcbus')[0].classList.add('badge-inactive');
                $('#badge-dcbus')[0].classList.remove('badge-danger');
            }
        });
    }, 1000);
};