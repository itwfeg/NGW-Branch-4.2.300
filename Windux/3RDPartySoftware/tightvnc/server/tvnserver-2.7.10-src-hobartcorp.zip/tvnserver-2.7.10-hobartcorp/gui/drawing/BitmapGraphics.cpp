// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "BitmapGraphics.h"

BitmapGraphics::BitmapGraphics(DeviceContext *complatibleDC, int width, int height)
: Graphics(complatibleDC), m_isPainting(false)
{
  m_bitmap = new Bitmap(complatibleDC->m_dc, width, height);
  m_dc = new DeviceContext(complatibleDC);
}

BitmapGraphics::~BitmapGraphics()
{
  delete m_bitmap;
  delete m_dc;
}

Bitmap *BitmapGraphics::getBitmap()
{
  return m_bitmap;
}

void BitmapGraphics::beginPaint()
{
  _ASSERT(!m_isPainting);

  m_isPainting = true;
  m_oldBitmap = m_dc->selectObject(m_bitmap->m_bitmap);
}

void BitmapGraphics::endPaint()
{
  _ASSERT(m_isPainting);

  m_isPainting = false;
  m_dc->selectObject(m_oldBitmap);
}
