var AccountCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded AccountCtrl','account');
  // Preperations

  // Properties

  // Functions
  $scope.savePasswordChange = function() {
    var inputOldPass = $('form#UserChangePasswordForm input#input-old-password'),
        inputNewPass = $('form#UserChangePasswordForm input#input-new-password'),
        inputConfirmPass = $('form#UserChangePasswordForm input#input-confirm-password');

    $('.error').remove();

    if( inputOldPass.val().length === 0 ) {
      inputOldPass.after('<div class="error">Current Password was not provided.</div>');
    } else if ( inputNewPass.val().length === 0 ) {
      inputNewPass.after('<div class="error">New Password  was not provided.</div>');
    } else if ( inputConfirmPass.val().length === 0 ) {
      inputConfirmPass.after('<div class="error">Confirm Password was not provided.</div>');
    } else if ( inputNewPass.val() !== inputConfirmPass.val() ) {
      inputConfirmPass.after('<div class="error">New Password and Confirm Password do not match.</div>');
    } else {
      var params = {
          "old": inputOldPass.val(),
          "password": inputNewPass.val()
      };

      lpApi.securityPasswordChange(params);

      $resultScope = lpApi.go('',$scope);

      var msg, msgType;
      if ($resultScope.securityPasswordChange.success === true) {
        msg = 'Security Password Changed Successfully!';
        msgType = 'success';
      }
      else {
        msg = 'Security Password Not Changed! '+$resultScope.securityPasswordChange.errorMessage;
        msgType = 'error';
      }
      Debug.log(msg,'account');
      $scope.setSystemMsg(msg, msgType);
    }
  };

  // Executions
  $scope.clearSystemMsg();

  $scope.assertAuthentication();

  $scope.menuItemSelect($scope, 'gateway');
};

AccountCtrl.$inject = ['$scope', 'lpApi', '$http'];

AccountCtrl.prototype.ctrlActions = {
  items : [{
    href : '',
    template : ''
  }]
};

AccountCtrl.prototype.mainActions = {
  items : [{
    href : '',
    template : ''
  }]
};

AccountCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};
