var searchData=
[
  ['samplelabelembedder_2ecpp',['SampleLabelEmbedder.cpp',['../SampleLabelEmbedder_8cpp.html',1,'']]],
  ['sell_5fby_5fdate',['SELL_BY_DATE',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39aad4b4eac15396441e9619e23ad51017f',1,'SampleLabelEmbedder.cpp']]]
];
