// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __RFBDISPATCHER_H__
#define __RFBDISPATCHER_H__

#include "thread/Thread.h"
#include "RfbDispatcherListener.h"
#include "util/AnEventListener.h"
#include "win-system/WindowsEvent.h"
#include <map>

class RfbDispatcher : public Thread
{
public:
  RfbDispatcher(RfbInputGate *gate,
                AnEventListener *m_extTerminationListener);
  RfbDispatcher(RfbInputGate *gate,
                WindowsEvent *terminationEvent);

  virtual ~RfbDispatcher();

  void registerNewHandle(UINT32 code, RfbDispatcherListener *listener);

protected:
  virtual void execute();
  void notifyAbTermination();

  RfbInputGate *m_gate;

  std::map<UINT32, RfbDispatcherListener *> m_handlers;

  AnEventListener *m_extTerminationListener;
  WindowsEvent *m_terminationEvent;
};

#endif // __RFBDISPATCHER_H__
