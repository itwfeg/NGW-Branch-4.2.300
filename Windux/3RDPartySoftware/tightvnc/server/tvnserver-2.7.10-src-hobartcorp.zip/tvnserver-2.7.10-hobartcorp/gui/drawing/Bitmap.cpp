// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "Bitmap.h"

Bitmap::Bitmap(int width, int height)
: m_bitmap(NULL)
{
  // Prepare buffer
  int bpp = 32;
  size_t size = width * height * (bpp / 8);
  std::vector<unsigned char> bits(size);
  if (width != 0 && height != 0) {
    memset(&bits.front(), 0, size);
    // Create bitmap handle
    m_bitmap = CreateBitmap(width, height, 1, bpp, &bits.front());
  }
}

Bitmap::Bitmap(HDC dc, int width, int height)
{
  m_bitmap = CreateCompatibleBitmap(dc, width, height);
}

Bitmap::Bitmap(HBITMAP bitmap)
: m_bitmap(bitmap)
{
}

Bitmap::~Bitmap()
{
  if (m_bitmap != NULL) {
    DeleteObject(m_bitmap);
  }
}

int Bitmap::getWidth() const
{
  BITMAP bitmap;
  if (GetObject(m_bitmap, sizeof(BITMAP), &bitmap) == 0) {
    return 0;
  }
  return bitmap.bmWidth;
}

int Bitmap::getHeight() const
{
  BITMAP bitmap;
  if (GetObject(m_bitmap, sizeof(BITMAP), &bitmap) == 0) {
    return 0;
  }
  return bitmap.bmHeight;
}
