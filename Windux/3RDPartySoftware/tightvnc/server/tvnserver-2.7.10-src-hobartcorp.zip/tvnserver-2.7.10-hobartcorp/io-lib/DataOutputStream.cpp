// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "DataOutputStream.h"
#include "util/Utf8StringStorage.h"
#include <vector>

#define GETBYTE(x, n) (((x) >> ((n) * 8)) & 0xFF)

DataOutputStream::DataOutputStream(OutputStream *outputStream)
: m_outStream(outputStream)
{
}

DataOutputStream::~DataOutputStream()
{
}

size_t DataOutputStream::write(const void *buffer, size_t len)
{
  return m_outStream->write(buffer, len);
}

void DataOutputStream::writeFully(const void *buffer, size_t len)
{
  char *typedBuffer = (char *)buffer;
  size_t totalWritten = 0;
  size_t left = len;
  while (totalWritten < len) {
    size_t written = m_outStream->write(typedBuffer + totalWritten, left);
    left -= written;
    totalWritten += written;
  }
}

void DataOutputStream::writeUInt8(UINT8 x)
{
  writeFully((char *)&x, 1);
};

void DataOutputStream::writeUInt16(UINT16 data)
{
  UINT8 buf[2];

  buf[0] = GETBYTE(data, 1);
  buf[1] = GETBYTE(data, 0);

  writeFully((char *)buf, sizeof(buf));
}

void DataOutputStream::writeUInt32(UINT32 data)
{
  UINT8 buf[4];

  buf[0] = GETBYTE(data, 3);
  buf[1] = GETBYTE(data, 2);
  buf[2] = GETBYTE(data, 1);
  buf[3] = GETBYTE(data, 0);

  writeFully((char *)buf, sizeof(buf));
}

void DataOutputStream::writeUInt64(UINT64 data)
{
  UINT8 buf[8];

  buf[0] = GETBYTE(data, 7);
  buf[1] = GETBYTE(data, 6);
  buf[2] = GETBYTE(data, 5);
  buf[3] = GETBYTE(data, 4);
  buf[4] = GETBYTE(data, 3);
  buf[5] = GETBYTE(data, 2);
  buf[6] = GETBYTE(data, 1);
  buf[7] = GETBYTE(data, 0);

  writeFully((char *)buf, sizeof(buf));
}

void DataOutputStream::writeInt8(INT8 x)
{
  writeUInt8((UINT8)x);
}

void DataOutputStream::writeInt16(INT16 x)
{
  writeUInt16((UINT16)x);
}

void DataOutputStream::writeInt32(INT32 x)
{
  writeUInt32((UINT32)x);
}

void DataOutputStream::writeInt64(INT64 x)
{
  writeUInt64((UINT64)x);
}

void DataOutputStream::writeUTF8(const TCHAR *string)
{
  size_t sizeInBytes = 0;

  // to UTF8 string convertion
  Utf8StringStorage utf8String(&StringStorage(string));

  // FIXME: Why try/catch() is used?
  try {
    unsigned int sizeInBytes = (unsigned int)utf8String.getSize();
    _ASSERT(sizeInBytes == utf8String.getSize());
    writeUInt32(sizeInBytes);
    writeFully(utf8String.getString(), sizeInBytes);
  } catch (...) {
    throw;
  }
}

void DataOutputStream::flush()
{
  m_outStream->flush();
}
