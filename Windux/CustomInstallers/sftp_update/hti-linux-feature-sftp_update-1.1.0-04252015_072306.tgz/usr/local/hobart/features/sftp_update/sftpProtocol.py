import os
import traceback
import time

if os.name == 'posix':
    from pexpectScp import ScpClient as scpClient
    import paramiko
else:
    from chilkatScp import ScpClient as scpClient

SCP_EXIT_CODES = {0:'SUCCESS',
                  1:'UNDETERMINED_ERROR',
                  3:'DESTINATION_NOT_DIR',
                  4:'CONNECTION_FAILED',
                  5:'CONNECTION_LOST',
                  6:'FILE_DOESNT_EXIST',
                  7:'NO_PERMISSIONS',
                  8:'SSHFILEXFER_ERROR',
                  9:'PROTOCOL_MISMATCH',
                  255:'SSH_ERROR',
                  }

class SCPError(Exception):
    UNDETERMINED_ERROR = 'Undetermined error occured during SCP: {error}'
    DESTINATION_NOT_DIR = 'SCP Expected a directory, but was given something else: {error}'
    CONNECTION_FAILED = 'SCP could not connect to given host: {error}'
    CONNECTION_LOST = 'SCP lost connection to host during file transfer: {error}'
    FILE_DOESNT_EXIST = 'SCP could not find file specified: {error}'
    NO_PERMISSIONS = 'SCP does not have permissions to do file transfer: {error}'
    SSHFILEXFER_ERROR = 'Error occured during SSH file transfer: {error}'
    PROTOCOL_MISMATCH = 'SSH Protocol mismatch during SCP: {error}'
    SSH_ERROR = 'Unknown error occured during SSH connection: {error}'
    UNKOWN = 'Unknown Error occured during scp: {error}'

    def __init__(self, data):
        self.data = data

    def __str__(self):
        return self.data

    def __repr__(self):
        return 'SCPError(data={data})'.format(data=self.data)


class SFTPClient():
    def __init__(self,  username, password, host):

        # setup logging
        #paramiko.util.log_to_file('sftp_log.log')

        # get self.hostname
        self.username = username
        self.password = password

        #Port constant, only used by paramiko for listdir.
        self.port = 22

        self.hostname = str(host)
        self.scpClient = scpClient(self.hostname, self.username, self.password)


    def connect(self):
                return 'success'

    def disconnect(self):
        pass

    def listFiles(self, dir):
        if os.name == 'posix':
            try:
                transport = paramiko.Transport((self.hostname, self.port))
            except NameError:
                return scpClient.listDir(dir)

            try:
                transport.connect(None, self.username, self.password)
                sftp = paramiko.SFTPClient.from_transport(transport)
            except RuntimeError:
                #Happens if we're already connected to SFTP
                pass
            except Exception as e:
                print '*** Caught exception: %s: %s' % (e.__class__, e)
                traceback.print_exc()
                try:
                    transport.close()
                except:
                    pass
                return "failure"

            dir = sftp.listdir(dir)
            transport.close()
            return dir

        elif os.name == 'nt':
            dirList = []
            dirList = self.scpClient.listFiles(dir)

            return dirList

    def getIpAddress(self):
        return self.hostname

    def wait_and_retry(self, method, server_file_name, local_file_name, num_retries=5):
        for num_retry in xrange(0, num_retries):
            results = method(server_file_name, local_file_name)
            status, data, exit_code = results.split('|')

            if status == 'success' and exit_code == '0':
                return results
            else:
                print 'ERROR: ' + data
                time.sleep(60)

        self._handle_error(exit_code, data)

    def downloadFile(self, serverFileName, localFileName):
        #Get archive ServerFileName and store it in LocalFileName
        results = self.scpClient.downloadFile(serverFileName, localFileName)

        status, data, exitCode = results.split('|')

        if status == 'success' and exitCode == '0':
            return results
        elif 'port 22: Connection timed out' not in data:
            return self.wait_and_retry(self.scpClient.downloadFile, serverFileName, localFileName)
        else:
            self._handle_error(exitCode, data)

    def uploadFile(self, serverFileName, localFileName):
        #Put archive localFileName on server in serverFileName
        results = self.scpClient.uploadFile(serverFileName, localFileName)

        status, data, exitCode = results.split('|')

        if status == 'success' and exitCode == '0':
            return results
        elif 'port 22: Connection timed out' not in data:
            results = self.wait_and_retry(self.scpClient.uploadFile, serverFileName, localFileName)
        else:
            self._handle_error(exitCode, data)

    def _handle_error(self, exitCode, data):
        try:
            exit_code_str = SCP_EXIT_CODES[exitCode]
#
        except KeyError:
            exit_code_str = 'UNKOWN'
#
        try:
            message = getattr(SCPError, exit_code_str)
#
        except AttributeError:
            message = SCPError.UNKOWN
#
        raise SCPError(message.format(error=data))

