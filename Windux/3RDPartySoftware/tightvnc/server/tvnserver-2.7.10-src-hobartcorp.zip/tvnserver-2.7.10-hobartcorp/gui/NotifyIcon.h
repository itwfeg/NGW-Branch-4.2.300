// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _NOTIFY_ICON_H_
#define _NOTIFY_ICON_H_

#include "util/CommonHeader.h"

#include "NotifyIconWindow.h"

#include "gui/drawing/Icon.h"

#include <shellapi.h>

// FIXME: Add documentation to class.
class NotifyIcon : public NotifyIconWindow
{
public:
  NotifyIcon(bool showAfterCreation = true);
  virtual ~NotifyIcon();

  const Icon *getIcon() const;
  bool isVisible() const;

  void setIcon(Icon *icon);
  void setText(const TCHAR *text);

  void showBalloon(const TCHAR *message, const TCHAR *caption, DWORD timeoutMillis);

  void show();
  void hide();

protected:
  NOTIFYICONDATA m_nid;
  Icon *m_icon;
  bool m_visible;
};

#endif
