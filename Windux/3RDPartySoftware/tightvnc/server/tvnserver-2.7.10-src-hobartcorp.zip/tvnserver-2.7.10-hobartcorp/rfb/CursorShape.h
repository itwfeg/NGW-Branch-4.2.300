// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CURSORSHAPE_H__
#define __CURSORSHAPE_H__

#include "FrameBuffer.h"
#include "region/Point.h"

class CursorShape
{
public:
  CursorShape(): m_mask(0) {}
  ~CursorShape();

  bool clone(const CursorShape *srcCursorShape);

  bool setDimension(const Dimension *newDim);
  Dimension getDimension() const { return m_pixels.getDimension(); }

  bool setPixelFormat(const PixelFormat *pixelFormat);
  PixelFormat getPixelFormat() const { return m_pixels.getPixelFormat(); }

  // This function set both PixelFormat and Dimension
  bool setProperties(const Dimension *newDim, const PixelFormat *pixelFormat);

  const FrameBuffer *getPixels() const { return &m_pixels; }
  int getPixelsSize() const { return m_pixels.getBufferSize(); }
  const char *getMask() const { return m_mask.empty() ? 0 : &m_mask.front(); }
  void assignMaskFromRfb(const char *srcMask);
  void assignMaskFromWindows(const char *srcMask);
  int getMaskSize() const;
  int getMaskWidthInBytes() const;

  void setHotSpot(int x, int y) { m_hotSpot.x = x; m_hotSpot.y = y; }
  Point getHotSpot() const { return m_hotSpot; }

  // Resets the cursor shape to empty state (zero dimension and hot spot
  // and empty masks). But the pixel format saves the same.
  void resetToEmpty();

private:
  bool resizeBuffer();

  FrameBuffer m_pixels;
  std::vector<char> m_mask;
  Point m_hotSpot;
};

#endif // __CURSORSHAPE_H__
