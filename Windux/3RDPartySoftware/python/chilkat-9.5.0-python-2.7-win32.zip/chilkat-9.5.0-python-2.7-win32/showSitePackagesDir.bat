
showSitePackagesDir.py

pause

