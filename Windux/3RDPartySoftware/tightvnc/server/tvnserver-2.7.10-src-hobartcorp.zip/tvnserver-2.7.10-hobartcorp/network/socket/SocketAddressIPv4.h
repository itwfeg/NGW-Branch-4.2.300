// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef SOCKET_ADDRESS_IPV4_H
#define SOCKET_ADDRESS_IPV4_H

#include "util/CommonHeader.h"
#include "thread/LocalMutex.h"
#include "SocketException.h"
#include "sockdefs.h"
#include "win-system/WsaStartup.h"

// FIXME: Deprecated method, only for testing of old code.
void getLocalIPAddrString(char *buffer, int buflen);

class SocketAddressIPv4
{
public:
  SocketAddressIPv4();
  SocketAddressIPv4(struct sockaddr_in);
  SocketAddressIPv4(const TCHAR *host, unsigned short port);

  SocketAddressIPv4(const SocketAddressIPv4 &socketAddressIPv4);
  SocketAddressIPv4 &operator=(const SocketAddressIPv4 &socketAddressIPv4);

  socklen_t getAddrLen() const;
  struct sockaddr_in getSockAddr() const;

  // Converts socket address to it's string value (ip address as string).
  void toString(StringStorage *address) const;

  static SocketAddressIPv4 resolve(const TCHAR *host, unsigned short port) throw(SocketException);

protected:
  WsaStartup m_wsaStartup;
  unsigned short m_port;
  struct in_addr m_addr;

  static LocalMutex s_resolveMutex;
};

#endif
