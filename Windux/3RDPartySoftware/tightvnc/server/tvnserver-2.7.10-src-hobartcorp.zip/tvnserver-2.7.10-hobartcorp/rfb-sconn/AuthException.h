// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __AUTHEXCEPTION_H__
#define __AUTHEXCEPTION_H__

#include "util/exception.h"

class AuthException : public Exception
{
public:
  AuthException(const TCHAR *message): Exception(message) {}
  virtual ~AuthException() {}
};

#endif // __AUTHEXCEPTION_H__
