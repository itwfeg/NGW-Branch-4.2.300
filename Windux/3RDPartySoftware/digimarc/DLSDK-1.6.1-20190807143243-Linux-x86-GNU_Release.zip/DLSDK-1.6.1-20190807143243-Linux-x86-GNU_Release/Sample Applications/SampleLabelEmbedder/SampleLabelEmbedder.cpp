/*
 *
 *  DIGIMARC CORPORATION PROPRIETARY INFORMATION
 *  Copyright, Digimarc Corporation.  All Rights Reserved.
 *
 *  This software contains confidential information, including trade secrets,
 *  of Digimarc that is protected by the confidentiality agreement entered into
 *  between you and Digimarc.  It is important that this information be used only
 *  in accordance with your agreement with Digimarc.  Receipt of this software
 *  conveys no license under Digimarc's patent, trademark, trade secret, or
 *  copyright rights.  Use of this software - and the technology detailed therein -
 *  requires a license from Digimarc. The technology embodied in this software is
 *  protected by US and International Patents.
 *
 */

/**
 * @example SampleLabelEmbedder.cpp
 */

#include <fstream>
#include <iostream>
#include <cstring>
#include <cctype>

//! [includes]
#include <dsmsdk.h>
#include <PayloadHelper.h>

#include "optionparser.h"

//! [includes]

// command line options
enum optionIndex
{
	  UNKNOWN
	, HELP
	, INPUT_FILE
	, OUTPUT_FILE
	, IMAGE_TYPE
	, IMAGE_RESOLUTION
	, IMAGE_WIDTH
	, IMAGE_HEIGHT
	, IMAGE_STRIDE
	, PAYLOAD
	, DOT_DENSITY
	, DOT_SIZE
    , DOT_PATTERN
	, WATERMARK_RESOLUTION
	, PAYLOAD_ALIAS
	, IMAGE_BLEND_MODE
	, KEEP_OUT_REGION_1_TOP_LEFT_X
	, KEEP_OUT_REGION_1_TOP_LEFT_Y
	, KEEP_OUT_REGION_1_WIDTH
	, KEEP_OUT_REGION_1_HEIGHT
	, KEEP_OUT_REGION_2_TOP_LEFT_X
	, KEEP_OUT_REGION_2_TOP_LEFT_Y
	, KEEP_OUT_REGION_2_WIDTH
	, KEEP_OUT_REGION_2_HEIGHT

	, PAYLOAD_TYPE
	, SELL_BY_DATE
	, PRICE
	, WEIGHT_IN_POUNDS
	, WEIGHT_IN_KILOGRAMS
	, COUNT
	, EXTRA_DATA_TYPE
	, EXTRA_DATA
    , FILTER_VALUE
    , COMPANY_PREFIX_LENGTH
    , SERIAL_NUMBER
};

// command line usage
const option::Descriptor usage [] =
{
	{ HELP,					0,	"h",	"help",	option::Arg::None,								" -h,	--help\n\tPrint usage and exit.\n"	},
    { PAYLOAD,				0,	"p",	"payload",	option::Arg::Optional,						" -p,	--payload=PAYLOAD (Required)\n\tMust have valid check digit.\n\tFor --payload-type=gtin and --payload-type=sgtin, must be GTIN-14.\n\tFor --payload-type=upce, must be UPC-E.\n\tFor --payload-type=expandedfresh, must be GTIN-13.\n\tFor --payload-type=expandedfreshweightrange2, must be GTIN-13.\n\tFor --payload-type=simpleproductidgtin, must be GTIN-14.\n\tFor --payload-type=simpleproductidupce, must be UPC-E.\n"},
	{ INPUT_FILE,			0,	"i",	"input",	option::Arg::Optional,						" -i,	--input=INPUT\n\tUnmarked INPUT pgm file. \n\tOptional.\n\tIf input image specified, then options width and height are ignored.\n"	},
	{ OUTPUT_FILE,			0,	"o",	"output",	option::Arg::Optional,						" -o,	--output=OUTPUT\n\tMarked OUTPUT pgm or pbm file. \n\t(Default = SampleImageOut.pgm)\n"	},
	{ IMAGE_TYPE,			0,	"t",	"image-type",	option::Arg::Optional,					" -t,	--image-type=[g|i|o]\n\t g: grayscale. i: inverted grayscale. o: one bit per pixel. \n\t(Default = i)\n"	},
	{ IMAGE_RESOLUTION,		0,	"r",	"image-resolution",	option::Arg::PositiveInteger,		" -r,	--image-resolution=RESOLUTION\n\tImage RESOLUTION. \n\t(Default = 203)\n"	},
	{ IMAGE_WIDTH,			0,	"x",	"image-width",	option::Arg::PositiveInteger,			" -x,	--image-width=WIDTH\n\tImage WIDTH. \n\t(Default = 406)\n"	},
	{ IMAGE_HEIGHT,			0,	"y",	"image-height",	option::Arg::PositiveInteger,			" -y,	--image-height=HEIGHT\n\tImage HEIGHT. \n\t(Default = 406)\n"	},
	{ DOT_DENSITY,			0,	"d",	"dot-density",	option::Arg::PositiveInteger,			" -d,	--dot-density=DENSITY\n\tWatermark dot DENSITY. Valid values are in the range of 1 to 100. Recommended value is 35. \n\t(Default = 40)\n"	},
	{ DOT_SIZE,				0,	"z",	"dot-size",	option::Arg::PositiveInteger,				" -z,	--dot-size=SIZE\n\tWatermark dot SIZE. \n\tMust not be larger than the ratio of image resolution and watermark resolution. \n\t(Default = 1)\n"	},
    { DOT_PATTERN,          0,	"c",	"dot-pattern", option::Arg::Optional,                   " -c,	--dot-pattern=[c|h]\n\t c: circular dot pattern. h: checkerboard dot pattern. \n\t(Default = c)\n" },
	{ WATERMARK_RESOLUTION,	0,	"w",	"watermark-resolution",	option::Arg::PositiveInteger,	" -w,	--watermark-resolution=RESOLUTION\n\tWatermark RESOLUTION. Recommended value is 150. \n\t(Default = 75)\n" },
	{ IMAGE_BLEND_MODE,		0,	"b",	"image-blend-mode",	option::Arg::Optional,				" -b,	--image-blend-mode=[o|m|d]\n\t o: overwrite original image. m: merge dots to the original image. d: dilate the original image\n\t(Default = o)\n"	},

	{ KEEP_OUT_REGION_1_TOP_LEFT_X,	0,	"",	"keep-out-region-1-top-left-x",	option::Arg::Optional,			" --keep-out-region-1-top-left-x=X_COORDINATE\n\tX-coordinate of the top left corner of the keep out region 1\n\t(Default = 0)\n"	},
	{ KEEP_OUT_REGION_1_TOP_LEFT_Y,	0,	"",	"keep-out-region-1-top-left-y",	option::Arg::Optional,			" --keep-out-region-1-top-left-y=Y_COORDINATE\n\tY-coordinate of the top left corner of the keep out region 1\n\t(Default = 0)\n"	},
	{ KEEP_OUT_REGION_1_WIDTH,		0,	"",	"keep-out-region-1-width",	option::Arg::Optional,				" --keep-out-region-1-width=WIDTH\n\tWidth of the keep out region 1\n\t(Default = 0)\n"	},
	{ KEEP_OUT_REGION_1_HEIGHT,		0,	"",	"keep-out-region-1-height",	option::Arg::Optional,				" --keep-out-region-1-height=HEIGHT\n\tHeight of the keep out region 1\n\t(Default = 0)\n"	},

	{ KEEP_OUT_REGION_2_TOP_LEFT_X,	0,	"",	"keep-out-region-2-top-left-x",	option::Arg::Optional,			" --keep-out-region-2-top-left-x=X_COORDINATE\n\tX-coordinate of the top left corner of the keep out region 2\n\t(Default = 0)\n"	},
	{ KEEP_OUT_REGION_2_TOP_LEFT_Y,	0,	"",	"keep-out-region-2-top-left-y",	option::Arg::Optional,			" --keep-out-region-2-top-left-y=Y_COORDINATE\n\tY-coordinate of the top left corner of the keep out region 2\n\t(Default = 0)\n"	},
	{ KEEP_OUT_REGION_2_WIDTH,		0,	"",	"keep-out-region-2-width",	option::Arg::Optional,				" --keep-out-region-2-width=WIDTH\n\tWidth of the keep out region 2\n\t(Default = 0)\n"	},
	{ KEEP_OUT_REGION_2_HEIGHT,		0,	"",	"keep-out-region-2-height",	option::Arg::Optional,				" --keep-out-region-2-height=HEIGHT\n\tHeight of the keep out region 2\n\t(Default = 0)\n"	},

    { PAYLOAD_TYPE,			0,	"",		"payload-type",	option::Arg::Optional,					" --payload-type=[gtin|upce|expandedfresh|expandedfreshweightrange2|simpleproductidgtin|simpleproductidupce|sgtin]\n\t(Default = gtin)\n"	},
	{ SELL_BY_DATE,			0,	"",		"sell-by-date",	option::Arg::Optional,					" --sell-by-date=yymmdd\n\tExpandedFresh Sell by Date. Range: January 01, 2016 to May 08, 2106\n\tUse 0 to specified unused (Default = 0)\n"	},
	{ PRICE,				0,	"",		"price",	option::Arg::Optional,						" --price=PRICE\n\tExpanded Fresh Price\n\tRange: 1 to 9999999\n\tFor example, 12345 = 123.45\n\tUse 0 to specified unused (Default = 0)\n"	},
	{ WEIGHT_IN_POUNDS,		0,	"",		"weight-in-pounds",	option::Arg::Optional,				" --weight-in-pounds=WEIGHT\n\tExpanded Fresh Weight\n\tRange: 1 to 22767\n\tFor --payload-type=expandedfresh, three decimal precision. For example, 12345 = 12.345\n\tFor --payload-type=expandedfreshweightrange2, two decimal precision. For example, 12345 = 123.45\n\tDo not specify both pounds and kilograms\n\tUse 0 to specified unused (Default = 0)\n"	},
	{ WEIGHT_IN_KILOGRAMS,	0,	"",		"weight-in-kilograms",	option::Arg::Optional,			" --weight-in-kilograms=WEIGHT\n\tExpanded Fresh Weight\n\tRange: 1 to 22767\n\tFor --payload-type=expandedfresh, three decimal precision. For example, 12345 = 12.345\n\tFor --payload-type=expandedfreshweightrange2, two decimal precision. For example, 12345 = 123.45\n\tDo not specify both pounds and kilograms\n\tUse 0 to specified unused (Default = 0)\n"	},
	{ COUNT,				0,	"",		"count",	option::Arg::Optional,						" --count=COUNT\n\tExpanded Fresh Count\n\tRange: 1 to 99\n\tDo not specify both weight and count\n\tUse 0 to specified unused (Default = 0)\n"		},
	{ EXTRA_DATA_TYPE,		0,	"",		"extra-data-type",	option::Arg::Optional,				" --extra-data-type=TYPE\n\tSimple Product ID Extra Data Type\n\tn for Numeric Extra Data\n\ta for Alpha-Numeric Extra Data\n"	},
	{ EXTRA_DATA,			0,	"",		"extra-data",	option::Arg::Optional,					" --extra-data=DATA\n\tSimple Product ID Extra Data\n\tFor --extra-data-type=n, Valid decimal range of Numeric extra data is 0 to 281474976710655. (Up to 15 decimal digits)\n\tFor --extra-data-type=a, Alpha-Numeric extra data can have up to 8 characters, each taken from the ASCII range spanning from Space (ASCII 32) to '_' (ASCII 95). This includes the numeric digits, all the capital English alphabet characters, and some other punctuation characters. However, leading and trailing spaces (ASCII 32) are not allowed.\n"	},
	{ FILTER_VALUE,			0,	"",		"filter-value",	option::Arg::Optional,					" --filter-value=FILTER_VALUE\n\tSGTIN Filter Value (1 for POS)\n\tRange: 0 to 7\n"   },
    { COMPANY_PREFIX_LENGTH,0,	"",		"company-prefix-length", option::Arg::Optional,			" --company-prefix-length=LENGTH\n\tSGTIN Company Prefix Length\n"	},
    { SERIAL_NUMBER,    	0,	"",		"serial-number", option::Arg::Optional,					" --serial-number=DATA\n\tSGTIN Serial Number\n\tValid decimal range is 0 to 274877906943. (Up to 12 decimal digits)\n"	},
    {0,0,0,0,0,0}
};

bool MyReadImageFromPgmFile(const char* FileName, DSM_UINT32& height, DSM_UINT32& width, DSM_UINT32& stride, unsigned char*& ImgData);
bool MyWriteBlockToPGMFile(const char* Filename, int& height, int& width, int& stride, const unsigned char*&  ImageData);
bool MyReadImageFromPbmFile(const char* FileName, DSM_UINT32& height, DSM_UINT32& width, DSM_UINT32& stride, unsigned char*& ImgData);
bool MyWriteBlockToPbmFile(const char* Filename, int& height, int& width, int& stride, const unsigned char*&  ImageData);
bool MyConvertPayload(const char* PayloadType, const char* Payload, const char* SellbyDate, const char* Price, const char* WeightInPounds, const char* WeightInKiloGrams, const char* Count, const char* extraDataType, const char* extraData, const char* filterValue, const char* companyPrefixLength, const char* serialNumber, char *ConvertedPayloadBuffer);

int main(int argc, char** argv) {

	//! [commandline options]
	// initialize commandline options
	DSM_RESULT res = DSM_OK;
	const char* payload = NULL;
	const char* inputFile = NULL;
	const char* outputFile = "SampleImageOut.pgm";
	const char* outputPBMFile = "SampleImageOut.pbm";
	DSM_DATADESC_TYPE dataDescType = DSM_DATADESC_GRAYSCALE_INV;
	DSM_UINT16 imageResolution = 203;
	DSM_UINT32 imageWidth = imageResolution * 2; // Set the default image width to 2 inches
	DSM_UINT32 imageHeight = imageResolution * 2; // Set the default image height to 2 inches
	DSM_UINT32 imageStride = imageWidth;
	DSM_UINT16 dotDensity = 40;
	DSM_UINT16 dotSize = 1;
    DSM_DOT_PATTERN dotPattern = DSM_DOT_PATTERN_CIRCULAR;
	DSM_UINT16 watermarkResolution = 75;
	DSM_IMAGE_BLEND_MODE imageBlendMode = DSM_IMAGE_BLEND_MODE_OVERWRITE;

	DSM_UINT32 keepOutRegion1TopLeftX = 0;
	DSM_UINT32 keepOutRegion1TopLeftY = 0;
	DSM_UINT32 keepOutRegion1Width = 0;
	DSM_UINT32 keepOutRegion1Height = 0;

	DSM_UINT32 keepOutRegion2TopLeftX = 0;
	DSM_UINT32 keepOutRegion2TopLeftY = 0;
	DSM_UINT32 keepOutRegion2Width = 0;
	DSM_UINT32 keepOutRegion2Height = 0;

	const char* payloadType = NULL;
	const char* sellByDate = NULL;
	const char* price = NULL;
	const char* weightInPounds = NULL;
	const char* weightInKilograms = NULL;
	const char* count = NULL;
	const char* extraDataType = NULL;
	const char* extraData = NULL;
    const char* filterValue = NULL;
    const char* companyPrefixLength = NULL;
    const char* serialNumber = NULL;

	char convertedPayload[MAX_PAYLOAD_OUT_BUFFER] = {'\0'};

	// parse command line arguments
	// skip program name argv[0] if present
	char* programName = argv[0];
	argc-=(argc>0);
	argv+=(argc>0);

	option::Option* options = NULL;
	option::Option* buffer = NULL;
	option::Stats stats(false, usage, argc, argv, 0, false);

	// initialize options
	options = new (std::nothrow) option::Option[stats.options_max];
	if (options == NULL)
	{
		printf("Error: stats.option_max=%d\n", stats.options_max);
		printf("Error: memory allocation for options failed\n");
		res = DSM_MEMORY_ERROR;
		return res;
	}

	// initialize options buffer
	buffer = new (std::nothrow) option::Option[stats.buffer_max];
	if (buffer == NULL)
	{
		printf("Error: stats.buffer_max=%d\n", stats.buffer_max);
		printf("Error: memory allocation for options buffer failed\n");
		res = DSM_MEMORY_ERROR;
		return res;
	}

	// parse options
	option::Parser parse(usage, argc, argv, options, buffer);

	// print usage
	if (parse.error() || options[HELP] || argc == 0)
	{
		printf("\nUsage: %s [options]\n\nOptions:\n", programName);
		option::printUsage(std::cerr, usage);
		printf("Examples:\n\n");
		printf("%s -p12345678901231\n", programName);
		printf("%s -p12345678901231 -to\n", programName);
		printf("%s -p08525960043024 -ooutput.pgm -tg -r203 -x203 -y203 -d35 -z1 -w150 -bo\n", programName);
		printf("%s -p08525960043024 -ooutput.pgm -tg -r305 -x305 -y305 -d35 -z2 -w150 -bo\n", programName);
		printf("%s -p12345678901231 -iinput.pgm -ooutput.pgm -bd\n", programName);
		printf("%s -p1234567890128 --payload-type=expandedfresh --sell-by-date=181231 --price=12345 --count=98\n", programName);
		printf("%s -p1234567890128 --payload-type=expandedfreshweightrange2 --sell-by-date=181231 --price=7654321 --weight-in-pounds=12345\n", programName);
		printf("%s -p12345678901231 --payload-type=simpleproductidgtin --extra-data-type=n --extra-data=123456789\n", programName);
		printf("%s -p00012386 --payload-type=simpleproductidupce --extra-data-type=a --extra-data=PID3677\n", programName);
        printf("%s -p12345678901231 --payload-type=sgtin --filter-value=1 --company-prefix-length=9 --serial-number=274877906943\n", programName);
		printf("%s -p12345678901231 --keep-out-region-1-top-left-x=250 --keep-out-region-1-top-left-y=350 --keep-out-region-1-width=200 --keep-out-region-1-height=300\n", programName);
		res = DSM_OK;
		return res;
	}

	// -p, --payload
	if (options[PAYLOAD] && options[PAYLOAD].arg)
	{
		payload = options[PAYLOAD].arg;
		printf("--payload=%s\n", payload);
	}
	else
	{
		res = DSM_INVALID_ARGUMENT;
		printf("Payload is required\n");
		return res;
	}

	// -i, --input
	if (options[INPUT_FILE] && options[INPUT_FILE].arg)
	{
		inputFile = options[INPUT_FILE].arg;
	}
	printf("--input=%s\n", inputFile);

	// -o, --output
	if (options[OUTPUT_FILE] && options[OUTPUT_FILE].arg)
	{
		outputFile = options[OUTPUT_FILE].arg;
		outputPBMFile = options[OUTPUT_FILE].arg;
	}
	printf("--output=%s\n", outputFile);

	// -t, --image-type
	if (options[IMAGE_TYPE] && options[IMAGE_TYPE].arg)
	{
		printf("--image-type=%s\n", options[IMAGE_TYPE].arg);
		if (strcmp(options[IMAGE_TYPE].arg, "g") == 0)
		{
			dataDescType = DSM_DATADESC_GRAYSCALE;
		}
		else if(strcmp(options[IMAGE_TYPE].arg, "i") == 0)
		{
			dataDescType = DSM_DATADESC_GRAYSCALE_INV;;
		}
		else if(strcmp(options[IMAGE_TYPE].arg, "o") == 0)
		{
			dataDescType = DSM_DATADESC_ONE_BPP;
		}
		else
		{
			printf("Error: Invalid image type\n");
			res = DSM_INVALID_DATA_DESC;
			return res;
		}
	}
	printf("dataDescType=%d\n", dataDescType);

	// -r, --image-resolution
	if (options[IMAGE_RESOLUTION] && options[IMAGE_RESOLUTION].arg)
	{
		imageResolution = strtol(options[IMAGE_RESOLUTION].arg, NULL, 0);
	}
	printf("--image-resolution=%d\n", imageResolution);

	// -x, --image-width
	if (options[IMAGE_WIDTH] && options[IMAGE_WIDTH].arg)
	{
		imageWidth = strtol(options[IMAGE_WIDTH].arg, NULL, 0);
	}
	printf("--image-width=%d\n", imageWidth);

	// -y, --image-height
	if (options[IMAGE_HEIGHT] && options[IMAGE_HEIGHT].arg)
	{
		imageHeight = strtol(options[IMAGE_HEIGHT].arg, NULL, 0);
	}
	printf("--image-height=%d\n", imageHeight);

	// image stride
	// For pgm file, image stride = image width
	// For pbm file, image stride is padded to full byte and image stride = (image width + 7 ) / 8
	// For other image format, image stride may be different, depending on padding, and other factors.
	if (dataDescType == DSM_DATADESC_ONE_BPP)
	{
		imageStride = (imageWidth + 7) / 8;
	}
	else
	{
		imageStride = imageWidth;
	}
	printf("image stride=%d\n", imageStride);

	// -d, --dot-density
	if (options[DOT_DENSITY] && options[DOT_DENSITY].arg)
	{
		dotDensity = strtol(options[DOT_DENSITY].arg, NULL, 0);
	}
	printf("--dot-density=%d\n", dotDensity);

	// -z, --dot-size
	if (options[DOT_SIZE] && options[DOT_SIZE].arg)
	{
		dotSize = strtol(options[DOT_SIZE].arg, NULL, 0);
	}
	printf("--dot-size=%d\n", dotSize);

    // -c, --dot-pattern
    if (options[DOT_PATTERN] && options[DOT_PATTERN].arg)
    {
        printf("--dot-pattern=%s\n", options[DOT_PATTERN].arg);
        if (strcmp(options[DOT_PATTERN].arg, "c") == 0)
        {
            dotPattern = DSM_DOT_PATTERN_CIRCULAR;
        }
        else if(strcmp(options[DOT_PATTERN].arg, "h") == 0)
        {
            dotPattern = DSM_DOT_PATTERN_CHECKERBOARD;
        }
        else
        {
            printf("Error: Invalid dot pattern\n");
            res = DSM_INVALID_ARGUMENT;
            return res;
        }
    }
    printf("dotPattern=%d\n", dotPattern);

	// -w, --watermark-resolution
	if (options[WATERMARK_RESOLUTION] && options[WATERMARK_RESOLUTION].arg)
	{
		watermarkResolution = strtol(options[WATERMARK_RESOLUTION].arg, NULL, 0);
	}
	printf("--watermark-resolution=%d\n", watermarkResolution);

	// -b, --image-blend-mode
	if (options[IMAGE_BLEND_MODE] && options[IMAGE_BLEND_MODE].arg)
	{
		printf("--image-blend-mode=%s\n", options[IMAGE_BLEND_MODE].arg);
		if (strcmp(options[IMAGE_BLEND_MODE].arg, "o") == 0)
		{
			imageBlendMode = DSM_IMAGE_BLEND_MODE_OVERWRITE;
		}
		else if(strcmp(options[IMAGE_BLEND_MODE].arg, "m") == 0)
		{
			imageBlendMode = DSM_IMAGE_BLEND_MODE_MERGE;
		}
		else if(strcmp(options[IMAGE_BLEND_MODE].arg, "d") == 0)
		{
			imageBlendMode = DSM_IMAGE_BLEND_MODE_DILATE;
		}
		else
		{
			printf("Error: Invalid image blend mode\n");
			res = DSM_INVALID_ARGUMENT;
			return res;
		}
	}
	printf("imageBlendMode=%d\n", imageBlendMode);

	// --keep-out-region-1-top-left-x
	if (options[KEEP_OUT_REGION_1_TOP_LEFT_X] && options[KEEP_OUT_REGION_1_TOP_LEFT_X].arg)
	{
		keepOutRegion1TopLeftX = strtol(options[KEEP_OUT_REGION_1_TOP_LEFT_X].arg, NULL, 0);
	}
	printf("--keep-out-region-1-top-left-x=%d\n", keepOutRegion1TopLeftX);

	// --keep-out-region-1-top-left-y
	if (options[KEEP_OUT_REGION_1_TOP_LEFT_Y] && options[KEEP_OUT_REGION_1_TOP_LEFT_Y].arg)
	{
		keepOutRegion1TopLeftY = strtol(options[KEEP_OUT_REGION_1_TOP_LEFT_Y].arg, NULL, 0);
	}
	printf("--keep-out-region-1-top-left-y=%d\n", keepOutRegion1TopLeftY);

	// --keep-out-region-1-width
	if (options[KEEP_OUT_REGION_1_WIDTH] && options[KEEP_OUT_REGION_1_WIDTH].arg)
	{
		keepOutRegion1Width = strtol(options[KEEP_OUT_REGION_1_WIDTH].arg, NULL, 0);
	}
	printf("--keep-out-region-1-width=%d\n", keepOutRegion1Width);

	// --keep-out-region-height
	if (options[KEEP_OUT_REGION_1_HEIGHT] && options[KEEP_OUT_REGION_1_HEIGHT].arg)
	{
		keepOutRegion1Height = strtol(options[KEEP_OUT_REGION_1_HEIGHT].arg, NULL, 0);
	}
	printf("--keep-out-region-1-height=%d\n", keepOutRegion1Height);

	// --keep-out-region-2-top-left-x
	if (options[KEEP_OUT_REGION_2_TOP_LEFT_X] && options[KEEP_OUT_REGION_2_TOP_LEFT_X].arg)
	{
		keepOutRegion2TopLeftX = strtol(options[KEEP_OUT_REGION_2_TOP_LEFT_X].arg, NULL, 0);
	}
	printf("--keep-out-region-2-top-left-x=%d\n", keepOutRegion2TopLeftX);

	// --keep-out-region-2-top-left-y
	if (options[KEEP_OUT_REGION_2_TOP_LEFT_Y] && options[KEEP_OUT_REGION_2_TOP_LEFT_Y].arg)
	{
		keepOutRegion2TopLeftY = strtol(options[KEEP_OUT_REGION_2_TOP_LEFT_Y].arg, NULL, 0);
	}
	printf("--keep-out-region-2-top-left-y=%d\n", keepOutRegion2TopLeftY);

	// --keep-out-region-2-width
	if (options[KEEP_OUT_REGION_2_WIDTH] && options[KEEP_OUT_REGION_2_WIDTH].arg)
	{
		keepOutRegion2Width = strtol(options[KEEP_OUT_REGION_2_WIDTH].arg, NULL, 0);
	}
	printf("--keep-out-region-2-width=%d\n", keepOutRegion2Width);

	// --keep-out-region-2-height
	if (options[KEEP_OUT_REGION_2_HEIGHT] && options[KEEP_OUT_REGION_2_HEIGHT].arg)
	{
		keepOutRegion2Height = strtol(options[KEEP_OUT_REGION_2_HEIGHT].arg, NULL, 0);
	}
	printf("--keep-out-region-2-height=%d\n", keepOutRegion2Height);

	// --payload-type
	if (options[PAYLOAD_TYPE] && options[PAYLOAD_TYPE].arg)
	{
		printf("--payload-type=%s\n", options[PAYLOAD_TYPE].arg);
		if ((strcmp(options[PAYLOAD_TYPE].arg, "gtin") != 0)
			&& (strcmp(options[PAYLOAD_TYPE].arg, "upce") != 0)
			&& (strcmp(options[PAYLOAD_TYPE].arg, "expandedfresh") != 0)
			&& (strcmp(options[PAYLOAD_TYPE].arg, "expandedfreshweightrange2") != 0)
			&& (strcmp(options[PAYLOAD_TYPE].arg, "simpleproductidgtin") != 0)
            && (strcmp(options[PAYLOAD_TYPE].arg, "simpleproductidupce") != 0)
            && (strcmp(options[PAYLOAD_TYPE].arg, "sgtin") != 0))
		{
			printf("Error: Invalid payload type\n");
			res = DSM_INVALID_ARGUMENT;
			return res;
		}
		payloadType = options[PAYLOAD_TYPE].arg;
	}

	// --sell-by-date
	if (options[SELL_BY_DATE] && options[SELL_BY_DATE].arg)
	{
		sellByDate = options[SELL_BY_DATE].arg;
		printf("--sell-by-date=%s\n", sellByDate);
	}

	// --price
	if (options[PRICE] && options[PRICE].arg)
	{
		price = options[PRICE].arg;
		printf("--price=%s\n", price);
	}

	// --weight-in-pounds
	if (options[WEIGHT_IN_POUNDS] && options[WEIGHT_IN_POUNDS].arg)
	{
		weightInPounds = options[WEIGHT_IN_POUNDS].arg;
		printf("--weight-in-pounds=%s\n", weightInPounds);
	}

	// --weight-in-kilograms
	if (options[WEIGHT_IN_KILOGRAMS] && options[WEIGHT_IN_KILOGRAMS].arg)
	{
		weightInKilograms= options[WEIGHT_IN_KILOGRAMS].arg;
		printf("--weight-in-kilograms=%s\n", weightInKilograms);
	}

	// --count
	if (options[COUNT] && options[COUNT].arg)
	{
		count = options[COUNT].arg;
		printf("--count=%s\n", count);
	}

	// --extra-data-type
	if (options[EXTRA_DATA_TYPE] && options[EXTRA_DATA_TYPE].arg)
	{
		printf("--extra-data-type=%s\n", options[EXTRA_DATA_TYPE].arg);
		if (strcmp(options[EXTRA_DATA_TYPE].arg, "n") == 0)
		{
			extraDataType = "0"; // Numeric extra data
		}
		else if(strcmp(options[EXTRA_DATA_TYPE].arg, "a") == 0)
		{
			extraDataType = "1"; // Alpha-numeric extra data
		}
	}

	// --extra-data
	if (options[EXTRA_DATA] && options[EXTRA_DATA].arg)
	{
		extraData = options[EXTRA_DATA].arg;
		printf("--extra-data=%s\n", extraData);
	}

    // --filter-value
    if (options[FILTER_VALUE] && options[FILTER_VALUE].arg)
    {
        filterValue = options[FILTER_VALUE].arg;
        printf("--filter-value=%s\n", filterValue);
    }

    // --company-prefix-length
    if (options[COMPANY_PREFIX_LENGTH] && options[COMPANY_PREFIX_LENGTH].arg)
    {
        companyPrefixLength = options[COMPANY_PREFIX_LENGTH].arg;
        printf("--company-prefix-length=%s\n", companyPrefixLength);
    }

    // --serial-number
    if (options[SERIAL_NUMBER] && options[SERIAL_NUMBER].arg)
    {
        serialNumber = options[SERIAL_NUMBER].arg;
        printf("--serial-number=%s\n", serialNumber);
    }

	//! [commandline options]

	// Pointer to a buffer that holds the watermark image data
	unsigned char* imageData = NULL;

	// If input file is specifed, read the input file
	if (inputFile != NULL )
	{
		bool readImageSuccessfully = false;

		if (dataDescType == DSM_DATADESC_ONE_BPP)
		{
			readImageSuccessfully = MyReadImageFromPbmFile(inputFile, imageHeight, imageWidth, imageStride, imageData);
		}
		else
		{
			readImageSuccessfully = MyReadImageFromPgmFile(inputFile, imageHeight, imageWidth, imageStride, imageData);
		}

		if(readImageSuccessfully)
		{
			printf("Read input image successful\n");
			printf("Use actual input image width and height\n");
			printf("--image-width=%d\n", imageWidth);
			printf("--image-Height=%d\n", imageHeight);
			printf("--image-stride=%d\n", imageStride);
		}
		else
		{
			printf("Error: read input image unsuccessful\n");
			res = DSM_INVALID_ARGUMENT;
			return res;
		}
	}
	else // create an image buffer for the watermark
	{
		imageData = new (std::nothrow) unsigned char[imageStride * imageHeight];
		if (imageData == NULL)
		{
			printf("Error: image buffer allocation failed.\n");
			res = DSM_MEMORY_ERROR;
			return res;
        }
        else
        {
            // Initializing memory based on the image type
            switch (dataDescType) {
            case DSM_DATADESC_GRAYSCALE:     memset(imageData, 0, imageStride * imageHeight);
                                             break;
            case DSM_DATADESC_GRAYSCALE_INV: memset(imageData, 255, imageStride * imageHeight);
                                             break;
            case DSM_DATADESC_ONE_BPP:       memset(imageData, 255, imageStride * imageHeight);
                                             break;
            default:                         memset(imageData, 0, imageStride * imageHeight);
                                             break;
            }

        }
	}

	//! [creation]
	// Create the primary SDK objects
	DSM_RESULT sdkResult = DSM_OK;
	DSM_DATADESC sdkImageDesc;
	DSM_EMBEDDER_OPTIONS sdkEmbedderOptions;

	// Initialize Embedder Options to default values
	res = DSM_InitializeEmbedderOptions(&sdkEmbedderOptions);
	if (res != DSM_OK)
	{
		printf("Error: DSM_InitializeEmbedderOptions() = %d.\n", res);
		return res;
	}

	// Assign user specified commandline options to image descriptions
	sdkImageDesc.BytesPerRow = imageStride;
	sdkImageDesc.DataDescType = dataDescType;
	sdkImageDesc.Height = imageHeight;
	sdkImageDesc.pData = imageData;
	sdkImageDesc.Resolution = imageResolution;
	sdkImageDesc.Width = imageWidth;

	// Assign user specified commandline options to embedder options
	sdkEmbedderOptions.nDotDensity = dotDensity;
	sdkEmbedderOptions.nDotSize = dotSize;
    sdkEmbedderOptions.eDotPattern = dotPattern;
	sdkEmbedderOptions.nWatermarkRes = watermarkResolution;
	sdkEmbedderOptions.eImageBlendMode = imageBlendMode;

	// Set keep out regions
	sdkEmbedderOptions.nNumKeepOutRegions = 2;
	sdkEmbedderOptions.pKeepOutRegionArray = new (std::nothrow) DSM_KEEP_OUT_REGION[sdkEmbedderOptions.nNumKeepOutRegions];
	if (sdkEmbedderOptions.pKeepOutRegionArray == 0)
	{
		sdkEmbedderOptions.nNumKeepOutRegions = 0;
		printf("Error: keep out region memory allocation failed.\n");
		res = DSM_MEMORY_ERROR;
		return res;
	}

		sdkEmbedderOptions.pKeepOutRegionArray[0].TopLeftX = keepOutRegion1TopLeftX;
		sdkEmbedderOptions.pKeepOutRegionArray[0].TopLeftY = keepOutRegion1TopLeftY;
		sdkEmbedderOptions.pKeepOutRegionArray[0].Width = keepOutRegion1Width;
		sdkEmbedderOptions.pKeepOutRegionArray[0].Height = keepOutRegion1Height;

		sdkEmbedderOptions.pKeepOutRegionArray[1].TopLeftX = keepOutRegion2TopLeftX;
		sdkEmbedderOptions.pKeepOutRegionArray[1].TopLeftY = keepOutRegion2TopLeftY;
		sdkEmbedderOptions.pKeepOutRegionArray[1].Width = keepOutRegion2Width;
		sdkEmbedderOptions.pKeepOutRegionArray[1].Height = keepOutRegion2Height;

	bool payloadConversionSuccessful = MyConvertPayload(payloadType
                                                        , payload
                                                        , sellByDate
                                                        , price
                                                        , weightInPounds
                                                        , weightInKilograms
                                                        , count
                                                        , extraDataType
                                                        , extraData
                                                        , filterValue
                                                        , companyPrefixLength
                                                        , serialNumber
                                                        , convertedPayload);

	if(payloadConversionSuccessful) {
		sdkEmbedderOptions.pPayload = convertedPayload;
	} else {
		printf("Error: Failed to convert provided payload and alias. Please check that the values are correct.\n");
		return(1);
	}

	// SDK handle
	DSM_API hSDKHandle = NULL;
	sdkResult = DSM_Open(&hSDKHandle);
	if (sdkResult == DSM_OK)
	{
		// DSM_API handle was initialized.  DSM_Close() should be called later on.
		printf("DSM_Open() = %d\n", sdkResult);
	}
	else
	{
		// DSM_API handle was NOT initialized and was instead set to NULL.  DSM_Close() should NOT be called.
		printf("Error: DSM_Open() = %d\n", sdkResult);
		return(sdkResult);
	}
	//! [creation]

	// Embed watermark
	printf("Calling DSM_EmbedSparseMark()\n");
	sdkResult = DSM_EmbedSparseMark(hSDKHandle, &sdkImageDesc, &sdkEmbedderOptions);

	// Check whether watermark is generated successfully
	printf("DSM_EmbedSparseMark() = %d\n", sdkResult);
	switch (sdkResult)
	{
		case DSM_OK:
			printf("Success\n");
			break;
		case DSM_INVALID_HANDLE:
			printf("Error: Invalid handle\n");
			break;
		case DSM_INVALID_ARGUMENT:
			printf("Error: Invalid argument\n");
			break;
		case DSM_IMAGE_RESOLUTION_OUT_OF_RANGE:
			printf("Erorr: Image resolution out of range\n");
			break;
		case DSM_WATERMARK_RESOLUTION_OUT_OF_RANGE:
			printf("Error: Watermark resolution out of range\n");
			break;
		case DSM_PAYLOAD_OUT_OF_RANGE:
			printf("Error: Payload out of range\n");
			break;
		case DSM_INVALID_DATA_DESC:
			printf("Error: Invalid data description\n");
			break;
		case DSM_MEMORY_ERROR:
			printf("Error: Memory error\n");
			break;
		case DSM_INTERNAL_ERROR:
			printf("Error: Internal error\n");
			break;
		default:
			printf("Error: Unknown error\n");
			break;
	}


	// If embed is successful,
	// then write the output image
	if (sdkResult == DSM_OK)
	{
		bool writeImageSuccessfully = false;

		if (dataDescType == DSM_DATADESC_ONE_BPP)
		{
			writeImageSuccessfully = MyWriteBlockToPbmFile(outputPBMFile, (int&)imageHeight, (int&)imageWidth, (int&)imageStride, (const unsigned char *&)imageData);
		}
		else
		{
			writeImageSuccessfully = MyWriteBlockToPGMFile(outputFile, (int&)imageHeight, (int&)imageWidth, (int&)imageStride, (const unsigned char *&)imageData);
		}
		if(writeImageSuccessfully)
		{
			printf("Write output image successful\n");
		}
		else
		{
			printf("Error: write output image unsuccessful\n");
		}
	}

	// Clean up
	delete[] imageData;
	imageData = NULL;

	if (sdkEmbedderOptions.pKeepOutRegionArray != 0 )
	{
		delete[] sdkEmbedderOptions.pKeepOutRegionArray;
		sdkEmbedderOptions.pKeepOutRegionArray = 0;
		sdkEmbedderOptions.nNumKeepOutRegions = 0;
	}

	// Close DSMSDK
	sdkResult = DSM_Close(&hSDKHandle);
	if (sdkResult == DSM_OK)
	{
		// DSM_API handle has been released and was set to NULL
		printf("DSM_Close() = %d\n", sdkResult);
	}
	else
	{
		// DSM_API handle has NOT been released and was probably invalid.
		printf("Error: DSM_Close() = %d\n", sdkResult);
	}

	// delete options
	delete [] options;
	options = NULL;

	// delete options buffer
	delete [] buffer;
	buffer = NULL;

	return(sdkResult);
}

bool MyReadImageFromPgmFile(const char* FileName, DSM_UINT32& height, DSM_UINT32& width, DSM_UINT32& stride, unsigned char*& ImgData) {
	if (FileName == NULL) {
		return(false);
	}

	std::ifstream pgmFile(FileName, std::ios_base::in | std::ios_base::binary);
	if (!pgmFile.is_open()) {
		return(false);
	}

	enum PPMParsing {
		PPM_HEADER,
		PPM_WIDTH, PPM_HEIGHT, PPM_MAX,
		PPM_RASTER,
		PPM_DONE,
		PPM_ERROR
	};

	// indicates the current file parsing objective
	PPMParsing state = PPM_HEADER;

	char header1('\n');
	char header2('\n');
	unsigned int maxValue(0);
	height = 0;
	width = 0;
	stride = 0;

	while (state != PPM_DONE && state != PPM_ERROR) {
		if (state != PPM_RASTER) {
			while (std::iscntrl(pgmFile.peek()) || std::isspace(pgmFile.peek())) {
				// discard whitespace
				pgmFile.ignore();
			}
			if (pgmFile.peek() == '#') {
				while (std::isprint(pgmFile.peek())) {
					// discard comment lines
					pgmFile.ignore();
				}
			}
		}
		if (pgmFile.fail()) {
			state = PPM_ERROR;
		}

		switch (state) {
			case PPM_HEADER:
				pgmFile >> header1 >> header2;
				state = PPM_ERROR;
				if (pgmFile.fail() == false) {
					if ((header1 == 'P') && ((header2 == '5') || (header2 == '6'))) {
						state = PPM_WIDTH;
					}
				}
				break;
			case PPM_WIDTH:
				pgmFile >> width;
				state = PPM_ERROR;
				if (pgmFile.fail() == false) {
					state = PPM_HEIGHT;
				}
				break;
			case PPM_HEIGHT:
				pgmFile >> height;
				state = PPM_ERROR;
				if (pgmFile.fail() == false) {
					state = PPM_MAX;
				}
				break;
			case PPM_MAX:
				pgmFile >> maxValue;
				state = PPM_ERROR;
				if (pgmFile.fail() == false) {
					state = PPM_RASTER;
				}
				break;
			case PPM_RASTER:
				switch (header2)
				{
					case '6':
						stride = 3 * width;			// assume RGB
						break;
					case '5':
					default:
						stride = width;
						break;
				}

				state = PPM_ERROR;
				ImgData = new unsigned char[stride * height];
				if (ImgData != NULL) {
					if (std::isspace(pgmFile.peek())) {
						// discard exactly one whitespace character
						pgmFile.ignore();
					}
					pgmFile.read((char*)(ImgData), stride * height);
					if (pgmFile.fail() == false) {
						state = PPM_DONE;
					}
				}
				break;
			default:
				state = PPM_ERROR;
				break;
		}
	}
	pgmFile.close();

	return(state == PPM_DONE);
}

bool MyWriteBlockToPGMFile(const char* Filename, int& height, int& width, int& stride, const unsigned char*& ImageData)
{
	std::ofstream pgmFile(Filename, std::ios_base::out | std::ios_base::binary);

	if (!pgmFile.is_open()) {
		return(false);
	}

	pgmFile << "P5" << std::endl;
	pgmFile << width << " " << height << std::endl;
	pgmFile << "255" << std::endl;

	for (int row = 0; row < height; row++) {
		pgmFile.write(reinterpret_cast<const char*>(ImageData + row * stride), width);
	}

	pgmFile.close();

	return(true);
}

bool MyReadImageFromPbmFile(const char* FileName, DSM_UINT32& height, DSM_UINT32& width, DSM_UINT32& stride, unsigned char*& ImgData) {
	if (FileName == NULL) {
		return(false);
	}

	std::ifstream pbmFile(FileName, std::ios_base::in | std::ios_base::binary);
	if (!pbmFile.is_open()) {
		return(false);
	}

	enum PPMParsing {
		PPM_HEADER,
		PPM_WIDTH, PPM_HEIGHT, PPM_MAX,
		PPM_RASTER,
		PPM_DONE,
		PPM_ERROR
	};

	// indicates the current file parsing objective
	PPMParsing state = PPM_HEADER;

	char header1('\n');
	char header2('\n');
	unsigned int maxValue(0);
	height = 0;
	width = 0;
	stride = 0;

	while (state != PPM_DONE && state != PPM_ERROR) {
		if (state != PPM_RASTER) {
			while (std::iscntrl(pbmFile.peek()) || std::isspace(pbmFile.peek())) {
				// discard whitespace
				pbmFile.ignore();
			}
			if (pbmFile.peek() == '#') {
				while (std::isprint(pbmFile.peek())) {
					// discard comment lines
					pbmFile.ignore();
				}
			}
		}
		if (pbmFile.fail()) {
			state = PPM_ERROR;
		}

		switch (state) {
			case PPM_HEADER:
				pbmFile >> header1 >> header2;
				state = PPM_ERROR;
				if (pbmFile.fail() == false) {
					if ((header1 == 'P') && ((header2 == '4'))) {
						state = PPM_WIDTH;
					}
				}
				break;
			case PPM_WIDTH:
				pbmFile >> width;
				state = PPM_ERROR;
				if (pbmFile.fail() == false) {
					state = PPM_HEIGHT;
				}
				break;
			case PPM_HEIGHT:
				pbmFile >> height;
				state = PPM_ERROR;
				if (pbmFile.fail() == false) {
					state = PPM_RASTER;
				}
				break;
			case PPM_RASTER:
				switch (header2)
				{
					case '4':
					default:
						stride = (width + 7 ) / 8;
						break;
				}

				state = PPM_ERROR;
				ImgData = new unsigned char[stride * height];
				if (ImgData != NULL) {
					if (std::isspace(pbmFile.peek())) {
						// discard exactly one whitespace character
						pbmFile.ignore();
					}
					pbmFile.read((char*)(ImgData), stride * height);
					if (pbmFile.fail() == false) {
						state = PPM_DONE;
					}
				}
				break;
			default:
				state = PPM_ERROR;
				break;
		}
	}
	pbmFile.close();

	// PBM file format uses 0 == white and 1 == black
	// We want 0 == black and 1 == white
	// So flip the bits
	for ( unsigned int i = 0; i < stride * height; ++i )
	{
		ImgData[i] = ~ImgData[i];
	}

	return(state == PPM_DONE);
}

bool MyWriteBlockToPbmFile(const char* Filename, int& height, int& width, int& stride, const unsigned char*& ImageData)
{
	std::ofstream pbmFile(Filename, std::ios_base::out | std::ios_base::binary);

	if (!pbmFile.is_open()) {
		return(false);
	}

	pbmFile << "P4" << std::endl;
	pbmFile << width << " " << height << std::endl;

	for (int row = 0; row < height; row++) {
		for (int col = 0; col < stride; col++)
		{
			// pbm file pixel value is opposite of most other file format
			// 0 means white and 1 means black
			// So flip the bits before write out the byte
			pbmFile.put((const char)(~(ImageData[row * stride + col])));
		}
	}

	pbmFile.close();

	return(true);
}

bool MyConvertPayload(const char* PayloadType
					  , const char* Payload
					  , const char* SellbyDate
					  , const char* Price
					  , const char* WeightInPounds
					  , const char* WeightInKiloGrams
					  , const char* Count
					  , const char* extraDataType
					  , const char* extraData
                      , const char* filterValue
                      , const char* companyPrefixLength
                      , const char* serialNumber
					  , char *ConvertedPayloadBuffer) {
	bool result = false;
	char resultBuffer[MAX_PAYLOAD_OUT_BUFFER] = {'\0'};

	if(Payload[0] == '{') {
		strcpy(ConvertedPayloadBuffer, Payload);
		result = true;
	} else if ((PayloadType == NULL) || (strcmp(PayloadType, "gtin") == 0)) {
		DSM_RESULT payloadHelperResult = DSM_GetGtinJson(Payload, resultBuffer);

		if(payloadHelperResult == DSM_OK) {
			strncpy(ConvertedPayloadBuffer, resultBuffer, 256);
			result = true;
		}
    } else if ( strcmp(PayloadType, "sgtin") == 0) {
        DSM_RESULT payloadHelperResult = DSM_GetSerializedGtinJson(Payload, filterValue, companyPrefixLength, serialNumber, resultBuffer);

		if(payloadHelperResult == DSM_OK) {
			strncpy(ConvertedPayloadBuffer, resultBuffer, 256);
			result = true;
		}
    } else if ( strcmp(PayloadType, "upce") == 0) {
        DSM_RESULT payloadHelperResult = DSM_GetUpceJson(Payload, resultBuffer);

        if(payloadHelperResult == DSM_OK) {
            strncpy(ConvertedPayloadBuffer, resultBuffer, 256);
            result = true;
        }
    } else if ( strcmp(PayloadType, "expandedfresh") == 0) {
		DSM_RESULT payloadHelperResult = DSM_GetExpandedFreshJson(Payload
			, SellbyDate
			, Price
			, WeightInPounds
			, WeightInKiloGrams
			, Count
			, resultBuffer);

		if(payloadHelperResult == DSM_OK) {
			strncpy(ConvertedPayloadBuffer, resultBuffer, 256);
			result = true;
		}
	} else if ( strcmp(PayloadType, "expandedfreshweightrange2") == 0) {
		DSM_RESULT payloadHelperResult = DSM_GetExpandedFreshJson_WeightRange2(Payload
			, SellbyDate
			, Price
			, WeightInPounds
			, WeightInKiloGrams
			, Count
			, resultBuffer);

		if(payloadHelperResult == DSM_OK) {
			strncpy(ConvertedPayloadBuffer, resultBuffer, 256);
			result = true;
		}
	} else if ( strcmp(PayloadType, "simpleproductidgtin") == 0) {
		DSM_RESULT payloadHelperResult = DSM_GetSimpleProductIdJson_Gtin(Payload
			, extraDataType
			, extraData
			, resultBuffer);

		if(payloadHelperResult == DSM_OK) {
			strncpy(ConvertedPayloadBuffer, resultBuffer, 256);
			result = true;
		}
	} else if ( strcmp(PayloadType, "simpleproductidupce") == 0) {
		DSM_RESULT payloadHelperResult = DSM_GetSimpleProductIdJson_Upce(Payload
			, extraDataType
			, extraData
			, resultBuffer);

		if(payloadHelperResult == DSM_OK) {
			strncpy(ConvertedPayloadBuffer, resultBuffer, 256);
			result = true;
		}
	}

	return(result);
}
