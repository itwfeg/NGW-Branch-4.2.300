// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CURSORPOSITIONDETECTOR_H__
#define __CURSORPOSITIONDETECTOR_H__

#include "UpdateDetector.h"
#include "win-system/WindowsEvent.h"
#include "log-writer/LogWriter.h"
#include "win-system/WinCursor.h"

class CursorPositionDetector : public UpdateDetector
{
public:
  CursorPositionDetector(UpdateKeeper *updateKeeper,
                UpdateListener *updateListener,
                LogWriter *log);
  virtual ~CursorPositionDetector(void);

  // Returns current position of a windows cursor.
  Point getCursorPos();

protected:
  virtual void execute();
  virtual void onTerminate();

private:
  WinCursor m_cursor;
  WindowsEvent m_sleepTimer;
  Point m_lastCursorPos;
  LogWriter *m_log;
};

#endif // __CURSORPOSITIONDETECTOR_H__
