// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _ICON_H_
#define _ICON_H_

#include "util/CommonHeader.h"

#include "Bitmap.h"

class Icon
{
public:
  Icon();
  Icon(HICON icon);
  Icon(Bitmap *bitmap);
  Icon(Bitmap *bitmap, Bitmap *mask);
  Icon(DWORD icon);
  virtual ~Icon();

  HICON getHICON();

protected:
  void fromBitmap(Bitmap *bitmap, Bitmap *mask);

protected:
  HICON m_icon;
  bool m_hasOwnIcon;
};

#endif
