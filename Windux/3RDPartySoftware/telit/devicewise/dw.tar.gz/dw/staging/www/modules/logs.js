var LogsCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded LogsCtrl');
  // Properties
  $scope.logFilterTypes = [];

  $scope.logItemsPerPage = '20';

  $scope.logPageNumber = '1';

  $scope.logPageNumberMax = '1';

  $scope.logPaginationOptions = {
    itemsPerPage: ['20'],
    pageNumbers: ['1']
  };

  lpApi.loggingCount({}).loggingQuery({'limit':$scope.logItemsPerPage,'page':String(Number($scope.logPageNumber)-1)}).loggingTypeList();

  // Resource Api
  $('#loading').show();
  $('#content-container').addClass('ng-cloak');
  Debug.log('Loading display '+$('#loading').css('display'));
  $http.post(lpApi.getUrl(''), lpApi.getPayload())
    .error($scope.errorCallback).success(function(a,b,c,d) {
      $scope.successCallback(a,b,c,d);
      $scope.logList = $scope.loggingQuery;
      if ($scope.loggingCount.success) {
        $scope.updateLogPaginationOptions($scope.loggingCount.params.count)
      }
    });

  // Functions
  $scope.convertLogLevel = function(level) {
    // Currently no level conversion information.
    switch(level) {
      case '1':
        return 'Fatal';
        break;
      case '2':
        return 'Error';
        break;
      case '3':
        return 'Warn';
        break;
      case '4':
        return 'Info';
        break;
    }
    return level;
  };

  $scope.convertLogType = function(type) {
    if($scope.loggingTypeList != undefined && $scope.loggingTypeList.success){
      return $scope.loggingTypeList.params[type][type];
    }
    return type;
  };

  $scope.goToFirstPage = function(){
    $scope.logPageNumber = String(1);
    $scope.queryLogs();
  };

  $scope.goToLastPage = function(){
    $scope.logPageNumber = String(Number($scope.logPageNumberMax));
    $scope.queryLogs();
  };

  $scope.goToNextPage = function(){
    $scope.logPageNumber = String(Number($scope.logPageNumber)+1);
    $scope.queryLogs();
  };

  $scope.goToPreviousPage = function(){
    $scope.logPageNumber = String(Number($scope.logPageNumber)-1);
    $scope.queryLogs();
  };

  $scope.queryLogs = function(){
    Debug.log('Querying the logs','queryLogs()');
    var count_params = {};
    var query_params = {};
    if ($scope.logFilterTypes.length > 0) {
      count_params['type'] = $scope.logFilterTypes;
      query_params['type'] = $scope.logFilterTypes;
    }
    query_params['limit'] = $scope.logItemsPerPage;
    query_params['page'] = String(Number($scope.logPageNumber)-1);
    lpApi.loggingCount(count_params).loggingQuery(query_params).loggingTypeList();
    $('#loading').show();
    $('#content-container').addClass('ng-cloak');

    $http.post(lpApi.getUrl(''), lpApi.getPayload())
      .error($scope.errorCallback).success(function(a,b,c,d) {
        $scope.successCallback(a,b,c,d);
        $scope.logList = $scope.loggingQuery;
        if ($scope.loggingCount.success) {
          $scope.updateLogPaginationOptions($scope.loggingCount.params.count)
        }
      });
  };

  $scope.showLogs = function() {
    if ($scope.logList != undefined && $scope.logList.params != undefined && $scope.logList.params.result.length > 0) {
      return '';
    }
    return 'display: none;';
  };

  $scope.showNoLogs = function() {
    if ($scope.logList == undefined || $scope.logList.params == undefined || $scope.logList.params.result.length == 0) {
      return '';
    }
    return 'display: none;';
  };

  $scope.updateLogFilterTypes = function() {
    Debug.log($('.logFilterTypes').length,'updateLogFilterTypes');
    $scope.logFilterTypes = [];
    $('.logFilterTypes').each(function(index){

      if ($scope['logFilterType_'+$(this).attr('value')] == true) {
        $scope.logFilterTypes.push($(this).attr('value'));
      }

      if ($('.logFilterTypes').length-1 == index) {
        $scope.queryLogs();
      }
    });
  };

  $scope.updateLogPaginationOptions = function(count) {
    count = new Number(count);
    $scope.logPaginationOptions.itemsPerPage = new Array('20'); $scope.logPaginationOptions.pageNumbers = new Array();
    if (count > 20) {
      $scope.logPaginationOptions.itemsPerPage.push('50');
    }
    if (count > 50) {
      $scope.logPaginationOptions.itemsPerPage.push('100');
    }
    if (count > 100) {
      $scope.logPaginationOptions.itemsPerPage.push('200');
    }
    if (count > 200) {
      $scope.logPaginationOptions.itemsPerPage.push('500');
    }

    $scope.logPageNumberMax = Math.ceil(count/Number($scope.logItemsPerPage));

    for (var a = 1; a <= Math.ceil(count/Number($scope.logItemsPerPage)) ; a++) {
      $scope.logPaginationOptions.pageNumbers.push(a);

    }
  };

  $scope.updateItemsPerPage = function() {
    if ($scope.logPageNumber != '1') {
      $scope.logPageNumber = '1';
    }
    $scope.queryLogs();
  };

  $scope.updatePage = function() {
    $scope.queryLogs();
  };

  // Executions
  $scope.clearSystemMsg();

  $scope.assertAuthentication();

  $scope.menuItemSelect($scope, 'gateway');
};

LogsCtrl.$inject = ['$scope','lpApi','$http'];

LogsCtrl.prototype.ctrlActions = {
  items : [{
    href : '',
    template : ''
  }]
};

LogsCtrl.prototype.mainActions = {
  items : [{
    href : '',
    template : ''
  }]
};

LogsCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};

$('li.paging span a').live('click', function(e){ e.preventDefault() });