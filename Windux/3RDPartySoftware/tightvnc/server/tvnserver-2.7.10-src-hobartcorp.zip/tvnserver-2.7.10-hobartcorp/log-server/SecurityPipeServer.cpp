// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "SecurityPipeServer.h"
#include "win-system/PipeServer.h"
#include "win-system/PipeClient.h"
#include "io-lib/DataInputStream.h"
#include "io-lib/DataOutputStream.h"
#include "win-system/Environment.h"
#include "win-system/WinHandles.h"
#include "ConnectionTimer.h"
#include <time.h>

SecurityPipeServer::SecurityPipeServer(Channel *tempPublChan)
: m_secChannel(0)
{
  try {
    generateSecConnection(tempPublChan);
    makeSure();
  } catch (...) {
    if (m_secChannel != 0) delete m_secChannel;
    throw;
  }
}

SecurityPipeServer::~SecurityPipeServer()
{
}

Channel *SecurityPipeServer::getChannel()
{
  Channel *chan = m_secChannel;
  m_secChannel = 0;
  return chan;
}

HANDLE SecurityPipeServer::assignHandleFor(unsigned int procId,
                                           HANDLE srcHandle)
{
  HANDLE processHandle = OpenProcess(PROCESS_DUP_HANDLE, FALSE, procId);
  if (processHandle == 0) {
    throw Exception(_T("Cannot open process to assign pipe")
                    _T(" handles for it"));
  }
  HANDLE dstHandle;
  try {
    dstHandle = WinHandles::assignHandleFor(srcHandle, processHandle,
                                            false, false);
    CloseHandle(processHandle);
    return dstHandle;
  } catch (...) {
    CloseHandle(processHandle);
    throw;
  }
}

void SecurityPipeServer::generateSecConnection(Channel *tempPublChan)
{
  NamedPipe *otherSideChannel = 0;

  try {
    DataInputStream svcInput(tempPublChan);
    DataOutputStream svcOutput(tempPublChan);

    UINT32 procId = svcInput.readUInt32();
    // Check the id. If it is "right" process then generate
    // transport handles specially for it.
    if (!Environment::isItTheSamePathAsCurrent(procId)) {
      throw Exception(_T("The process that has requested connection")
                      _T(" to the log server has not access right"));
    }
    // Give to process exclusive pipe handles

    StringStorage randomName;
    srand((unsigned)time(0));
    for (int i = 0; i < 20; i++) {
      randomName.appendChar('a' + rand() % ('z' - 'a'));
    }
    PipeServer pipeServer(randomName.getString(), 0, 1000);
    otherSideChannel = PipeClient::connect(randomName.getString());
    m_secChannel = pipeServer.accept();

    HANDLE otherSideHandle = otherSideChannel->getHandle();
    svcOutput.writeUInt64((UINT64)assignHandleFor(procId, otherSideHandle));
  } catch (...) {
    if (otherSideChannel != 0) delete otherSideChannel;
    throw;
  }
  if (otherSideChannel != 0) delete otherSideChannel;
}

void SecurityPipeServer::onTimeTimer()
{
  m_secChannel->close();
}

void SecurityPipeServer::makeSure()
{
  DataInputStream inputGate(m_secChannel);
  DataOutputStream outputGate(m_secChannel);
  // Acknowledgement of the receipt
  unsigned int timeOut = 10000; // milliseconds
  ConnectionTimer connTimer(this, timeOut);
  // If no byte received during time out interval connTimer has break
  // read operation and the make sure throws an Exception.
  inputGate.readInt8();
}
