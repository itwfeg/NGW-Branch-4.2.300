// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CONSOLEPOLLER_H__
#define __CONSOLEPOLLER_H__

#include "UpdateDetector.h"
#include "ScreenGrabber.h"
#include "win-system/WindowsEvent.h"
#include "log-writer/LogWriter.h"

class ConsolePoller : public UpdateDetector
{
public:
  ConsolePoller(UpdateKeeper *updateKeeper,
                UpdateListener *updateListener,
                ScreenGrabber *screenGrabber,
                FrameBuffer *backupFrameBuffer,
                LocalMutex *frameBufferMutex,
                LogWriter *log);

  virtual ~ConsolePoller();

protected:
  virtual void execute();
  virtual void onTerminate();

private:
  Rect getConsoleRect();

  ScreenGrabber *m_screenGrabber;
  FrameBuffer *m_backupFrameBuffer;
  LocalMutex *m_frameBufferMutex;
  Rect m_pollingRect;
  WindowsEvent m_intervalWaiter;
  LogWriter *m_log;
};

#endif // __CONSOLEPOLLER_H__
