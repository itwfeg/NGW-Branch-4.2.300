// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "DesktopSrvDispatcher.h"
#include "ReconnectException.h"
#include "util/CommonHeader.h"

DesktopSrvDispatcher::DesktopSrvDispatcher(BlockingGate *gate,
                                           AnEventListener *extErrorListener,
                                           LogWriter *log)
: m_gate(gate),
  m_extErrorListener(extErrorListener),
  m_log(log)
{
}

DesktopSrvDispatcher::~DesktopSrvDispatcher()
{
  terminate();
  resume();
  wait();
}

void DesktopSrvDispatcher::onTerminate()
{
}

void DesktopSrvDispatcher::notifyOnError()
{
  if (m_extErrorListener) {
    m_extErrorListener->onAnObjectEvent();
  }
}

void DesktopSrvDispatcher::execute()
{
  while (!isTerminating()) {
    try {
      UINT8 code = m_gate->readUInt8();
      std::map<UINT8, ClientListener *>::iterator iter = m_handlers.find(code);
      if (iter == m_handlers.end()) {
        StringStorage errMess;
        errMess.format(_T("Unhandled %d code has been ")
                       _T("received from a client"),
                       (int)code);
        throw Exception(errMess.getString());
      }
      (*iter).second->onRequest(code, m_gate);
    } catch (ReconnectException &) {
      m_log->message(_T("The DesktopServerApplication dispatcher has been reconnected"));
    } catch (Exception &e) {
      m_log->error(_T("The DesktopServerApplication dispatcher has ")
                 _T("failed with error: %s"), e.getMessage());
      notifyOnError();
      terminate();
    }
  }
  m_log->message(_T("The DesktopServerApplication dispatcher has been stopped"));
}

void DesktopSrvDispatcher::registerNewHandle(UINT8 code, ClientListener *listener)
{
  m_handlers[code] = listener;
}
