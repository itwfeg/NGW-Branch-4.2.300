// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __RFB_AUTH_DEFS_H_INCLUDED__
#define __RFB_AUTH_DEFS_H_INCLUDED__

#include "util/inttypes.h"

class SecurityDefs
{
public:
  static const UINT32 INVALID = 0;
  static const UINT32 NONE = 1;
  static const UINT32 VNC = 2;
  static const UINT32 TIGHT = 16;
  static UINT32 convertFromAuthType(UINT32 authType);
};

class AuthDefs
{
public:
  static const UINT32 NONE = 1;
  static const UINT32 VNC = 2;
  static const UINT32 EXTERNAL = 130;

  static const char *const SIG_NONE;
  static const char *const SIG_VNC;
  static const char *const SIG_EXTERNAL;

  // Return TightVNC authentication method corresponding to a VNC-style
  // security type. Returns 0 if the specified security type does not map
  // to any valid authentication type supported in TightVNC.
  static UINT32 convertFromSecurityType(UINT32 securityType);
};

#endif // __RFB_AUTH_DEFS_H_INCLUDED__
