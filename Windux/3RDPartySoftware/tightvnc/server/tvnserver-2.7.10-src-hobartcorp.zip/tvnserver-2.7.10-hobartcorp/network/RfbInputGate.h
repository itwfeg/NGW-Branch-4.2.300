// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _RFB_INPUT_GATE_H_
#define _RFB_INPUT_GATE_H_

#include "io-lib/Channel.h"

#include "io-lib/DataInputStream.h"

class RfbInputGate : public DataInputStream
{
public:
  RfbInputGate(Channel *stream);
  virtual ~RfbInputGate();
};

#endif
