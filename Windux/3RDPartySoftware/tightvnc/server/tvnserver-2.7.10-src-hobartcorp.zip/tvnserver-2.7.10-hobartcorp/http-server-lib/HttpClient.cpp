// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "HttpClient.h"

#include "HttpRequestHandler.h"

#include "network/socket/SocketStream.h"

HttpClient::HttpClient(SocketIPv4 *socket, LogWriter *log)
: TcpClientThread(socket),
  m_log(log)
{
  m_stream = new SocketStream(socket);

  m_dIS = new DataInputStream(m_stream);
  m_dOS = new DataOutputStream(m_stream);
}

HttpClient::~HttpClient()
{
  if (Thread::isActive()) {
    Thread::wait();
  }

  delete m_stream;
  delete m_dOS;
  delete m_dIS;
}

void HttpClient::execute()
{
  try {

    //
    // Convert peer ip address to string value.
    //

    SocketAddressIPv4 peerAddress;

    m_socket->getPeerAddr(&peerAddress);

    StringStorage peerHost;

    peerAddress.toString(&peerHost);

    //
    // Call request handler.
    //

    HttpRequestHandler httpRequestHandler(m_dIS, m_dOS, m_log, peerHost.getString());

    httpRequestHandler.processRequest();
  } catch (IOException &) { } // try / catch.

  try {
    m_socket->shutdown(SD_BOTH);
  } catch (...) { } // try / catch.

  try {
    m_socket->close();
  } catch (...) { } // try / catch.
}
