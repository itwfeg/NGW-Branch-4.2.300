// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __DESKTOPSRVDISPATCHER_H__
#define __DESKTOPSRVDISPATCHER_H__

#include "thread/GuiThread.h"
#include "BlockingGate.h"
#include "ClientListener.h"
#include "util/AnEventListener.h"
#include "win-system/WindowsEvent.h"
#include "log-writer/LogWriter.h"
#include <map>

class DesktopSrvDispatcher: public GuiThread
{
public:
  DesktopSrvDispatcher(BlockingGate *gate,
                       AnEventListener *m_extTerminationListener,
                       LogWriter *log);
  virtual ~DesktopSrvDispatcher();

  void registerNewHandle(UINT8 code, ClientListener *listener);

protected:
  virtual void execute();
  virtual void onTerminate();
  void notifyOnError();

  BlockingGate *m_gate;

  std::map<UINT8, ClientListener *> m_handlers;

  AnEventListener *m_extErrorListener;

  LogWriter *m_log;
};

#endif // __DESKTOPSRVDISPATCHER_H__
