// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __COPYRECTDETECTOR_H__
#define __COPYRECTDETECTOR_H__

#include "region/Rect.h"
#include "region/Point.h"
#include "util/CommonHeader.h"
#include <list>

struct WinProp
{
  WinProp(HWND _hwnd, Rect *_prevRect) { hwnd = _hwnd; prevRect = *_prevRect; }
  HWND hwnd;
  Rect prevRect;
};

class CopyRectDetector
{
public:
  CopyRectDetector();
  virtual ~CopyRectDetector();

  void detectWindowMovements(Rect *copyRect, Point *source);

protected:
  static BOOL CALLBACK enumWindowsFnCopyRect(HWND hwnd, LPARAM arg);
  BOOL checkWindowMovements(HWND hwnd);

  bool getWinRect(HWND hwnd, Rect *winRect);

  // If window properties successfully was found then function returns
  // true. Else this function returns false.
  bool findPrevWinProps(HWND hwnd, Rect *rect);

  Rect m_copyRect;
  Point m_source;

  std::list<WinProp> m_lastWinProps;
  std::list<WinProp> m_newWinProps;
};

#endif // __COPYRECTDETECTOR_H__
