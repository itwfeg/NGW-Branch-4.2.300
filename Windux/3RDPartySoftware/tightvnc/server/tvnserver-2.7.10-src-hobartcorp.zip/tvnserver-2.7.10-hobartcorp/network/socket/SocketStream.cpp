// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include <stdlib.h>
#include "SocketStream.h"

#include "../socket/sockdefs.h"

#include <crtdbg.h>

SocketStream::SocketStream(SocketIPv4 *sock)
: m_socket(sock)
{
  _ASSERT(m_socket != NULL);
}

SocketStream::~SocketStream()
{
}

size_t SocketStream::read(void *buf, size_t wanted)
{
  if ((int)wanted < 0) {
    throw IOException(_T("Wanted size too big."));
  }

  return (size_t)m_socket->recv((char *)buf, (int)wanted);
}

size_t SocketStream::write(const void *buf, size_t size)
{
  if ((int)size < 0) {
    throw IOException(_T("Size of buffer is too big."));
  }

  return (size_t)m_socket->send((char *)buf, (int)size);
}

void SocketStream::close()
{
  try {
    m_socket->shutdown(SD_BOTH);
  } catch (...) {
  }
  m_socket->close();
}
