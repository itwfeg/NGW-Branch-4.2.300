// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "Tab.h"

Tab::Tab()
: m_dialog(NULL)
{
  m_caption.setString(_T(""));
}

Tab::Tab(BaseDialog *dialog, const TCHAR *caption)
: m_dialog(dialog)
{
  m_caption.setString(caption);
}

void Tab::setVisible(bool visible)
{
  if (m_dialog != NULL) {
    m_dialog->getControl()->setVisible(visible);
  }
}
