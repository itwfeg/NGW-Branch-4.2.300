// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDOWSCLIPBOARD_H__
#define __WINDOWSCLIPBOARD_H__

#include "util/CommonHeader.h"
#include "gui/MessageWindow.h"
#include "ClipboardListener.h"
#include "log-writer/LogWriter.h"
#include "thread/GuiThread.h"

class WindowsClipboard : protected MessageWindow, GuiThread
{
public:
  WindowsClipboard(ClipboardListener *clipboardListener, LogWriter *log);
  virtual ~WindowsClipboard(void);

  // This function replaces clipboard content by the text
  virtual bool writeToClipBoard(const TCHAR *text);

  virtual void readFromClipBoard(StringStorage *clipDest) const;

protected:
  virtual bool wndProc(UINT message, WPARAM wParam, LPARAM lParam);

  virtual void execute();
  virtual void onTerminate();

  void convertToRfbFormat(const StringStorage *source, StringStorage *dest);
  void convertFromRfbFormat(const TCHAR *source, StringStorage *dest);

  HWND m_hwndNextViewer;

  ClipboardListener *m_clipboardListener;

  LogWriter *m_log;

  static const HINSTANCE m_hinst;
};

#endif // __WINDOWSCLIPBOARD_H__
