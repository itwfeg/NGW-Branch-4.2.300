cd bin
SoftekSDKDemo.exe