﻿using System;
using System.Globalization;
using System.Text;

namespace BnWasp
{
	public static class AddressUtils
	{
		public enum HexAddressSyntax
		{
			Plain,
			FullAddress,
			WaSPShort,
			HBTempShort,
			RepeaterShort,
			HBShipShort,
			Smart,
		}

		/// <summary>
		/// Converts the Bluetooth device address from a long integer to a hexadecimal string.
		/// The string is shortened whenever possible.
		/// 
		/// Available formats:
		/// Plain:			3C2DB78590D1
		/// FullAddress:	3C.2D.B7-85.90.D1
		/// WaSPShort:		A000028
		/// HBTempShort:	B00017C
		/// RepeaterShort:	C0082CD
		/// HBShipShort:	D002907
		/// Smart:
		///		Shortens the address when possible, else produces full address
		///		A00492C or B00017C or C0082CD or D002907 or 3C.2D.B7-85.90.D1
		/// </summary>
		/// <param name="address">Address value</param>
		/// <param name="syntax">HexAddressSyntax enumeration</param>
		/// <returns>Address as a hexadecimal string.</returns>
		public static string LongToHex(long? address, HexAddressSyntax syntax = HexAddressSyntax.Smart)
		{
			long addressNotNull = address ?? 0;
			if (address == 0)
				return "0";

			byte[] b = BitConverter.GetBytes(addressNotNull);

			string ret;
			switch (syntax)
			{
				case HexAddressSyntax.FullAddress:
					ret = String.Format("{0:X2}.{1:X2}.{2:X2}-{3:X2}.{4:X2}.{5:X2}", b[5], b[4], b[3], b[2], b[1], b[0]);
					break;

				case HexAddressSyntax.HBTempShort:
					if (b[5] == 0xBE && b[4] == 0xE0 && b[3] == 0x00)
						ret = String.Format("B{0:X2}{1:X2}{2:X2}", b[2], b[1], b[0]);
					else
						ret = String.Format("{0:X2}.{1:X2}.{2:X2}-{3:X2}.{4:X2}.{5:X2}", b[5], b[4], b[3], b[2], b[1], b[0]);
					break;

				case HexAddressSyntax.HBShipShort:
					if (b[5] == 0xDD && b[4] == 0xD0 && b[3] == 0x00)
						ret = String.Format("D{0:X2}{1:X2}{2:X2}", b[2], b[1], b[0]);
					else
						ret = String.Format("{0:X2}.{1:X2}.{2:X2}-{3:X2}.{4:X2}.{5:X2}", b[5], b[4], b[3], b[2], b[1], b[0]);
					break;

				case HexAddressSyntax.WaSPShort:
					if (b[5] == 0xAA && b[4] == 0xA0 && b[3] == 0x00)
						ret = String.Format("A{0:X2}{1:X2}{2:X2}", b[2], b[1], b[0]);
					else
						ret = String.Format("{0:X2}.{1:X2}.{2:X2}-{3:X2}.{4:X2}.{5:X2}", b[5], b[4], b[3], b[2], b[1], b[0]);
					break;

				case HexAddressSyntax.RepeaterShort:
					if (b[5] == 0xCC && b[4] == 0xC0 && b[3] == 0x00)
						ret = String.Format("C{0:X2}{1:X2}{2:X2}", b[2], b[1], b[0]);
					else
						ret = String.Format("{0:X2}.{1:X2}.{2:X2}-{3:X2}.{4:X2}.{5:X2}", b[5], b[4], b[3], b[2], b[1], b[0]);
					break;

				case HexAddressSyntax.Smart:
					if (b[5] == 0xBE && b[4] == 0xE0 && b[3] == 0x00)
						ret = String.Format("B{0:X2}{1:X2}{2:X2}", b[2], b[1], b[0]);
					else if (b[5] == 0xAA && b[4] == 0xA0 && b[3] == 0x00)
						ret = String.Format("A{0:X2}{1:X2}{2:X2}", b[2], b[1], b[0]);
					else if (b[5] == 0xCC && b[4] == 0xC0 && b[3] == 0x00)
						ret = String.Format("C{0:X2}{1:X2}{2:X2}", b[2], b[1], b[0]);
					else if (b[5] == 0xDD && b[4] == 0xD0 && b[3] == 0x00)
						ret = String.Format("D{0:X2}{1:X2}{2:X2}", b[2], b[1], b[0]);
					else
						ret = String.Format("{0:X2}.{1:X2}.{2:X2}-{3:X2}.{4:X2}.{5:X2}", b[5], b[4], b[3], b[2], b[1], b[0]);
					break;

				default:
					ret = String.Format("{0:X2}{1:X2}{2:X2}{3:X2}{4:X2}{5:X2}", b[5], b[4], b[3], b[2], b[1], b[0]);
					break;
			}

			return ret;
		}

		/// <summary>
		/// Converts a (possibly shortened) hexadecimal address to a long integer.
		/// All types of separators are ignored.
		/// "A000028"           -> 187604171489320 (0xAAA000000028)
		/// "B001283"           -> 209869281956483 (0xBEE000001283)
		/// "C0082CD"			-> 225125005820621 (0xCCC0000082CD)
		/// "D002907"           -> 243885422946567 (0xDDD000002907)
		/// "BEE000001283"      -> 209869281956483
		/// "BE:E0:00:00:12:83"	-> 209869281956483
		/// </summary>
		/// <param name="hexAddress">Scanned shortened Id</param>
		/// <returns>Expanded address as along integer.</returns>
		public static long HexToLong(string hexAddress)
		{
			hexAddress = hexAddress.Trim().ToUpper();
			if (hexAddress.Length == 7) // scanned shortened version
			{
				bool isWasp = hexAddress[0] == 'A';
				bool isRepeater = hexAddress[0] == 'C';
				bool isHbShip = hexAddress[0] == 'D';
				hexAddress = hexAddress.Substring(1);

				if (isWasp)
					return PartialHexAddressToLong(hexAddress, "AAA");

				if (isRepeater)
					return PartialHexAddressToLong(hexAddress, "CCC");

				if (isHbShip)
					return PartialHexAddressToLong(hexAddress, "DDD");

				return PartialHexAddressToLong(hexAddress); // BEE assumed
			}

			// possibly partial/full address, perform the default expansion
			return PartialHexAddressToLong(hexAddress);
		}

		/// <summary>
		/// Converts a hexadecimal Bluetooth address to its decimal representation.
		/// 
		/// The hex representation can skip any number of leading digits providing the address
		/// belongs to the default BE.E0.00 pool, or a different pool is provided.
		/// 
		/// Examples:
		///		"BEE000001283"		-> 209869281956483
		///		"BE.E0.00-00.12.83"	-> 209869281956483
		///		"BE:E0:00:00:12:83"	-> 209869281956483
		///		"12.83"				-> 209869281956483
		///		"1283"				-> 209869281956483
		/// 
		///		"AAA000000028"		-> 187604171489320
		///		"28", "AAA000"		-> 187604171489320
		/// 
		///		"209869281956483"	-> 209869281956483
		/// </summary>
		/// <param name="sensorIDPattern">Part of the hex address or the complete integer address</param>
		/// <param name="baseAddress">Auto-fill base for the shortened hex form</param>
		/// <returns>Numeric representation of the address.</returns>
		public static long PartialHexAddressToLong(string sensorIDPattern, string baseAddress = "BEE000")
		{
			long ret;

			StringBuilder sb = new StringBuilder();
			foreach (char c in sensorIDPattern.ToUpper())
			{
				if (Char.IsDigit(c) || (c >= 'A' && c <= 'F'))
					sb.Append(c);
			}

			if (sb.Length > 12) // must be a decimal form
			{
				Int64.TryParse(sb.ToString(), out ret);
			}
			else
			{
				if (baseAddress.Length < 12)
					baseAddress = baseAddress + new string('0', 12 - baseAddress.Length);

				StringBuilder hex = new StringBuilder(baseAddress);
				for (int i = 0; i < sb.Length; i++)
				{
					hex[i + 12 - sb.Length] = sb[i];
				}
				Int64.TryParse(hex.ToString(), NumberStyles.HexNumber, null, out ret);
			}

			return ret;
		}

	}

}
