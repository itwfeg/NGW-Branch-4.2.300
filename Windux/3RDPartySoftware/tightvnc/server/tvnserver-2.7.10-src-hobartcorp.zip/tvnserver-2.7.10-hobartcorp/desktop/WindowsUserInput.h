// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDOWSUSERINPUT_H__
#define __WINDOWSUSERINPUT_H__

#include "UserInput.h"
#include "WindowsClipboard.h"
#include "util/Keymap.h"
#include "win-system/InputInjector.h"
#include "win-system/WindowsDisplays.h"
#include "log-writer/LogWriter.h"

class WindowsUserInput : public UserInput
{
public:
  WindowsUserInput(ClipboardListener *clipboardListener,
                   bool ctrlAltDelEnabled,
                   LogWriter *log);
  virtual ~WindowsUserInput(void);

  virtual void setNewClipboard(const StringStorage *newClipboard);
  virtual void setMouseEvent(const Point *newPos, UINT8 keyFlag);
  virtual void setKeyboardEvent(UINT32 keySym, bool down);

  virtual void getCurrentUserInfo(StringStorage *desktopName,
                                  StringStorage *userName);
  virtual void getDisplayNumberCoords(Rect *rect,
                                      unsigned char dispNumber);
  virtual void getNormalizedRect(Rect *rect);
  virtual void getPrimaryDisplayCoords(Rect *rect);
  virtual void getWindowCoords(HWND hwnd, Rect *rect);
  virtual HWND getWindowHandleByName(const StringStorage *windowName);
  virtual void getApplicationRegion(unsigned int procId, Region *region);

  virtual void initKeyFlag(UINT8 initValue) { m_prevKeyFlag = initValue; }

protected:
  void toFbCoordinates(Rect *rect);

  WindowsClipboard *m_clipboard;
  WindowsDisplays m_winDisplays;

  Keymap m_keyMap;
  InputInjector m_inputInjector;

  UINT8 m_prevKeyFlag;

  LogWriter *m_log;
};

#endif // __WINDOWSUSERINPUT_H__
