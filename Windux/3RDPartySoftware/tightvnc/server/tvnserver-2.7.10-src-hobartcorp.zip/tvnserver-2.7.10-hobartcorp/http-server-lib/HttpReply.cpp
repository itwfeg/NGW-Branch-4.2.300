// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "HttpReply.h"

HttpReply::HttpReply(DataOutputStream *dataOutput)
: m_dataOutput(dataOutput)
{
}

HttpReply::~HttpReply()
{
}

void HttpReply::send200()
{
  const char HTTP_200[] = "HTTP/1.0 200 OK\r\n\r\n";

  m_dataOutput->writeFully(HTTP_200, strlen(HTTP_200));
}

void HttpReply::send404()
{
  const char HTTP_404 [] = "HTTP/1.0 404 Not Found\r\n\r\n"
                           "<HTML>\n"
                           "  <HEAD><TITLE>404 Not Found</TITLE></HEAD>\n"
                           "  <BODY>\n"
                           "    <H1>Not Found</H1>\n"
                           "    The requested file could not be found.\n"
                           "  </BODY>\n"
                           "</HTML>\n";

  m_dataOutput->writeFully(HTTP_404, strlen(HTTP_404));
}
