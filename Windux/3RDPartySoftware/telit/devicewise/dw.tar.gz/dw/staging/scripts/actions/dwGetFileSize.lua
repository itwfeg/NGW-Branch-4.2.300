function dw_action_register()
	local reg = {}
	reg.Key="DWGETFILESIZE"
	reg.Name="Get File Size"
	reg.Group="Extended File Support"
	return reg
end

function dw_action_query_metadata()
	local mdata = {}
	local input = nil
	local output = nil
	
	mdata.Inputs = {}
	mdata.Outputs = {}

	input = {}
	input.Name="FileName"
	input.Type="STRING"
	input.Count=1
	input.Length=64
	mdata.Inputs[1]=input
	
	output = {}
	output.Name="FileSize"
	output.Type="INT4"
	output.Count=1
	output.Length=0
	mdata.Outputs[1]=output	
	return mdata
end

function file_exists(name)
   local f=io.open(name,"r")
   if f~=nil then io.close(f) return true else return false end
end

function file_size(filename)
	local file = io.open( filename, "r" ) 
        local current = file:seek()      -- get current position
        local size = file:seek("end")    -- get file size
        file:seek("set", current)        -- restore position
        io.close(file)
        return size
end

function dw_action_notify()
	dw.log.exception("INFO", "LUA Action - GetFileSize - ENTRY", "LUA")

	local fName = "../staging/" .. DWInput.FileName

	local platform = "None"
	platform = os.getenv("OS")
	
	if platform ~= nil then
	  if string.find(platform, "Windows") ~= nil then
		fName = "c:\\deviceWISE\\Runtime\\staging\\" .. DWInput.FileName
	  end
	end
	
	local fexists = 0
	local fsize = 0

	-- dw.log.exception("INFO", "File Name (Set): [".. fName .."]")

	if file_exists ( fName ) then 
		fexists = 1
		fsize = file_size( fName )
	else
       		fexists = 0
	end
 
	dw.log.exception("INFO", "File Size = " .. fsize )
	dw.log.exception("INFO", "LUA Action - GetFileSize - EXIT", "LUA")

	DWOutput.FileSize=fsize

	return 0
end
