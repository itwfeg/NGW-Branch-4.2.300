// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __HOOKLOADERAPPLICATION_H__
#define __HOOKLOADERAPPLICATION_H__

#include "win-system/LocalWindowsApplication.h"
#include "ParentWatcher.h"

class HookLoaderApplication : public WindowsApplication,
                              private ParentEventsListener
{
public:
  HookLoaderApplication(HINSTANCE appInstance,
                        const TCHAR *windowClassName,
                        const TCHAR *commandLine);
  virtual ~HookLoaderApplication();

private:
  virtual void onParentTerminate();

  virtual void registerWindowClass(WNDCLASS *wndClass);
  virtual int processMessages();

  static LRESULT CALLBACK hookLoaderWndProc(HWND hWnd, UINT msg,
                                            WPARAM wparam,
                                            LPARAM lparam);

  StringStorage m_commandLine;

  ParentWatcher *m_parentWatcher;
};

#endif // __HOOKLOADERAPPLICATION_H__
