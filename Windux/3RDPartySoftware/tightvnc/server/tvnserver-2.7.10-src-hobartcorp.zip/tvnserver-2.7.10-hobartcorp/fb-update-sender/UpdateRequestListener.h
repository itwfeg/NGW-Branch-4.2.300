// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDATEREQUESTLISTENER_H__
#define __UPDATEREQUESTLISTENER_H__

#include "region/Rect.h"

class UpdateRequestListener
{
public:
  virtual ~UpdateRequestListener() {}
  // Interface function
  virtual void onUpdateRequest(const Rect *rectRequested,
                               bool incremental) = 0;
};

#endif // __UPDATEREQUESTLISTENER_H__
