var CellularCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded CellularCtrl','cellular');
  // Preperations
  self.scope = $scope;

  lpApi.modemInfo().modemGet().modemDiagnostic();

  $('#loading').show();
  $('#content-container').addClass('ng-cloak');
  Debug.log('Loading display '+$('#loading').css('display'));
  $http.post(lpApi.getUrl(''), lpApi.getPayload())
    .error($scope.errorCallback).success(function(a,b,c,d){ $scope.successCallback(a,b,c,d); $scope.populateCellularInfo(); $scope.populateModemInfo(); $scope.populateModemDiagnostic(); });

  // Properties
  $scope.ctrlActions = [{
    liId:  "li-gatewayReboot",
    liStyle: "",
    href: "#/gateway/reboot",
    aId: "menu-item-rebootGateway",
    imgSrc: "/img/icon/16/rebootGateway.png",
    imgClass: "icon prevent",
    imgAlt: "",
    text: "Reboot gateway"
  },{
    liId:  "li-modem-activate",
    liStyle: "display: none;",
    href: "#/cellular/modemActivate",
    aId: "menu-item-modemActivate",
    aClass: "prevent",
    imgSrc: "/img/icon/16/connectModem.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Activate modem"
  },{
    liId:  "li-modem-connect",
    liStyle: "display: none;",
    href: "#/cellular/modemConnect",
    aId: "menu-item-modemConnect",
    aClass: "prevent",
    imgSrc: "/img/icon/16/connectModem.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Connect modem"
  },{
    liId:  "li-modem-disconnect",
    liStyle: "display: none;",
    href: "#/cellular/modemDisconnect",
    aId: "menu-item-modemDisconnect",
    aClass: "prevent",
    imgSrc: "/img/icon/16/disconnectModem.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Disconnect modem"
  }];

  $scope.mainActions = [{
    id : 'main-action-editCellular',
    href : '#/editCellular',
    aClasses: "gray-button",
    text: 'Edit cellular'
  }];

  $scope.showCellularSettings = false;

  // Functions
  $scope.accessModemActivate = function() {
    $('loading').show();

    lpApi.modemActivate().modemInfo().modemGet().modemDiagnostic();

    $http.post(lpApi.getUrl(''), lpApi.getPayload())
      .error($scope.errorCallback).success(function(a,b,c,d){ Debug.log(a.modemActivate,'modemActivate'); $scope.successCallback(a,b,c,d); $scope.onMenuToggleReturn('activating modem', a.modemActivate); $scope.populateCellularInfo(); $scope.populateModemInfo(); $scope.populateModemDiagnostic(); });

    $scope.populateCellularInfo();

    $scope.populateModemInfo();

    $scope.populateModemDiagnostic();
  };

  $scope.accessModemConnect = function() {
    $('loading').show();

    lpApi.modemConnect().modemInfo().modemGet().modemDiagnostic();

    $http.post(lpApi.getUrl(''), lpApi.getPayload())
      .error($scope.errorCallback).success(function(a,b,c,d){ Debug.log(a.modemConnect,'modemConnect'); $scope.successCallback(a,b,c,d); $scope.onMenuToggleReturn('connecting modem', a.modemConnect); $scope.populateCellularInfo(); $scope.populateModemInfo(); $scope.populateModemDiagnostic(); });

    $scope.populateCellularInfo();

    $scope.populateModemInfo();

    $scope.populateModemDiagnostic();
  };

  $scope.accessModemDisconnect = function() {
    $('loading').show();

    lpApi.modemDisconnect().modemInfo().modemGet().modemDiagnostic();

    $http.post(lpApi.getUrl(''), lpApi.getPayload())
      .error($scope.errorCallback).success(function(a,b,c,d){ Debug.log(a.modemConnect,'modemDisconnect'); $scope.successCallback(a,b,c,d); $scope.onMenuToggleReturn('disconnecting modem', a.modemConnect); $scope.populateCellularInfo(); $scope.populateModemInfo(); $scope.populateModemDiagnostic(); });

    self.scope.populateCellularInfo();

    self.scope.populateModemInfo();

    self.scope.populateModemDiagnostic();
  };

  $scope.ngShowModemActivate = function() {
//    $scope.modemGet = {"success":true,"params":{"mode":"GSM","apn":"proxy","requires_auth":"Yes","file_name":"./wvdial.conf.verizon","connect_on_start":"Yes","phone_number":"*99#","user":"9083076821@vzw3g.com","pass":"vzw"}};
//    $scope.modemGet = {"success":true,"params":{"mode":"CDMA","status":"NOT ACTIVATED","file_name":"./wvdial.conf.verizon","connect_on_start":"Yes","auto_reboot":"6 hours","phone_number":"*99#","user":"9083076821@vzw3g.com","pass":"vzw"}};
    var displayVal = ($scope.modemGet != undefined && ($scope.modemGet.success == true && $scope.modemGet.params.mode.toLowerCase() == "gsm") ? 'none' : 'block');

    $('#li-modem-activate').css('display',displayVal);
  };

  $scope.ngShowModemConnect = function() {
    var displayVal = $scope.modemInfo != undefined && ($scope.modemInfo.success == true && $scope.modemInfo.params.status.toLowerCase() == "connected") ? 'none' : 'block';

    $('#li-modem-connect').css('display',displayVal);
  };

  $scope.ngShowModemDisconnect = function() {
    var displayVal = $scope.modemInfo != undefined && ($scope.modemInfo.success == false || $scope.modemInfo.params.status.toLowerCase() != "connected") ? 'none' : 'block';

    $("#li-modem-disconnect").css('display',displayVal);
  };

  $scope.onMenuToggleReturn = function(action, data) {
    var msg;
    if (data && data.success){
      msg = "Success " + action + "\n\n";
      alert(msg);
    }
    else {
      msg = "An error occurred while " + action + "\n\n" + data.errorMessage;
      alert(msg);
    }
  };

  $scope.populateModemInfo = function() {
//    $scope.modemInfo = {"success":true,"params":{"bars":"3","rssi":"-89","service_type":"#HSDPA#","service":"AT&T Mobility","my_phone_number":"#5165043452#","imei":"356215040035309","imsi":"310410329532497","iccid":"#JOHNOWESMETHIS#","status":"CONNECTED"}};
    if ($scope.modemInfo != undefined && $scope.modemInfo.params != undefined) { Debug.log($scope.modemInfo,'modemInfo');
      $scope.showCellularSettings = true;
      $scope.modemInfo.params.bars = ($scope.modemInfo.params.bars) ? $scope.modemInfo.params.bars : 0;
      $("#show-signal-strength").html('<img src="/img/icon/signal' + $scope.modemInfo.params.bars +  '.png" />');
    }
  };

  $scope.populateCellularInfo = function() {
//    $scope.cellularInfo = {"success":true,"params":{"mode":"GSM","apn":"proxy","requires_auth":"Yes","file_name":"./wvdial.conf.verizon","connect_on_start":"Yes","phone_number":"*99#","user":"9083076821@vzw3g.com","pass":"vzw"}};
    $scope.cellularInfo = $scope.modemGet;
    if ($scope.cellularInfo != undefined && $scope.cellularInfo.params != undefined) { Debug.log($scope.cellularInfo,'cellularInfo');
      $scope.showCellularSettings = true;
    }
  };

  $scope.populateModemDiagnostic = function() {
//    $scope.modemDiagnostic = {"success":true,"params":{"bars":"3","rssi":"-89","service_type":"#HSDPA#","service":"AT&T Mobility","my_phone_number":"#5165043452#","imei":"356215040035309","imsi":"310410329532497","iccid":"#JOHNOWESMETHIS#","status":"CONNECTED"}};
    if ($scope.modemDiagnostic != undefined && $scope.modemDiagnostic.params != undefined) { Debug.log($scope.modemDiagnostic,'modemDiagnostic');
      $scope.showCellularSettings = true;
    }
  };

  $scope.saveCellularSettings = function(){

    var cellularParams = {"connect_on_start" : "No", "phone_number" : $("#input-phone-number").val()};

    if ($("#input-connect-on-start").is(":checked")) {
      cellularParams.connect_on_start = "Yes";
    }
    Debug.log([$scope.cellularInfo, $scope.cellularInfo.params.mode, $("#input-apn").val(), $("#input-requires-auth").is(":checked"), $("#input-user").val(), $("#input-pass").val()],'saveCellularSettings');
    if ($scope.cellularInfo.params.mode == "GSM") {
      cellularParams.apn = $("#input-apn").val();
      Debug.log($("#input-requires-auth").is(":checked"),'#input-requires-auth');
      if ($("#input-requires-auth").is(":checked")) {
        cellularParams.requires_auth = "Yes";
      }
      else {
        cellularParams.requires_auth = "No";
      }

      if (cellularParams.requires_auth == "Yes") {
        cellularParams.user = $("#input-user").val();
        cellularParams.pass = $("#input-pass").val();
      }
    }
    Debug.log(cellularParams,'cellularParams');
    if(cellularParams.requires_auth == "Yes" && (cellularParams.user.length == 0 || cellularParams.pass.length == 0)){
      msg = 'Cellular Settings Not Saved! '+'Required authorization credentials not supplied.';
      msgType = 'error';
      $scope.setSystemMsg(msg, msgType);
    }
    else {
      lpApi.modemSet(cellularParams);

      $resultScope = lpApi.go('', $scope);

      var msg, msgType;
      if ($resultScope.modemSet.success == true) {
        msg = 'Cellular Setting Saved Successfully!';
        msgType = 'success';
      }
      else {
        msg = 'Cellular Settings Not Saved! '+$resultScope.modemSet.errorMessage;
        msgType = 'error';
      }
      Debug.log(msg,'cellular');
      $scope.setSystemMsg(msg, msgType);
    }
  };

  $scope.updateCtrlActions = function(){
    $scope.ngShowModemActivate();
    $scope.ngShowModemConnect();
    $scope.ngShowModemDisconnect();
  };

  // Executions
  $scope.clearSystemMsg();

  $scope.assertAuthentication();

  $scope.menuItemSelect($scope, 'gateway');

  $scope.populateCellularInfo();

  $scope.populateModemInfo();

  $scope.populateModemDiagnostic();
};

CellularCtrl.$inject = ['$scope', 'lpApi', '$http'];

CellularCtrl.modemActivate = function() {
  self.scope.accessModemActivate();
};

CellularCtrl.modemConnect = function() {
  self.scope.accessModemConnect();
};

CellularCtrl.modemDisconnect = function() {
  self.scope.accessModemDisconnect();
};

CellularCtrl.prototype.ctrlActions = {
  items : [{
    href : '/cellular/modemDisconnect',
    template : 'partials/cellular.html'
  },{
    href : '/cellular/modemConnect',
    template : 'partials/cellular.html'
  },{
    href : '/cellular/modemDisconnect',
    template : 'partials/cellular.html'
  }]
};

CellularCtrl.prototype.mainActions = {
  items : [{
    href : '/editCellular',
    template : 'partials/editCellular.html'
  }]
};

CellularCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};
