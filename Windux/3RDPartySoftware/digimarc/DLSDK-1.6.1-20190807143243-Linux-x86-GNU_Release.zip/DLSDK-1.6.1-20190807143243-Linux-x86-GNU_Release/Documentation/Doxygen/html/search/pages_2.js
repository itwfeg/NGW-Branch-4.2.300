var searchData=
[
  ['embedding_20guide',['Embedding Guide',['../EmbeddingGuide.html',1,'']]]
];
