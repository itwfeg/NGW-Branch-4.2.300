var CloudlinkCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded CloudlinkCtrl','cloudlink');
  // Preperations
  lpApi.cloudlinkInfo().cloudlinkRegistrationHWList().tunnelInfo();

  $('#loading').show();
  $('#content-container').addClass('ng-cloak');
  Debug.log('Loading display '+$('#loading').css('display'));
  $http.post(lpApi.getUrl(''), lpApi.getPayload())
    .error($scope.errorCallback).success(function(a,b,c,d){
      $scope.successCallback(a,b,c,d);
      $scope.populateCloudLinkInfo();
      $scope.populateTunnelInfo();
    });

  // Properties
  $scope.mainActions = [{
    id : 'main-action-editCloudlink',
    href : '#/editCloudlink',
    aClasses: "gray-button",
    text: 'Edit cloudlink'
  }];

  // Functions
  $scope.onChangeProxyType = function() {
    switch($('#input-proxy-type').val()){
      case 'SOCKS4(a)':
        $scope.block_proxy_address = true;
        $scope.block_proxy_user = true;
        $scope.block_proxy_pass = false;
        break;
      case 'SOCKS5':
      case 'HTTP':
        $scope.block_proxy_address = true;
        $scope.block_proxy_user = true;
        $scope.block_proxy_pass = true;
        break;
      case 'None':
      default:
        $scope.block_proxy_address = false;
        $scope.block_proxy_user = false;
        $scope.block_proxy_pass = false;
        break;
    }
  };

  $scope.populateCloudLinkInfo = function() {
    if ($scope.cloudlinkInfo != undefined && $scope.cloudlinkInfo.params != undefined) {
      Debug.log($scope.cloudlinkInfo,'cloudlinkInfo');
      if ($scope.cloudlinkInfo.params.proxy_type == undefined) {
        $scope.cloudlinkInfo.params.proxy_type = 'None';
      }
      $scope.onChangeProxyType();
    }
    return false;
  };

  $scope.populateTunnelInfo = function() {
    if ($scope.tunnelInfo != undefined && $scope.tunnelInfo.params != undefined) {
      Debug.log($scope.tunnelInfo,'tunnelInfo');
      if ($scope.tunnelInfo.params.inactivity_timeout == undefined) {
        $scope.tunnelInfo.params.inactivity_timeout = 0;
      }
    }
    return false;
  };

  $scope.saveCloudlinkSettings = function(){
    var cloudlink_set_params = {
      registration_server: $('#input-registration-server').val(),
      registration_hwid: $('#input-registration-hwid').val(),
      proxy_type: $('#input-proxy-type').val(),
      proxy_address: $('#input-proxy-address').val(),
      proxy_user: $('#input-proxy-user').val(),
      proxy_pass: $('#input-proxy-pass').val()
    };

    var tunnel_set_params = {
      allow_management: ($("#input-allow-management:checked").val()) ? 'Yes' : 'No',
      allow_ssh: ($("#input-allow-ssh:checked").val()) ? 'Yes' : 'No',
      allow_raw: ($("#input-allow-raw:checked").val()) ? 'Yes' : 'No',
      inactivity_timeout: ($('#input-inactivity-timeout').val() * 1000).toString()
    };

    lpApi.cloudlinkSet(cloudlink_set_params);
    lpApi.tunnelSet(tunnel_set_params);

    $resultScope = lpApi.go('', $scope);

    var msg, msgType;
    if ($resultScope.cloudlinkSet.success == true && $resultScope.tunnelSet.success == true) {
      msg = 'CloudLINK Changes Saved Successfully!';
      msgType = 'success';
    }
    else if ($resultScope.cloudlinkSet.success == false || $resultScope.tunnelSet.success == false ) {
      msg = 'CloudLINK Changes Not Saved!';
      msgType = 'error';
      if($resultScope.cloudlinkSet.success == false){
        msg += ' '+$resultScope.cloudlinkSet.errorMessage;
      }
      if($resultScope.tunnelSet.success == false){
        msg += ' '+$resultScope.tunnelSet.errorMessage;
      }
    }
    Debug.log(msg,'cloudlink');
    $scope.setSystemMsg(msg, msgType);
  };

  // Executions
  $scope.clearSystemMsg();

  $scope.assertAuthentication();

  $scope.menuItemSelect($scope, 'gateway');

  $scope.populateCloudLinkInfo();

  $scope.populateTunnelInfo();
};

CloudlinkCtrl.$inject = ['$scope', 'lpApi', '$http'];

CloudlinkCtrl.prototype.ctrlActions = {
  items : [{
    href : '',
    template : ''
  }]
};

CloudlinkCtrl.prototype.mainActions = {
  items : [{
    href : '/editCloudlink',
    template : 'partials/editCloudlink.html'
  }]
};

CloudlinkCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};
