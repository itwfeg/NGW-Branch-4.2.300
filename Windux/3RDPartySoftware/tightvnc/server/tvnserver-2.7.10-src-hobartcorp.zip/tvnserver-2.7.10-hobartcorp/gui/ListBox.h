// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _LIST_BOX_H_
#define _LIST_BOX_H_

#include "Control.h"
#include "util/StringStorage.h"

class ListBox : public Control
{
public:
  ListBox();
  ~ListBox();
public:
  void addString(const TCHAR *str);
  void addString(const TCHAR *str, void *tag);
  void getItemText(int index, StringStorage *storage);
  void setItemText(int index, const TCHAR *str);
  void insertString(int index, const TCHAR *str);
  void insertString(int index, const TCHAR *str, LPARAM data);
  void appendString(const TCHAR *str, LPARAM data);
  void setItemData(int index, LPARAM data);
  void removeString(int index);
  int getSelectedIndex();
  int getTopIndex();
  void setTopIndex(int index);
  void setSelectedIndex(int index);
  LPARAM getItemData(int index);
  int getCount();
  void clear();
};

#endif
