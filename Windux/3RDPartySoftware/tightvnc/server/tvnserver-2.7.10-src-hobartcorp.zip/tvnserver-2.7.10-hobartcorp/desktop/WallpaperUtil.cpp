// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "WallpaperUtil.h"
#include "win-system/Environment.h"
#include "server-config-lib/Configurator.h"

WallpaperUtil::WallpaperUtil(LogWriter *log)
: m_log(log)
{
  Configurator::getInstance()->addListener(this);
}

WallpaperUtil::~WallpaperUtil()
{
  Configurator::getInstance()->removeListener(this);

  try {
    Environment::restoreWallpaper(m_log);
    m_log->info(_T("Wallpaper was successfully restored"));
  } catch (Exception &e) {
    m_log->error(e.getMessage());
  }
}

void WallpaperUtil::onConfigReload(ServerConfig *serverConfig)
{
  updateWallpaper();
}

void WallpaperUtil::updateWallpaper()
{
  try {
    ServerConfig *srvConf = Configurator::getInstance()->getServerConfig();
    if (srvConf->isRemovingDesktopWallpaperEnabled()) {
      Environment::disableWallpaper(m_log);
      m_log->info(_T("Wallpaper was successfully disabled"));
    } else {
      Environment::restoreWallpaper(m_log);
      m_log->info(_T("Wallpaper was successfully restored"));
    }
  } catch (Exception &e) {
    m_log->error(e.getMessage());
  }
}
