// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDOWMESSAGEHANDLER_H__
#define __WINDOWMESSAGEHANDLER_H__

class WindowMessageHandler
{
public:
  // This function must return true if a message has been processed.
  virtual bool processMessage(UINT message, WPARAM wParam, LPARAM lParam) = 0;
};

#endif // __WINDOWMESSAGEHANDLER_H__
