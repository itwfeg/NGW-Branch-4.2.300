# Display sys.path
import sys

print("sys.path=", sys.path)



