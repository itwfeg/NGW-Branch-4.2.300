// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINCUSTOMD3D11TEXTURE2D_H__
#define __WINCUSTOMD3D11TEXTURE2D_H__

#include "WinD3D11Texture2D.h"

#include <d3d11.h>
#include <DXGI1_2.h>

class WinCustomD3D11Texture2D
{
public:
  // Initializes ID3D11Texture2D compatible to textures returned from the AcquireNextFrame() function.
  WinCustomD3D11Texture2D(ID3D11Device *device, UINT width, UINT height);
  virtual ~WinCustomD3D11Texture2D();

  ID3D11Texture2D *getTexture() const;

private:
  class Texture2DDescInitializer
  {
  public:
    Texture2DDescInitializer(UINT width, UINT height);

    D3D11_TEXTURE2D_DESC *getDesc();
  private:
    D3D11_TEXTURE2D_DESC m_desc;
  };

  Texture2DDescInitializer m_textDescInitializer;
  WinD3D11Texture2D m_textureWrapper;
};

#endif // __WINCUSTOMD3D11TEXTURE2D_H__
