// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDOWSINPUTBLOCKER_H__
#define __WINDOWSINPUTBLOCKER_H__

#include "util/CommonHeader.h"
#include "thread/Thread.h"
#include "thread/LocalMutex.h"
#include "win-system/WinTimeMillis.h"
#include "win-system/WindowsEvent.h"
#include "InputBlocker.h"
#include "log-writer/LogWriter.h"

// Only one instance of this class may be created.

class WindowsInputBlocker : public InputBlocker, protected Thread
{
public:
  WindowsInputBlocker(LogWriter *log);
  virtual ~WindowsInputBlocker();

  // This functions set/unset blocks on a local keyboard and mouse.
  virtual void setKeyboardBlocking(bool block);
  virtual void setMouseBlocking(bool block);
  // This functions set/unset blocks on a local keyboard and mouse on the
  // timeInterval interval from a last software event generation.
  virtual void setSoftKeyboardBlocking(bool block, unsigned int timeInterval);
  virtual void setSoftMouseBlocking(bool block, unsigned int timeInterval);

  virtual DateTime getLastInputTime() const;
  virtual void correctLastTime(DateTime newTime);

  virtual bool isRemoteInputAllowed();

protected:
  virtual void execute();
  virtual void onTerminate();

  bool setKeyboardFilterHook(bool block);
  bool setSoftKeyboardFilterHook(bool block);
  bool setMouseFilterHook(bool block);
  bool setSoftMouseFilterHook(bool block);

  static LRESULT CALLBACK lowLevelKeyboardFilterProc(int nCode,
                                                     WPARAM wParam,
                                                     LPARAM lParam);
  static LRESULT CALLBACK lowLevelSoftKeyboardFilterProc(int nCode,
                                                         WPARAM wParam,
                                                         LPARAM lParam);
  static LRESULT CALLBACK lowLevelMouseFilterProc(int nCode,
                                                  WPARAM wParam,
                                                  LPARAM lParam);
  static LRESULT CALLBACK lowLevelSoftMouseFilterProc(int nCode,
                                                      WPARAM wParam,
                                                      LPARAM lParam);

  static HHOOK m_hKeyboardHook;
  static HHOOK m_hSoftKeyboardHook;
  static HHOOK m_hMouseHook;
  static HHOOK m_hSoftMouseHook;

  static WindowsInputBlocker *m_instance;
  static LocalMutex m_instanceMutex;

  bool m_isKeyboardBlocking;
  bool m_isMouseBlocking;

  bool m_isSoftKeyboardBlocking;
  bool m_isSoftMouseBlocking;

  static unsigned int m_timeInterval;
  static DateTime m_lastInputTime;
  static LocalMutex m_lastInputTimeMutex;

  LogWriter *m_log;
};

#endif // __WINDOWSINPUTBLOCKER_H__
