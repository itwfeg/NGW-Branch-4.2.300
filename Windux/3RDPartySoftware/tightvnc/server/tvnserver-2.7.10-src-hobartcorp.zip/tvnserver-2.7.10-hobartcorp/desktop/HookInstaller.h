// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __HOOKINSTALLER_H__
#define __HOOKINSTALLER_H__

#include "util/CommonHeader.h"
#include "win-system/DynamicLibrary.h"

class HookInstaller
{
public:
  HookInstaller();
  ~HookInstaller();

  // Instals hooks to windowed applications.
  // targedWinHwnd - is hwnd to a target window that will receive
  // hooked messages.
  void install(HWND targedWinHwnd);
  // Uninstals hooks from windowed applications.
  void uninstall();

private:
  static const TCHAR LIBRARY_NAME[];
  static const char SET_HOOK_FUNCTION_NAME[];
  static const char UNSET_HOOK_FUNCTION_NAME[];

  DynamicLibrary m_lib;
  FARPROC m_pSetHook;
  FARPROC m_pUnSetHook;
};

#endif // __HOOKINSTALLER_H__
