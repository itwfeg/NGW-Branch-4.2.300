// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDSENDERMSGDEFS_H__
#define __UPDSENDERMSGDEFS_H__

#include "util/inttypes.h"

class UpdSenderClientMsgDefs
{
public:
  static const UINT32 RFB_VIDEO_FREEZE = 152;
  const static char RFB_VIDEO_FREEZE_SIG[];
};

#endif // __UPDSENDERMSGDEFS_H__
