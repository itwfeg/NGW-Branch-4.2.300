#!/bin/sh

export CC=arm-linux-gnueabihf-gcc
export CXX=arm-linux-gnueabihf-g++

NODE_MODULES=node_modules
if [ -d $NODE_MODULES ]; then
	rm -r $NODE_MODULES
fi

#Compile the node.js application modules for ARM for deployment. (Relieves the target of Compiling/Downloading the modules itself)
npm --arch=arm install

#cleanup
unset CC
unset CXX

