// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __SASUSERINPUT_H__
#define __SASUSERINPUT_H__

#include "UserInput.h"
#include "desktop-ipc/UserInputClient.h"

// This class delegates all inputs but the "ctrl+alt+del" under Vista or later
// it process by himself.
class SasUserInput : public UserInput
{
public:
  SasUserInput(UserInputClient *client, LogWriter *log);
  virtual ~SasUserInput();

  virtual void sendInit(BlockingGate *gate);
  virtual void setNewClipboard(const StringStorage *newClipboard);
  virtual void setMouseEvent(const Point *newPos, UINT8 keyFlag);
  virtual void setKeyboardEvent(UINT32 keySym, bool down);
  virtual void getCurrentUserInfo(StringStorage *desktopName,
                                  StringStorage *userName);
  virtual void getPrimaryDisplayCoords(Rect *rect);
  virtual void getDisplayNumberCoords(Rect *rect,
                                      unsigned char dispNumber);
  virtual void getNormalizedRect(Rect *rect);
  virtual void getWindowCoords(HWND hwnd, Rect *rect);
  virtual HWND getWindowHandleByName(const StringStorage *windowName);
  virtual void getApplicationRegion(unsigned int procId, Region *region);

private:
  UserInputClient *m_client;

  bool m_ctrlPressed;
  bool m_altPressed;
  bool m_underVista;
  LogWriter *m_log;
};

#endif // __SASUSERINPUT_H__
