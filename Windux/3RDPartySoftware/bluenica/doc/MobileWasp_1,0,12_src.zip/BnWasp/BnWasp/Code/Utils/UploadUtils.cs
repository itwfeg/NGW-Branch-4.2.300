﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

namespace BnWasp
{
	public static class UploadUtils
	{
		private static readonly List<string> m_gateways;
		private static int m_crrGateway;

		static UploadUtils()
		{
			m_gateways = new List<string>();
			m_gateways.Add(@"http://novotrace.com");
			m_gateways.Add(@"http://bn-gateway.com");

			m_crrGateway = 0;
		}

		#region XMIT record

		// standard record header
		private const byte RDB_REC_SYNTAX = 1;
		private const byte RDB_REC_HDR_LEN = 10;

		// record types
		private const byte RECTYPE_TRANSMISSION = 2;

		// Transmission records subtypes
		private const byte RECSUBTYPE_XMIT_SINGLE_SENSOR = 1;
		private const byte RECSUBTYPE_XMIT_WASP_STATS = 2;
		private const byte RECSUBTYPE_XMIT_WASP_LOG = 3;
		private const byte RECSUBTYPE_XMIT_ADV_TEMP_DATA = 4;
		private const byte RECSUBTYPE_XMIT_ADV_DATA = 5;
		private const byte RECSUBTYPE_XMIT_FULL_ADV = 6;

		// Wasp XMIT record
		private const int XmitWaspBaseSize = 16;
		private const int XmitPayloadSize = XmitWaspBaseSize + WaspStats.WaspStatsSize;
		private const int XmitRecordSize = RDB_REC_HDR_LEN + XmitPayloadSize;


		public static void BuildXmitHeader(MemoryStream ms, long localAddress, WaspStats stats)
		{
			// Xmit record header
			ms.WriteByte(RDB_REC_SYNTAX);
			ms.WriteByte(0); // record ID - N/A in XMIT record
			ms.WriteByte(0);
			ms.WriteByte(0);
			ms.WriteByte(RECTYPE_TRANSMISSION);
			ms.WriteByte(RECSUBTYPE_XMIT_FULL_ADV);
			ms.WriteByte(0); // internal clock - N/A in XMIT record
			ms.WriteByte(0);
			ms.WriteByte(0);
			ms.WriteByte(XmitPayloadSize);

			// Payload: Base + optional statistics
			// Sensor ID - N/A in adv. data
			for (int i = 0; i < 6; i++)
				ms.WriteByte(0);

			// WaSP ID
			byte[] bff = new byte[6];
			BinUtils.TagIdToPayloadBytes(localAddress, bff, 0);
			ms.Write(bff, 0, 6);

			// UTC
			UInt32 epoch = Epoch.GetCurrentEpoch();
			BinUtils.UInt32ToPayloadBytes(epoch, bff, 0);
			ms.Write(bff, 0, 4);

			// Wasp statistics
			bff = new byte[WaspStats.WaspStatsSize];
			stats.BuildStatsBuffer(bff);
			ms.Write(bff, 0, WaspStats.WaspStatsSize);
		}

		#endregion

		#region Data sending

		public static bool SendCollectedData(MemoryStream ms, long tagId, WaspStats stats, bool isDownload)
		{
			byte[] resp = null;
			byte[] bytes = ms.GetBuffer(); // access to the internal byte buffer

			// calculate and append simple CRC
			UInt32 crc = 0;
			for (int i = 0; i < ms.Length; i++)
			{
				crc += bytes[i];
			}
			byte[] bff = new byte[6];
			BinUtils.UInt32ToPayloadBytes(crc, bff, 0);
			ms.Write(bff, 0, 4);

			// send
			bytes = ms.ToArray();  // only used bytes in the buffer
			string url = BuildUrl(tagId, bytes.Length, isDownload);
			resp = HttpUtils.PostDataToServer(url, bytes, null);

			if (resp == null)
				stats.AddConnErrors();

			if (!CheckRespIsSuccess(resp))
			{
				UseNextGateway();
				url = BuildUrl(tagId, bytes.Length, isDownload);
				resp = HttpUtils.PostDataToServer(url, bytes, null);
			}

			return CheckRespIsSuccess(resp);
		}

		private static string BuildUrl(long tagId, int dataSize, bool isDownload)
		{
			string name = BuildFName(tagId, dataSize, isDownload);
			string sid = BuildRandomSessionId();
			string url = string.Format("{0}/BinPost.ashx?dest=1&opt=1&fname={1}&sid={2}&crc=4", m_gateways[m_crrGateway], name, sid);
			return url;
		}

		/// <summary>
		/// Builds the fname - upload comment
		/// </summary>
		/// <returns>Data file comment.</returns>
		/// <param name="tagId">Tag identifier.</param>
		/// <param name = "dataSize">Number of bytes to send</param>
		/// <param name = "isDownload">Download/discovery flag</param>
		private static string BuildFName(long tagId, int dataSize, bool isDownload)
		{
			// WF250_g1_AAA000001278_fb_s1165
			// g - gateway index
			// fb - full broadcast
			// sd - sensor download
			string fname = string.Format("Mobile_g{0}_{1}_{2}_s{3}.dat", 
				               m_crrGateway, 
				               AddressUtils.LongToHex((long)tagId, AddressUtils.HexAddressSyntax.Plain), 
				               isDownload ? "dl" : "fb",
				               dataSize - 4); // -4 - exclude CRC size

			return fname;
		}

		private static string BuildRandomSessionId()
		{
			StringBuilder sb = new StringBuilder(4);
			Random rnd = new Random();
			for (int i = 0; i < 4; i++)
			{
				sb.Append((char)('A' + rnd.Next(26)));
			}
			return sb.ToString();
		}

		private static void UseNextGateway()
		{
			m_crrGateway++;
			if (m_crrGateway >= m_gateways.Count)
				m_crrGateway = 0;
		}

		private static bool CheckRespIsSuccess(byte[] resp)
		{
			UploadResponse ur = new UploadResponse(resp);
			System.Diagnostics.Debug.WriteLine(ur.Summary);

			return ur.Status == UploadResponse.StatusSuccess;
		}

		#endregion


	}
}

