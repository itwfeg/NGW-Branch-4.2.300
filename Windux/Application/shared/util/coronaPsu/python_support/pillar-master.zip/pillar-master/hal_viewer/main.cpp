#include <iostream>
#include <stdio.h>

#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#define MAX_BUFFER_SZ (64 << 10)

void hex_dump(char *desc, void *addr, int len)
{
    int i;
    unsigned char buff[17];
    unsigned char *pc = (unsigned char *) addr;

    // Output description if given.
    if (desc != NULL)
        printf("%s:\n", desc);

    if (len == 0)
    {
        printf("  ZERO LENGTH\n");
        return;
    }
    if (len < 0)
    {
        printf("  NEGATIVE LENGTH: %i\n", len);
        return;
    }

    // Process every byte in the data.
    for (i = 0; i < len; i++)
    {
        // Multiple of 16 means new line (with line offset).

        if ((i % 16) == 0)
        {
            // Just don't print ASCII for the zeroth line.
            if (i != 0)
                printf("  %s\n", buff);

            // Output the offset.
            printf("  %04x ", i);
        }

        // Now the hex code for the specific character.
        printf(" %02x", pc[i]);

        // And store a printable ASCII character for later.
        if ((pc[i] < 0x20) || (pc[i] > 0x7e))
            buff[i % 16] = '.';
        else
            buff[i % 16] = pc[i];
        buff[(i % 16) + 1] = '\0';
    }

    // Pad out last line if not exactly 16 characters.
    while ((i % 16) != 0)
    {
        printf("   ");
        i++;
    }

    // And print the final ASCII bit.
    printf("  %s\n", buff);
}

int main(int argc, char **argv)
{
    struct sockaddr_un remote;
    if (argc < 2)
    {
        std::cerr << "Usage:" << std::endl;
        std::cerr << argv[0] << " <socket filename>" << std::endl;
        return -1;
    }

    int unix_fd = socket(AF_UNIX, SOCK_SEQPACKET, 0);
    if (unix_fd < 0)
    {
        std::cerr << "An error occurred while opening to the socket: " << errno << " (" << strerror(errno) << ") " << std::endl;
        return unix_fd;
    }

    remote.sun_family = AF_UNIX;
    strcpy(remote.sun_path, argv[1]);
    int status = connect(unix_fd, (struct sockaddr *) &remote, sizeof(struct sockaddr_un));
    if (status < 0)
    {
        std::cerr << "An error occurred while connecting to the socket: " << errno << " (" << strerror(errno) << ") " << std::endl;
        close(unix_fd);
        return -1;
    }

    /* Continuously receive data while the socket is open. */
    status = 0;
    uint8_t buffer[MAX_BUFFER_SZ];
    while (status >= 0)
    {
        int n = recv(unix_fd, buffer, sizeof(buffer), 0);
        if (n <= 0)
        {
            if (errno == EINTR)
                continue;

            status = -1;//done, exit.
        }

        if (n > 0)
            hex_dump((char *) "Packet Received", buffer, n);

        status = 0;
    }

    close(unix_fd);
    std::cout << "[INFO]: Socket closed" << std::endl;

    return 0;
}

