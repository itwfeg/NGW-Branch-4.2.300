//
// Created by collin on 9/21/17.
//

#ifndef PILLAR_HAL_INTERFACE_H
#define PILLAR_HAL_INTERFACE_H


#include <thread>
#include <functional>
#include <atomic>

typedef std::function<void(const std::string&)> modbus_callback;

class hal_interface
{
protected:
    int serial_fd;

    std::atomic_flag modbus_listener_run;
    std::thread modbus_listener;

public:
    hal_interface();
    virtual ~hal_interface();

    int connect(const std::string& port);
    int get_modbus_packet(std::string& packet);

    int modbus_start_listen(modbus_callback callback);
    int modbus_stop_listen();
};


#endif //PILLAR_HAL_INTERFACE_H
