// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __DESKTOPWINIMPL_H__
#define __DESKTOPWINIMPL_H__

#include "util/CommonHeader.h"
#include "DesktopConfigLocal.h"
#include "desktop/WallpaperUtil.h"
#include "thread/GuiThread.h"
#include "DesktopBaseImpl.h"
#include "Win32ScreenDriverFactory.h"
#include "log-writer/LogWriter.h"

class DesktopWinImpl : public GuiThread, public DesktopBaseImpl
{
public:
  DesktopWinImpl(ClipboardListener *extClipListener,
             UpdateSendingListener *extUpdSendingListener,
             AbnormDeskTermListener *extDeskTermListener,
             LogWriter *log);
  virtual ~DesktopWinImpl();

protected:
  virtual void execute();
  virtual void onTerminate();

private:
  void freeResource();

  // Writes some desktop info to log.
  void logDesktopInfo();

  virtual bool isRemoteInputTempBlocked();
  virtual void applyNewConfiguration();

  Win32ScreenDriverFactory m_scrDriverFactory;

  WallpaperUtil *m_wallPaper;

  DesktopConfigLocal *m_deskConf;

  LogWriter *m_log;
};

#endif // __DESKTOPWINIMPL_H__
