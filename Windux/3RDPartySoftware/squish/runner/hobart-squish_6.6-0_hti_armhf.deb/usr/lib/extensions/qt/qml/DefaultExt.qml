import Qt 4.7
import com.froglogic.squish.qml 0.1

SquishHook {
  priority: 100

    function isLayoutType( item ) {
        return ( isQmlType( item, "Column" ) ||
        isQmlType( item, "Flow" ) ||
        isQmlType( item, "Grid" ) ||
        isQmlType( item, "Row" ) );
    }

  function containerFor( item ) {
      var parents = [];
      for ( var obj = item.parent; obj != null; obj = obj.parent ) {
          parents.push(obj);
          var type = qmlType( obj );
          if ( isQmlType( obj, "Flickable" ) ) {
              // Only use flickable as a container if we are not
              // the only item inside. For single items, the flickable serves
              // as a QScrollArea which is not useful for object names.
              if ( isQmlType( obj, "ListView" ) || isQmlType( obj, "GridView" ) ) {
                  // List or Grid backed by a model (list, ListModel etc.)
                  var model = obj.model;
                  if ( isQmlType( model, "QAbstractItemModel" ) ||
                    model.length > 1 ||
                    model.count > 1 ) {
                      if ( parents.length > 2 ) {
                          // parents: [ ..., viewItem, contentItem, flickable ]
                          // item is a child of viewItem
                          var viewItem = parents[ parents.length - 3 ];
                          if ( viewItem != item ) {
                              return viewItem;
                          }
                      } else {
                          // parents: [ contentItem, flickable ]
                          // item is a direct child of contentItem
                          return obj;
                      }
                  }
              } else if ( obj.contentItem ) {
                  var flickChildren = obj.contentItem.children;
                  if ( ( flickChildren.length > 1 ) ||
                      ( flickChildren.length == 1 &&
                          isLayoutType( flickChildren[0] ) ) ) {
                      return obj;
                  }
              }
              // item is the only one inside the flickable
              return null;
          } else if ( isQmlType( obj, "Flipable" ) ) {
              return obj;
          }
      }
      return unhandled;
  }

  function isIgnored( item ) {
      var itemType = qmlType( item );

      /* Keep items that have a custom type (declared at runtime) */
      if ( isCustomQmlType( item ) ) {
          return false;
      }

      /* Keep top-level items */
      var itemParent = item.parent;
      if ( itemParent == null ) {
          return false;
      }

      /* Keep top-level items of delegates */
      if ( isQmlType( itemParent, "GridView" ) ||
              isQmlType( itemParent, "ListView" ) ||
              isQmlType( itemParent, "PathView" ) ) {
          return false;
      }

      var itemUrl = source( item );
      var itemParentUrl = source( itemParent );

      /*
       * When the source between item and parent changes, item is the top
       * of a component.
       * When the item source is empty, it belongs to the parent component.
       *
       * Do not ignore component its top-level item
       */
      if ( itemUrl && itemUrl != "" && itemUrl != itemParentUrl ) {
          return false;
      }

      // Pure declarative items that are not subclasses in any way are
      // always trivial, they are not really drawn on screen and merely act
      // as a container object, not suitable for interaction
      if ( itemType == 'Item' ) {
          return true;
      }

      /* Ignore layout items */
      if ( isLayoutType( item ) ) {
          return true;
      }

      /* Keep what is not considered */
      return unhandled;
  }

  function isItemReady( item ) {
      while ( item != null ) {
          if ( isQmlType( item, "Flickable" ) && item.moving ) {
              // An Item is not ready if it or one of its parents
              // is a flickable that is currently moving
              return false;
          } else if ( isQmlType( item, "PathView" ) && ( item.moving || item.flicking ) ) {
              // Wait for flicked or dragged PathViews
              return false;
          }

          item = item.parent
      }
      return unhandled;
  }

  function listViewIndex( item ) {
      if ( item.parent ) {
          var view = item.parent.parent;
          if ( view && ( isQmlType( view, "ListView" ) ||
                isQmlType( view, "GridView" ) ) ) {
              return view.indexAt( item.x, item.y );
          }
      }
      return -1;
  }

  function extraPropertiesFor( item ) {
      if ( listViewIndex( item ) != -1 ) {
          return ['index'];
      }
      return unhandled;
  }

  function propertyFor( item, property ) {
      if ( property == 'backgroundcolor' ) {
          if ( isQmlType( item, 'Rectangle' ) ) {
              return unhandled;
          }
          for ( var obj = item.parent; obj != null; obj = obj.parent ) {
              if ( isQmlType( obj, 'Rectangle' ) ) {
                  return obj.color;
              }
          }
      } else if ( property == 'index' ) {
          var idx = listViewIndex( item );
          if ( idx != -1 )
            return idx;
      }
      return unhandled;
  }
}
