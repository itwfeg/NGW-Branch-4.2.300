//
// Created by collin on 8/10/17.
//
#include <gtest/gtest.h>
#include "ipc_server.h"

/// @brief Test a typical filename for the unix socket works as expected.
TEST(IPC_SERVER_TEST, filename_test)
{
    std::string socket_fn = "typical.unix";
    ipc_server dut(socket_fn);

    ASSERT_STREQ(socket_fn.c_str(), dut.getSocket_filename().c_str());
}

/// @brief Test an empty filename provided to the constructor is replaced with a default string.
TEST(IPC_SERVER_TEST, filename_empty_test)
{
    std::string socket_fn = "";
    ipc_server dut(socket_fn);

    ASSERT_STREQ(DEFAULT_SOCKET_FILENAME, dut.getSocket_filename().c_str());
}
