// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "GateKicker.h"
#include "thread/AutoLock.h"

GateKicker::GateKicker(BlockingGate *gate)
: m_gate(gate)
{
  resume();
}

GateKicker::~GateKicker()
{
  terminate();
  wait();
}

void GateKicker::onTerminate()
{
  m_sleeper.notify();
}

void GateKicker::execute()
{
  while (!isTerminating()) {
    m_sleeper.waitForEvent(500);
    if (!isTerminating()) {
      try {
        AutoLock al(m_gate);
        m_gate->writeUInt8(255);
      } catch (...) {
      }
    }
  }
}
