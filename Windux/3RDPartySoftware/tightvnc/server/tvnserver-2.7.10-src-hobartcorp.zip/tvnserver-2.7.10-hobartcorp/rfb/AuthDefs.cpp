// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "rfb/AuthDefs.h"

const char *const AuthDefs::SIG_NONE = "NOAUTH__";
const char *const AuthDefs::SIG_VNC = "VNCAUTH_";
const char *const AuthDefs::SIG_EXTERNAL = "XTRNAUTH";

UINT32 SecurityDefs::convertFromAuthType(UINT32 authType)
{
  switch (authType) {
  case AuthDefs::NONE:
    return NONE;
  case AuthDefs::VNC:
    return VNC;
  }

  return INVALID; // no corresponding authentication method
}

UINT32 AuthDefs::convertFromSecurityType(UINT32 securityType)
{
  switch (securityType) {
  case SecurityDefs::NONE:
    return NONE;
  case SecurityDefs::VNC:
    return VNC;
  }

  return 0; // no corresponding authentication method
}
