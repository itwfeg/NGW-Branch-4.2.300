// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "SecurityPipeClient.h"
#include "io-lib/DataInputStream.h"
#include "io-lib/DataOutputStream.h"
#include "win-system/NamedPipe.h"

SecurityPipeClient::SecurityPipeClient(Channel *tempPublChan)
: m_secChannel(0)
{
  try {
    DataInputStream svcInput(tempPublChan);
    DataOutputStream svcOutput(tempPublChan);
    // Send our process id
    svcOutput.writeUInt32(GetCurrentProcessId());
    // Get working channel.
    HANDLE pipeHandle = (HANDLE)svcInput.readUInt64();
    m_secChannel = new NamedPipe(pipeHandle, false);
    DataOutputStream output(m_secChannel);
    // Send sure message.
    output.writeUInt8(255);
  } catch (...) {
    if (m_secChannel != 0) delete m_secChannel;
    throw;
  }
}

SecurityPipeClient::~SecurityPipeClient()
{
}

Channel *SecurityPipeClient::getChannel()
{
  Channel *chan = m_secChannel;
  m_secChannel = 0;
  return chan;
}
