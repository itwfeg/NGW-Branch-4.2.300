// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _RFB_OUTPUT_GATE_H_
#define _RFB_OUTPUT_GATE_H_

#include "io-lib/DataOutputStream.h"
#include "io-lib/BufferedOutputStream.h"

#include "thread/LocalMutex.h"

/**
 * Gate for writting rfb messages.
 *
 * @features: gate is synchonized (can be locked and unlocked, supports data buffering, and writting
 * typized data).
 * @remark: after every message you want to send to must manually call flush() cause
 * "autoflush on unlock" is removed.
 * @author enikey.
 */
class RfbOutputGate : public DataOutputStream,
                      public LocalMutex
{
public:
  /**
   * Creates new rfb output gate.
   * @param stream real output stream.
   */
  RfbOutputGate(OutputStream *stream);
  /**
   * Deletes rfb output gate.
   */
  virtual ~RfbOutputGate();

  /**
   * Flushes inner buffer to real output stream.
   * @throws IOException on error.
   */
  virtual void flush() throw(IOException);

private:
  /**
   * Tunnel that adds buffering.
   */
  BufferedOutputStream *m_tunnel;
};

#endif
