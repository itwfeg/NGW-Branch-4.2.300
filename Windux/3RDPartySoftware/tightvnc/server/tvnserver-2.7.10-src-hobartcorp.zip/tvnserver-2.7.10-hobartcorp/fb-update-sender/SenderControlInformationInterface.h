// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __SENDERCONTROLINFORMATIONINTERFACE_H__
#define __SENDERCONTROLINFORMATIONINTERFACE_H__

// Provide necessary information to send a update.
class SenderControlInformationInterface
{
public:
  virtual void onGetViewPort(Rect *viewRect, bool *shareApp, Region *shareAppRegion) = 0;
};

#endif // __SENDERCONTROLINFORMATIONINTERFACE_H__
