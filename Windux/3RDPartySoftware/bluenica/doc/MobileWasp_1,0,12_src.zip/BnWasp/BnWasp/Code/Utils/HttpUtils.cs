﻿using System;
using System.IO;
using System.Net;
using System.Collections.Generic;

namespace BnWasp
{
	public static class HttpUtils
	{
		/// <summary>
		/// A blocking function POSTing any data to server.
		/// Example:
		/// 	byte[] resp = HttpUtils.PostDataToServer("http://novotrace.com/BinPost.ashx?dest=4&opt=1&fname=GraphColors", bytes, null);
		/// </summary>
		/// <returns>Server response or null on connection failure.</returns>
		/// <param name="url">Complete URL with parameterts</param>
		/// <param name="postBytes">Bytes to POST</param>
		/// <param name="callback">Optional callback guaranteed to be invoked after the data transmission</param>
		public static byte[] PostDataToServer(string url, byte[] postBytes, Action<byte[]> callback = null)
		{
			byte[] respBytes = null;

			try
			{
				WebRequest req = WebRequest.Create(url);
				req.ContentType = "application/x-www-form-urlencoded";
				req.Method = "POST";
				req.ContentLength = postBytes.Length;

				// write the data to the request stream
				Stream os = req.GetRequestStream();
				os.Write(postBytes, 0, postBytes.Length); 
				os.Close();

				// get the response
				WebResponse resp = req.GetResponse();
				if (resp == null)
					return null;

				// get the response stream and read the response
				StreamReader sr = new StreamReader(resp.GetResponseStream());           
				List<byte> result = new List<byte>((int)resp.ContentLength);
				int b = sr.Read();
				while (b >= 0)
				{
					result.Add((byte)b);
					b = sr.Read();
				}
				respBytes = result.ToArray();

				// close the streams
				sr.Close();
				resp.Close();
			}
			catch
			{
				respBytes = null;
			}

			if (callback != null)
			{
				try
				{
					callback(respBytes);
				}
				catch (Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message);					
				}
			}

			return respBytes;
		}

	}

}
