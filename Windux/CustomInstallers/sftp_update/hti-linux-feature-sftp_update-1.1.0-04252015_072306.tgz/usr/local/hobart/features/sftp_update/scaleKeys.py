import sys
import string
import os
import shellCommand
import file_io

''''Purpose: userspace interface to the software keys partition of the on board serial flash.
    This script will only handle the first block on the serial flash software keys partition 
    which will limit the amount of key data stored.
'''
keyFile = os.path.join("/","tmp")
CONST_PART_SIZE = 4096
BLANK_KEY = '\xff'

def readAllKeys():
    '''' read all the keys in the first block of the parition '''
    if os.path.exists(os.path.join("/","dev", "mtdblock6" )):
        try:

            # open the software keys partition 
            inFile = open(os.path.join("/","dev", "mtd6"), 'rb')

            # read the entire partition  
            partition = inFile.read(CONST_PART_SIZE)
            result = ('success', partition)
            
        except IOError, exception_details:
            result = ('error', 'Reading Keys partition failed: ' + ', Reason:' + exception_details[1])

    return result

def eraseAllKeys():

    cmd = []
    if os.name == "posix":
        cmd.append(os.path.join("/","usr","sbin","flash_eraseall"))
        cmd.append(os.path.join("/", "dev","mtd6"))
    else:
        # TODO:
        # need windows implementation
        pass

    exitCode, stdout, stderr = shellCommand.execute(cmd)
    if exitCode == 0:
        return ('success', None)
    else:
        return ('error', stderr)
    
def writeAllKeys(keys):
    '''' writes a key  to the fisrt available space in the scaleKeys partition '''

  # check if block device file exists for mtd6
    if os.path.exists(os.path.join("/","dev", "mtdblock6" )):

        try:

            #write the new key information to file
            outFile = open(os.path.join("/", "tmp", "keys.dat"),  'w')
            outFile.write(keys)
            outFile.close()

            # if blank, flash the image data to mtd6
            cmd = []

            if os.name == "posix":
                cmd.append(os.path.join("/","usr","sbin","flashcp"))
                cmd.append("/tmp/keys.dat")
                cmd.append(os.path.join("/", "dev", "mtd6"))
            else:
                # TODO:
                # need windows implementation
                pass

            exitCode, stdout, stderr = shellCommand.execute(cmd)

            if exitCode == 0:
                
                if os.name == "posix":
                    os.remove(os.path.join("/", "tmp", "keys.dat"))
                else:
                    # TODO:
                    # need windows implementation
                    pass
                
                result = ('success',  None)
                    
            else:
                resullt = ('error', 'flashcp command failed')
                
        except IOError, exception_details:

            result = ('error', 'Flashing Keys partition failed: ' + ', Reason:' + exception_details[1])

    return result
