var structDSM__KEEP__OUT__REGION =
[
    [ "Height", "structDSM__KEEP__OUT__REGION.html#a70e1879329b621be38e3bd7406110d1f", null ],
    [ "TopLeftX", "structDSM__KEEP__OUT__REGION.html#ab7f52eeb394bc84320f76fbd44cc7e24", null ],
    [ "TopLeftY", "structDSM__KEEP__OUT__REGION.html#a9ff5821e331a3d20104eb0f9e601809a", null ],
    [ "Width", "structDSM__KEEP__OUT__REGION.html#a30bb79e10cd737848fc7994cbed2af37", null ]
];