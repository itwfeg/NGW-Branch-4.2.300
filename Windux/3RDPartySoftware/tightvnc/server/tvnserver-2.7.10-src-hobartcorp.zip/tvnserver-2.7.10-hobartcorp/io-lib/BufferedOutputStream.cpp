// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "BufferedOutputStream.h"

BufferedOutputStream::BufferedOutputStream(OutputStream *output)
: m_dataLength(0)
{
  m_output = new DataOutputStream(output);
}

BufferedOutputStream::~BufferedOutputStream()
{
  try {
    flush();
  } catch (...) {
  } // try / catch.

  delete m_output;
}

size_t BufferedOutputStream::write(const void *buffer, size_t len)
{
  if (m_dataLength + len >= sizeof(m_buffer)) {
    flush();

    m_output->writeFully(buffer, len);
  } else {
    memcpy(&m_buffer[m_dataLength], buffer, len);

    m_dataLength += len;
  }

  return len;
}

void BufferedOutputStream::flush()
{
  m_output->writeFully(&m_buffer[0], m_dataLength);

  m_dataLength = 0;
}
