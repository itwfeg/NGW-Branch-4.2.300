﻿using Android.Bluetooth;

using System;

namespace BnWasp
{
	public class BNDevice
	{
		// input parameters
		public BluetoothDevice Peripheral { get; private set; }
		public byte[] ManufacturerData { get; private set; }
		public string Name { get; set; }
		public int Rssi { get; set; }

		// parsed out parameters
		public long Address { get; set; }
		public long PhysicalAddress { get; set; }
		public UInt32 RecId { get; set; }

		// AD sections in the scan record
		public const byte GapADTypeManufacturerSpecific = 0xFF; // Manufacturer Specific Data: first 2 octets contain the Company Identifier Code followed by the additional manufacturer specific data


		// 'scanRecord' contains the complete advertisement packet.
		public BNDevice(BluetoothDevice p, byte[] scanRecord, int rssi)
		{
			Peripheral = p;
			Name = p.Name;
			Rssi = rssi;

			// both addresses can be different (repeater case)
			PhysicalAddress = AddressUtils.HexToLong(p.Address);
			Address = PhysicalAddress; // default, but can be overwritten by the scan record parser

			try
			{
				ParseNameAndScanRecord(p.Name, scanRecord);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);	
			}
		}

		private void ParseNameAndScanRecord(string name, byte[] scanRecord)
		{
			Address = 0;
			RecId = 0;

			if (name.Length < 2 || name[1] != '#')
				return; // non-bluenica sensor

			if (scanRecord == null || scanRecord.Length < 17)
			{
				if (name.Length >= 15) // prototype sensor advertising only the name "B#9059AF287C9A"
				{
					string addr = name.Substring(3, 12);
					Address = AddressUtils.HexToLong(addr);
				}
				return;
			}

			// new style sensor, advertising temperature and other details
			int adLen;
			int adType;
			int pos = 0;
			int end = scanRecord.Length - 1;

			while (pos < end)
			{
				adLen = scanRecord[pos++]; // length of the next AD item
				if (adLen > 0)
				{
					adType = scanRecord[pos];

					if (adType == GapADTypeManufacturerSpecific)
					{
						ManufacturerData = new byte[adLen - 2];
						Array.Copy(scanRecord, pos + 1, ManufacturerData, 0, adLen - 2);
						if (ManufacturerData.Length >= 14)
						{
							// buffer start with the manufacturer code (right after LEN and FF)
							Address = BinUtils.PayloadBytesRevToTagId(ManufacturerData, 2);
							RecId = BinUtils.PayloadBytesToUInt24(ManufacturerData, 13);
						}
					}

					// go to the next item
					pos += adLen;
				}
				else
				{
					pos = end;
				}
			}
		}

	}
}

