// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "rfb/EncodingDefs.h"

const char *const EncodingDefs::SIG_RAW = "RAW_____";
const char *const EncodingDefs::SIG_COPYRECT = "COPYRECT";
const char *const EncodingDefs::SIG_RRE = "RRE_____";
const char *const EncodingDefs::SIG_HEXTILE = "HEXTILE_";
const char *const EncodingDefs::SIG_TIGHT = "TIGHT___";
const char *const EncodingDefs::SIG_ZRLE = "ZRLE____";

const char *const PseudoEncDefs::SIG_COMPR_LEVEL = "COMPRLVL";
const char *const PseudoEncDefs::SIG_X_CURSOR = "X11CURSR";
const char *const PseudoEncDefs::SIG_RICH_CURSOR = "RCHCURSR";
const char *const PseudoEncDefs::SIG_POINTER_POS = "POINTPOS";
const char *const PseudoEncDefs::SIG_LAST_RECT = "LASTRECT";
const char *const PseudoEncDefs::SIG_DESKTOP_SIZE = "NEWFBSIZ";
const char *const PseudoEncDefs::SIG_QUALITY_LEVEL = "JPEGQLVL";
