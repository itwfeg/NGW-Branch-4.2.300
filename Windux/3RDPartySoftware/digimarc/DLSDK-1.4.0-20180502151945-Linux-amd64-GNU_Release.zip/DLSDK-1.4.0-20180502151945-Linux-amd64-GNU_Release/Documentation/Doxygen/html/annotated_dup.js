var annotated_dup =
[
    [ "DSM_DATADESC", "structDSM__DATADESC.html", "structDSM__DATADESC" ],
    [ "DSM_EMBEDDER_OPTIONS", "structDSM__EMBEDDER__OPTIONS.html", "structDSM__EMBEDDER__OPTIONS" ],
    [ "DSM_GENERATOR_OPTIONS", "structDSM__GENERATOR__OPTIONS.html", "structDSM__GENERATOR__OPTIONS" ],
    [ "DSM_KEEP_OUT_REGION", "structDSM__KEEP__OUT__REGION.html", "structDSM__KEEP__OUT__REGION" ]
];