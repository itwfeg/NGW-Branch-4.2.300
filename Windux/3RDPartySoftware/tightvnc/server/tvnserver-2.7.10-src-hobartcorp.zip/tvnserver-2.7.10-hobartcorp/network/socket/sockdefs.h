// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef	SOCKDEFS_H
#define SOCKDEFS_H

#include "util/CommonHeader.h"

#define socklen_t int

#endif
