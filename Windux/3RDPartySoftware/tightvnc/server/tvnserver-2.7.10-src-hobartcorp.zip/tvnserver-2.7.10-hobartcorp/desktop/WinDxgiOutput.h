// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDXGIOUTPUT_H__
#define __WINDXGIOUTPUT_H__

#include "region/Rect.h"

#include "WinDxgiAdapter.h"

#include <d3d11.h>
#include <DXGI1_2.h>

class WinDxgiOutput
{
public:
  WinDxgiOutput(WinDxgiAdapter *dxgiAdapter, UINT iOutput);
  WinDxgiOutput(const WinDxgiOutput &src);
  virtual ~WinDxgiOutput();

  WinDxgiOutput &operator = (WinDxgiOutput const &src);

  bool isAttachedtoDesktop();

  Rect getDesktopCoordinates();

  void getDeviceName(StringStorage *out);

  HRESULT queryInterface(REFIID riid, void **ppvObject);

private:
  void copy(const WinDxgiOutput &src);

  IDXGIOutput *m_dxgiOutput;
  DXGI_OUTPUT_DESC m_description;
};

#endif // __WINDXGIOUTPUT_H__
