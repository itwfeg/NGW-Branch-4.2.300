﻿using System;

namespace BnWasp
{
	// QQ todo: collect stats

	// Wasp stats are appended to XMIT records
	public class WaspStats
	{
		public const int WaspStatsSize = 23;

		public static string VersionString;

		private const int WASP_STAT_OFS_VERSION        =  0; // 4B code version
		private const int WASP_STAT_OFS_CLOCK          =  4; // 4B system clock
		private const int WASP_STAT_OFS_TOT_TIME       =  8; // 2B total time (secs)
		private const int WASP_STAT_OFS_TOT_DISCOVERED = 10; // 2B total discovered devices
		private const int WASP_STAT_OFS_MAX_DISCOVERED = 12; // 1B max discovered devices
		private const int WASP_STAT_OFS_TOT_RECORDS    = 13; // 2B # of records created
		private const int WASP_STAT_OFS_TOT_UPLOADS    = 15; // 2B upload attempts
		private const int WASP_STAT_OFS_CONN_ERRORS    = 17; // 2B (WiFi) connect errors
		private const int WASP_STAT_OFS_SEND_ERRORS    = 19; // 2B data send errors
		private const int WASP_STAT_OFS_MODEM_RESETS   = 21; // 1B number of modem resets
		private const int WASP_STAT_OFS_RSSI           = 22; // 1B RSSI

		private Int32  m_lastClock = 0;
		private UInt16 m_totDiscovered = 0;
		private byte   m_maxDiscovered = 0;
		private UInt16 m_totRecords = 0;
		private UInt16 m_totUploads = 0;
		private UInt16 m_connErrors = 0;
		private UInt16 m_sendErrors = 0;
		private byte   m_modemResets = 0;
		private byte   m_rssi = 0;

		private byte m_discoveredInThisCycle = 0;

		byte m_versionMajor = 0;
		byte m_versionMinor = 0;
		Int16 m_versionBuild = 0;

		public WaspStats()
		{
			ResetStats();

			if (VersionString != null)
			{
				string[] tokens = VersionString.Split('.');
				if (tokens.Length > 0)
				{
					byte.TryParse(tokens[0], out m_versionMajor);
					if (tokens.Length > 1)
					{
						byte.TryParse(tokens[1], out m_versionMinor);
						if (tokens.Length > 2)
						{
							Int16.TryParse(tokens[2], out m_versionBuild);
						}
					}
				}
			}
		}

		public void BuildStatsBuffer(byte[] bff)
		{
			if (bff == null || bff.Length < WaspStatsSize)
				return;

			// 4B code version
			bff[WASP_STAT_OFS_VERSION+0] = m_versionMajor;
			bff[WASP_STAT_OFS_VERSION+1] = m_versionMinor;
			bff[WASP_STAT_OFS_VERSION+2] = (byte)m_versionBuild;
			bff[WASP_STAT_OFS_VERSION+3] = (byte)(m_versionBuild >> 8);

			// 4B system clock
			UInt32 clock = (UInt32)Environment.TickCount;
			BinUtils.UInt32ToPayloadBytes(clock, bff, WASP_STAT_OFS_CLOCK);

			// 2B cycle time (secs)
			UInt32 totTime = (UInt32)((clock - m_lastClock) / 1000);
			UInt16 time = (UInt16)((totTime > 65535) ? 65535 : totTime);
			BinUtils.UInt16ToPayloadBytes(time, bff, WASP_STAT_OFS_TOT_TIME);

			// 2B total discovered devices
			BinUtils.UInt16ToPayloadBytes(m_totDiscovered, bff, WASP_STAT_OFS_TOT_DISCOVERED);

			// 1B max discovered devices
			bff[WASP_STAT_OFS_MAX_DISCOVERED] = m_maxDiscovered;

			// 2B # of records created
			BinUtils.UInt16ToPayloadBytes(m_totRecords, bff, WASP_STAT_OFS_TOT_RECORDS);

			// 2B upload attempts
			BinUtils.UInt16ToPayloadBytes(m_totUploads, bff, WASP_STAT_OFS_TOT_UPLOADS);

			// 2B (WiFi) connect errors
			BinUtils.UInt16ToPayloadBytes(m_connErrors, bff, WASP_STAT_OFS_CONN_ERRORS);

			// 2B data send errors
			BinUtils.UInt16ToPayloadBytes(m_sendErrors, bff, WASP_STAT_OFS_SEND_ERRORS);

			// 1B number of modem resets
			bff[WASP_STAT_OFS_MODEM_RESETS] = m_modemResets;

			// 1B RSSI
			bff[WASP_STAT_OFS_RSSI] = m_rssi;
		}

		public void ResetStats()
		{
			m_lastClock = Environment.TickCount;
			m_totDiscovered = 0;
			m_maxDiscovered = 0;
			m_totRecords = 0;
			m_totUploads = 0;
			m_connErrors = 0;
			m_sendErrors = 0;
			m_modemResets = 0;
			m_rssi = 0;

			UpdateRssi();

			m_discoveredInThisCycle = 0;
		}

		public void UpdateRssi()
		{
			// reads the WiFi RSSI
			//int rssi = wizReadRssi();
			//if (rssi != 0)
			//	m_rssi = rssi;
		}

		public void DiscoveryStart()
		{
			m_discoveredInThisCycle = 0;
		}

		public void DiscoveryEnd()
		{
			if (m_discoveredInThisCycle > m_maxDiscovered)
				m_maxDiscovered = m_discoveredInThisCycle;

			m_discoveredInThisCycle = 0;
		}

		public void AddDiscovered()
		{
			m_totDiscovered++;
			m_discoveredInThisCycle++;
		}

		public void AddRecord()
		{
			m_totRecords++;
		}

		public void AddTotUploads()
		{
			m_totUploads++;
		}

		public void AddConnErrors()
		{
			m_connErrors++;
		}

		public void AddSendError()
		{
			m_sendErrors++;
		}

		public void AddModemReset()
		{
			if (m_modemResets < 255)
				m_modemResets++;
		}

	}

}

