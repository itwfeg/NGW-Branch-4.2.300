// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "WinDxRecoverableException.h"

// The header including of this cpp file must be at last place to avoid build conflicts.
#include "WinDxgiAcquiredFrame.h"

WinDxgiAcquiredFrame::WinDxgiAcquiredFrame(WinDxgiOutputDuplication *outDupl, UINT timeOutMilliSec)
: m_wasTimeOut(false),
  m_desktopResource(0),
  m_outDupl(*outDupl)
{
  ZeroMemory(&m_frameInfo, sizeof(m_frameInfo));
  HRESULT hr = m_outDupl.getDxgiOutputDuplication()->AcquireNextFrame(timeOutMilliSec, &m_frameInfo, &m_desktopResource);
  if (hr == DXGI_ERROR_WAIT_TIMEOUT) {
    m_wasTimeOut = true;
  } else if (FAILED(hr)) {
    throw WinDxRecoverableException(_T("Can't AcquireNextFrame()"), hr);
  }
}

WinDxgiAcquiredFrame::~WinDxgiAcquiredFrame()
{
  if (m_desktopResource != 0) {
    m_desktopResource->Release();
    m_desktopResource = 0;
  }
  m_outDupl.getDxgiOutputDuplication()->ReleaseFrame();
}

bool WinDxgiAcquiredFrame::wasTimeOut()
{
  return m_wasTimeOut;
}

IDXGIResource *WinDxgiAcquiredFrame::getDxgiResource()
{
  return m_desktopResource;
}

DXGI_OUTDUPL_FRAME_INFO *WinDxgiAcquiredFrame::getFrameInfo()
{
  return &m_frameInfo;
}
