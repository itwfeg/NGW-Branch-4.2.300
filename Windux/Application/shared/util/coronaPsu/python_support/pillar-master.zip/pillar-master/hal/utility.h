//
// Created by collin on 11/11/17.
//

#ifndef PILLAR_UTILITY_H
#define PILLAR_UTILITY_H

#include <queue>
#include <list>
#include "data.h"

int write_nv(const std::string& filename, std::list<Datapoint>& nv);
int read_nv(const std::string& filename, std::list<Datapoint>& nv);

#endif //PILLAR_UTILITY_H
