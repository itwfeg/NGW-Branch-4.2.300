// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "BalloonTip.h"

BalloonTip::BalloonTip(const TCHAR *text, const TCHAR *caption)
{
  setText(text);
  setTitle(caption);
}

BalloonTip::BalloonTip()
{
  setText(_T(""));
  setTitle(_T(""));
}

BalloonTip::~BalloonTip()
{
}

void BalloonTip::showTooltip(Control *control)
{
  MessageBox(control->getWindow(), m_text.getString(), m_title.getString(), MB_OK | MB_ICONWARNING);
}

void BalloonTip::setText(const TCHAR *text)
{
  m_text.setString(text);
}

void BalloonTip::setTitle(const TCHAR *title)
{
  m_title.setString(title);
}

void BalloonTip::getText(StringStorage *text) const
{
  text->setString(m_text.getString());
}

void BalloonTip::getTitle(StringStorage *title) const
{
  title->setString(m_title.getString());
}

void BalloonTip::setIconType(int iconType)
{
}

int BalloonTip::getIconType() const
{
  return 0;
}
