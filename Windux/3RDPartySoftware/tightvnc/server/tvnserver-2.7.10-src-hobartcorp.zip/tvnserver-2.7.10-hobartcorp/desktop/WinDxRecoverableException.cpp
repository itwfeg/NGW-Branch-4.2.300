// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "WinDxRecoverableException.h"

WinDxRecoverableException::WinDxRecoverableException(const TCHAR *message, HRESULT errCode)
: WinDxException(message, errCode)
{
}

WinDxRecoverableException::~WinDxRecoverableException()
{
}
