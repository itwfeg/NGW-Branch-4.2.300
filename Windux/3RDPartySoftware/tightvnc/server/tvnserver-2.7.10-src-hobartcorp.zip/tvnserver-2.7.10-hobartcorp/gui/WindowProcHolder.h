// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _WINDOW_PROC_HOLDER_H_
#define _WINDOW_PROC_HOLDER_H_

#include "util/CommonHeader.h"

class WindowProcHolder
{
public:
  WindowProcHolder();
  virtual ~WindowProcHolder();

protected:
  virtual LRESULT windowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool *useDefWindowProc) = 0;

  static LRESULT CALLBACK defWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

  friend class NotifyIconWindow;
};

#endif
