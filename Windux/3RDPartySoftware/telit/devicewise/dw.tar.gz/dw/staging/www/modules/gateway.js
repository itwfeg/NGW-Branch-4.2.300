var GatewayCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded GatewayCtrl','gateway');
  // Preperations
  self.scope = $scope;
  lpApi.cloudlinkInfo().tr50Get().loggingQuery({limit:"5",page:"0"}).osInfo().systemNodeinfo().systemProductinfo().tunnelInfo();

  $('#loading').show();
  $('#content-container').addClass('ng-cloak');
  Debug.log('Loading display '+$('#loading').css('display'));
  $http.post(lpApi.getUrl(''), lpApi.getPayload())
    .error($scope.errorCallback).success(function(a,b,c,d){
      $scope.successCallback(a,b,c,d);
    });

  // Properties
  $scope.ctrlActions = [{
    liId:  "li-startCloudLinkCloud",
    liStyle: "display: none;",
    show: false,
    href: "",
    action: "cloudlinkStart",
    aId: "menu-item-startCloudLinkCloud",
    imgSrc: "/img/icon/16/startCloudLinkCloud2.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Start CloudLINK"
  },{
    liId:  "li-stopCloudLinkCloud",
    liStyle: "display: none;",
    show: false,
    href: "",
    action: "cloudlinkStop",
    aId: "menu-item-stopCloudLinkCloud",
    imgSrc: "/img/icon/16/stopCloudLinkCloud2.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Stop CloudLINK"
  },{
    liId:  "li-startTr50",
    liStyle: "display: none;",
    show: false,
    href: "",
    action: "tr50Start",
    aId: "menu-item-startTr50",
    imgSrc: "/img/icon/16/startCloudLinkCloud2.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Start TR50"
  },{
    liId:  "li-stopTr50",
    liStyle: "display: none;",
    show: false,
    href: "",
    action: "tr50Stop",
    aId: "menu-item-stopTr50",
    imgSrc: "/img/icon/16/stopCloudLinkCloud2.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Stop TR50"
  },{
    liId:  "li-gatewayReboot",
    liStyle: "display: block;",
    show: true,
    href: "#/gateway/reboot",
    action: "#/gateway/reboot",
    aId: "menu-item-rebootGateway",
    imgSrc: "/img/icon/16/rebootGateway.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Reboot gateway"
  },{
    liId:  "li-connectivity",
    liStyle: "display: block;",
    show: true,
    href: "#/connectivity",
    action: "#/connectivity",
    aId: "",
    imgSrc: "/img/icon/16/disconnect.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Check connectivity"
  }];

  $scope.secondaryActions = [{
    liId:  "",
    liStyle: "display: block;",
    show: true,
    href: "#/addAsset",
    action: "#/addAsset",
    aId: "",
    imgSrc: "/img/icon/16/addAsset.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Add an asset"
  }];

  // Functions
  $scope.calculateDiskUsage = function(byteTotal,byteFree){
    var diskUsage = ((byteTotal-byteFree)/byteTotal)*100;

    return diskUsage.toFixed(0);
  };

  $scope.getCloudlinkInfoState = function(){
    var state = 'Stopped';

    if ($scope.cloudlinkInfo !== undefined && $scope.cloudlinkInfo.params !== undefined && $scope.cloudlinkInfo.params.state !== undefined){
      state = $scope.cloudlinkInfo.params.state;
      if (state.indexOf(' ') > 0) {
        state = state.substr(0,state.indexOf(' '));
      }
      state = state.toLowerCase();
      state = state.substr(0,1).toUpperCase()+state.substr(1);
    }

    return state;
  };

  $scope.getCloudlinkInfoStatus = function(){
    var status = 'Disconnected';

    if ($scope.cloudlinkInfo !== undefined && $scope.cloudlinkInfo.params !== undefined && $scope.cloudlinkInfo.params.status !== undefined){
      status = $scope.cloudlinkInfo.params.status;
      if (status.indexOf(' ') > 0) {
        status = status.substr(0,status.indexOf(' '));
      }
      status = status.toLowerCase();
      status = status.substr(0,1).toUpperCase()+status.substr(1);
    }

    return status;
  };

  $scope.getModemInfoBars = function() {
    var bars = 0;

    if($scope.modemInfo !== undefined && $scope.modemInfo.success !== undefined && $scope.modemInfo.success && $scope.modemInfo.params.bars !== undefined){
      bars = $scope.modemInfo.params.bars;
    }

    return bars;
  };

  $scope.getModemInfoRssi = function() {
    var rssi = 0;

    if($scope.modemInfo !== undefined && $scope.modemInfo.success !== undefined && $scope.modemInfo.success && $scope.modemInfo.params.rssi !== undefined){
      rssi = $scope.modemInfo.params.rssi;
    }

    return rssi;
  };

  $scope.getModemInfoStatus = function() {
    var status = 'Disconnected';

    if($scope.modemInfo !== undefined && $scope.modemInfo.success !== undefined && $scope.modemInfo.success && $scope.modemInfo.params.status !== undefined){
      status = $scope.modemInfo.params.status;
      if (status.indexOf(' ') > 0) {
        status = status.substr(0,status.indexOf(' '));
      }
      status = status.toLowerCase();
      status = status.substr(0,1).toUpperCase()+status.substr(1);
    }

    return status;
  };

  $scope.getOsInfoCpuUsage = function() {
    $('#osInfoCpu').prev().children('div').css('width', (($scope.osInfo !== undefined && $scope.osInfo.params !== undefined && $scope.osInfo.params.cpuUsage !== undefined) ? $scope.osInfo.params.cpuUsage : '0')+'%');

    return ($scope.osInfo !== undefined && $scope.osInfo.params !== undefined && $scope.osInfo.params.cpuUsage !== undefined) ? $scope.osInfo.params.cpuUsage : '0';
  };

  $scope.getOsInfoDiskUsage = function($idx) {
    $('#osInfoDisk').prev().children('div').css('width', (($scope.osInfo !== undefined && $scope.osInfo.params !== undefined && $scope.osInfo.params.disks[$idx] !== undefined) ? $scope.calculateDiskUsage($scope.osInfo.params.disks[$idx].byteTotal, $scope.osInfo.params.disks[$idx].byteFree) : '0')+'%');

    return ($scope.osInfo !== undefined && $scope.osInfo.params !== undefined && $scope.osInfo.params.disks[$idx] !== undefined) ? $scope.calculateDiskUsage($scope.osInfo.params.disks[$idx].byteTotal, $scope.osInfo.params.disks[$idx].byteFree) : '0';
  };

  $scope.getOsInfoMemUsage = function() {
    $('#osInfoMem').prev().children('div').css('width', (($scope.osInfo !== undefined && $scope.osInfo.params !== undefined && $scope.osInfo.params.memUsage !== undefined) ? $scope.osInfo.params.memUsage : '0')+'%');

    return ($scope.osInfo !== undefined && $scope.osInfo.params !== undefined && $scope.osInfo.params.memUsage !== undefined) ? $scope.osInfo.params.memUsage : '0';
  };

  $scope.getTr50GetState = function(){
    var state = 'Stopped';

    if ($scope.tr50Get !== undefined && $scope.tr50Get.params !== undefined && $scope.tr50Get.params.state !== undefined){
      state = $scope.tr50Get.params.state;
      if (state.indexOf(' ') > 0) {
        state = state.substr(0,state.indexOf(' '));
      }
      state = state.toLowerCase();
      state = state.substr(0,1).toUpperCase()+state.substr(1);
    }

    return state;
  };

  $scope.getTr50GetStatus = function(){
    var status = 'Disconnected';

    if ($scope.tr50Get !== undefined && $scope.tr50Get.params !== undefined && $scope.tr50Get.params.status !== undefined){
      status = $scope.tr50Get.params.status;
      if (status.indexOf(' ') > 0) {
        status = status.substr(0,status.indexOf(' '));
      }
      status = status.toLowerCase();
      status = status.substr(0,1).toUpperCase()+status.substr(1);
    }

    return status;
  };

  $scope.ngShowAllowRemoteAccess = function(){
    for (var ca in $scope.ctrlActions) {
      if ($scope.ctrlActions[ca].liId === 'li-allowRemoteAccess') {
        return $scope.ctrlActions[ca].show = $scope.tunnelInfo !== undefined && ($scope.tunnelInfo.params.allow_raw.toUpperCase() === 'YES') ? false : true;
      }
    }
    return false;
  };

  $scope.ngShowDenyRemoteAccess = function(){
    for (var ca in $scope.ctrlActions) {
      if ($scope.ctrlActions[ca].liId === 'li-denyRemoteAccess') {
        return $scope.ctrlActions[ca].show = $scope.tunnelInfo !== undefined && ($scope.tunnelInfo.params.allow_raw.toUpperCase() === 'NO') ? false : true;
      }
    }
    return false;
  };

  $scope.ngShowStartCloudLink = function(){
    for (var ca in $scope.ctrlActions) {
      if ($scope.ctrlActions[ca].liId === 'li-startCloudLinkCloud') {
        return $scope.ctrlActions[ca].show = $scope.cloudlinkInfo !== undefined && ($scope.cloudlinkInfo.params.state === 'Started' || $scope.cloudlinkInfo.params.state === 'STARTED') ? false : true;
      }
    }
    return false;
  };

  $scope.ngShowStopCloudLink = function(){
    for (var ca in $scope.ctrlActions) {
      if ($scope.ctrlActions[ca].liId === 'li-stopCloudLinkCloud') {
        return $scope.ctrlActions[ca].show = $scope.cloudlinkInfo !== undefined && ($scope.cloudlinkInfo.params.state === 'Stopped' || $scope.cloudlinkInfo.params.state === 'STOPPED') ? false : true;
      }
    }
    return false;
  };

  $scope.ngShowStartTr50 = function(){
    if (!$scope.tr50Get || !$scope.tr50Get.success) return false;
    for (var ca in $scope.ctrlActions) {
      if ($scope.ctrlActions[ca].liId === 'li-startTr50') {
        return $scope.ctrlActions[ca].show = $scope.tr50Get !== undefined && ($scope.tr50Get.params.state === 'Started' || $scope.tr50Get.params.state === 'STARTED') ? false : true;
      }
    }
    return false;
  };

  $scope.ngShowStopTr50 = function(){
    if (!$scope.tr50Get || !$scope.tr50Get.success) return false;
    for (var ca in $scope.ctrlActions) {
      if ($scope.ctrlActions[ca].liId === 'li-stopTr50') {
        return $scope.ctrlActions[ca].show = $scope.tr50Get !== undefined && ($scope.tr50Get.params.state === 'Stopped' || $scope.tr50Get.params.state === 'STOPPED') ? false : true;
      }
    }
    return false;
  };

  $scope.updateCtrlActions = function(){
    $scope.ngShowAllowRemoteAccess();
    $scope.ngShowDenyRemoteAccess();
    $scope.ngShowStartCloudLink();
    $scope.ngShowStopCloudLink();
    $scope.ngShowStartTr50();
    $scope.ngShowStopTr50();
  };

  // Execution
  $scope.clearSystemMsg();

  $scope.assertAuthentication();

  $scope.menuItemSelect($scope, 'gateway');
};

GatewayCtrl.reboot = function(){
  var confirmation = confirm("Are you sure you want to reboot the gateway?");
  if (confirmation){
    lpApi.logOff();
    lpApi.osReboot();
    $resultScope = lpApi.go('', self.scope);
    $().redirect('/');
  }
  return false;
};

GatewayCtrl.$inject = ['$scope', 'lpApi', '$http'];

GatewayCtrl.prototype.ctrlActions = {
  items : [{
    href : '#/gateway/reboot',
    template: "partials/rebooting.html"
  }]
};

GatewayCtrl.prototype.mainActions = {
  items : [{
    href : '',
    template : ''
  }]
};

GatewayCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};
