// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CLIENTAUTHLISTENER_H__
#define __CLIENTAUTHLISTENER_H__

#include "desktop/Desktop.h"
#include "rfb-sconn/RfbClient.h"
#include "AuthException.h"

class ClientAuthListener
{
public:
  virtual ~ClientAuthListener() {}

  // Interface function
  // This function returns zero if a server refuse a client
  // connection, else returns pointer to a WinDesktop object
  virtual Desktop *onClientAuth(RfbClient *client) = 0;
  // Checks the client to ban.
  // Return true if client is banned else reurns false.
  virtual bool onCheckForBan(RfbClient *client) = 0;
  // This function notifies about auth failed of the client.
  virtual void onAuthFailed(RfbClient *client) = 0;
  virtual void onCheckAccessControl(RfbClient *client) throw(AuthException) = 0;
};

#endif // __CLIENTAUTHLISTENER_H__
