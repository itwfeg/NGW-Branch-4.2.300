// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "Win32ScreenDriverFactory.h"
#include "Win32MirrorScreenDriver.h"
#include "Win32ScreenDriver.h"
#include "Win8ScreenDriver.h"

Win32ScreenDriverFactory::Win32ScreenDriverFactory(ServerConfig *srvConf)
: m_srvConf(srvConf)
{
}

Win32ScreenDriverFactory::~Win32ScreenDriverFactory()
{
}

ScreenDriver *Win32ScreenDriverFactory::
createScreenDriver(UpdateKeeper *updateKeeper,
                   UpdateListener *updateListener,
                   FrameBuffer *fb,
                   LocalMutex *fbLocalMutex,
                   LogWriter *log)
{
  // Try to use Win8 duplication API firstly because it's in preference to other methods.
  try {
    return new Win8ScreenDriver(updateKeeper, updateListener, fbLocalMutex, log);
  } catch (Exception &e) {
    log->error(_T("The Win8 duplication api can't be used: %s"),
               e.getMessage());
  }

  if (isMirrorDriverAllowed()) {
    log->info(_T("Mirror driver usage is allowed, try to start it..."));
    try {
      return createMirrorScreenDriver(updateKeeper, updateListener,
                                      fbLocalMutex, log);
    } catch (Exception &e) {
      log->error(_T("The mirror driver factory has failed: %s"),
                 e.getMessage());
    }
  } else {
    log->info(_T("Mirror driver usage is disallowed"));
  }
  log->info(_T("Using the standart screen driver"));
  return createStandardScreenDriver(updateKeeper,
                                    updateListener,
                                    fb,
                                    fbLocalMutex, log);
}

ScreenDriver *Win32ScreenDriverFactory::
createStandardScreenDriver(UpdateKeeper *updateKeeper,
                           UpdateListener *updateListener,
                           FrameBuffer *fb,
                           LocalMutex *fbLocalMutex,
                           LogWriter *log)
{
  return new Win32ScreenDriver(updateKeeper, updateListener, fb, fbLocalMutex, log);
}

ScreenDriver *Win32ScreenDriverFactory::
createMirrorScreenDriver(UpdateKeeper *updateKeeper,
                         UpdateListener *updateListener,
                         LocalMutex *fbLocalMutex,
                         LogWriter *log)
{
  return new Win32MirrorScreenDriver(updateKeeper, updateListener, fbLocalMutex, log);
}

bool Win32ScreenDriverFactory::isMirrorDriverAllowed()
{
  return m_srvConf->getMirrorIsAllowed();
}
