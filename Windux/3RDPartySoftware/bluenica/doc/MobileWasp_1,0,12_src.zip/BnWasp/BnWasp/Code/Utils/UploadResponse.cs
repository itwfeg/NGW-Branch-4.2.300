﻿using System;
using System.Text;
using System.Globalization;

namespace BnWasp
{
	public class UploadResponse
	{
		public const int StatusUnk = -1;
		public const int StatusSuccess = 0;
		public const int StatusError = 1;

		/// <summary>
		/// Gateway response keys
		/// </summary>
		public enum GrKeys
		{
			Nop = 0,
			Err = 1,    // error code (result)
			Sid = 2,    // upload session ID
			Crc = 3,    // check
			Utc = 4,    // current UTC time
			Src = 5,    // source data PKey (record ID) as a hex string
			Ext1 = 250, // reserved
			Ext2 = 251, // reserved
			Ext3 = 252, // reserved
			Ext4 = 253, // reserved
			Ext5 = 254, // reserved
			Ext6 = 255  // reserved
		}

		public int Status { get; private set; }
		public UInt32 Crc { get; private set; }
		public UInt32 CalculatedCrc { get; private set; }
		public string Sid { get; private set; }
		public DateTime Utc { get; private set; }

		public string Summary { get; private set; }

		public UploadResponse(byte[] resp)
		{
			Clear();
			ParseBinaryServerResponse(resp);
		}

		public void Clear()
		{
			Status = StatusUnk;
			Crc = 0;
			CalculatedCrc = 0;
			Sid = string.Empty;
			Utc = DateTime.MinValue;

			Summary = string.Empty;
		}

		/// <summary>
		/// Example:
		///   resp[0] = 'B';
		///   resp[1] = 'N';
		///   resp[2] = 1; // err
		///   resp[3] = 1;
		///   resp[4] = 0;
		///   resp[5] = 2; // sid
		///   resp[6] = 4;
		///   resp[7] = sid[0];
		///   resp[8] = sid[1];
		///   resp[9] = sid[2];
		///   resp[10] = sid[3];
		///   resp[11] = 3; // crc
		///   resp[12] = 4;
		///   resp[13] = 156;
		///   resp[14] = 76;
		///   resp[15] = 13;
		///   resp[16] = 19;
		/// 
		/// respLen = 17;
		/// </summary>
		/// <param name="resp">Server binary response to data upload</param>
		private void ParseBinaryServerResponse(byte[] resp)
		{
			StringBuilder msg = new StringBuilder();

			if (resp.Length >= 2)
			{
				// required header - "BN"
				if (resp[0] == 'B' && resp[1] == 'N')
				{
					msg.Append("Prefix=").Append("BN");

					// parse all sections in the response
					int pos = 2;
					int key = 0;
					while (pos < resp.Length && key >= 0)
					{
						key = resp[pos++];
						byte len = resp[pos++];
						switch (key)
						{
							case (byte)GrKeys.Err:
								Status = resp[pos];
								msg.Append(", err=").Append(Status.ToString(CultureInfo.InvariantCulture));
								break;

							case (byte)GrKeys.Sid:
								StringBuilder sid = new StringBuilder(len);
								for (int i = 0; i < len; i++)
								{
									sid.Append((char)resp[pos + i]);
								}
								msg.Append(", sid=").Append(sid);
								Sid = sid.ToString();
								break;

							case (byte)GrKeys.Utc:
								UInt32 epoch = BinUtils.PayloadBytesToUInt32(resp, pos);
								Utc = Epoch.EpochToUTC(epoch);
								msg.Append(", utc=").Append(Utc.ToString("f"));
								break;

							case (byte)GrKeys.Src:
								// source data record ID, ignored
								break;

							case (byte)GrKeys.Crc:
								Crc = BinUtils.PayloadBytesToUInt32(resp, pos);
								msg.Append(", crc=").Append(Crc);
								break;
						}

						pos += len;
					}

					CalculatedCrc = 0;
					for (int i = 0; i < resp.Length - 1 - 1 - 4; i++) // skip last 6 bytes - CRC section
					{
						CalculatedCrc += resp[i];
					}
					msg.Append(", calc crc=").Append(CalculatedCrc);
				}
				else
				{
					msg.Append("Invalid prefix - expected 'BN'");
				}
			}
			else
			{
				msg.Append("Missing 'BN' prefix");
			}

			Summary = msg.ToString();
		}


	}
}

