// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __DESKTOPCONFIGCLIENT_H__
#define __DESKTOPCONFIGCLIENT_H__

#include "desktop-ipc/DesktopServerProto.h"
#include "DesktopSrvDispatcher.h"
#include "util/DateTime.h"

class DesktopConfigClient: public DesktopServerProto
{
public:
  DesktopConfigClient(BlockingGate *forwGate);
  virtual ~DesktopConfigClient();

  virtual void updateByNewSettings(BlockingGate *gate);
  virtual bool isRemoteInputAllowed();

private:
  DateTime m_lastInputTime;
};

#endif // __DESKTOPCONFIGCLIENT_H__
