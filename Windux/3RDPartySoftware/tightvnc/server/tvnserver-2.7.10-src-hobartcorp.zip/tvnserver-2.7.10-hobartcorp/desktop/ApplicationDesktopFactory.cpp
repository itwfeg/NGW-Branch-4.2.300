// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "ApplicationDesktopFactory.h"
#include "DesktopWinImpl.h"

ApplicationDesktopFactory::ApplicationDesktopFactory()
{
}

ApplicationDesktopFactory::~ApplicationDesktopFactory()
{
}

Desktop *ApplicationDesktopFactory::createDesktop(ClipboardListener *extClipListener,
                                                          UpdateSendingListener *extUpdSendingListener,
                                                          AbnormDeskTermListener *extDeskTermListener,
                                                          LogWriter *log)
{
  return new DesktopWinImpl(extClipListener, extUpdSendingListener,
                            extDeskTermListener, log);
}
