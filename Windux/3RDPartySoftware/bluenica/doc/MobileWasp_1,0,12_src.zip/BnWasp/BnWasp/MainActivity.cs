﻿using Android.App;
using Android.Content;
using Android.Widget;
using Android.OS;
using System;

namespace BnWasp
{
	[Activity(Label = "Mobile WaSP", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
		protected override void OnCreate(Bundle savedInstanceState)
		{
			base.OnCreate(savedInstanceState);

			SetContentView(Resource.Layout.Main);

			ShowFooter();

			// UI bindings
			Button discoveringWaspButton = FindViewById<Button>(Resource.Id.MainMenuDiscoveringWaspButton);
			discoveringWaspButton.Click += delegate
			{
				Intent activity = new Intent(this, typeof(DiscoveringWaspActivity));
				StartActivity(activity);
			};
		}

		private void ShowFooter()
		{
			try
			{
				TextView label = FindViewById<TextView>(Resource.Id.LoginCopyrightLabel);
				int year = 2015;
				if (DateTime.Now.Year > 2015)
					year = DateTime.Now.Year;
				label.Text = "(C) 2012, " + year + " bluenica";
				label = FindViewById<TextView>(Resource.Id.LoginVersionLabel);
				WaspStats.VersionString = PackageManager.GetPackageInfo(PackageName, 0).VersionName;
				label.Text = "v." + WaspStats.VersionString;
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		}

	}
}


