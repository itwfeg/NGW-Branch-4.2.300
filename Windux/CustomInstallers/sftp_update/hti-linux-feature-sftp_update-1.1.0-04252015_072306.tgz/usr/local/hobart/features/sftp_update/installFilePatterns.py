import os

if os.name == 'posix':

    PATCH_UPGRADE_FILENAME = "hti-linux-upgrade"

    CORE_UPGRADE_OLD_FILENAME = "hte"
    CORE_UPGRADE_FILENAME = "hti-linux-core"

    BOOTLOADER_UPGRADE_OLD_FILENAME = "hte-uBoot"
    BOOTLOADER_UPGRADE_FILENAME = "hti-linux-uboot"

    RECOVERY_UPGRADE_OLD_FILENAME = "hte-recovery"
    RECOVERY_UPGRADE_FILENAME = "hti-linux-recovery"

    LANGUAGE_UPGRADE_OLD_FILENAME = "hte-lang_[a-z][a-z]"
    LANGUAGE_UPGRADE_FILENAME = "htseries-any-training_videos_[a-z]+"
    FEATURE_UPGRADE_OSAGNOSTIC_FILENAME = "htseries-any-feature-[a-z,_]+"
    MONOLITHIC_UPGRADE_FILENAME = "hti-linux-feature-monolithic_core+"

    FPC_UPGRADE_OLD_FILENAME = "hte-fpc"
    FPC_UPGRADE_FILENAME = "htseries-any-fpc"

    FEATURE_UPGRADE_OLD_FILENAME = "hte-feature_[a-z,_]+"
    FEATURE_UPGRADE_FILENAME = "hti-linux-feature-[a-z,_]+"

    BACKEND_UPGRADE_FILENAME = "hte-feature_sm_backend"
    BACKEND_UPGRADE_NEW_FILENAME = "htseries-any-feature-sm_backend"

    LICENSE_INSTALL_FILENAME = "[a-z,0-9,A-Z,_]+"

elif os.name == 'nt':

    PATCH_UPGRADE_FILENAME = "hti-win-upgrade"

    CORE_UPGRADE_OLD_FILENAME = "hte"
    CORE_UPGRADE_FILENAME = "htx-win-core"

    BOOTLOADER_UPGRADE_OLD_FILENAME = "hte-uBoot"
    BOOTLOADER_UPGRADE_FILENAME = "htx-win-uboot"

    RECOVERY_UPGRADE_OLD_FILENAME = "hte-recovery"
    RECOVERY_UPGRADE_FILENAME = "htx-win-recovery"

    LANGUAGE_UPGRADE_OLD_FILENAME = "hte-lang_[a-z][a-z]"
    LANGUAGE_UPGRADE_FILENAME = "htseries-any-training_videos_[a-z]+"

    FPC_UPGRADE_OLD_FILENAME = "hte-fpc"
    FPC_UPGRADE_FILENAME = "htseries-any-fpc"

    FEATURE_UPGRADE_OLD_FILENAME = "hte-feature_[a-z,_]+"
    FEATURE_UPGRADE_FILENAME = "htx-win-feature-[a-z,_]+"
    FEATURE_UPGRADE_OSAGNOSTIC_FILENAME = "htseries-any-feature-[a-z,_]+"

    BACKEND_UPGRADE_FILENAME = "hte-feature_sm_backend"
    BACKEND_UPGRADE_NEW_FILENAME = "htseries-any-feature-sm_backend"

    LICENSE_INSTALL_FILENAME = "[a-z,0-9,A-Z,_]+"

    MONOLITHIC_UPGRADE_FILENAME = "hti-linux-feature-monolithic_core+"

CORE_UPGRADE_OLD_FILENAME_REGEX = CORE_UPGRADE_OLD_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"
CORE_UPGRADE_FILENAME_REGEX = CORE_UPGRADE_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"

BOOTLOADER_UPGRADE_OLD_FILENAME_REGEX = BOOTLOADER_UPGRADE_OLD_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"
BOOTLOADER_UPGRADE_FILENAME_REGEX = BOOTLOADER_UPGRADE_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"

RECOVERY_UPGRADE_OLD_FILENAME_REGEX = RECOVERY_UPGRADE_OLD_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"
RECOVERY_UPGRADE_FILENAME_REGEX = RECOVERY_UPGRADE_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"

LANGUAGE_UPGRADE_OLD_FILENAME_REGEX = LANGUAGE_UPGRADE_OLD_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"
LANGUAGE_UPGRADE_FILENAME_REGEX = LANGUAGE_UPGRADE_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"

FPC_UPGRADE_OLD_FILENAME_REGEX = FPC_UPGRADE_OLD_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"
FPC_UPGRADE_FILENAME_REGEX = FPC_UPGRADE_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"

FEATURE_UPGRADE_OLD_FILENAME_REGEX = FEATURE_UPGRADE_OLD_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"
FEATURE_UPGRADE_FILENAME_REGEX = FEATURE_UPGRADE_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"

BACKEND_UPGRADE_FILENAME_REGEX = BACKEND_UPGRADE_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"
BACKEND_UPGRADE_NEW_FILENAME_REGEX = BACKEND_UPGRADE_NEW_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"

LICENSE_INSTALL_FILENAME_REGEX = LICENSE_INSTALL_FILENAME + "\.lic"

FEATURE_UPGRADE_OSAGNOSTIC_FILENAME_REGEX = FEATURE_UPGRADE_OSAGNOSTIC_FILENAME + "-[0-9]+\.[0-9]+-.*\.tgz"

MONOLITHIC_UPGRADE_FILENAME_REGEX = MONOLITHIC_UPGRADE_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"

PATCH_UPGRADE_FILENAME_REGEX = PATCH_UPGRADE_FILENAME + "-[0-9]+\.[0-9]+\.[0-9]+-.*\.tgz"
