﻿using System;

namespace BnWasp
{
	public class POSTRequestResults
	{
		public int StatusCode { get; set; }
		public string Content { get; set; }
		public Exception Exc { get; set; }
		public bool RequestCompleted { get; set; }

		public POSTRequestResults()
		{
			Content = string.Empty;
			StatusCode = -1;
			Exc = null;
			RequestCompleted = false;
		}
	}
}
