// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _TAB_H_
#define _TAB_H_

#include "BaseDialog.h"
#include "Control.h"
#include "util/StringStorage.h"

class Tab
{
public:
  Tab();
  Tab(BaseDialog *dialog, const TCHAR *caption);

  //
  // Access methods to protected members
  //

  void setCaption(const TCHAR *caption) { m_caption.setString(caption); }

  const TCHAR *getCaption() {
    return m_caption.getString();
  }

  void setDialog(BaseDialog *dialog) { m_dialog = dialog; }
  BaseDialog *getDialog() { return m_dialog; }

  //
  // Method return true if tab has dialog
  //

  bool isOk() { return m_dialog != NULL; }

  //
  // Changes visible state of dialog donates by this tab
  //

  void setVisible(bool visible);

protected:

  BaseDialog *m_dialog;
  StringStorage m_caption;
};

#endif
