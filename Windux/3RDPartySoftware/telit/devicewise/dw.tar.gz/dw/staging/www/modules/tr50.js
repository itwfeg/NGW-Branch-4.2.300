var Tr50Ctrl = function($scope, lpApi, $http) {
  Debug.log('Loaded Tr50Ctrl','tr50');
  // Preperations
  lpApi.tr50Get().tr50RegistrationHWList().tr50TunnelGet();

  $('#loading').show();
  $('#content-container').addClass('ng-cloak');
  Debug.log('Loading display '+$('#loading').css('display'));
  $http.post(lpApi.getUrl(''), lpApi.getPayload())
    .error($scope.errorCallback).success(function(a,b,c,d){
      $scope.successCallback(a,b,c,d);
      $scope.populateTr50Get();
      $scope.populateTr50RegistrationHWList();
    });

  // Properties
  $scope.mainActions = [{
    id : 'main-action-editTr50',
    href : '#/editTr50',
    aClasses: "gray-button",
    text: 'Edit TR50'
  }];

  $scope.tr50ConnectionTypes = {params: [
    "MQTT",
    "MQTT with TLS",
    "MQTT via HTTPS Proxy"
  ]};

  // Functions
  $scope.getCloudlinkInfoState = function(){
    var state = 'Stopped';

    if ($scope.cloudlinkInfo !== undefined && $scope.cloudlinkInfo.params !== undefined && $scope.cloudlinkInfo.params.state !== undefined){
      state = $scope.cloudlinkInfo.params.state;
      if (state.indexOf(' ') > 0) {
        state = state.substr(0,state.indexOf(' '));
      }
      state = state.toLowerCase();
      state = state.substr(0,1).toUpperCase()+state.substr(1);
    }

    return state;
  };
  $scope.onChangeDeviceId = function() {
    switch($scope.tr50Get.params.device_id){
      case 'Custom':
        $scope.block_custom_device_id = true;
        break;
      default:
        $scope.block_custom_device_id = false;
        break;
    }
  };

  $scope.onChangeProxyType = function() {
    switch($scope.tr50Get.params.proxy_type){
      case 'SOCKS4(a)':
        $scope.block_proxy_address = true;
        $scope.block_proxy_user = true;
        $scope.block_proxy_pass = false;
        break;
      case 'SOCKS5':
      case 'HTTP':
        $scope.block_proxy_address = true;
        $scope.block_proxy_user = true;
        $scope.block_proxy_pass = true;
        break;
      case 'None':
      default:
        $scope.block_proxy_address = false;
        $scope.block_proxy_user = false;
        $scope.block_proxy_pass = false;
        break;
    }
  };

  $scope.populateTr50Get = function() {
    if ($scope.tr50Get !== undefined && $scope.tr50Get.params !== undefined) {
      if ($scope.tr50Get.params.proxy_type === undefined) {
        $scope.tr50Get.params.proxy_type = 'None';
      }
      $scope.onChangeProxyType();
    }
    return false;
  };

  $scope.populateTr50RegistrationHWList = function() {
    if ($scope.tr50RegistrationHWList !== undefined && $scope.tr50RegistrationHWList.params !== undefined) {
      if ($scope.tr50RegistrationHWList.params.indexOf('Custom') === -1) {
        $scope.tr50RegistrationHWList.params.push('Custom');
      }
      $scope.onChangeDeviceId();
    }
    return false;
  };

  $scope.saveTr50Settings = function(){
    var tr50_set_params = {
      server_host: $scope.tr50Get.params.server_host,
      connection_type: $scope.tr50Get.params.connection_type,
      device_id: $scope.tr50Get.params.device_id,
      custom_device_id: $scope.tr50Get.params.custom_device_id,
      app_token: $scope.tr50Get.params.app_token,
      proxy_type: $scope.tr50Get.params.proxy_type,
      proxy_address: $scope.tr50Get.params.proxy_address,
      proxy_user: $scope.tr50Get.params.proxy_user,
      proxy_pass: $scope.tr50Get.params.proxy_pass
    };

    var tr50_tunnel_set_params = {
      allow_management: ($('#input-allow-management:checked').val()) ? 'Yes' : 'No',
      allow_tunnels: ($('#input-allow-tunnels:checked').val()) ? 'Yes' : 'No'
    };

    lpApi.tr50Set(tr50_set_params);
    lpApi.tr50TunnelSet(tr50_tunnel_set_params);

    $resultScope = lpApi.go('', $scope);

    var msg, msgType;
    if ($resultScope.tr50Set.success === true) {// && $resultScope.tunnelSet.success === true) {
      msg = 'TR50 Changes Saved Successfully! Restart connection for settings to take effect.';
      msgType = 'success';
    }
    else if ($resultScope.tr50Set.success === false) {// || $resultScope.tunnelSet.success === false ) {
      msg = 'TR50 Changes Not Saved!';
      msgType = 'error';
      if($resultScope.tr50Set.success === false){
        msg += ' '+$resultScope.tr50Set.errorMessage;
      }
      if($resultScope.tr50TunnelSet.success === false){
        msg += ' '+$resultScope.tr50TunnelSet.errorMessage;
      }
    }
    Debug.log([msg, msgType],'saveTr50Settings');
    $scope.setSystemMsg(msg, msgType);
  };

  // Executions
  $scope.clearSystemMsg();

  $scope.assertAuthentication();

  $scope.menuItemSelect($scope, 'gateway');

  $scope.populateTr50Get();

  $scope.populateTr50RegistrationHWList();
};

Tr50Ctrl.$inject = ['$scope', 'lpApi', '$http'];

Tr50Ctrl.prototype.ctrlActions = {
  items : [{
    href : '',
    template : ''
  }]
};

Tr50Ctrl.prototype.mainActions = {
  items : [{
    href : '/editTr50',
    template : 'partials/editTr50.html'
  }]
};

Tr50Ctrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};
