// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __LOGCONN_H__
#define __LOGCONN_H__

#include "io-lib/Channel.h"
#include "thread/Thread.h"
#include "win-system/Pipe.h"
#include "LogListener.h"
#include "LogLevelSender.h"

class LogConnAuthListener;

class LogConn : public Thread
{
public:
  LogConn(Channel *channel, LogConnAuthListener *extAuthListener,
          LogListener *extLogListener, unsigned char logLevel);
  virtual ~LogConn();

  // This function closes the connection that brings to object
  // termination.
  virtual void close();

  void changeLogLevel(unsigned char newLevel);

private:
  virtual void execute();
  virtual void onTerminate();

  void assignConnection();
  void dispatch();

  LogConnAuthListener *m_extAuthListener;
  LogListener *m_extLogListener;

  Channel *m_serviceChannel;
  Channel *m_logListenChannel;
  Channel *m_levelSendChannel;
  FileAccountHandle m_handle;
  LocalMutex m_channelMutex;

  unsigned char m_logLevel;
  LocalMutex m_logLevelMutex;

  LogLevelSender m_logLevelSender;
};

#endif // __LOGCONN_H__
