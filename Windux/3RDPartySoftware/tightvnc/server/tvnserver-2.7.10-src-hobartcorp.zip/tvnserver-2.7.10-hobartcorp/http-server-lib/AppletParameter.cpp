// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "AppletParameter.h"

#include "util/CommonHeader.h"

#include <crtdbg.h>

AppletParameter::AppletParameter(const char *name, const char *value)
: m_isValid(false)
{
  _ASSERT(name != NULL);
  _ASSERT(value != NULL);

  m_isValid = isStringValid(name) && isStringValid(value);

  if (isValid()) {
    char format[] = "<PARAM NAME=\"%s\" VALUE=\"%s\" >\n";
    m_formattedString.format(format, name, value);
  }
}

AppletParameter::~AppletParameter()
{
}

const char *AppletParameter::getFormattedString() const
{
  return m_formattedString.getString();
}

bool AppletParameter::isValid() const
{
  return m_isValid;
}

bool AppletParameter::isStringValid(const char *str) const
{
  // Applet argument can contain alnum, '_', '.', ' ' characters.
  for (size_t i = 0; i < strlen(str); i++) {
    if (!(isalnum(str[i]) || str[i] == '_' || str[i] == '.' || str[i] == ' ')) {
      return false;
    } // if character is not valid.
  } // for all characters if value.

  return true;
}
