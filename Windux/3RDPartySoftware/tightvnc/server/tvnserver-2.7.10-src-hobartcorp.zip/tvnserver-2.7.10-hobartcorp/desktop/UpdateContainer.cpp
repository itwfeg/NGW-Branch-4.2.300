// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "UpdateContainer.h"

UpdateContainer::UpdateContainer()
{
  clear();
}

UpdateContainer::~UpdateContainer(void)
{
}

void UpdateContainer::clear()
{
  copiedRegion.clear();
  changedRegion.clear();
  videoRegion.clear();
  screenSizeChanged = false;
  cursorPosChanged = false;
  cursorShapeChanged = false;
  copySrc.clear();
  //cursorPos.clear();
}

UpdateContainer& UpdateContainer::operator=(const UpdateContainer& src)
{
  copiedRegion        = src.copiedRegion;
  changedRegion       = src.changedRegion;
  videoRegion         = src.videoRegion;
  screenSizeChanged   = src.screenSizeChanged;
  cursorPosChanged    = src.cursorPosChanged;
  cursorShapeChanged  = src.cursorShapeChanged;
  copySrc             = src.copySrc;
  cursorPos           = src.cursorPos;

  return *this;
}

bool UpdateContainer::isEmpty() const
{
  return copiedRegion.isEmpty() &&
         changedRegion.isEmpty() &&
         videoRegion.isEmpty() &&
         !screenSizeChanged &&
         !cursorPosChanged &&
         !cursorShapeChanged;
}
