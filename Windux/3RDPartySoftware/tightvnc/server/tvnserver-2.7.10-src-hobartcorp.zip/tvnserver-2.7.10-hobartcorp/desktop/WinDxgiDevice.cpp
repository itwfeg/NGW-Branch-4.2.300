// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "util/Exception.h"

// The header including of this cpp file must be at last place to avoid build conflicts.
#include "WinDxgiDevice.h"

WinDxgiDevice::WinDxgiDevice(WinD3D11Device *winD3D11Device)
: m_dxgiDevice(0)
{
  HRESULT hr = winD3D11Device->deviceQueryInterface(__uuidof(IDXGIDevice), reinterpret_cast<void**>(&m_dxgiDevice));
  if (FAILED(hr)) {
    StringStorage errMess;
    errMess.format(_T("Can't QueryInterface for IDXGIDevice (%l)"), (long)hr);
    throw Exception(errMess.getString());
  }
}

WinDxgiDevice::~WinDxgiDevice()
{
  if (m_dxgiDevice != 0) {
    m_dxgiDevice->Release();
    m_dxgiDevice = 0;
  }
}

HRESULT WinDxgiDevice::getParent(REFIID riid, void **ppvObject)
{
  return m_dxgiDevice->GetParent(riid, ppvObject);
}
