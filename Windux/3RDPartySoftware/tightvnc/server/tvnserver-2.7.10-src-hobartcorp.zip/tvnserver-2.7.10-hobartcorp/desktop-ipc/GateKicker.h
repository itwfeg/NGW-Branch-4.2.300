// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __GATEKICKER_H__
#define __GATEKICKER_H__

#include "BlockingGate.h"
#include "thread/Thread.h"
#include "win-system/WindowsEvent.h"

class GateKicker : public Thread
{
public:
  GateKicker(BlockingGate *gate);
  virtual ~GateKicker();

protected:
  virtual void execute();
  virtual void onTerminate();
private:
  BlockingGate *m_gate;
  WindowsEvent m_sleeper;
};

#endif // __GATEKICKER_H__
