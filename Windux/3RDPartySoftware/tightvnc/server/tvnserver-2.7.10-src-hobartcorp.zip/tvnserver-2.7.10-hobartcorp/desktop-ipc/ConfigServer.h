// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CONFIGSERVER_H__
#define __CONFIGSERVER_H__

#include "DesktopSrvDispatcher.h"
#include "DesktopServerProto.h"
#include "desktop/DesktopConfigLocal.h"

class ConfigServer : public DesktopServerProto, public ClientListener
{
public:
  ConfigServer(DesktopSrvDispatcher *dispatcher, LogWriter *log);
  virtual ~ConfigServer();

protected:
  // Internal dispatcher
  virtual void onRequest(UINT8 reqCode, BlockingGate *backGate);

  void reloadSettings(BlockingGate *backGate);
  void answerOnSoftInputEnablingReq(BlockingGate *backGate);

  DesktopConfigLocal m_deskConf;
};

#endif // __CONFIGSERVER_H__
