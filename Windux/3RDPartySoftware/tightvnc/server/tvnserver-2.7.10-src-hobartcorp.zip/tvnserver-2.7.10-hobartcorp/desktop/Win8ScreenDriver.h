// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WIN8SCREENDRIVER_H__
#define __WIN8SCREENDRIVER_H__

// FIXME: Remove this detectors when will be ready win8 detectors.
#include "CursorPositionDetector.h"
#include "CursorShapeDetector.h"
#include "WindowsCursorShapeGrabber.h"

#include "ScreenDriver.h"
#include "WinVideoRegionFounderImpl.h"
#include "UpdateKeeper.h"
#include "UpdateListener.h"
#include "log-writer/LogWriter.h"
#include "Win8ScreenDriverImpl.h"

class Win8ScreenDriver : public WinVideoRegionFounderImpl
{
public:
  // (Note: This class has no link to an external backup frame buffer and then it does not have
  // to use an external belonged mutex. Thread safe coordiantion commitments between this class
  // and external some elements should be entirely provided by an owner code.)

  Win8ScreenDriver(UpdateKeeper *updateKeeper,
                   UpdateListener *updateListener,
                   LocalMutex *fbLocalMutex,
                   LogWriter *log);
  virtual ~Win8ScreenDriver();

  // Starts screen update detection if it not started yet.
  virtual void executeDetection();

  // Stops screen update detection.
  virtual void terminateDetection();

  virtual Dimension getScreenDimension();
  virtual bool grabFb(const Rect *rect = 0);
  virtual FrameBuffer *getScreenBuffer();
  virtual bool getScreenPropertiesChanged();
  virtual bool getScreenSizeChanged();
  virtual bool applyNewScreenProperties();

  virtual bool grabCursorShape(const PixelFormat *pf);
  virtual const CursorShape *getCursorShape();
  virtual Point getCursorPosition();

  virtual void getCopiedRegion(Rect *copyRect, Point *source);

private:
  LogWriter *m_log;
  LocalMutex *m_fbLocalMutex;
  UpdateKeeper *m_updateKeeper;
  UpdateListener *m_updateListener;
  // This member must be always gueranted non zero. Otherwise an excption must
  // be provided from the constructor of this class.
  Win8ScreenDriverImpl *m_drvImpl;

  CursorShape m_cursorShape;

  bool m_detectionEnabled;
};

#endif // __WIN8SCREENDRIVER_H__
