How To run

Suppose the example is called JniMyExample and the jar file is called JniMyExample.jar,
then following the instruction below depending on your operating system.

Linux:

- Copy java/dlsdk.jar and java/libdlsdkjava.* to this folder.
- Run the following in shell prompt:

  java -classpath dlsdk.jar:JniMyExample.jar -Djava.library.path=. com.digimarc.LabelEmbedder.example.JniMyExample

Windows:

- Copy java\dlsdk.jar and java\dlsdkjava.* to this folder.
- Run the following in command prompt:

  java -classpath dlsdk.jar;JniMyExample.jar -Djava.library.path=. com.digimarc.LabelEmbedder.example.JniMyExample
