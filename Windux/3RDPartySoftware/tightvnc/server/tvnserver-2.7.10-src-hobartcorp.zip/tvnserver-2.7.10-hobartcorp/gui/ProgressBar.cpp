// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "ProgressBar.h"

#include <commctrl.h>

ProgressBar::ProgressBar()
{
}

ProgressBar::~ProgressBar()
{
}

void ProgressBar::setRange(WORD min, WORD max)
{
  SendMessage(m_hwnd, PBM_SETRANGE, 0, MAKELPARAM(min, max));
}

void ProgressBar::setPos(WORD pos)
{
  SendMessage(m_hwnd, PBM_SETPOS, (WPARAM)pos, 0);
}
