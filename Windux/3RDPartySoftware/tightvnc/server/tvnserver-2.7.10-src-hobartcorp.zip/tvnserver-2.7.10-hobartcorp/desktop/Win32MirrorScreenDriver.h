// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WIN32MIRRORSCREENDRIVER_H__
#define __WIN32MIRRORSCREENDRIVER_H__

#include "MirrorScreenDriver.h"
#include "Win32ScreenDriverBaseImpl.h"

class Win32MirrorScreenDriver : public Win32ScreenDriverBaseImpl
{
public:
  Win32MirrorScreenDriver(UpdateKeeper *updateKeeper,
                          UpdateListener *updateListener,
                          LocalMutex *fbLocalMutex,
                          LogWriter *log);
  virtual ~Win32MirrorScreenDriver();

  // Starts screen update detection if it not started yet.
  virtual void executeDetection();

  // Stops screen update detection.
  virtual void terminateDetection();

  // Note: This class is a wrapper for the MirrorScreenDriver class and then
  // only MirrorScreenDriver can provide appropriate thread safety for the ScreenDriver functions.

  virtual Dimension getScreenDimension();
  virtual bool grabFb(const Rect *rect = 0);
  virtual FrameBuffer *getScreenBuffer();
  virtual bool getScreenPropertiesChanged();
  virtual bool getScreenSizeChanged();
  virtual bool applyNewScreenProperties();

private:
  MirrorScreenDriver m_mirrorDriver;
};

#endif // __WIN32MIRRORSCREENDRIVER_H__
