
function split(str, delim, maxNb)
    -- Eliminate bad cases...
    if string.find(str, delim) == nil then
        return { str }
    end
    if maxNb == nil or maxNb < 1 then
        maxNb = 0    -- No limit
    end
    local result = {}
    local pat = "(.-)" .. delim .. "()"
    local nb = 0
    local lastPos
    for part, pos in string.gfind(str, pat) do
        nb = nb + 1
        result[nb] = part
        lastPos = pos
        if nb == maxNb then break end
    end
    -- Handle the last field
    if nb ~= maxNb then
        result[nb + 1] = string.sub(str, lastPos)
    end
    return result
end

function foobar()
  local sum = 0
  DWOutput["Z"] = DWInput["X"];
  print(DWInput["Y"])
  
  return 0
end

function arraytest()
  local sum = 0
  print(DWInput["X"][1])
  print(DWInput["X"][2])
  print(DWInput["X"][3])
  print(DWInput["X"][4])
  
  DWOutput["Z"] = DWInput["X"][1]+DWInput["X"][2]+DWInput["X"][3]+DWInput["X"][4];
  print(DWInput["Y"])
  
  return 0
end

function stringarray()
  local sum = 0
  print("{" .. DWInput["StringArr"][1] .. "}")
  print("{" .. DWInput["StringArr"][2] .. "}")
  print("{" .. DWInput["StringArr"][3] .. "}")
  
  local arr = {}
  
  arr = split("this,is,a,test",",",10)
  print("{" .. arr[1] .. "}")
  print("{" .. arr[2] .. "}")
  print("{" .. arr[3] .. "}")
  print("{" .. arr[4] .. "}")
   
  DWOutput["OUT"] = DWInput["StringArr"][1] .. DWInput["StringArr"][2] .. DWInput["StringArr"][3]
  return 0
end

function stringsplit()  
  DWOutput["OUT"] = split(DWInput["string"],",",10)
  return 0
end

function return_one_string()  
  DWOutput["OUT"] = "Hello World"
  return 0
end

function arrayreturn()
  DWOutput["OUT"] = {10,20,30,40}
  return 0
end