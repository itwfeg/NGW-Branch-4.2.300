// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __DESKTOPFACTORY_H__
#define __DESKTOPFACTORY_H__

#include "ClipboardListener.h"
#include "UpdateSendingListener.h"
#include "AbnormDeskTermListener.h"
#include "log-writer/LogWriter.h"
#include "Desktop.h"

class DesktopFactory
{
public:
  virtual Desktop *createDesktop(ClipboardListener *extClipListener,
                                          UpdateSendingListener *extUpdSendingListener,
                                          AbnormDeskTermListener *extDeskTermListener,
                                          LogWriter *log) = 0;
};

#endif // __DESKTOPFACTORY_H__
