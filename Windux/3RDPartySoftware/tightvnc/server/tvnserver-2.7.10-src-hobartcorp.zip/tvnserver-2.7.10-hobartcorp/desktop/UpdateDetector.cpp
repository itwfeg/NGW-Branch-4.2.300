// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "UpdateDetector.h"

UpdateDetector::UpdateDetector(UpdateKeeper *updateKeeper,
                               UpdateListener *updateListener)
: m_updateKeeper(updateKeeper),
m_updateListener(updateListener)
{
}

UpdateDetector::~UpdateDetector()
{
}
