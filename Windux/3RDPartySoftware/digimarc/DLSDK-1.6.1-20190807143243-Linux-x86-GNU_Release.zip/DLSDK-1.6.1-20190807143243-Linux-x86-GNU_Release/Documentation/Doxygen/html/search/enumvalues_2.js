var searchData=
[
  ['extra_5fdata',['EXTRA_DATA',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39aa6af7aafde8baa57e9f927b088fe9ebf',1,'SampleLabelEmbedder.cpp']]],
  ['extra_5fdata_5ftype',['EXTRA_DATA_TYPE',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a38a3dccda52f051b528c37b3fa2b5ef0',1,'SampleLabelEmbedder.cpp']]]
];
