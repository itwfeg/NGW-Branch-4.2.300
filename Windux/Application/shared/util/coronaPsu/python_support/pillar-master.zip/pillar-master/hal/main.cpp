#include <getopt.h>
#include <string.h>
#include <iostream>

#include <thread>
#include <mutex>
#include <condition_variable>

#include <unistd.h>
#include <vector>
#include <queue>
#include <list>
#include <cmath>
#include <selene_iot/ipc/ipc_source.h>

#include "hal_interface.h"
#include "ipc/ipc_sink.h"

#include "data.h"
#include "utility.h"
#include "cJSON.h"

const char *port = "/dev/ttyS4";
const char *ipc_socket = "iot_hal.unix";
const char *nv_file = "iot_data.nv";

const int datapoint_nv_size = 86400;    //24 hours at 1 second sampling
const int datapoint_nv_sync_time = 20;  //period to sync the NV file in seconds.

int ipc_retries = 10;
bool debug = false;

bool quit = false;

static void print_usage(const char *prog)
{
    printf("Usage: %s [-srpnd]\n", prog);
    std::cerr << "-s --socket   IPC Socket" << std::endl;
    std::cerr << "-r --retries  IPC Socket connect retry count" << std::endl;
    std::cerr << "-p --port     TTY Port" << std::endl;
    std::cerr << "-n --nv       NV database filename" << std::endl;
    std::cerr << "-d --debug    Debug mode" << std::endl;
    exit(1);
}

static void parse_opts(int argc, char *argv[])
{
    static const struct option lopts[] = {
            {"port",    1, 0,    'p'},
            {"socket",  1, 0,    's'},
            {"retries", 1, 0,    'r'},
            {"debug",   0, NULL, 'd'},
            {"nv",      1, 0,    'n'},
            {NULL,      0, 0,    0},
    };
    int c;

    while ((c = getopt_long(argc, argv, "p:s:r:d", lopts, NULL)) != -1)
    {
        switch (c)
        {
            case 'p':
                port = optarg;
                break;
            case 's':
                ipc_socket = optarg;
                break;
            case 'r':
                ipc_retries = atoi(optarg);
                break;
            case 'd':
                debug = true;
                break;
            case 'n':
                nv_file = optarg;
                break;

            case 0:
                break;

            default:
                std::cout << "Got " << c << std::endl;
                print_usage(argv[0]);
                break;
        }
    }
}

std::condition_variable data_ready_cv;
std::mutex data_mutex;
std::queue<Datapoint> data_buffer;

std::condition_variable datapoint_nv_ready_cv;
std::mutex datapoint_nv_mutex;
std::list<Datapoint> datapoint_nv;

std::condition_variable command_condition;
std::mutex command_mutex;
std::queue<std::string> commands;

void manage_requests()
{
    selene::ipc_sink sink;

    int status = -1;
    bool quit = false;

    /* Connect to the IPC sink. */
    while (status != 0)
    {
        status = sink.connect_sink(ipc_socket);
        if (status != 0)
        {
            std::cerr << "An error occurred while connecting to the IPC server !!(" << -status << "): "
                      << strerror(-status) << std::endl;
            std::cerr << "Retrying..." << std::endl;
            sleep(2);
        }
    }

    /* Loop on commands. */
    while (!quit)
    {
        /* Wait for a command. */
        std::unique_lock<std::mutex> lock(command_mutex);
        while (!quit && commands.size() == 0)
            command_condition.wait(lock);

        /* Transmit the data. */
        while (sink.send_packet((uint8_t *) commands.front().data(), commands.front().length()) < 0)
        {
            /* Try to reconnect. */
            sink.disconnect_sink();
            status = sink.connect_sink(ipc_socket);
            if (status != 0)
            {
                std::cerr << "An error occurred while connecting to the IPC server (" << -status << "): "
                          << strerror(-status) << std::endl;
                std::cerr << "Retrying..." << std::endl;

                sleep(2);
            }
        }

        commands.pop(); //remove from the work queue.
    }
}

void push_command(const std::string &cmd)
{
    std::unique_lock<std::mutex> lock(command_mutex);
    commands.push(cmd);    //save the command.
    command_condition.notify_all();                         //notify availability of the command.
}

int main(int argc, char **argv)
{
    parse_opts(argc, argv);

    selene::ipc_source source;
    source.create_source("iot_hal_in.unix", [](const uint8_t *data, int size)
    {

    });

    hal_interface interface;
    if (!debug)
    {
        interface.connect(port);
        interface.modbus_start_listen(std::function<void(const std::string &)>(
                [](const std::string &line)
                {

//            std::cout << __FUNCTION__ << " " << __LINE__ << std::endl;
                    /* Parse the line data. */
                    char *ptr = (char *) line.c_str();

                    /* Make sure the first line is a colon. */
                    if ((line[0] & 0x7F) != ':')
                        return;

                    char str[5];
                    memset(str, 0, sizeof(str));
                    strncpy(str, &ptr[1], 2);
                    uint16_t REMOTE_ADDR = (uint16_t) strtol(
                            str, NULL, 16);
//        printf("REMOTE_ADDR=0x%04X ", REMOTE_ADDR);

                    memset(str, 0, sizeof(str));
                    strncpy(str, &ptr[3], 2);
                    uint16_t FUNC_CODE = (uint16_t) strtol(
                            str, NULL, 16);
//        printf("FUNC_CODE=0x%04X ", FUNC_CODE);

                    memset(str, 0, sizeof(str));
                    strncpy(str, &ptr[5], 4);
                    uint16_t power = (uint16_t) strtol(
                            str, NULL, 16);
//        printf("power=%s 0x%04X (%d)", str, power, power);

                    memset(str, 0, sizeof(str));
                    strncpy(str, &ptr[9], 4);
                    uint16_t voltage = (uint16_t) strtol(
                            str, NULL, 16);
//        printf("voltage=%s 0x%04X (%d) ", str, voltage, voltage);

                    memset(str, 0, sizeof(str));
                    strncpy(str, &ptr[13], 4);
                    uint16_t current = (uint16_t) strtol(
                            str, NULL, 16);
//        printf("current=%s 0x%04X (%d) ", str, current, current);

                    memset(str, 0, sizeof(str));
                    strncpy(str, &ptr[17], 4);
                    uint16_t freq = (uint16_t) strtol(
                            str, NULL, 16);
//        printf("freq=%s 0x%04X (%d) ", str, freq, freq);

                    memset(str, 0, sizeof(str));
                    strncpy(str, &ptr[21], 2);
                    uint8_t fault = (uint8_t) strtol(str,
                                                     NULL,
                                                     16);

//            std::cout << __FUNCTION__ << " " << __LINE__ << std::endl;
                    /* Create a data point & push it to the listener. */
                    std::unique_lock<std::mutex> lock;
                    data_buffer.push(
                            Datapoint(voltage * 10, freq,
                                      (double)power / 10.0,
                                      current, fault));
                    data_ready_cv.notify_all();
//            std::cout << __FUNCTION__ << " " << __LINE__ << std::endl;
                }));
    } else
    {
        std::thread debug_thread([]()
                                 {

                                     double voltage = 0;
                                     double current = 0;
                                     double freq = 0;
                                     double power = 0;
                                     int fault = 0;

                                     double t = 0;
                                     while (!quit)
                                     {
                                         voltage = 50.0 * sin(2.0 * 3.14159 * t * .05) + 35.0;
                                         current = 5.0 * cos(2.0 * 3.14159 * t * .05) + 5.0;
                                         power = (voltage * current) / 100.0;
                                         freq = remainder(t, 5.0) + 10.0;

                                         t += .05;

                                         double rem = remainder(t, 5.0);
                                         fault = rem < 0 ? INVERTER_ON | HIGH_TEMP_FAULT | DC_BUS_FAULT |
                                                           INTERLOCK_FAULT | CURRENT_TRIP_FAULT | OVER_VOLT_FAULT
                                                         : 0x00;//create an ON signal.

                                         std::unique_lock<std::mutex> lock;
                                         data_buffer.push(Datapoint(voltage * 10, freq, power * 100, current, fault));
                                         data_ready_cv.notify_all();
                                         usleep(50000);
                                     }
                                 });

        debug_thread.detach();
    }

    std::vector<Datapoint> datapoint_average;

    struct timespec average_start;
    struct timespec nv_start;

    /* Read existing data */
    read_nv(nv_file, datapoint_nv);
    clock_gettime(CLOCK_MONOTONIC, &nv_start);

    /* Start the request management thread. */
    std::thread request_handler(&manage_requests);

    while (!quit)
    {
        /* Wait for a new data sample. */
        std::unique_lock<std::mutex> lock(data_mutex);
        while (!quit && data_buffer.size() == 0)
            data_ready_cv.wait(lock);

        Datapoint dp = data_buffer.front();

        /* Transmit the data. */
        cJSON *serialized;
        dp.serialize(&serialized);
        cJSON *data_package = cJSON_CreateObject();
        cJSON_AddItemToObject(data_package, "data", serialized);
        cJSON_AddStringToObject(data_package, "cmd", "livedata");

        char *data_package_str = cJSON_Print(data_package);
        push_command(data_package_str);

        free(data_package_str);
        cJSON_Delete(data_package);

        /* Get the current time for comparison. */
        timespec current_time;
        clock_gettime(CLOCK_MONOTONIC, &current_time);

        /* Add the datapoint to the averaging collection. */
        if (datapoint_average.size() == 0)
            clock_gettime(CLOCK_MONOTONIC, &average_start); // Set the start time.

        datapoint_average.push_back(dp);//add the item to the collection

        /* If the sample time has been elapsed, average the sample and store it to NV. */
        double current = (current_time.tv_nsec / 1000000000.0) + current_time.tv_sec;
        double start = (average_start.tv_nsec / 1000000000.0) + average_start.tv_sec;
        if ((current - start) >= 1.0)
        {
            Datapoint average(datapoint_average);   //average the sample

            std::unique_lock<std::mutex> lock(datapoint_nv_mutex); //lock the resources for the datapoint NV
            datapoint_nv.push_back(average);        //record the averaged sample into long term NV.
            datapoint_nv_ready_cv.notify_all();     //indicate that a new sample is available.
            datapoint_average.clear();              //clear the samples that have been averaged.

            if (datapoint_nv.size() > datapoint_nv_size)
            {
                datapoint_nv.pop_front();//start dropping old data if the NV store is at the limit.
            }
        }

        /* If the sync time has been elapsed, re-write the NV file. */
        double sync_start = (nv_start.tv_nsec / 1000000000.0) + nv_start.tv_sec;
        if ((current - sync_start) >= datapoint_nv_sync_time)
        {
            std::unique_lock<std::mutex> lock(datapoint_nv_mutex); //lock the resources for the datapoint NV

            /* Write the nv data to a file. */
            write_nv(nv_file, datapoint_nv);
            clock_gettime(CLOCK_MONOTONIC, &nv_start);
        }

//        printf("current=%fA voltage=%fV frequency=%fkHz power=%fW, faults=0x%02X\n", dp.getCurrent(), dp.getVoltage(),
//               dp.getFrequency(), dp.getPower(), dp.getFaults());

        /* Finished with this sample, pop it off the queue. */
        data_buffer.pop();
    }


    return 0;
}
