﻿using System;
using System.Threading;

namespace BnWasp
{
	public class DiscoveringWaspWorker
	{
		private static DiscoveringWaspWorker m_instance;
		private bool m_canRun = true;
		private readonly DiscoveringWaspData m_data;
		private readonly WaspStats m_stats;

		private DiscoveringWaspWorker()
		{ 
			m_data = new DiscoveringWaspData();
			m_stats = new WaspStats();
		}

		#region Interface

		public event EventHandler<FeedbackEventArgs> Feedback = delegate {};
		public event EventHandler<CycleEventArgs> Cycle = delegate {};
		public event EventHandler<WorkerStatusEventArgs> Status = delegate {};

		public static DiscoveringWaspWorker Instance
		{
			get
			{
				if (m_instance == null)
				{
					m_instance = new DiscoveringWaspWorker();
				}
				return m_instance;
			}
		}

		public void Start()
		{
			StartWorker();
		}

		public void Stop()
		{
			m_canRun = false;
			if (m_isRunning)
				ShowFeedback("Stopping...");
			else
				ShowFeedback("Already stopped");
		}

		#endregion

		#region Event helpers

		private void ShowFeedback(string text, FeedbackEventType type = FeedbackEventType.Dbg)
		{
			System.Diagnostics.Debug.WriteLine(text);

			Feedback(this, new FeedbackEventArgs(type, text));
		}

		private void ShowStatus(int tags, int records)
		{
			Status(this, new WorkerStatusEventArgs(tags, records));
		}

		private void SignalNextCycle(int number)
		{
			Cycle(this, new CycleEventArgs(number));
		}

		private void FeedbackHandler(object sender, FeedbackEventArgs e)
		{
			ShowFeedback(e.Message, e.FType);
		}

		#endregion

		#region Background thread

		private bool m_isRunning = false;
		private Thread m_thread;
		private int m_cycle;

		private void StartWorker()
		{
			// add a lock if multithreading race issues apply
			if (!m_isRunning || m_thread == null || m_thread.ThreadState == ThreadState.Stopped)
			{
				ShowFeedback("Starting...");
				m_thread = new Thread(new ThreadStart(WorkerLoop));
				m_thread.IsBackground = true;
				m_thread.Name = "DiscoveringWaspWorker";
				m_thread.Start();
			}
			else
			{
				ShowFeedback("Thread is already running.");
			}			
		}

		public void WorkerLoop()
		{
			m_canRun = true;
			m_cycle = 0;
			m_isRunning = true;

			m_data.Clear();

			if (ScanAgent == null)
			{
				ScanAgent = new DiscoveringWaspScan();
			}
			ScanAgent.Feedback -= FeedbackHandler;
			ScanAgent.Feedback += FeedbackHandler;

			if (UploadAgent == null)
			{
				UploadAgent = new DiscoveringWaspUpload();
			}
			UploadAgent.Feedback -= FeedbackHandler;
			UploadAgent.Feedback += FeedbackHandler;

			SendingInterval = RegularSendingInterval;

			ShowFeedback("Thread Started");

			while (m_canRun)
			{
				m_cycle++;

				try
				{
					SignalNextCycle(m_cycle);
					RunNextCycle();
					Thread.Sleep(2000);
				}
				catch (Exception ex)
				{
					ShowFeedback(ex.Message);
				}
			}

			m_isRunning = false;
			ScanAgent.Feedback -= FeedbackHandler;
			ShowFeedback("Thread Stopped");
		}

		#endregion

		private readonly TimeSpan RegularSendingInterval = new TimeSpan(0, 5, 0);
		private readonly TimeSpan ShortSendingInterval = new TimeSpan(0, 0, 30);
		private readonly int ScanDurationSecs = 5;

		private DateTime m_lastDataSendTimestamp = DateTime.MinValue;
		private TimeSpan SendingInterval;

		DiscoveringWaspScan ScanAgent;
		DiscoveringWaspUpload UploadAgent;

		private void RunNextCycle()
		{
			ShowStatus(m_data.TagsCount, m_data.RecordsCount);

			try
			{
				TimeSpan timeSinceLastSend = DateTime.UtcNow - m_lastDataSendTimestamp;
				if (timeSinceLastSend.TotalSeconds >= SendingInterval.TotalSeconds)
				{
					SendData();
					m_lastDataSendTimestamp = DateTime.UtcNow;
					ShowStatus(m_data.TagsCount, m_data.RecordsCount);
				}

				PerformDiscovery();
			}
			catch (Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message);
				ShowFeedback("Loop:" + ex.Message);
			}
		}

		private void PerformDiscovery()
		{
			ShowFeedback("Discovering...");
			ScanAgent.PerformScan(m_data, m_stats, ScanDurationSecs);
		}

		private void SendData()
		{
			ShowFeedback("Sending data...");
			bool success = false;

			try
			{
				success = UploadAgent.UploadAdvData(m_data, m_stats);				
			}
			catch (Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message);
				ShowFeedback("Send: " + ex.Message);
				success = false;
			}

			if (success)
			{
				m_data.Clear();
				m_stats.ResetStats();
				ShowFeedback("Data sent successfully");
				SendingInterval = RegularSendingInterval;
			}
			else
			{
				m_stats.AddSendError();
				ShowFeedback("Failed to send data, will try again");
				SendingInterval = ShortSendingInterval;
			}
		}

	}

}

