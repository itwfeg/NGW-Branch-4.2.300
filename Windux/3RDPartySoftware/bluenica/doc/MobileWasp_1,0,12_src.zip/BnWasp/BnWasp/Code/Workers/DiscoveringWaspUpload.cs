﻿using System;
using System.IO;

namespace BnWasp
{
	public class DiscoveringWaspUpload
	{
		public event EventHandler<FeedbackEventArgs> Feedback = delegate {};

		public bool UploadAdvData(DiscoveringWaspData data, WaspStats stats)
		{
			stats.AddTotUploads();

			ShowFeedback(string.Format("{0} record{1} to send", data.RecordsCount, (data.RecordsCount == 1) ? "" : "s"));

			long localAddress = BTDiscoveryInterface.GetLocalAddress();

			MemoryStream ms = new MemoryStream();
			UploadUtils.BuildXmitHeader(ms, localAddress, stats);
			AppendData(ms, data);
			return UploadUtils.SendCollectedData(ms, localAddress, stats, false);
		}

		#region Upload data builder

		private void AppendData(MemoryStream ms, DiscoveringWaspData data)
		{
			// Adv. data header (6 bytes)
			// num of tags (1), num of recs (4), size of a rec (1)
			ms.WriteByte((byte)data.TagsCount);
			byte[] bff = new byte[6];
			BinUtils.UInt32ToPayloadBytes((UInt32)data.RecordsCount, bff, 0);
			ms.Write(bff, 0, 4);
			ms.WriteByte(DiscoveringWaspData.AdvRecTotSize);

			// Lookup table of Tags
			foreach (DiscoveringWaspData.OneTag tag in data.GetTags())
			{
				BinUtils.TagIdToPayloadBytes(tag.Address, bff, 0);
				ms.Write(bff, 0, 6);
				ms.WriteByte(tag.Index);
			}

			// All data records
			foreach (DiscoveringWaspData.OneRecord rec in data.GetRecords())
			{
				// tag index
				ms.WriteByte(rec.TagIndex);

				// timestamp
				UInt32 epoch = Epoch.UTCToEpoch(rec.Utc);
				BinUtils.UInt32ToPayloadBytes(epoch, bff, 0);
				ms.Write(bff, 0, 4);

				// name
				ms.WriteByte(rec.Name[0]);
				ms.WriteByte(rec.Name[1]);

				// data
				ms.Write(rec.Data, 0, DiscoveringWaspData.AdvRecDataSize);
			}
		}

		#endregion

		#region Event helpers

		private void ShowFeedback(string text, FeedbackEventType type = FeedbackEventType.Dbg)
		{
			System.Diagnostics.Debug.WriteLine(text);

			Feedback(this, new FeedbackEventArgs(type, text));
		}

		#endregion

	}

}

