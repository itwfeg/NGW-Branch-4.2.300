// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "Win8CursorShape.h"

Win8CursorShape::Win8CursorShape()
: m_isVisible(false),
  m_threadOwner(-1)
{
}

Win8CursorShape::~Win8CursorShape()
{
}

const CursorShape *Win8CursorShape::getCursorShape() const
{
  if (getIsVisible()) {
    return &m_cursorShape;
  } else {
    return &m_emptyDimensionCursorShape;
  }
}

CursorShape *Win8CursorShape::getCursorShapeForWriting()
{
  return &m_cursorShape;
}

void Win8CursorShape::setVisibility(bool value, int threadOwner)
{
  // Set to false is allowed only for a thread owner. Else, a not owner thread can
  // set the false value after owner thread and then cusrsor shape will disappear.
  if (value || m_threadOwner == threadOwner) {
    m_isVisible = value;
    m_threadOwner = threadOwner;
  }
}

bool Win8CursorShape::getIsVisible() const
{
  return m_isVisible;
}
