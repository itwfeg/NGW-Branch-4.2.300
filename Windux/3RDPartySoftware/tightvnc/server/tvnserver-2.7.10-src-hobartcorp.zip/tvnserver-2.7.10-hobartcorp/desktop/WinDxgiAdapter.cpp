// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "WinDxCriticalException.h"
#include "WinDxRecoverableException.h"

// The header including of this cpp file must be at last place to avoid build conflicts.
#include "WinDxgiAdapter.h"

WinDxgiAdapter::WinDxgiAdapter(WinDxgiDevice *winDxgiDevice)
: m_dxgiAdapter(0)
{
  HRESULT hr = winDxgiDevice->getParent(__uuidof(IDXGIAdapter), reinterpret_cast<void**>(&m_dxgiAdapter));
  if (FAILED(hr)) {
    throw WinDxCriticalException(_T("Can't GetParent for IDXGIAdapter"), hr);
  }
}

WinDxgiAdapter::~WinDxgiAdapter()
{
  if (m_dxgiAdapter != 0) {
    m_dxgiAdapter->Release();
    m_dxgiAdapter = 0;
  }
}

void WinDxgiAdapter::getDxgiOutput(UINT iOutput, IDXGIOutput **iDxgiOutput)
{
  HRESULT hr = m_dxgiAdapter->EnumOutputs(iOutput, iDxgiOutput);
  if (hr == DXGI_ERROR_NOT_FOUND) {
    StringStorage errMess;
    errMess.format(_T("IDXGIOutput not found for iOutput = %u"), iOutput);
    throw WinDxRecoverableException(errMess.getString(), hr);
  } else if (FAILED(hr)) {
    throw WinDxCriticalException(_T("Can't IDXGIAdapter::EnumOutputs()"), hr);
  }
}
