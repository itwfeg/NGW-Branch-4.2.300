#include <errno.h>
#include <list>
#include <map>

#include <queue>
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <thread>
#include <mutex>

#include <unistd.h>
#include <unordered_set>

#include "errlog.h"

#ifndef PILLAR_IPC_SERVER_H
#define PILLAR_IPC_SERVER_H

#define DEFAULT_SOCKET_FILENAME "local.unix"
#define MAX_BUFFER_SZ (64 << 10)


typedef void(*data_handler)(int sender, const void* rx_data, int rx_len);

/**
 * @brief
 * Manage Inter-Process Communications with a Unix socket.
 *
 * Allows the user to broadcast data to a group of clients and receive data from individual clients.
 */
class ipc_server
{

private:
    static void serve_remotes(ipc_server* server, int s_local);
    static void listen_remote(ipc_server* server, int s_remote);

protected:
    std::string socket_filename;    ///socket filename

    int s_local;                    ///local socket file descriptor
    std::thread server_thread;

    std::mutex remote_mutex;                 ///mutex for remote_ variables.
    std::map<int, std::thread*> remotes;    ///remote threads, id'd by their file descriptors

    std::mutex handler_mutex;               ///mutex for handler_ variables.
    data_handler handler_callback;                   ///Handler callback

public:
    const std::string &getSocket_filename() const
    {
        return socket_filename;
    }

public:
    /** Create a server.
     * @param file The filename of the unix socket to host.
     * */
    ipc_server(const std::string& file);

    /** Destroy a server. */
    virtual ~ipc_server();

    /** Start the server
     *
     * @return
     * Returns 0 on success. A negative error code is returned on failure.
     */
    int start();

    /** Stop the server
     *
     * @return
     * Returns 0 on success. A negative error code is returned on failure.
     */
    int stop();

    /** Broadcast data to all of the clients.
     *
     * Broadcast a data package to all of the connnected clients.
     *
     * @param data  The data to transmit to the clients.
     * @param len   The length of the data package in bytes.
     * @return
     * Returns 0 on success. A negative error code is returned on failure.
     */
    int broadcast(const void* data, int len);

    /** Installed a listener callback to execute when data is received from a remote client.
     *
     * The provided handler replaces the existing handler.
     * @param handler   The handler function that receives incoming data from clients.
     * @return
     * Returns 0 on success. A negative error code is returned on failure.
     */
    int install_listener(data_handler handler);

    /** Removes the listener callback.
     */
    void uninstall_listener();

};


#endif //PILLAR_IPC_SERVER_H
