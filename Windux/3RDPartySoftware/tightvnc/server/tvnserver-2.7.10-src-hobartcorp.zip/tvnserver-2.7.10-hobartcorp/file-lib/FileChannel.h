// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __FILECHANNEL_H__
#define __FILECHANNEL_H__

#include "io-lib/Channel.h"

class FileChannel : public Channel
{
public:
  // Set file pointer to specified position starting from current
  // file pointer position. Can move forward and backward.
  virtual void seek(INT64 n) = 0;
};

#endif // __FILECHANNEL_H__
