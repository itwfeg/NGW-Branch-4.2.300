
showPythonPath.py

pause

