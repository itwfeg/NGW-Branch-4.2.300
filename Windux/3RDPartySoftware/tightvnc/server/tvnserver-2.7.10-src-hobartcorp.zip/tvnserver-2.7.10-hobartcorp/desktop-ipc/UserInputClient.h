// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __USERINPUTCLIENT_H__
#define __USERINPUTCLIENT_H__

#include "util/CommonHeader.h"
#include "desktop/UserInput.h"
#include "desktop/ClipboardListener.h"
#include "util/inttypes.h"
#include "DesktopServerProto.h"
#include "DesktopSrvDispatcher.h"

class UserInputClient : public UserInput, public DesktopServerProto,
                        public ClientListener
{
public:
  UserInputClient(BlockingGate *forwGate, DesktopSrvDispatcher *dispatcher,
                  ClipboardListener *clipboardListener);
  virtual ~UserInputClient();

  virtual void sendInit(BlockingGate *gate);
  virtual void setNewClipboard(const StringStorage *newClipboard);
  virtual void setMouseEvent(const Point *newPos, UINT8 keyFlag);
  virtual void setKeyboardEvent(UINT32 keySym, bool down);
  virtual void getCurrentUserInfo(StringStorage *desktopName,
                                  StringStorage *userName);
  virtual void getPrimaryDisplayCoords(Rect *rect);
  virtual void getDisplayNumberCoords(Rect *rect,
                                      unsigned char dispNumber);
  virtual void getNormalizedRect(Rect *rect);
  virtual void getWindowCoords(HWND hwnd, Rect *rect);
  virtual HWND getWindowHandleByName(const StringStorage *windowName);
  virtual void getApplicationRegion(unsigned int procId, Region *region);

  // To catch a new clipboard
  virtual void onRequest(UINT8 reqCode, BlockingGate *backGate);

protected:
  UINT8 m_sendMouseFlags;
  ClipboardListener *m_clipboardListener;
};

#endif // __USERINPUTCLIENT_H__
