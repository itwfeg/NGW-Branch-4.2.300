var opcua = require("node-opcua");

/* Construct the OPC-UA server */
var server = new opcua.OPCUAServer({
    port: 4334,
    resourcePath: "UA/PillarTech",
    buildInfo: {
        productName: "IoTConceptServer",
        buildNumber: "1000",
        buildDate: new Date(2017, 8, 1)
    }
});

var testVariable = 1;

/* Initialize the server. */
server.initialize(function() {
    console.log("OPC UA Server Initialized.");

    /* Construct an address space for the device. */
    var addressSpace = server.engine.addressSpace;
    var device = addressSpace.addObject({
        organizedBy: addressSpace.rootFolder.objects,
        browseName: "P6000"
    });

    addressSpace.addVariable({
        componentOf: device,
        browseName: "TestVariable",
        dataType: "Double",
        value: {
            get: function() { return new opcua.Variant({dataType: opcua.DataType.Double, value: testVariable});},
            set: function(variant) {
                testVariable = parseFloat(variant.value);
            }
        }
    });

    server.start(function() {
        console.log("Server is running ...");
        console.log("Port " + server.endpoints[0].port);

        var endpointUrl = server.endpoints[0].endpointDescriptions()[0].endpointUrl;
        console.log("Endpoint: ", endpointUrl );
    })
});

setInterval(function() { testVariable += 1;}, 500);

