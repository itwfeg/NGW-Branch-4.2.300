// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "WindowProcHolder.h"

WindowProcHolder::WindowProcHolder()
{
}

WindowProcHolder::~WindowProcHolder()
{
}

LRESULT CALLBACK WindowProcHolder::defWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  WindowProcHolder *wph = (WindowProcHolder *)GetWindowLongPtr(hWnd, GWLP_USERDATA);

  if (wph == 0) {
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
  }

  bool useDefWndProc = false;

  LRESULT r = wph->windowProc(hWnd, uMsg, wParam, lParam, &useDefWndProc);

  if (useDefWndProc) {
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
  }

  return r;
}
