import string
import shellCommand
import osUtils
import os
import configInfo

def display(message, width=1024, height=600, fontFamily="Sans", fontSize=24, timer=None):
    if os.name == 'posix':
        mbExeFullPath = os.path.join(os.sep, "usr", "bin", "mb")
    else:
        mbExeFullPath = configInfo.getRootFolder() + os.path.join(os.sep, "mb")

    myEnv = os.environ
    myEnv['DISPLAY'] = ":0"
    myEnv['LC_ALL'] = "en_US.UTF-8"

    cmd = []
    cmd.append(mbExeFullPath)
    cmd.append("-full")
    cmd.append('-msg')
    cmd.append(message)

    if timer != None:
        cmd.append("-timer")
        timeValue = 1000 * timer
        cmd.append(str(timeValue))
	
    cmd.append("-fontFamily")
    cmd.append(fontFamily)
    cmd.append("-fontPointSize")
    cmd.append(str(fontSize))
    cmd.append("&")
    exitCode, stdout, stderr, pid = shellCommand.execCommandGetPID(cmd,False)

    return (exitCode,  pid)

def destroy(pid):
    # do not try and kill a process with id 0 or we will be killing everything
    if pid != 0:
        try:
            osUtils.killProcess(pid)
        except:
            pass

if __name__ == "__main__":
    import time
    exitCode,  mbId = display("hello")
    print mbId
    time.sleep(5)
    destroy(mbId)
