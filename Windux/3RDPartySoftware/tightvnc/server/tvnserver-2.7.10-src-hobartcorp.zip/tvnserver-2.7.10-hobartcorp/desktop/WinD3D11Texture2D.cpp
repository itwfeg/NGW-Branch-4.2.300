// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "WinDxRecoverableException.h"

// The header including of this cpp file must be at last place to avoid build conflicts.
#include "WinD3D11Texture2D.h"

WinD3D11Texture2D::WinD3D11Texture2D(ID3D11Device *device, D3D11_TEXTURE2D_DESC *deskTexture)
: m_dxgiTexture(0)
{
  HRESULT hr = device->CreateTexture2D(deskTexture, 0, &m_dxgiTexture);
  if (FAILED(hr) || m_dxgiTexture == 0) {
    throw WinDxRecoverableException(_T("Can't CreateTexture2D()"), hr);
  }
}

WinD3D11Texture2D::WinD3D11Texture2D(IDXGIResource *dxgiResource)
: m_dxgiTexture(0)
{
  HRESULT hr = dxgiResource->QueryInterface(__uuidof(ID3D11Texture2D), reinterpret_cast<void **>(&m_dxgiTexture));
  if (FAILED(hr) || m_dxgiTexture == 0) {
    throw WinDxRecoverableException(_T("Can't QueryInterface() to create ID3D11Texture2D"), hr);
  }
}

WinD3D11Texture2D::~WinD3D11Texture2D()
{
  if (m_dxgiTexture != 0) {
    m_dxgiTexture->Release();
  }
}

ID3D11Texture2D *WinD3D11Texture2D::getTexture() const
{
  return m_dxgiTexture;
}
