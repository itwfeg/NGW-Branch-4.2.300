var searchData=
[
  ['topleftx',['TopLeftX',['../structDSM__KEEP__OUT__REGION.html#ab7f52eeb394bc84320f76fbd44cc7e24',1,'DSM_KEEP_OUT_REGION']]],
  ['toplefty',['TopLeftY',['../structDSM__KEEP__OUT__REGION.html#a9ff5821e331a3d20104eb0f9e601809a',1,'DSM_KEEP_OUT_REGION']]]
];
