// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WALLPAPERUTIL_H__
#define __WALLPAPERUTIL_H__

#include "server-config-lib/ConfigReloadListener.h"
#include "log-writer/LogWriter.h"

class WallpaperUtil : protected ConfigReloadListener
{
public:
  WallpaperUtil(LogWriter *log);
  virtual ~WallpaperUtil();

  virtual void updateWallpaper();

protected:
  virtual void onConfigReload(ServerConfig *serverConfig);

private:
  LogWriter *m_log;
};

#endif // __WALLPAPERUTIL_H__
