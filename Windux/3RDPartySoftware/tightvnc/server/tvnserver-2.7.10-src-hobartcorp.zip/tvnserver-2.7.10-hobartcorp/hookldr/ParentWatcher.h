// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __PARENTWATCHER_H__
#define __PARENTWATCHER_H__

#include "win-system/ParentProcess.h"
#include "ParentEventsListener.h"
#include "win-system/WindowsEvent.h"
#include "util/CommonHeader.h"
#include "thread/Thread.h"
#include <Tlhelp32.h>

class ParentWatcher : private Thread
{
public:
  ParentWatcher(ParentEventsListener *parentEventListener);
  virtual ~ParentWatcher();

private:
  virtual void execute();
  virtual void onTerminate();

  ParentEventsListener *m_parentEventListener;
  ParentProcess m_parentProcess;
  WindowsEvent m_timer;
};

#endif // __PARENTWATCHER_H__
