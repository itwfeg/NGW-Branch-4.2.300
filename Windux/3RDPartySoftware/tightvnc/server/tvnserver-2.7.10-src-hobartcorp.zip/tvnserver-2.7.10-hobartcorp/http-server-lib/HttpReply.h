// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _HTTP_REPLY_H_
#define _HTTP_REPLY_H_

#include "io-lib/DataOutputStream.h"
#include "io-lib/IOException.h"

class HttpReply
{
public:
  HttpReply(DataOutputStream *dataOutput);
  virtual ~HttpReply();

  void send200() throw(IOException);
  void send404() throw(IOException);

protected:
  DataOutputStream *m_dataOutput;
};

#endif
