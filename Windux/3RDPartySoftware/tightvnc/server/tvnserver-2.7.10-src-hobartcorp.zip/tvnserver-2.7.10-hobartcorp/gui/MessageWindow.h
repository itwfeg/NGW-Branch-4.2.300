// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDOW_H__
#define __WINDOW_H__

#include "util/CommonHeader.h"
#include "WindowMessageHandler.h"

class MessageWindow
{
public:
  // messageHandler is an external message handler that replace the
  // wndProc() function on message processing. If
  // messageHandler == 0 the wndProc() function will be used.
  MessageWindow(const HINSTANCE hinst, const TCHAR *windowClassName,
                WindowMessageHandler *messageHandler = 0);
  virtual ~MessageWindow(void);

  virtual bool createWindow(WindowMessageHandler *messageHandler = 0);
  virtual void destroyWindow();

  HWND getHWND() const { return m_hwnd; }

protected:
  // Function must return true value if the message has been processed.
  virtual bool wndProc(UINT message, WPARAM wParam, LPARAM lParam) { return true; }

  HWND m_hwnd;
  WindowMessageHandler *m_messageHandler;

  HINSTANCE m_hinst;
  TCHAR *m_windowClassName;

private:
  ATOM regClass(HINSTANCE hinst, TCHAR *windowClassName);

  static LRESULT CALLBACK staticWndProc(HWND hwnd,
                                        UINT message,
                                        WPARAM wParam,
                                        LPARAM lParam);
};

#endif // __WINDOW_H__
