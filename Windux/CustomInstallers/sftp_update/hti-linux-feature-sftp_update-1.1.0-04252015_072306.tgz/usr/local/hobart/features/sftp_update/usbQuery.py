import sys
import os
import string

if os.name == 'posix':
    import dbus
else:
    import wmi

class UsbDeviceQuery:

    DEVICE_TYPE_USB = 'USB'
    DEVICE_TYPE_ALL = '*'
    
    def __init__(self):
        if os.name == 'posix':
            self.deviceList = {}
            self.mountList = {}
            self.bus = None

    def splitPNPDeviceID(self,device,tokenNumber=-2):
        if os.name == 'nt':
            tokens = string.split(device.PNPDeviceID,'&')
            return tokens[tokenNumber]
        elif os.name == 'posix':
            pass

    def findDeviceBasedOnMount(self, mountPoint):
        for curdevice in self.deviceList.keys():
            if curdevice == mountPoint[:-1]:
                return curdevice
        return None

    def findDevicesInClass(self, device_class=DEVICE_TYPE_USB):
        if os.name == 'nt':
            # TODO: only supports USB devices at this time under Windows
            c = wmi.WMI ()
            usbDevices = c.Win32_DiskDrive(InterfaceType=device_class)
            return usbDevices
        elif os.name == 'posix':
            self.bus = dbus.SystemBus()
            ud_manager_obj = self.bus.get_object("org.freedesktop.UDisks", "/org/freedesktop/UDisks")
            ud_manager = dbus.Interface(ud_manager_obj, 'org.freedesktop.UDisks')
            devices = ud_manager.EnumerateDevices()
            for dev in devices:
                device_obj = self.bus.get_object("org.freedesktop.UDisks", dev)
                device_props = dbus.Interface(device_obj, dbus.PROPERTIES_IFACE)
                if device_props.Get('org.freedesktop.UDisks.Device', "DeviceIsDrive"):
                    vendor = device_props.Get('org.freedesktop.UDisks.Device', "DriveVendor")
                    model = device_props.Get('org.freedesktop.UDisks.Device', "DriveModel")
                    interface = device_props.Get('org.freedesktop.UDisks.Device', "DriveConnectionInterface")
                    serial_number = device_props.Get('org.freedesktop.UDisks.Device', "DriveSerial")
                    media = device_props.Get('org.freedesktop.UDisks.Device', "DriveMediaCompatibility")
                    if device_props.Get('org.freedesktop.UDisks.Device', "DeviceIsRemovable"):
                        storageType = 'Removable'
                    else:
                        storageType = 'Fixed'
                    test = device_props.Get('org.freedesktop.UDisks.Device', 'DeviceFile')
                    self.deviceList[device_props.Get('org.freedesktop.UDisks.Device', "DeviceFile")]  = {  
                        'device' : dev, 
                        'mount_points' : [],
                        'vendor' : str(vendor),
                        'description' : str(model), 
                        'media' : media,
                        'storageType' : storageType,
                        'interface' : str(interface),
                        'serial_number' : str(serial_number)}
                elif device_props.Get('org.freedesktop.UDisks.Device', "DeviceIsMounted"):
                    self.mountList[str(device_props.Get('org.freedesktop.UDisks.Device', "DeviceFile"))] = {'mount_points' : str(device_props.Get('org.freedesktop.UDisks.Device', "DeviceMountPaths")[0])}

            # now we have to attach mount points to device entries
            for dev in self.mountList.keys():
                #print dev
                #print self.mountList[dev]['mount_points']
                if dev[:-1] in self.deviceList.keys():
                    self.deviceList[dev[:-1]]['mount_points']  = self.deviceList[dev[:-1]]['mount_points']  + [{'partition' : dev,  'mount_point' : self.mountList[dev]['mount_points']}]
 
            #print self.deviceList
            if device_class == '*':
                return self.deviceList
            else:
                newList = {}
                for i in self.deviceList.keys():
                    if self.deviceList[i]['interface'] == string.lower(device_class):
                        newList[i] = self.deviceList[i]
                return newList
                
    def getDeviceId(self, device):
        if os.name == 'nt':
            return device.PNPDeviceID
        elif os.name == 'posix':
            return device

    # only relevant for posix OS
    def getMountPoints(self, device):
        if os.name == 'nt':
            return []
        elif os.name == 'posix':
            return self.deviceList[device]['mount_points']
        
    # getDeviceLetter on posix system returns mount point of device not
    # device letter like on windows
    def getDeviceLetter(self, device):
        if os.name == 'nt':
            physical_disk = device
            for partition in physical_disk.associators ("Win32_DiskDriveToDiskPartition"):
                for logical_disk in partition.associators ("Win32_LogicalDiskToPartition"):
                    return logical_disk.Caption
        elif os.name == 'posix':
            try:
                mountPoint = self.deviceList[device]['mount_points'][0]['mount_point']
            except:
                mountPoint = None
            return mountPoint
        
    def getVendorName(self, device):
        if os.name == 'nt':
            vendor = self.splitPNPDeviceID(device,1)
            return vendor[4:]
        elif os.name == 'posix':
            return self.deviceList[device]['vendor']

    def getStorageType(self, device):
        if os.name == 'nt':
            dataItem = self.splitPNPDeviceID(device,0)
            tokens = string.split(dataItem,'\\')
            return tokens[1]
        elif os.name == 'posix':
            return self.deviceList[device]['storageType']
            
    def getProductDescription(self, device):
        if os.name == 'nt':
            prodDesc = self.splitPNPDeviceID(device,2)
            return prodDesc[5:]
        elif os.name == 'posix':
            return self.deviceList[device]['description']

    def getConnectionInterface(self, device):
        if os.name == 'posix':
            return self.deviceList[device]['interface']
        else:
            return None

    def getSerialNumber(self, device):
        if os.name == 'nt':
            dataItem = self.splitPNPDeviceID(device,-2)
            tokens = string.split(dataItem,'\\')
            if len(tokens) > 1:
                return string.upper(tokens[1])
            else:
                return string.upper(tokens[0])
        elif os.name == 'posix':
            return string.upper(self.deviceList[device]['serial_number'])

if __name__ == "__main__":
    usbDevices = UsbDeviceQuery()
    if os.name == 'nt':
        devices = usbDevices.findDevicesInClass(usbDevices.DEVICE_TYPE_USB)
    else:
        devices = usbDevices.findDevicesInClass(usbDevices.DEVICE_TYPE_ALL)
    i = 0
    for dev in devices:
        i = i + 1
        print ''
        print 'Device %d' % i
        print 'Device Id: %s' % usbDevices.getDeviceId(dev)
        print 'Storage Type: %s' % usbDevices.getStorageType(dev)
        print 'Vendor Name: %s' % usbDevices.getVendorName(dev)
        print 'Description: %s' % usbDevices.getProductDescription(dev)
        print 'Serial Number: %s' % usbDevices.getSerialNumber(dev)
        print 'Device Letter: %s' % usbDevices.getDeviceLetter(dev)
        print 'Mount Points:' 
        mountPoints = usbDevices.getMountPoints(dev)
        for i in xrange(0, len(mountPoints)):
            print '  Parition: %s' % mountPoints[i]['partition']
            print '  Mount Point: %s' % mountPoints[i]['mount_point']
        print 'Interface: %s' % usbDevices.getConnectionInterface(dev)
