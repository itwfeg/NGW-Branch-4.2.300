var searchData=
[
  ['dsm_5fdatadesc_5ftype',['DSM_DATADESC_TYPE',['../dsmsdk_8h.html#a13fbdca3ed1aadc6e59ddda6d8962d12',1,'dsmsdk.h']]],
  ['dsm_5fimage_5fblend_5fmode',['DSM_IMAGE_BLEND_MODE',['../dsmsdk_8h.html#a0fd55dc403447cbf5f88f43b6cf267c0',1,'dsmsdk.h']]],
  ['dsm_5fresult',['DSM_RESULT',['../dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16e',1,'dsmsdk.h']]]
];
