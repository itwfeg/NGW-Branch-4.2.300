var NAVTREE =
[
  [ "DigimarcLabelSDK", "index.html", [
    [ "Change List", "ChangeList.html", [
      [ "Overview", "ChangeList.html#changeListOverview", [
        [ "Deprecated APIs", "ChangeList.html#deprecatedNotes", null ]
      ] ],
      [ "Release: 1.3.0", "ChangeList.html#release_1-3-0", [
        [ "Features", "ChangeList.html#features_1-3-0", null ]
      ] ],
      [ "Release: 1.2.3", "ChangeList.html#release_1-2-3", [
        [ "Features", "ChangeList.html#features_1-2-3", null ],
        [ "Fixes", "ChangeList.html#fixes_1-2-3", null ]
      ] ],
      [ "Release: 1.2.2", "ChangeList.html#release_1-2-2", [
        [ "Features", "ChangeList.html#features_1-2-2", null ]
      ] ],
      [ "Release: 1.2.1", "ChangeList.html#release_1-2-1", [
        [ "Fixes", "ChangeList.html#fixes_1-2-1", null ]
      ] ],
      [ "Release: 1.2.0", "ChangeList.html#release_1-2-0", [
        [ "Features", "ChangeList.html#features_1-2-0", null ],
        [ "Fixes", "ChangeList.html#fixes_1-2-0", null ]
      ] ],
      [ "Release: 1.1.1", "ChangeList.html#release_1-1-1", [
        [ "Fixes", "ChangeList.html#fixes_1-1-1", null ]
      ] ],
      [ "Release: 1.1.0", "ChangeList.html#release_1-1-0", [
        [ "Features", "ChangeList.html#features_1-1-0", null ],
        [ "Fixes", "ChangeList.html#fixes_1-1-0", null ]
      ] ],
      [ "Release: 1.0.0", "ChangeList.html#release_1-0-0", [
        [ "Features", "ChangeList.html#features_1-0-0", null ]
      ] ]
    ] ],
    [ "Embedding Guide", "EmbeddingGuide.html", [
      [ "Overview", "EmbeddingGuide.html#embeddingGuideOverview", null ],
      [ "Recommended Label Settings", "EmbeddingGuide.html#recommendedLabelSettings", null ],
      [ "Label Coverage", "EmbeddingGuide.html#labelCoverage", [
        [ "Minimum Coverage", "EmbeddingGuide.html#minimumCoverage", null ],
        [ "Small Labels", "EmbeddingGuide.html#smallLabels", null ],
        [ "Minimum Clear Area", "EmbeddingGuide.html#minimumClearArea", null ],
        [ "Keep Out Regions", "EmbeddingGuide.html#keepOutRegions", null ]
      ] ],
      [ "Image Blend Mode", "EmbeddingGuide.html#imageBlendMode", null ]
    ] ],
    [ "Open Source Components", "OpenSourceComponents.html", [
      [ "Overview", "OpenSourceComponents.html#openSourceComponentsOverview", null ],
      [ "Copyright Notices", "OpenSourceComponents.html#copyrightNotices", [
        [ "optionsparser.h", "OpenSourceComponents.html#optionsparser", null ],
        [ "aes", "OpenSourceComponents.html#aes", null ],
        [ "sha1", "OpenSourceComponents.html#sha1", null ],
        [ "stdint", "OpenSourceComponents.html#stdint", null ],
        [ "yajl", "OpenSourceComponents.html#yajl", null ]
      ] ]
    ] ],
    [ "Testing Guide", "TestingGuide.html", [
      [ "Overview", "TestingGuide.html#testingGuideOverview", null ],
      [ "General Testing Guidelines", "TestingGuide.html#generalTestingGuidelines", null ],
      [ "Robustness", "TestingGuide.html#robustness", null ],
      [ "Data Accuracy", "TestingGuide.html#dataAccuracy", null ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Classes", null, [
      [ "Class List", "annotated.html", "annotated" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"ChangeList.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';