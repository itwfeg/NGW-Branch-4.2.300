// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _SOLID_BRUSH_H_
#define _SOLID_BRUSH_H_

#include "Brush.h"

class SolidBrush : public Brush
{
public:
  SolidBrush(COLORREF color);
  virtual ~SolidBrush();
};

#endif
