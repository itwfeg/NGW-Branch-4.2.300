// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "RectSerializer.h"
#include <tchar.h>
#include <stdio.h>
#include "util/Exception.h"

void RectSerializer::toString(const Rect *rect, StringStorage *strOut)
{
  strOut->format(_T("%dx%d+%d+%d"), rect->getWidth(),
                                    rect->getHeight(),
                                    rect->left,
                                    rect->top);
}

Rect RectSerializer::toRect(const StringStorage *strIn)
{
  int width, height, x, y;
  TCHAR c;
  if (_stscanf(strIn->getString(),
               _T("%dx%d+%d+%d%c"), &width, &height, &x, &y, &c) != 4 ||
      width < 0 || height < 0) {
    StringStorage errMess;
    errMess.format(_T("Invalid string format to convert it to a rectangle")
                   _T(" (%s)."), strIn->getString());
    throw Exception(errMess.getString());
  }
  return Rect(x, y, x + width, y + height);
}
