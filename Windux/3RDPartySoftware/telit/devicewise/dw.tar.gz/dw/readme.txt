OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
O                                                         O
O XXXXXX   XXXXXXXX XX      XX XXXXXXXX   XXXX   XXXXXXXX O
O XX   XX  XX       XX      XX    XX     XX  XX  XX       O
O XX    XX XX        XX    XX     XX    XX    XX XX       O
O XX    XX XX        XX    XX     XX    XX       XX       O
O XX    XX XXXXXX     XX  XX      XX    XX       XXXXXX   O
O XX    XX XX         XX  XX      XX    XX       XX       O
O XX    XX XX          XXXX       XX    XX    XX XX       O
O XX   XX  XX          XXXX       XX     XX  XX  XX       O
O XXXXXX   XXXXXXXX     XX     XXXXXXXX   XXXX   XXXXXXXX O
O                                                         O
OXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO
OXXXXXXXX  XXXXXX  XX        XXX      XXX        XXXXXXXXXO
OXXXXXXXX  XXXXXX  XXXXX  XXXXX  XXXX  XX  XXXXXXXXXXXXXXXO
OXXXXXXXX  XXXXXX  XXXXX  XXXXX  XXXXXXXX  XXXXXXXXXXXXXXXO
OXXXXXXXX  XXXXXX  XXXXX  XXXXX  XXXXXXXX  XXXXXXXXXXXXXXXO
OXXXXXXXX  XX  XX  XXXXX  XXXXXX      XXX      XXXXXXXXXXXO
OXXXXXXXX  XX  XX  XXXXX  XXXXXXXXXXX  XX  XXXXXXXXXXXXXXXO
OXXXXXXXX  XX  XX  XXXXX  XXXXXXXXXXX  XX  XXXXXXXXXXXXXXXO
OXXXXXXXX  XX  XX  XXXXX  XXXXX  XXXX  XX  XXXXXXXXXXXXXXXO
OXXXXXXXX          XX        XXX      XXX        XXXXXXXXXO
OXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO
OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO


Getting Help
============

 * Online Help:

   http://help.devicewise.com

 * Product Support:

   http://help.devicewise.com/display/M2MOPEN/Technical+Support

 
Special Notes
=============

 When running the 32-bit version of deviceWISE Asset
 or Enterprise Gateway on a 64-bit Operating System,
 you must install the 32-bit C runtime compatibility
 library for the OS. For example, on CentOS i386:
 
  # yum install -y glibc.i686
  
Open Source & Third Party License Information
=============================================

 * Refer to the ThirdPartyLicenses directory.
