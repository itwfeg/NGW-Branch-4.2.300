// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDATEFILTER_H__
#define __UPDATEFILTER_H__

#include "WindowsScreenGrabber.h"
#include "ScreenDriver.h"
#include "rfb/FrameBuffer.h"
#include "thread/LocalMutex.h"
#include "UpdateContainer.h"
#include "GrabOptimizator.h"

class UpdateFilter
{
public:
  UpdateFilter(ScreenDriver *screenDriver,
               FrameBuffer *frameBuffer,
               LocalMutex *frameBufferCriticalSection,
               LogWriter *log);
  ~UpdateFilter();

  void filter(UpdateContainer *updateContainer);

private:
  void getChangedRegion(Region *rgn, const Rect *rect);
  void updateChangedRect(Region *rgn, const Rect *rect);
  void updateChangedSubRect(Region *rgn, const Rect *rect);

  // This function update the screen grabber frame buffer.
  // If success the function returns the true.
  // Also, this function researching an optimal way to grab from
  // the whole screen grabbing or 
  bool grab();

  ScreenDriver *m_screenDriver;
  FrameBuffer *m_frameBuffer;
  LocalMutex *m_fbMutex;
  GrabOptimizator m_grabOptimizator;

  LogWriter *m_log;
};

#endif // __UPDATEFILTER_H__
