// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _NOTIFY_ICON_WINDOW_H_
#define _NOTIFY_ICON_WINDOW_H_

#include "util/CommonHeader.h"

#include "WindowProcHolder.h"

class NotifyIconWindow
{
public:
  NotifyIconWindow();
  virtual ~NotifyIconWindow();

  HWND getWindow();

  void setWindowProcHolder(WindowProcHolder *wph);
  
protected:
  HWND m_window;
  WindowProcHolder *m_wph;

  friend class NotifyIcon;
};

#endif
