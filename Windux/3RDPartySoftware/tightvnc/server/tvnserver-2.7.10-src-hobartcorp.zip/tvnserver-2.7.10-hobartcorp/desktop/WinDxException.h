// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDXEXCEPTION_H__
#define __WINDXEXCEPTION_H__

#include "util/Exception.h"

class WinDxException : public Exception
{
public:
  WinDxException(const TCHAR *message, HRESULT errCode);
  virtual ~WinDxException();

  HRESULT getErrorCode() const;

private:
  HRESULT m_errCode;
};

#endif // __WINDXEXCEPTION_H__
