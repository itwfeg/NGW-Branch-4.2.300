// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "Pen.h"

#include <crtdbg.h>

Pen::Pen(int type, int width, COLORREF color)
: m_pen(NULL)
{
  m_pen = CreatePen(type, width, color);

  _ASSERT(m_pen != NULL);
}

Pen::~Pen()
{
  DeleteObject(m_pen);
}
