// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CLIPBOARDLISTENER_H__
#define __CLIPBOARDLISTENER_H__

#include "util/CommonHeader.h"

class ClipboardListener
{
public:
  ClipboardListener();
  ~ClipboardListener();

  // Interface function
  virtual void onClipboardUpdate(const StringStorage *newClipboard) = 0;
};

#endif // __CLIPBOARDLISTENER_H__
