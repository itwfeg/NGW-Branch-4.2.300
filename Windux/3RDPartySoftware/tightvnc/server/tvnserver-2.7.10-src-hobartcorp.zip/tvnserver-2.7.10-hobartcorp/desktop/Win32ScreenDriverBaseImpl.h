// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WIN32SCREENDRIVERBASEIMPL_H__
#define __WIN32SCREENDRIVERBASEIMPL_H__

#include "ScreenDriver.h"
#include "WinVideoRegionFounderImpl.h"
#include "CursorPositionDetector.h"
#include "CursorShapeDetector.h"
#include "WindowsCursorShapeGrabber.h"
#include "CopyRectDetector.h"

// This class implements "grabbers" and "detectors" which is not couple� with screen frame buffer.
class Win32ScreenDriverBaseImpl : public WinVideoRegionFounderImpl
{
public:
  Win32ScreenDriverBaseImpl(UpdateKeeper *updateKeeper,
                          UpdateListener *updateListener,
                          LocalMutex *fbLocalMutex,
                          LogWriter *log);
  virtual ~Win32ScreenDriverBaseImpl();

  // Starts screen update detection if it not started yet.
  virtual void executeDetection();

  // Stops screen update detection.
  virtual void terminateDetection();

  virtual bool grabCursorShape(const PixelFormat *pf);
  virtual const CursorShape *getCursorShape();
  virtual Point getCursorPosition();

  virtual void getCopiedRegion(Rect *copyRect, Point *source);

protected:
  LocalMutex *getFbMutex();

private:
  LocalMutex *m_fbLocalMutex;

  CursorPositionDetector m_cursorPosDetector;
  WindowsCursorShapeGrabber m_curShapeGrabber;
  CursorShapeDetector m_curShapeDetector;

  CopyRectDetector m_copyRectDetector;
};

#endif // __WIN32SCREENDRIVERBASEIMPL_H__
