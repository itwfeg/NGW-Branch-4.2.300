// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __HOOKSUPDATEDETECTOR_H__
#define __HOOKSUPDATEDETECTOR_H__

#include "UpdateDetector.h"
#include "win-system/WindowsEvent.h"
#include "HookInstaller.h"
#include "gui/MessageWindow.h"
#include "HookUpdateTimer.h"
#include "win-system/Process.h"
#include "log-writer/LogWriter.h"

class HooksUpdateDetector : public UpdateDetector
{
public:
  HooksUpdateDetector(UpdateKeeper *updateKeeper,
                      UpdateListener *updateListener, LogWriter *log);
  virtual ~HooksUpdateDetector();

protected:
  virtual void execute();
  virtual void onTerminate();

  void start32Loader();
  void terminate32Loader();

  WindowsEvent m_initWaiter;

  HookInstaller *m_hookInstaller;
  MessageWindow *m_targetWin;
  HookUpdateTimer m_updateTimer;
  Process m_hookLoader32;

private:
  void broadcastMessage(UINT message);

  static const TCHAR HOOK_LOADER_NAME[];

  LogWriter *m_log;
};

#endif // __HOOKSUPDATEDETECTOR_H__
