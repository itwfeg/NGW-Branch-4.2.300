var searchData=
[
  ['resolution',['Resolution',['../structDSM__DATADESC.html#a2e5f971445d298411973f7e2b91ae740',1,'DSM_DATADESC']]]
];
