var requires_login = true;

angular.module('SharedServices', [])
    .config(function ($httpProvider) {
        $httpProvider.responseInterceptors.push('myHttpInterceptor');
        var spinnerFunction = function (data, headersGetter) {
            // todo start the spinner here
            if($('#loading').css('display') !== 'block'){
Debug.log([data,headersGetter], 'SharedServices Show Loading');
              $('#loading').show();
            }
            return data;
        };
        $httpProvider.defaults.transformRequest.push(spinnerFunction);
    })
// register the interceptor as a service, intercepts ALL angular ajax http calls
    .factory('myHttpInterceptor', function ($q, $window) {
        return function (promise) {
            return promise.then(function (response) {
                // do something on success
                // todo hide the spinner
                if($('#loading').css('display') === 'block'){
Debug.log([$q, $window, response], 'SharedServices Hide Loading on success');
                  $('#loading').hide();
                }
                return response;

            }, function (response) {
                // do something on error
                // todo hide the spinner
                if($('#loading').css('display') === 'block'){
Debug.log([$q, $window, response], 'SharedServices Hide Loading on error');
                  $('#loading').hide();
                }
                return $q.reject(response);
            });
        };
    });

var LocalPortal = angular.module('LocalPortal', ['ngResource','SharedServices'])
  .value('lpApi', {
    //Properties
    _apiList : [],
    _apiUri : '/api',
    _functionStack : {},
    _host : document.location.hostname,
    _port : document.location.port,
    _protocol : document.location.protocol,
    sessionTimeout : 900000,
    // Functions
    _addToCallStack : function(param) {
      this._functionStack = $.extend(this._functionStack, param);
    },
    _doApiCall : function(dataSegment, command, params) {
      var segment = {};
      segment[dataSegment] = {"command" : command};
      if (params) {
        segment[dataSegment]["params"] = params;
      }

      this._addToCallStack(segment);

      $.subscribe('api.received', function(e,data) {
        $.publish(command, data[dataSegment]);
      });
    },
    _restoreAuthState : function() {
      var _authState = (sessionStorage.getItem('lpApi.authState')) ? JSON.parse(sessionStorage.getItem('lpApi.authState')) : {};
      lpApi.authState = _authState;
    },
    _setAuthTime : function(timeVal) {
      lpApi.authState.authTime = timeVal;
      lpApi._storeAuthState();
    },
    _storeAuthState : function() {
      sessionStorage.setItem('lpApi.authState', JSON.stringify(lpApi.authState));
    },
    _url : function() {
      return this._protocol + '//'
              + this._host +
              (this._port ? ':' + this._port : '')
      + this._apiUri;
    },
    alertList : function() {
      this._doApiCall("alertList", "alert.list");
      return this;
    },
    apiList : function() {
      this._doApiCall("apiList", "api.list");
      return this;
    },
    assetCreate : function (name, type, assetProperties) {
      var params = {"name" : name, "type" : type, "properties" : assetProperties};
      this._doApiCall("assetCreate", "asset.create", params);
      return this;
    },
    assetDelete : function (name) {
      var params = {"name" : name};
      this._doApiCall("assetDelete", "asset.delete", params);
      return this;
    },
    assetDetail : function(params) {
      this._doApiCall("assetDetail", "asset.detail", params);
      return this;
    },
    assetList : function() {
      this._doApiCall("assetList", "asset.list");
      return this;
    },
    assetTypeDetail : function(params) {
      this._doApiCall("assetTypeDetail", "asset.type.detail",params);
      return this;
    },
    assetTypeList : function() {
      this._doApiCall("assetTypeList", "asset.type.list");
      return this;
    },
    assetTypeListall : function() {
      this._doApiCall("assetTypeListall", "asset.type.listall");
      return this;
    },
    cloudlinkInfo : function() {
      this._doApiCall("cloudlinkInfo", "cloudlink.info");
      return this;
    },
    cloudlinkRegistrationHWList : function() {
      this._doApiCall("cloudlinkRegistrationHWList", "cloudlink.registration.hwlist");
      return this;
    },
    cloudlinkSet : function(params) {
      this._doApiCall("cloudlinkSet", "cloudlink.set", params);
      return this;
    },
    cloudlinkStart : function() {
      this._doApiCall("cloudlinkStart", "cloudlink.start");
      this.cloudlinkInfo().loggingQuery({limit:"5",page:"0"}).systemNodeinfo().osInfo();
      return this;
    },
    cloudlinkStop : function() {
      this._doApiCall("cloudlinkStop", "cloudlink.stop");
      this.cloudlinkInfo().loggingQuery({limit:"5",page:"0"}).systemNodeinfo().osInfo();
      return this;
    },
    filesystemStagingDirList : function(params) {
      this._doApiCall("filesystemStagingDirList", "filesystem.staging.dir.list", params);
      return this;
    },
    getPayload : function() {
      // Append globally required calls, first
      this._functionStack["modemInfo"] = {"command" : "modem.info"};
      var payload = this._functionStack;
      this._functionStack = {};
      return payload;
    },
    getUrl : function(uriExt) {
      return this._url() + uriExt;
    },
    go : function(uriExt,$scope) {
      Debug.log('go() going.');
      $scope.assertAuthentication();

      uriExt = uriExt || '';

      var payload = JSON.stringify(this._functionStack);
      this._functionStack = {};

      var ajaxSettings = {
        async : false,
        type : "POST",
        dataType: "json",
        cache : false,
        data  : payload,
        crossDomain : true,
        success : function(data,textStatus,jqXHR) {
          Debug.log(lpApi.authState, "lpApi.authState");
          Debug.log(data, "AjaxSuccess[data]");

          if ((data.success !== undefined && data.success !== false) || data.success === undefined) {
            lpApi._setAuthTime(new Date().getTime());
          }

          for (var o in data){
            Debug.log(data[o],'Adding AjaxSuccess[data].'+o+' to $scope.'+o);
            $scope[o] = data[o];
          }

          $.publish('api.received', data, this);

          //after pub, clear all api.recieved events
          $.unsubscribe('api.received');
        },
        error : function(jqXHR, textStatus, errorThrown){
          Debug.log(lpApi.authState, "lpApi.authState");
          Debug.log(jqXHR, "AjaxError[jqXHR]");
          Debug.log(textStatus, "AjaxError[textStatus]");
          Debug.log(errorThrown, "AjaxError[errorThrown]");
        }
      };
      $.support.cors = true; // Because IE doesn't like cross origin requests by default

      $.ajax(this.getUrl(uriExt), ajaxSettings);

      return $scope;
    },
    init : function(){
      var loc = document.location;

      this._apiList = sessionStorage.getItem('apiList');
      this._host = loc.hostname;
      this._port = loc.port;
      this._protocol = loc.protocol;

      //store a reference to this object for later callbacks to access
      window.lpApi = this;

      //restore authentication state if any
      lpApi._restoreAuthState();
    },
    loggingCount : function(params) {
      this._doApiCall("loggingCount", "logging.count", params);
      return this;
    },
    loggingQuery : function(params) {
      this._doApiCall("loggingQuery", "logging.query", params);
      return this;
    },
    loggingTypeList : function() {
      this._doApiCall("loggingTypeList", "logging.type.list");
      return this;
    },
    logOff : function() {
      lpApi._setAuthTime(0);
      sessionStorage.removeItem('lpApi.authState');
    },
    modemActivate : function() {
      this._doApiCall("modemActivate", "modem.activate");
      return this;
    },
    modemConnect : function() {
      this._doApiCall("modemConnect", "modem.connect");
      return this;
    },
    modemDiagnostic : function() {
      this._doApiCall("modemDiagnostic", "modem.diagnostic");
      return this;
    },
    modemDisconnect : function() {
      this._doApiCall("modemDisconnect", "modem.disconnect");
      return this;
    },
    modemGet : function() {
      this._doApiCall("modemGet", "modem.get");
      return this;
    },
    modemInfo : function() {
      this._doApiCall("modemInfo", "modem.info");
      return this;
    },
    modemSet : function(params) {
      this._doApiCall("modemSet", "modem.set", params);
      return this;
    },
    networkCheckDns : function(params) {
      this._doApiCall("networkCheckDns", "network.check.dns", params);
      return this;
    },
    networkCheckPing : function(params) {
      this._doApiCall("networkCheckPing", "network.check.ping", params);
      return this;
    },
    networkCheckTcp : function(params) {
      this._doApiCall("networkCheckTcp", "network.check.tcp", params);
      return this;
    },
    osInfo : function() {
      this._doApiCall("osInfo", "os.info");
      return this;
    },
    osNetworkDnsSet : function (params) {
      this._doApiCall("osNetworkDnsSet", "os.network.dns.set", params);
      return this;
    },
    osNetworkGet : function() {
      this._doApiCall("osNetworkGet", "os.network.get");
      return this;
    },
    osNetworkIfaceSet : function (params) {
      this._doApiCall("osNetworkIfaceSet", "os.network.iface.set", params);
      return this;
    },
    osReboot : function() {
      this._doApiCall("osReboot", "os.reboot");
      return this;
    },
    osTimeInfo: function() {
      this._doApiCall("osTimeInfo", "os.time.info");
      return this;
    },
    osTimeSet: function(params) {
      this._doApiCall("osTimeSet", "os.time.set", params);
      return this;
    },
    osTimezoneList: function() {
      this._doApiCall("osTimezoneList", "os.timezone.list");
      return this;
    },
    osTimezoneSet: function(params) {
      this._doApiCall("osTimezoneSet", "os.timezone.set", params);
      return this;
    },
    securityPasswordChange : function(params) {
      this._doApiCall("securityPasswordChange", "security.password.change", params);
      return this;
    },
    systemNodeinfo : function() {
      this._doApiCall("systemNodeinfo", "system.nodeinfo");
      return this;
    },
    systemNodeset : function(name, description, status) {
      var params = {"nodeName" : name, "nodeDescription" : description, "status" : status};
      this._doApiCall("systemNodeset", "system.nodeset", params);
      return this;
    },
    systemProductinfo : function() {
      this._doApiCall("systemProductinfo", "system.productinfo");
      return this;
    },
    systemSysvarList : function() {
      this._doApiCall("systemSysvarList", "system.sysvar.list");
      return this;
    },

    tr50Get : function () {
      this._doApiCall("tr50Get", "tr50.get");
      return this;
    },
    tr50RegistrationHWList : function() {
      this._doApiCall("tr50RegistrationHWList", "hardwareid.list");
      return this;
    },
    tr50Set : function (params) {
      this._doApiCall("tr50Set", "tr50.set", params);
      return this;
    },
    tr50Start : function () {
      this._doApiCall("tr50Start", "tr50.start");
      this.tr50Get().loggingQuery({limit:"5",page:"0"}).systemNodeinfo().osInfo();
      return this;
    },
    tr50Stop : function () {
      this._doApiCall("tr50Stop", "tr50.stop");
      this.tr50Get().loggingQuery({limit:"5",page:"0"}).systemNodeinfo().osInfo();
      return this;
    },
    tr50TunnelGet : function () {
      this._doApiCall("tr50TunnelGet", "tr50.tunnel.get");
      return this;
    },
    tr50TunnelSet : function (params) {
      this._doApiCall("tr50TunnelSet", "tr50.tunnel.set", params);
      return this;
    },

    tunnelInfo : function() {
      this._doApiCall("tunnelInfo", "tunnel.info");
      return this;
    },
    tunnelSet : function(params){
      this._doApiCall("tunnelSet", "tunnel.set", params);
      this._doApiCall("tunnelInfo", "tunnel.info");
      return this;
    },
    tunnelNamedCreate : function(params){
      this._doApiCall("tunnelNamedCreate", "tunnel.named.create", params);
      return this;
    },
    tunnelNamedDelete : function(params){
      this._doApiCall("tunnelNamedDelete", "tunnel.named.delete", params);
      return this;
    },
    tunnelNamedList : function(){
      this._doApiCall("tunnelNamedList", "tunnel.named.list");
      return this;
    },
    tunnelStopall : function(){
      this._doApiCall("tunnelStopall", "tunnel.stopall");
      return this;
    },
    useropExec : function(params){
      this._doApiCall("useropExec", "userop.exec", params);
      return this;
    },
    useropList : function(){
      this._doApiCall("useropList", "userop.list");
      return this;
    }
  })
  .config(function($routeProvider) {
    Debug.log('config() configuring');
    if (requires_login) {
      $routeProvider.
        when('/login', {templateUrl: 'partials/login.html', controller: LoginCtrl}).
        otherwise({redirectTo:'/login', templateUrl: 'partials/login.html', controller: LoginCtrl});
    }
    else {
      $routeProvider.
        when('/account', {templateUrl: 'partials/account.html', controller: AccountCtrl}).
        when('/login', {templateUrl: 'partials/login.html', controller: LoginCtrl}).
        when('/home', {templateUrl: 'partials/gateway.html', controller: GatewayCtrl}).
        when('/gateway', {templateUrl: 'partials/gateway.html', controller: GatewayCtrl}).
        when('/assets', {templateUrl: 'partials/assets.html', controller: AssetsCtrl}).
        when('/connectivity', {templateUrl: 'partials/connectivity.html', controller: ConnectivityCtrl}).
        when('/logs', {templateUrl: 'partials/logs.html', controller: LogsCtrl}).
        when('/node', {templateUrl: 'partials/node.html', controller: NodeCtrl}).
        when('/network', {templateUrl: 'partials/network.html', controller: NetworkCtrl}).
        when('/cloudlink', {templateUrl: 'partials/cloudlink.html', controller: CloudlinkCtrl}).
        when('/tr50', {templateUrl: 'partials/tr50.html', controller: Tr50Ctrl}).
        when('/cellular', {templateUrl: 'partials/cellular.html', controller: CellularCtrl}).
        otherwise({redirectTo:'/home', templateUrl: 'partials/gateway.html', controller: GatewayCtrl});
    }
    for (var that in this) {
      if (that.substr(-4) === 'Ctrl') {
        if (this[that].prototype.menu) {
          for (var index in this[that].prototype.menu.items) {
            $routeProvider.
              when(this[that].prototype.menu.items[index].href, {
                templateUrl: this[that].prototype.menu.items[index].template,
                controller: that
              });
          }
        }
        if (this[that].prototype.ctrlActions) {
          for (var index in this[that].prototype.ctrlActions.items) {
            $routeProvider.
              when(this[that].prototype.ctrlActions.items[index].href, {
                templateUrl: this[that].prototype.ctrlActions.items[index].template,
                controller: that
              });
          }
        }
        if (this[that].prototype.mainActions) {
          for (var index in this[that].prototype.mainActions.items) {
            $routeProvider.
              when(this[that].prototype.mainActions.items[index].href, {
                templateUrl: this[that].prototype.mainActions.items[index].template,
                controller: that
              });
          }
        }

        if (this[that].prototype.secondaryActions) {
          for (var index in this[that].prototype.secondaryActions.items) {
            $routeProvider.
              when(this[that].prototype.secondaryActions.items[index].href, {
                templateUrl: this[that].prototype.secondaryActions.items[index].template,
                controller: that
              });
          }
        }
      }
    }
  })
  .directive('appTopMenu', function() {
    return {
      restrict: 'E',
      templateUrl: 'partials/top-menu.html'
    }
  })
  .directive('appMenu', function() {
    return {
      restrict: 'E',
      templateUrl: 'partials/menu.html',
      link: function(scope,element,attr) {
        for (var that in this) {
          if (that.substr(-4) === 'Ctrl') {
            if (this[that].prototype.menu) {
              for (var index in this[that].prototype.menu.items) {
                scope.menu.items[scope.menu.items.length] = this[that].prototype.menu.items[index];
              }
            }
          }
        }
      }
    }
  })
  .filter('ip4Octet', function() {
    return function(input,octetPos){
      if (input !== undefined){
        var octets = new Array;
        octets = input.split('.');
        return octets[octetPos];
      }
      return null;
    }
  })
  .filter('obfuscate', function() {
    return function(input){
      if (input !== undefined){
        var output = input.replace(/\w/g, '*');
        return output;
      }
      return null;
    }
  })
  .run(function(){ Debug.log('run() running'); });

var IndexCtrl = function($scope, lpApi, $location, $http) {
  Debug.log('Loaded IndexCtrl');
  //Properties
  $scope._localPortalContainer = 'container';

  $scope._loggedIn = true;

  $scope.menu = {
    items: [{
      name: 'Gateway',
      classes: 'selected',
      href: '/home',
      id: 'menu-item-gateway',
      ngShow: true
    }, {
      name: 'Assets',
      classes: '',
      href: '/assets',
      id: 'menu-item-assets',
      ngShow: "UnlimitedAccess"
    }],
    adminItems: [{
      name: 'Administration',
      id: 'menu-item-administration',
      href: '',
      target: '',
      click: '',
      subMenu: '/partials/administration_menu.html',
      ngShow: true
    }, {
      name: 'Help',
      id: 'menu-item-help',
      href: 'http://help.devicewise.com/display/M2MOPEN/Asset+Gateway+Web+Interface+User%27s+Guide',
      target: '_blank',
      click: '',
      ngShow: true
    }]
  };

  $scope.showSystemMsg = false;

  $scope.topMenu = {
    items: [{
      spanId: 'username-label'
    }, {
      href: '/account',
      aId: 'top-menu-account',
      name: 'Account'
    }, {
      liClasses: 'last',
      href: '/login',
      aId: 'menu-item-logoff',
      name: 'Log off'
    }]
  };

  //Functions
  $scope.assertAuthentication = function() {
    if(!$scope.isAuthenticated()){
      lpApi.logOff();
      $scope.setRouteReload('/login');
    }
  };

  $scope.clearSystemMsg = function() {
    $scope.systemMsg = null;
    $scope.systemMsgType = null;
    $scope.showSystemMsg = false;
  };

  $scope.errorCallback = function(data, status, headers, config) {
    Debug.log(data, "AjaxError[data]");
    Debug.log(status, "AjaxError[status]");
    Debug.log(headers, "AjaxError[headers]");
    Debug.log(config, "AjaxError[config]");
    Debug.log('Loading display '+$('#loading').css('display'),'$scope.errorCallback');
    if ($('#content-container').hasClass('ng-cloak')) { $('#content-container').removeClass('ng-cloak'); }
    $('#loading').hide();
  };

  $scope.execCtrlAction = function(action) {
    var cmd = {}, q = '', params = {};

    if (action.indexOf('/?') > 2) {
      q = action.substr(action.indexOf('/?')+2);
      action = action.substr(0, action.indexOf('/?'));
    }

    if (action.indexOf('#/') === -1) {
      cmd = action;
    }
    else {
      cmd = action.substr(action.indexOf('#/')+2);
    }

    var pairs = new Array(), pair = new Array();
    if (q.length !== undefined && q.length > 0) {
      pairs = q.split('&');
    }

    for (var a=0; a<pairs.length; a++) {
      pair = pairs[a].split(':');
      params[pair[0]] = pair[1];
    }

    if(lpApi[cmd]){
      lpApi[cmd](params);
Debug.log([cmd, params],'$scope.execCtrlAction [cmd, params]');
      $http.post(lpApi.getUrl(''), lpApi.getPayload())
        .error($scope.errorCallback).success(function (a,b,c,d) { $scope.successCallback(a,b,c,d); });
    }
    else if (cmd.indexOf('/')>0) {
      var ctrl_cmd = cmd.split('/'), ctrl;
      ctrl = ctrl_cmd[0].substr(0,1).toUpperCase()+ctrl_cmd[0].substr(1)+'Ctrl';
      if(window[ctrl][ctrl_cmd[1]]){
Debug.log([ ctrl, ctrl_cmd[1], $scope ],'$scope.execCtrlAction ctrl, ctrl_cmd[1], $scope');
        window[ctrl][ctrl_cmd[1]]($scope);
      }
    }

    return false;
  };

  $scope.formatTs = function(timestamp, format) {
    if(timestamp === undefined){
      return null;
    }
    return new Date(new Number(timestamp)).format(format);
  };

  $scope.getLocalPortalContainer = function() {
    return $scope._localPortalContainer;
  };

  $scope.getLoggedInStatus = function() {
    return $scope._loggedIn;
  };

  $scope.hasAuthStateRole = function(role) {
    if (role === true || role === false) {
      return role;
    }

    if (lpApi.authState !== undefined && lpApi.authState.roles !== undefined) {
      if (typeof role === 'string') {
        if (lpApi.authState.roles.indexOf(role) !== -1) { return true; }
      }
      else if (typeof role === 'object') {
        for (var r in role) {
          if (lpApi.authState.roles.indexOf(role[r]) !== -1) { return true; }
        }
      }
    }
    return false;
  };

  $scope.isAuthenticated = function() {
    if (sessionStorage) {
      if (sessionStorage.getItem('lpApi.authState')) {
        lpApi.init();
        return ((new Date().getTime() - lpApi.authState.authTime) < lpApi.sessionTimeout);
      }
      else {
        lpApi.init();
        return false;
      }
    }
    return false;
  };

  $scope.loadData = function(data, status, headers, config) {
    if(status === 200){
      for(var a in data){
        $scope[a] = data[a];
      }
    }
  };

  $scope.menuItemSelect = function($scope, menu_item_name) {
    for (var index in $scope.menu.items) {
      if ($scope.menu.items[index].id === 'menu-item-'+menu_item_name){
        $('#'+$scope.menu.items[index].id).parent('li').addClass('selected');
      }
      else {
        $('#'+$scope.menu.items[index].id).parent('li').removeClass('selected');
      }
    }
  };

  $scope.postError = function(data, status, headers, config){
    // output error message
    $scope.setSystemMsg(data.errorMessage[0], 'error')
  };

  $scope.setSystemMsg = function(msg, msgType) {
    $scope.systemMsg = msg;
    $scope.systemMsgType = msgType;
    $scope.showSystemMsg = true;
    $('body,html').animate({scrollTop: 0}, 0);
  };

  $scope.setLocalPortalContainer = function($container){
    $scope._localPortalContainer = $container;
  };

  $scope.setLoggedInStatus = function(status) {
    $scope._loggedIn = status;
  };

  $scope.setRoute = function($route) {
    $location.path($route);
  };

  $scope.setRouteReload = function($route) {
    $location.path($route);
    document.location.reload();
  };

  $scope.showSecondaryActions = function(bool) {
    return bool;
  };

  $scope.successCallback = function(data, status, headers, config) {
    Debug.log([data, status, headers, config], '$scope.successCallback');
    Debug.log(lpApi.authState, "lpApi.authState");
    Debug.log(data, "AjaxSuccess[data]");
    Debug.log(status, "AjaxSuccess[status]");
    Debug.log(headers, "AjaxSuccess[headers]");
    Debug.log(config, "AjaxSuccess[config]");
    if (status === 200) {
      lpApi._setAuthTime(new Date().getTime());
    }

    var requireRecall = [];

    for (var o in data){
      Debug.log(data[o],'$scope.successCallback Adding AjaxSuccess[data]'+o+' to $scope.'+o);
      $scope[o] = data[o];
      if (['systemNodeinfo'].indexOf(o) === -1 && $scope[o].params !== undefined && $scope[o].params.status !== undefined && $scope[o].params.status.substr(-3) === 'ing') {
        var _o = {};
        _o[o] = $scope[o].params;
        requireRecall.push(_o);
      }
    }

    $.publish('api.received', data, this);

    //after pub, clear all api.recieved events
    $.unsubscribe('api.received');
    Debug.log('Loading display '+$('#loading').css('display'),'$scope.successCallback');
    if ($('#content-container').hasClass('ng-cloak')) { $('#content-container').removeClass('ng-cloak'); }
    $('#loading').hide();
    if (requireRecall.length) {
Debug.log(requireRecall, 'Require Recall');
      for (var rtrI=0; rtrI<requireRecall.length; ++rtrI) {
Debug.log(requireRecall[rtrI],'$scope.successCallback');
Debug.log(Object.keys(requireRecall[rtrI])[0],'$scope.successCallback');
        var cmd = Object.keys(requireRecall[rtrI])[0];
        var params;
        lpApi[cmd](params);
Debug.log([cmd, params],'$scope.successCallback [cmd, params]');
      }
      $http.post(lpApi.getUrl(''), lpApi.getPayload())
        .error($scope.errorCallback).success(function (a,b,c,d) { $scope.successCallback(a,b,c,d); });
    }
  };

  // Executions
  if (!$scope.isAuthenticated()) {
    $scope.setLocalPortalContainer('container-small');
    $scope.setLoggedInStatus(false);
    $scope.setRoute('/login');
  }

  $(document).on('mouseenter', '#menu-item-administration', function(){
    $(this).children('ng-include').children('ul').css('display','block');
  }).on('mouseleave', '#menu-item-administration', function(){
    $(this).children('ng-include').children('ul').css('display','none');
  });
};

IndexCtrl.$inject = ['$scope', 'lpApi', '$location', '$http'];

// Loading modules and plugins on initial page load. Must be done synchronously otherwise the angular.module for Local Portal will not have what it needs to configure itself properly.
// module_js must always be defined with 'login' otherwise system will never function.
var module_js = ['login'], plugin_js = [], cmd_stack = {};

// Operational files need to be found in the modules directory for core behavior, and the plugins directory for custom 3rd party behavior.
cmd_stack = $.extend(cmd_stack, {
    "filesystemStagingDirListModules" : {
      "command" : "filesystem.staging.dir.list",
      "params" : {
        "path" : "www/modules"
      }
    }
  });
cmd_stack = $.extend(cmd_stack, {
    "filesystemStagingDirListPlugins" : {
      "command" : "filesystem.staging.dir.list",
      "params" : {
        "path" : "www/plugins"
      }
    }
  });
var fileAjaxSettings = {
  async : false,
  type : "POST",
  dataType: "json",
  cache : false,
  data  : JSON.stringify(cmd_stack),
  crossDomain : true,
  success : function(data,textStatus,jqXHR) {
    Debug.log(data, "fileAjaxSettings.AjaxSuccess[data]");
    if (data['filesystemStagingDirListModules'] !== undefined && data['filesystemStagingDirListModules'].success === true && data['filesystemStagingDirListModules'].params !== undefined) {
      var module_files = data['filesystemStagingDirListModules'].params.files;
      module_js = [];
      Debug.log(module_files, 'fileAjaxSettings.AjaxSuccess[data][filesystemStagingDirListModules]');
      for (var mf in module_files) {
        if (module_files[mf].type === 'file') {
          Debug.log(module_files[mf].name, 'fileAjaxSettings.AjaxSuccess Module name');
          var extension = (data['filesystemStagingDirListModules'].params.files[mf].name.indexOf('.js') > -1) ? '.js' : '.JS';
          module_js.push(module_files[mf].name.substring(0,data['filesystemStagingDirListModules'].params.files[mf].name.indexOf(extension)));
        }
      }
      Debug.log(module_js, 'fileAjaxSettings.AjaxSuccess module_js');
    }

    if (data['filesystemStagingDirListPlugins'] !== undefined && data['filesystemStagingDirListPlugins'].success === true && data['filesystemStagingDirListPlugins'].params !== undefined) {
      var plugin_dirs = data['filesystemStagingDirListPlugins'].params.files;
      plugin_js = [];
      Debug.log(plugin_dirs, 'filesystemStagingDirListPlugins');
      for (var pd in plugin_dirs) {
        if (plugin_dirs[pd].type !== 'file') {
          Debug.log(plugin_dirs[pd].name, 'Plugin name');
          plugin_js.push(plugin_dirs[pd].name);
        }
      }
    }

    $.publish('api.received', data, this);
    //after pub, clear all api.recieved events
    $.unsubscribe('api.received');
  },
  error : function(jqXHR, textStatus, errorThrown){
    Debug.log(jqXHR, "AjaxError[jqXHR]");
    Debug.log(textStatus, "AjaxError[textStatus]");
    Debug.log(errorThrown, "AjaxError[errorThrown]");
  }
};
$.support.cors = true; // Because IE doesn't like cross origin requests by default
$.ajax(document.location.protocol+'//'+document.location.hostname+':'+document.location.port+'/api', fileAjaxSettings);

$.ajaxSetup({async:false});
for (var m_index in module_js){
  var m_name = module_js[m_index];
  var m_ctrl = String(m_name.substr(0,1)).toUpperCase()+m_name.substr(1).toLowerCase()+'Ctrl';
  var m_path = 'modules/'+m_name+'.js';
  Debug.log(m_name, 'Module Loading');
  if(m_ctrl in window) {
    Debug.log(m_ctrl,'Already have');
  }
  else {
    Debug.log(m_path, 'Attempting to retrieve');
    $.get(m_path, function(){ Debug.log('Loaded '+m_path+' => '+m_ctrl); });
  }
}
requires_login = (module_js.length < 2);
delete module_js;

if (plugin_js.length>0) {
  for (var p_index in plugin_js){
    var p_name = plugin_js[p_index];
    var p_ctrl = String(p_name.substr(0,1)).toUpperCase()+p_name.substr(1).toLowerCase()+'Ctrl';
    var p_path = 'plugins/'+p_name+'/'+p_name+'.js';
    Debug.log(p_name, 'Plugin Loading');
    if(p_ctrl in window) {
      Debug.log(p_ctrl,'Already have');
    }
    else {
      Debug.log(p_path, 'Attempting to retrieve:');
      $.get(p_path, function(){ Debug.log('Loaded '+p_path+' => '+p_ctrl); });
    }
  }
}
delete plugin_js;
$.ajaxSetup({async:true});

$(document).on('keydown', '.ip_octet', function(e) {
  var kCode = e.keyCode;
  var octet_pos = $(this).attr('id').substr($(this).attr('id').lastIndexOf('-')+1);
  var val = $(this).val();
  var val_len = $(this).val().length;
  if (kCode === 110 || kCode === 190) {
    if (val_len < 1) {
      alert('The current octet is still empty.');
      $(this).val(val);
      return false;
    }
    else {
      $(this).next('input').focus();
      return false;
    }
  }
  else if (octet_pos < 1 && (kCode === 48 || kCode === 96)) {
    alert('This ip octet requires a number greater than 0.');
    $(this).val(val);
    return false;
  }
  else if (kCode === 8 || kCode === 9 || kCode === 16 || kCode === 17 || kCode === 18 || kCode === 27 || kCode === 35 || kCode === 36 || kCode === 37 || kCode === 38 || kCode === 39 || kCode === 40 || kCode === 45 || kCode === 46) {
   return true;
  }
  else if (kCode < 48 || (kCode > 57 && kCode < 96) || kCode > 105) {
    alert('Not a valid entry.');
    $(this).attr('value', val);
    return false;
  }
  else {
    $(document).on('keyup', '.ip_octet', function (e) {
      var val_len = $(this).val().length;
      if (val_len > 2) {
        $(this).next('input').focus();
        return false;
      }
      return false;
    });
  }
  return true;
});
//$(document).ready(function(){ $('#loading').show().hide(); });
