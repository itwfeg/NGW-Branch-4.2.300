/**
 *
 *  DIGIMARC CORPORATION PROPRIETARY INFORMATION
 *  Copyright, Digimarc Corporation.  All Rights Reserved.
 *
 *  This software contains confidential information, including trade secrets, 
 *  of Digimarc that is protected by the confidentiality agreement entered into 
 *  between you and Digimarc.  It is important that this information be used only
 *  in accordance with your agreement with Digimarc.  Receipt of this software 
 *  conveys no license under Digimarc's patent, trademark, trade secret, or 
 *  copyright rights.  Use of this software - and the technology detailed therein - 
 *  requires a license from Digimarc. The technology embodied in this software is 
 *  protected by US and International Patents.
 *
 */
 
package com.digimarc.LabelEmbedder.example;

import com.digimarc.DLSDK.*;
import java.io.*;
 
public class JniExampleKeepOutRegions {

	static {
		System.loadLibrary("dlsdkjava");
	}

	static void save(String filename, byte[] img, int width, int height) {
		try {
			FileOutputStream outfile = new FileOutputStream(filename);
			PrintWriter writer = new PrintWriter(outfile);
			writer.format("P5\n%d %d\n255\n", width, height);
			writer.flush();
			outfile.write(img);
			outfile.close();
		} catch(FileNotFoundException ex) {
		} catch(IOException ex) {
		}
	}
	
	public static void main(String[] args) {
	
		// User specified Expanded Fresh data
		String gtin13 = "1234567890128";
		String sellByDate = "181231";
		String price = "12345";
		String weightInPounds = "";
		String weightInKilograms = "";
		String count = "98";
		
		// User specified options
		String outputFile = "JniExampleOut.pgm";
		DSM_DATADESC_TYPE dataDescType = DSM_DATADESC_TYPE.DSM_DATADESC_GRAYSCALE_INV;
		int imageResolution = 203;
		int imageWidth = 406;
		int imageHeight = 406;
		int imageStride = 406; // image width * bytes per pixel
		int dotDensity = 40;
		int dotSize = 1;
		int watermarkResolution = 75;
		DSM_IMAGE_BLEND_MODE imageBlendMode = DSM_IMAGE_BLEND_MODE.DSM_IMAGE_BLEND_MODE_OVERWRITE;
		
		// User specified Keep out regions
		int numKeepOutRegions = 2;
		
		int keepOutRegion0TopLeftX = 25;
		int keepOutRegion0TopLeftY = 50;
		int keepOutRegion0Width = 75;
		int keepOutRegion0Height = 100;

		int keepOutRegion1TopLeftX = 150;
		int keepOutRegion1TopLeftY = 200;
		int keepOutRegion1Width = 125;
		int keepOutRegion1Height = 175;
	
		// Create a LabelEmbedder object
		// Instead of instantiating LabelEmbedder object each time you embed a label,
		// we recommend that you instantiate the LabelEmbedder only once.
		// And then you can embed as many labels as you want, 
		// This helps reduce the overhead of setting up the embedder and is more efficient,
		// especially if you are printing multiple labels at the same label settings.
		LabelEmbedder le = new LabelEmbedder();
		
		// Initialize the LabelEmbedder
		DSM_RESULT result = le.initialize();
		if (result != DSM_RESULT.DSM_OK) {
			System.out.println("Error initializing!");
			System.exit(1);
		}
		
		// Create an ImageDescriptor object
		ImageDescriptor img = new ImageDescriptor();
		
		// Assign user specified data to image descriptions
		img.setBytesPerRow(imageStride);
		img.setDataType(dataDescType);
		img.setWidth(imageWidth);
		img.setHeight(imageHeight);
		img.setResolution(imageResolution);
		
		// Create an EmbedderOptions object
		EmbedderOptions embedopts = new EmbedderOptions();
		
		// Assign user specified options to embedder options
		embedopts.setDotDensity(dotDensity);
		embedopts.setDotSize(dotSize);
		embedopts.setWatermarkResolution(watermarkResolution);
		embedopts.setImageBlendMode(imageBlendMode);
		
		// Configure user specified keep out regions
		// Set total number of keep out regions
		embedopts.setNumKeepOutRegions(numKeepOutRegions);

		// Configure keep out region 0
		embedopts.getKeepOutRegionByIndex(0).setTopLeftX(keepOutRegion0TopLeftX);
		embedopts.getKeepOutRegionByIndex(0).setTopLeftY(keepOutRegion0TopLeftY);
		embedopts.getKeepOutRegionByIndex(0).setWidth(keepOutRegion0Width);
		embedopts.getKeepOutRegionByIndex(0).setHeight(keepOutRegion0Height);

		// Configure keep out region 1
		embedopts.getKeepOutRegionByIndex(1).setTopLeftX(keepOutRegion1TopLeftX);
		embedopts.getKeepOutRegionByIndex(1).setTopLeftY(keepOutRegion1TopLeftY);
		embedopts.getKeepOutRegionByIndex(1).setWidth(keepOutRegion1Width);
		embedopts.getKeepOutRegionByIndex(1).setHeight(keepOutRegion1Height);
		
		// Get a converted JSON string payload from user specified Expanded Fresh data
		String json = le.getExpandedFreshJson(gtin13, sellByDate, price, weightInPounds, weightInKilograms, count);
		
		// Set the payload in embedder options
		embedopts.setPayload(json);
		
		// Create image buffer
		byte[] buffer = new byte[imageWidth * imageHeight];
		
		// Embed the Label
		result = le.embed(img, embedopts, buffer);
		
		// Check embed result
		if (result == DSM_RESULT.DSM_OK) {
			save(outputFile, buffer, imageWidth, imageHeight);
			System.out.println("Embed successful");
			System.out.println("Output image saved as " + outputFile);
		} else {
			System.out.println("Embed failed with result code " + result);
		}
	}
}