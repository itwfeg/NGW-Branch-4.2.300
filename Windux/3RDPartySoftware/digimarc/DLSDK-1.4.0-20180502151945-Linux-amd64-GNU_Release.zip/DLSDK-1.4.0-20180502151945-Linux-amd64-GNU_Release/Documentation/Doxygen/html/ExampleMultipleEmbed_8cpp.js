var ExampleMultipleEmbed_8cpp =
[
    [ "main", "ExampleMultipleEmbed_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "MyWriteImageToPGMFile", "ExampleMultipleEmbed_8cpp.html#ad5029e04a563b879a1f3ddee01d23b80", null ]
];