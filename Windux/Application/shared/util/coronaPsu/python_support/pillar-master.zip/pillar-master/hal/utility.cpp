//
// Created by collin on 11/11/17.
//

#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

#include "utility.h"

int write_nv(const std::string &filename, std::list<Datapoint> &nv)
{
    /* Open the file for write. */
    int fd = open(filename.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if(fd < 0)
        return -errno;

    /* Write the serialized data to the output file. */
    char serialized[64];
    for(auto nv_item = nv.begin();nv_item != nv.end();++nv_item)
    {
        size_t sz = (size_t)nv_item->serialize_binary((void*)serialized);   //serialize the NV data.
        write(fd, serialized, sz);                                          //write the serialized data to the NV file.
    }

    close(fd);
    return 0;
}

int read_nv(const std::string &filename, std::list<Datapoint>& nv)
{
    /* Open the file for read. */
    int fd = open(filename.c_str(), O_RDONLY);
    if(fd < 0)
        return -errno;

    /* Get the file size. */
    size_t sz = lseek(fd, 0, SEEK_END);
    lseek(fd, 0, SEEK_SET); //rewind

    nv.clear();//cleanup the current database before populating it.

    /* Read in single datapoints until the end of the file. */
    Datapoint dp(0,0,0,0,0);
    uint8_t buffer[DATAPOINT_BINARY_SERIALIZATION_SIZE];
    int status = 0;
    for(int k = 0;k < sz;k += DATAPOINT_BINARY_SERIALIZATION_SIZE)
    {
        status = read(fd, buffer, sizeof(buffer));
        if(status < 0)
        {
            status = -errno;
            close(fd);
            return status;
        }
        dp.deserialize_binary(buffer);
        nv.push_back(dp);
    }

    /* Cleanup */
    close(fd);

    return 0;
}
