// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _FOLDER_LISTENER_H_
#define _FOLDER_LISTENER_H_

#include "util/inttypes.h"
#include "ft-common/FileInfo.h"

//
// This class is used to easy listing files from specified directory
// or system root to array of FileInfo[].
//
// Also it calculates data size in bytes that needed for
// file transfer protocol if server supportes compression.
//
// If specified folder name is empty it will return system roots,
// file list from specified catalog otherwise.
//
// Class usage:
//
// First, create instance, call list() method,
// after that get needed information through get methods
//

class FolderListener
{
public:
  FolderListener(const TCHAR *folderPath);
  ~FolderListener();

  const FileInfo *getFilesInfo() const;
  UINT32 getFilesCount() const;

  bool list();

protected:
  StringStorage m_folderPath;
  FileInfo *m_filesInfo;
  UINT32 m_filesCount;
};

#endif
