
local string = require("string")
local table = require("table")
local io = require("io")

local base = _G

module("xml")

XmlParser = {};

function ToXmlString(value)
	value = string.gsub (value, "&", "&amp;");		-- '&' -> "&amp;"
	value = string.gsub (value, "<", "&lt;");		-- '<' -> "&lt;"
	value = string.gsub (value, ">", "&gt;");		-- '>' -> "&gt;"
	--value = string.gsub (value, "'", "&apos;");	-- '\'' -> "&apos;"
	value = string.gsub (value, "\"", "&quot;");	-- '"' -> "&quot;"
	-- replace non --printable char -> "&#xD;"
   	value = string.gsub(value, "([^%w%&%;%p%\t% ])",
       	function (c) 
       		return string.format("&#x%X;", string.byte(c)) 
       		--return string.format("&#x%02X;", string.byte(c)) 
       		--return string.format("&#%02d;", string.byte(c)) 
       	end);
	return value;
end

function FromXmlString(value)
  	value = string.gsub(value, "&#x([%x]+)%;",
      	function(h) 
      		return string.char(tonumber(h,16)) 
      	end);
  	value = string.gsub(value, "&#([0-9]+)%;",
      	function(h) 
      		return string.char(tonumber(h,10)) 
      	end);
	value = string.gsub (value, "&quot;", "\"");
	value = string.gsub (value, "&apos;", "'");
	value = string.gsub (value, "&gt;", ">");
	value = string.gsub (value, "&lt;", "<");
	value = string.gsub (value, "&amp;", "&");
	return value;
end
   
function ParseArgs(s)
	local arg = {}
	string.gsub(s, "(%w+)=([\"'])(.-)%2", function (w, _, a)
    	arg[w] = FromXmlString(a);
	end)
	return arg
end

function ParseXmlText(xmlText)
	local node = {Name=nil,Value=nil,Attributes={}}
	local stack = {}
	local ni,c,label,xarg, empty
	local i, j = 1, 1
	
	-- put the root node on the top of the stack
	table.insert(stack,node)
	
	while true do
		ni,j,c,label,xarg, empty = string.find(xmlText, "<(%/?)([%w:]+)(.-)(%/?)>", i)
		if not ni then break end
		
		local text = string.sub(xmlText, i, ni-1);
		if not string.find(text, "^%s*$") then
			node.Value=(node.Value or "")..FromXmlString(text);
		end
		--base.print("text: "..text)
		
		if empty == "/" then  -- empty element tag
			stack[#stack][label]={Name=label,Value=nil,Attributes=ParseArgs(xarg)}
			--base.print("empty element:"..label.." ")
		elseif c == "" then   -- start tag
			node = {Name=label, Value=nil, Attributes=ParseArgs(xarg)}
			--if label~=nil then
			--	base.print("start element:"..label.." ")
			--end
			--if stack[#stack].Name~=nil then
			--	base.print("  child of:"..stack[#stack].Name.." ")
			--end
			-- put the new node on the stack
			if stack[#stack][label]~=nil then
				--base.print("  node already exists on stack")
				if stack[#stack][label].Name==nil then
					--base.print("  array already exists in node")
					--already converted to a array
					table.insert(stack[#stack][label],node)
					table.insert(stack,node)
				else
					--convert the single entry to a table
					--base.print("  converting node to array")
					local temp = stack[#stack][label]
					stack[#stack][label] = {}
					table.insert(stack[#stack][label],temp)
					table.insert(stack[#stack][label],node)
					table.insert(stack,node)
				end
			else
				stack[#stack][label] = node
				table.insert(stack,node)
			end
			
		else  -- end tag
			table.remove(stack)
			--base.print("end element:"..label.." ")
			--if stack[#stack][label].Name==nil then
				--base.print("popping array off stack")
				--table.remove(stack)
			--end
			
			if #stack < 1 then
				error("XmlParser: nothing to close with "..label)
			end
		end
		i = j+1
	end
	return stack[1];
end

function ParseXmlFile(xmlFileName)
	local hFile,err = io.open(xmlFileName,"r");
	if (not err) then
		local xmlText=hFile:read("*a"); -- read file content
		io.close(hFile);
        return ParseXmlText(xmlText),nil;
	else
		return nil,err;
	end
end
