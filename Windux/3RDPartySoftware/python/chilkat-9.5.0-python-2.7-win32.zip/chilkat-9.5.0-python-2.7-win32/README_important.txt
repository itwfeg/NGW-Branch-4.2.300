Note: The online examples at http://www.example-code.com/python/default.asp
may use print statements without parentheses.  This is valid in version of Python
prior to 3.*, but not valid Python 3.*.  To fix, each print statement should
be modified to use parentheses:

This is no longer valid in Python 3.*:

	print "This is a test"

This is valid:

	print("This is a test")

