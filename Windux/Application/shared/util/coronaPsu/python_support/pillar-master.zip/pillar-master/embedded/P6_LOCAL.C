#pragma  SYMBOLS DEBUG                                                                                                       
#pragma  CODE
#pragma  SMALL

#include <reg51f.h>	/* 89C51RC+ */
#include <stdio.h>        
#include <intrins.h>
#include "defines.h"
#include "protos.h"
#include "sysvar.h"
/******************************************************************************/
/* main program                                                               */
/* TITLE:: DISPLAY P6000 AB10324-24 software                                  */
/* DESCRIPTION::Control program for the membrane (CP635-4) touchpad           */
/*              designed to work with a REMOTE.                               */
/*              Works on a CB10314-19 display board, software modified        */
/*              from the AB10324-14 software.                                 */
/* AUTHOR::     Janet M. Peterson                                             */
/*              Pillar Technologies                                           */
/*              475 Industrial Drive                                          */
/*              Hartland, WI  53029                                           */
/*              (262)912-7219                                                 */
/* DATE::       February 13, 2002                                             */
/* REVISION::                                                                 */
/* REV HISTORY::    Start from Revision B of AB10324-14.                      */
/*              Changes:  The main contactor turning on and off has not been  */
/*              a preferred solution for the autostart.  While it is still    */
/*              desired to have the zero speed done by the display board      */
/*              using the encoder, we will use the spare output as the auto   */
/*              start output to feed back into the control board auto start   */
/*              loop.                                                         */
/* A 6/4/03 JMP Changed PLC run mode operation. Previously, the physical      */
/*              start button was needed to initially start the power sup-     */
/*              ply and restart the supply after a fault.  Re-wrote so        */
/*              that the start can be done remotely.  The plc start           */
/*              contact needs to be open until the power supply is ready      */
/*              to run and then closed again to initiate the start. This      */
/*              change was made because of a new Tredigar order.  There       */
/*              are supposedly no units already using the PLC run feature.    */
/* B 8/27/03 JMP Would not start with Zero Speed Enabled and Auto Start Dis-  */
/*              abled (TBE1-9 and 10 open) when up to speed. Needed to have   */
/*              CR1 closed (this is in series with the auto start loop on the */
/*              control board).                                               */
/* C 9/17/03 JMP The rev A change was never tested.  The Tredigar unit        */
/*              used a CB10314-9 board, the change was made to this software  */
/*              simultaneously but there wasn't a unit available with the     */
/*              wiring for a -19 board to test.  Therefore debugging was      */
/*              necessary.  The start button does not need to be pressed      */
/*              initially for the PLC run contact to start the power supply   */
/*              in plc run mode - fixed this.  Also, removed the Inverter on  */
/*              flashing when the power supply was off in plc run mode.       */ 
/*              It was necessary to start the power supply from the local     */
/*              keypad in plc run mode but since the maintained contact is    */
/*              used for the start/stop it is difficult to override this and  */
/*              still have control at the station. To get around this, the    */
/*              local start button will start the power supply while the      */
/*              button is held down, the plc will monitor the run contact and */
/*              adjust the plc run contact accordingly.  Charter films unit.  */
/* D 10/31/03 JMP Changed start condition for PLC Start so that will start    */
/*              power supply if zero speed disabled OR zero speed enabled     */
/*              and speed condition met. Was previously only starting if      */
/*              zero speed disabled.                                          */
/* E 7/21/04  JMP Had problem with Southern Film, using TFC (PLCRun enabled   */
/*              and zero speed disabled).  Autostart was going through the    */
/*              control board, a PLC_Stop was not stopping it from auto start-*/
/*              ing.  Added code to energize stop relay if PLC stop signal    */
/*              present.                                                      */
/* F 9/13/07 JMP Had problem with 3M, using TFC and Remote.  The previous     */
/*              change was causing a maintained stop.  With the Remote start  */
/*              contact in series with the stop contacts, we were not able to */
/*              start from the remote.  Changed to monitor PLC_Start and when */
/*              changed to stop, energize the stop contact momentarily.  This */
/*              will keep the control board from auto starting while being    */
/*              to start remotely. Also, it was noticed that if switching     */
/*              to/from external mode while running, the unit would stop but  */
/*              not switch where the setpoint was coming from (change relay   */
/*              states going to control board).  This was fixed also.         */
/* G 2/25/08 JMP W&H/StarPac does not like our LTI logic.  They want to only  */
/*              have the LTI alarm activate if there is a trip, fault or if   */
/*              treat level is not within limits. Do not activate if stopped  */
/*              by the operator or for zero speed.							  */
/* H 7/31/08 JMP Updated BOM.  Micro obsolete, added alternate.				  */
/* J 2/12/09 JMP Changed zero speed minimum frequency from 2 hz to 1 hz for   */
/*              Corona Supplies.											  */
/* K 11/13/09 MDS Added the Controlled_Stop byte so that the LTI relay can be */
/*				ignored if the customer purposly stops the treater and opens  */
/*				the interlocks with the treater in a stopped condition.	      */
/******************************************************************************/

void main (void)
{
 sfrinit();             /* Initialize special function register values */
 sysinit();             /* Initialize I/O */
 EA = 1;                /* Enables interrupts */
 EX0 = 1;				/* Enables encoder interrupt */
 while(1);
}/* main */
/****************************************************************************/
/*      TITLE:: SFRINIT                                                     */
/*      DESCRIPTION::   This is an initialization function.  It             */
/*                      initializes the special function registers.         */
/*      TYPE::          void                                                */
/*      ARGUMENTS::     none                                                */
/*      RETURNS::       nothing                                             */
/*  	CALLS::         none                                                */      
/*  	AUTHOR::    	Janet Peterson                                      */
/*  	DATE::      	July 17, 1996                                       */
/*      REVSISION::                                                         */
/****************************************************************************/
void sfrinit (void) using 0
{
                    	// Timer 0 used for button status (12.5 ms)
 TH0 = 0x6A;            // Count rate = 1/6 * 18.432 MHz = 3.072M Cnts/sec
 TL0 = 0x00;            // 12.5 ms timer = 38,400 counts (0x9600)
                        // overflow value - counts = register reload value
			            // 0x10000 - 0x9600 = 0x6A00

                        // Timer 2 used for baud rate generation
 RCAP2H = 0xFF;         // 19.2K = 18.432M/(16*(65536-RCAP2H,RCAP2L))
 RCAP2L = 0xC4;         // RCAP2H,L = 65476 (0xFFC4)
 TH2 = 0xFF;
 TL2 = 0xC4;

                        // Timer 1 used for LED updates (0.7 ms)
 TH1 = 0xF7;            // Count rate = 1/6 * 18.432 MHz = 3.072M Cnts/sec
 TL1 = 0x9A;            // 0.7 ms timer = 2150 counts (0x866)
                        // overflow value - counts = register reload value
                        // 0x10000 - 0x866 = 0xF79A

 SCON = 0x60;           // Serial Port Control Register 0110 0000
                        // SM0 (SCON.7) - 0 Mode specifier 8-bit UART 
                        // SM1 (SCON.6) - 1 Mode specifier  (MODE 1)
                        // SM2 (SCON.5) - 1 RI not activated w/o valid STOP bit
                        // REN (SCON.4) - 0 disables reception
                        // TB8 (SCON.3) - x 9th bit transmitted 
                        // RB8 (SCON.2) - x 9th bit received
                        // TI  (SCON.1) - 0 transmit interrupt flag
                        // RI  (SCON.0) - 0 receive interrupt flag
  
 TMOD = 0x11;           // Timer/Counter Mode Control Register 0001 0001
                        // GATE - 0 software control of timer 1
                        // C/T  - 0 set for timer operation
                        // M1   - 0 (MODE 1 - 16 bit timer)
                        // M0   - 1     
                        // GATE - 0 software control of timer 0
                        // C/T  - 0 set for timer operation not counter
                        // M1   - 0  (MODE 1 - 16 bit timer)
                        // M0   - 1     

 T2MOD = 0;             // Timer 2 Mode Control Register  XXXX XX00
                        // T2OE  (T2MOD.1) - 0 Disable output
                        // DCEN  (T2MOD.0) - 0 Down counter disable

 TCON = 0x05;           // Timer/Counter Control Register 0101 0000
                        // TF1 (TCON.7) - x set/clr by hardware
                        // TR1 (TCON.6) - 0 turns timer 1 OFF
                        // TF0 (TCON.5) - x set/clr by hardware  
                        // TR0 (TCON.4) - 0 turns timer 0 OFF
                        // IE1 (TCON.3) - x set/clr by hardware
                        // IT1 (TCON.2) - 1 set up for interrupt 1 edge trig.
                        // IE0 (TCON.1) - x set/clr by hardware
                        // IT0 (TCON.0) - 1 set up for interrupt 0 edge trig.

 T2CON = 0x34;          // Timer 2 Control register 0011 0100
                        // TF2   (T2CON.7) - 0 Timer 2 overflow flag
                        // EXF2  (T2CON.6) - 0 Timer 2 external flag
                        // RCLK  (T2CON.5) - 1 Tells Serial port to use
                        //                              timer 2 vs 1 for rec clk
                        // TCLK  (T2CON.4) - 1 Tells Serial port to use
                        //                      timer 2 for transmit clk
                        // EXEN2 (T2CON.3) - 0 Ignore events on T2EX
                        // TR2   (T2CON.2) - 1 Turn timer 2 on
                        // C/T2* (T2CON.1) - 0 Internal timer
                        // CP/RL2* (T2CON.0) - x bit is ignored and 
                        // forced to autoreload with TCLK and RCLK set

 PCON = 0;              // Power Control Register 0000 0000
                        // SMOD (PCON.7) - 0  (1 doubles baud rate)
                        //      (PCON.6) - reserved
                        //      (PCON.5) - reserved
                        //      (PCON.4) - reserved
                        // GF1  (PCON.3) - 0 General-purpose flag
                        // GF0  (PCON.2) - 0 General-purpose flag
                        // PD   (PCON.1) - 0 (1 activates power down)
                        // IDL  (PCON.0) - 0 (1 activates idle mode)

 IP = 0x11;             // Interrupt Priority Register 0001 1000
                        //    (IP.7) - reserved
                        //    (IP.6) - reserved
                        //    (IP.5) - reserved
                        // PS (IP.4) - 1 sets serial intr. to high priority
                        // PT1(IP.3) - 0 sets timer 1 to high priority 
                        // PX1(IP.2) - 0 sets ext. intr. 1 to low priority
                        // PT0(IP.1) - 0 sets timer 0 to low priority
                        // PX0(IP.0) - 1 sets ext. intr. 0 to high priority

 IPH = 0x09;            // Interrupt Priority Register 0001 1000
                        //    (IPH.7) - reserved
                        //    (IPH.6) - reserved
                        //    (IPH.5) - reserved
                        // PSH (IPH.4) - 0 sets serial intr. to high priority
                        // PT1H(IPH.3) - 1 LEVEL 3 (HIGHEST)
                        // PX1H(IPH.2) - 0 sets ext. intr. 1 to low priority
                        // PT0H(IPH.1) - 0 sets timer 0 to low priority
                        // PX0H(IPH.0) - 1 LEVEL 3

 IE = 0x10;             // Interrupt Enable Register 0001 1010 
                        // EA (IE.7) - 0 disables interrupts
                        //    (IE.6) - reserved 
                        //    (IE.5) - reserved
                        // ES (IE.4) - 1 enables serial port intr.
                        // ET1(IE.3) - 0 disables timer 1 interrupt
                        // EX1(IE.2) - 0 disables external intr. 1
                        // ET0(IE.1) - 0 disables timer 0 interrupt
                        // EX0(IE.0) - 0 disables external intr. 0 
                        // NOTE:: Don't enable intr. until initial
                        // values are obtained
AUXR = 0x00;            // Auxiliary Register (RX+ only)
                        //              (AUXR.7) - reserved
                        //              (AUXR.6) - reserved
                        //              (AUXR.5) - reserved
                        //              (AUXR.4) - reserved
                        //              (AUXR.3) - reserved
                        //              (AUXR.2) - reserved
                        // EXTRAM(AUXR.1) - 0 uses internal extended RAM
                        // A0   (AUXR.0) - 0 disables ALE (emits at 1/6 the osc. freq.)
}

/************************************************************************/
/* TITLE::      SYSINIT                                                 */
/* DESCRIPTION::This is an initialization function.  It                 */
/*              initializes the ports, displays and reads values        */
/*              from EEPROM.                                            */      
/* TYPE::       void                                                    */
/* ARGUMENTS::  none                                                    */
/* RETURNS::    none                                                    */
/* CALLS::      get_eeprom, shift_out_cs, set_eeprom_defaults,          */
/*              power_setpoint, update_DAC, update_ADC,                 */
/*              update_LED_registers                                    */
/* AUTHOR::    Janet Peterson                                           */
/* DATE::      November 1997                                            */
/* REVISION::                                                           */
/************************************************************************/
void sysinit (void)
{
 unsigned int count = 0;
 unsigned char attempt = 0;
 unsigned char last_DIP = 0;
 unsigned char match = 0;

 shift_out_cs(CS_NONE);		// disable chip selects 
 Di = 1;					// inputs must be set high so they float
 Stop_ButtonHit = 1;		// must first press start button before plc starting
 Start_ButtonHit = 0;
 Stop_Relay = STOP_OFF;		
 Start_Relay = START_OFF;
 De = TRANSMIT_ENABLE; 		// set transceiver to transmit
 
 P3 |= 0x31;  				// inputs must be set high so they float
 
 P0 = 0;					// turn OFF LEDs
 P2=Display_driver[0]; 		// Point to collum 0 leave all inputs high	
 Reset_Relay = RESET_OFF;		// Besure relay is off

 
 /********** CHECK STATUS OF REMOTE DISABLE ***********/
 EA = 1;        // enable timers (serial communications)
 while ((!Message_Received) && (attempt < 5))
 {
  count = 0;
  update_remote_LED();  // LEDs are 0, but find out if remote is out there or disabled
  while ((!Message_Received) && (count < 22000))  //wait approx. 100ms for response
   { count++; }
  attempt++;
 }
 if (!Message_Received)
  Remote_Disable = 1;
 EA = 0;        // disable all interrupts
 ET1 = 1;       // timer 1 interrupt enabled
 ET0 = 1;       // timer 0 interrupt enabled
 TR1 = 1;       // start timer 1
 TR0 = 1;       // start timer 0

 /********** READING LED STATUS **********/
 LED_Col[0] = ~(shift_register_in(CS_LED1));	// need to read shift register so not driving line low
 LED_Col[1] = ~(shift_register_in(CS_LED2));

 
 LED_Col[0] = 0;
 LED_Col[1] = 0;

 LED_Port[5] = 0;
 LED_Port[6] = 0; 
 
 /********** READ DIP SETTINGS **********/

 Shift_Input =  shift_register_in(CS_DIP);

 last_DIP = DIP_Switch;
 attempt = 0;
 while ((match<10)&&(attempt<100))
 {
  Shift_Input = shift_register_in(CS_DIP);
  if (last_DIP == DIP_Switch)
   match++;
  else
   {
    last_DIP = DIP_Switch;
	match = 0;
   }
  attempt++;
 }
 if (match < 10)
  {
   DIP_Switch = 0xff;		   // disable all DIP switches
   Shift_Input |= 0x03;
  }

 Local_Disable = Local_Switch;					// save switch values at startup
 External_Disable = External_Switch;			// in case we are getting noise on 
 HCC_Auto_Disable = HCC_Auto_Switch;			// the line we don't want the enables
 PLCRun_Disable = PLCRun_Switch;				// changing during operation
 WattDensity_Disable = WattDensity_Switch;
 PropSpeed_Disable = PropSpeed_Switch;
 ZSpeed_Disable = ZSpeed_Switch;
 PLC_Start_Previous = PLC_Start;				// Rev. F monitor previous mode of PLC_Start

 Size = DIP_Switch & 0x07;              /* Size is 3 LSB of DIP Switch */
 if ( get_eeprom(ID_ADDR) != EEPROM_ID) /* check that eeprom has been setup */
  set_eeprom_defaults();                /* if not, set to default values    */
 else
 {                 
  Power_Set_KW = get_eeprom(POWER_ADDR);
  if (Power_Set_KW > Inverter_Power[Size])
  {
   Power_Set_KW = Inverter_Power[Size];
  }
  power_setpoint();

  Ramp_Counter = get_eeprom(RAMP_TIME_ADDR);    // jmp 7/21/98 start ramp counter
  if ((Ramp_Counter < RAMP_TIME_MIN) || (Ramp_Counter > RAMP_TIME_MAX))
   Ramp_Counter = RAMP_TIME_DEFAULT;

 /********** SET MODE **********/
  Mode = (unsigned char)get_eeprom(MODE_ADDR);
   //           RESET RELAY     AUX RELAY
   // LOCAL         OFF           OFF
   // REMOTE        ON            OFF
   // EXTERNAL      OFF           ON 
  
  switch(Mode)          // check that we are in valid mode
  {
   case EXTERNAL_MODE:
        if (External_Disable||WattDensity_Enable||PropSpeed_Enable) switch_modes();
        break;
   case LOCAL_MODE:
        if (Local_Disable) switch_modes();
        break;
   case REMOTE_MODE:
        if (Remote_Disable) switch_modes();
        break;
   case LOC_EXT_MODE:
        if (External_Disable||(WattDensity_Disable&&PropSpeed_Disable)) switch_modes();
		break;
   default:
        Mode = LOCAL_MODE;
        break;
  }
  
  set_mode();                           // sets the relays

  On_Time = (unsigned long)(0x00010000 * get_eeprom(HOUR_METER_ADDR_HI));
  On_Time += (unsigned long)get_eeprom(HOUR_METER_ADDR_LO);
  
  Selected_Readout = (unsigned char)get_eeprom(READOUT_ADDR);
  Selected_Readout_Remote = (unsigned char)get_eeprom(REMOTE_ADDR);

  Zero_Speed_Rate = (unsigned int)get_eeprom(ZERO_SPEED_ADDR);

  KW_Minutes = (unsigned long)(0x00010000 * get_eeprom(KWH_METER_ADDR_HI));
  KW_Minutes += (unsigned long)get_eeprom(KWH_METER_ADDR_LO);

  Electrode_Width = (unsigned int)get_eeprom(ELECTRODE_WIDTH_ADDR);

  Watt_Density_Setpoint = (unsigned char)get_eeprom(WATT_DENSITY_ADDR);

  Prop_Speed_Slope = (unsigned long)(0x00010000 * get_eeprom(PROP_SPEED_ADDR_HI));
  Prop_Speed_Slope += (unsigned long)get_eeprom(PROP_SPEED_ADDR_LO);
  
 } // end eeprom not empty so download variables

 /********** SET READOUT AND LED BAR VALUES **********/
 switch(Selected_Readout)
 {
 case POWER_INDEX:
        LED_Port[3] = POWER;    
		if ((Mode==LOC_EXT_MODE)&&(WattDensity_Enable))
		 LED_Port[4] = NO_UNITS;
		else
         LED_Port[4] = KW;       
        break;
 case VOLTAGE_INDEX:
        LED_Port[3] = VOLTAGE;
        LED_Port[4] = KV;
        break;
 case CURRENT_INDEX:
        LED_Port[3] = CURRENT;
        LED_Port[4] = AMP;
        break;
 case FREQ_INDEX:
        LED_Port[3] = FREQ;
        LED_Port[4] = KHZ;
        break;
 default:
        LED_Port[3] = POWER;
        LED_Port[4] = KW;
        Selected_Readout = POWER_INDEX;
        break;
 }
 /********** SET REMOTE READOUT AND LED BAR VALUES **********/
 switch(Selected_Readout_Remote)
 {
  case POWER_INDEX:
        RLED_Port[3] = POWER;   
		if ((Mode==LOC_EXT_MODE)&&(WattDensity_Enable))
		 RLED_Port[4] = NO_UNITS;		
        else
         RLED_Port[4] = KW;      
        break;
 case VOLTAGE_INDEX:
        RLED_Port[3] = VOLTAGE;
        RLED_Port[4] = KV;
        break;
 case CURRENT_INDEX:
        RLED_Port[3] = CURRENT;
        RLED_Port[4] = AMP;
        break;
 case FREQ_INDEX:
        RLED_Port[3] = FREQ;
        RLED_Port[4] = KHZ;
        break;
 default:
        RLED_Port[3] = POWER;
        RLED_Port[4] = KW;
        Selected_Readout_Remote = POWER_INDEX;
        break;
 }


 /********** UPDATE ANALOG DEVICES **********/
 power_setpoint();
 update_DAC();
 update_ADC();

 /********** SET 7-SEGMENT LED VALUES **********/

 update_LED_registers(&LED_Port, Selected_Readout, Readout_Timer, Display_Upper_Digits);
 update_LED_registers(&RLED_Port, Selected_Readout_Remote, RReadout_Timer, Display_Upper_Digits_Remote);

 LED_index = 0;

 count = 0;                                             // add extra delay!!!
 while (count != 0xffff)
  {count++;}
 count = 0;
 attempt = 0;
 Stop_Relay = STOP_ON;                  // reset control board
 while (attempt < 5)
  {
   count++;
   if (count == 0)
    attempt++;
  }
 Stop_Relay = STOP_OFF;
}       /* end of initializations */

/****************************************************************************/
/*      TITLE:: TIMER1                                                      */
/*      DESCRIPTION::   This function is controlled by timer 1.  It         */
/*                      interrupts every 1ms. It updates the display        */
/*                      drivers and scans keyboard                          */
/*      TYPE::          interrupt                                           */
/*      ARGUMENTS::     none                                                */
/*      RETURNS::       none                                                */
/*  CALLS::             none                                                */      
/*  AUTHOR::    Janet Peterson                                              */
/*  DATE::      November 6, 1997                                            */
/*  REVISION::                                                              */
/****************************************************************************/
void timer1 () interrupt 3 using 2 
{
 unsigned char col, keypad;
                        // Reload timer value   (0.7 ms)
 TH1 = 0xF7;            // Count rate = 1/6 * 18.432MHz = 3.072M Cnts/sec
 TL1 = 0x9A;            // .7 ms timer = 2150 counts (0x866)
                        // overflow value - counts = register reload value
                        // 0x10000 - 0x866 = 0xF79A

 P0 = 0;                // disable display drivers
 
 P2 = (P2 & 0x10) | Display_driver[LED_index];  // select next LED to display
 P0 = LED_Port[LED_index]; 		// Light up leds
 keypad = P2;					// save buttons
 if (LED_index < 4)				// first 4 columns drive the keypad switches
 {
  for (col = 0; col < 4; col++)         	// check for keys hit in row LED_index
  {
    if ((keypad & READ_KEY) != 0)		
    Keypad_Hit [LED_index] [col] = 0;   	// key is logic 1, not active
   else
    {
     Keypad_Hit[LED_index] [col]++;    		// else increment the number of hits
     if (Keypad_Hit[LED_index] [col] == 0)	// and don't let it wrap around
      Keypad_Hit[LED_index] [col] = 0xFF;
    }
   keypad = _crol_(keypad,1);			// look at next column
  }
 }

 LED_index++;                           // look at next row next time
 if (LED_index > 6) LED_index = 0;
} 

/****************************************************************************/
/*      TITLE:: TIMER0                                                      */
/*      DESCRIPTION::   This function is controlled by timer 0.  It         */
/*                      interrupts every 50ms. The keypad is acted on in    */
/*                      this routine.                                       */
/*      TYPE::          interrupt                                           */
/*      ARGUMENTS::     none                                                */
/*      RETURNS::       none                                                */
/*      CALLS::         none                                                */
/*  	AUTHOR::    Janet Peterson                                          */
/*  	DATE::      November 3, 1997                                        */
/*      REVISION::                                                          */
/* B 8/27/03  Fixed start problem when zero speed enabled and auto start    */
/*            disabled.           											*/
/* C 9/18/03  Removed inverter on flashing when PLC run enabled but off.    */
/*            Added PLC start without start button being pressed and only   */
/*            if zero speed disabled.                                       */
/* E 7/21/04  Energize stop relay even if inverter off, when plc run is     */
/*            enabled and zero speed is disabled.  This will make sure that */
/*            the control board will not auto start.                        */
/****************************************************************************/
void timer0 () interrupt 1
{
static unsigned char Counter_25ms = 0;
static unsigned char Counter_12ms = 0;

                        // Timer 0 used for button status (12.5 ms)
 TH0 = 0x6A;            // Count rate = 1/6 * 18.432 MHz = 3.072M Cnts/sec 
 TL0 = 0x00;            // 12.5 ms timer = 38,400 counts (0x9600)
                        // overflow value - counts = register reload value
                        // 0x10000 - 0x9600 = 0x6A00
 Counter_12ms++;
 if (Counter_12ms % 2 == 0)
  Counter_25ms++;        // increments every 25ms
 else
  return;
 if (Counter_25ms == 40)  // 1 sec
  {
   EX0 = 0;				/* Disables encoder interrupt */
   Encoder_Rate = (Encoder_Rate*2)/10 + (Tics*8)/10;
   Tics = 0;
   EX0 = 1;				/* Enables encoder interrupt */
   Counter_25ms = 0;
  }
 if ((Counter_25ms % 4) == 0)   // satisfys condition every 100ms
  {
   if (Inverter_On)
    {
     if (On_Time < ON_TIME_LIMIT)	// stop counting after hitting
      {                             // display limits
       Counter_100ms++;       
       if (Counter_100ms == 10)
       {
        Counter_100ms = 0;
        Counter_Sec++;
        if (Counter_Sec == 60)
         {
          On_Time++;         // On_Time is incremented every minute
          Time_Change = 1;   // write to EEprom after its been changed
          Counter_Sec = 0;
		  KW_Minutes += (((unsigned long)Readout[POWER_INDEX]*(unsigned long)Inverter_Power[Size]*(unsigned long)10)/0xFF);    // divide by 6,000 to get KWH
         } // end if Counter_Sec equals 1 minute
       } // end if Counter_100ms equals 1 sec.
     } // end if On time is less than 99900 hours
   } // end if Inverter is on

   if (Ramping)
        {
         if (Current_Trip)
          Current_Trip_Counter++;
         else
           Current_Trip_Counter = 0;
         if (Current_Trip_Counter == 5)
          {
           Number_of_CT++;
           if (((Ramp_Reduction) && ((Ramp_Timer - Current_Trip_Time) < 20)) || (Number_of_CT > 9))
            { // if just reduced power, stop treater if still tripping within 2 sec
                 Stop_Active = 2;
                 Stop_Relay = STOP_ON; 		// stop the supply
                 Ramping = 0;
                }
           else
                {
             Ramp_Set = (Ramp_Set/3)*2;     // reduce setpoint by 1/3
             if (Ramp_Set < (Power_Set/10))
               Ramp_Set = Power_Set/10;     // set a lower power limit of 10% of setpoint
             Ramp_Reduction = 1;            // indicate that power was just reduced
             Current_Trip_Time = Ramp_Timer;
                }
          }
         if ((Ramp_Reduction) && ((Ramp_Timer - Current_Trip_Time) > 20))
          Ramp_Reduction = 0;               // ok to reduce power again
         if (Current_Trip_Counter > 20)
          { // if Current tripped for more the 2 sec. STOP!!!
           Stop_Active = 2;
           Stop_Relay = STOP_ON;
           Ramping = 0;
          }
         if (Inverter_On) Ramp_Timer++;
         if (((Ramp_Timer % Ramp_Timer_Increment) == 0) && (Inverter_On))
           Ramp_Set++;
         if ((Ramp_Set >= Power_Set)||((!Inverter_On)&&(Ramp_Timer>10)))
           Ramping = 0;
         } // end if ramping

   if (Readout_Timer > 0)
    Readout_Timer++;         // incremented ever 100 ms represents
   if (RReadout_Timer > 0)
    RReadout_Timer++;        // incremented every 100ms

   if (Readout_Timer == READOUT_LIMIT)
    {
     LED_Port[3] &= ALARMFAULT;       // turn OFF all lights except alarm fault
     LED_Port[3] |= POWER;            // turn ON power light
	 if ((Mode==LOC_EXT_MODE)&&(WattDensity_Enable))
	  LED_Port[4] = NO_UNITS;
	 else
      LED_Port[4] = KW;
     Selected_Readout = POWER_INDEX;
	 Readout_Timer = 0;
    }

   if (RReadout_Timer == READOUT_LIMIT)
    {
     RLED_Port[3] &= ALARMFAULT;      // turn OFF all lights except alarm fault
     RLED_Port[3] |= POWER;           // turn ON power light
	 if ((Mode==LOC_EXT_MODE)&&(WattDensity_Enable))
	  RLED_Port[4] = NO_UNITS;
	 else
      RLED_Port[4] = KW;
     Selected_Readout_Remote = POWER_INDEX;
	 RReadout_Timer = 0;
    }


/* UPDATES TO EEPROM  counter now 100ms counter*/   
   if (!Button_Held)
    {
     if (EE_Power_Change)
      {
       write_eeprom(POWER_ADDR, Power_Set_KW);
       EE_Power_Change = 0;
      } /* end update EEprom for Power Change */
     else
      if (Mode_Change)
       {
        write_eeprom(MODE_ADDR,Mode);
        Mode_Change = 0;
       }
      else
       if (Time_Change && !Inverter_On)		// too many writes to EEPROM will wear it out
        {
         write_eeprom(HOUR_METER_ADDR_HI,(unsigned int)(On_Time/0x00010000));
         write_eeprom(HOUR_METER_ADDR_LO,(unsigned int)(On_Time & 0x0000FFFF));
         write_eeprom(KWH_METER_ADDR_HI,(unsigned int)(KW_Minutes/0x00010000));
         write_eeprom(KWH_METER_ADDR_LO,(unsigned int)(KW_Minutes & 0x0000FFFF));
         Time_Change = 0;
        } /* end update EEprom for Meter Change */
       else
        if (Readout_Change)
         {
          write_eeprom(READOUT_ADDR,Selected_Readout);
          Readout_Change = 0;
         } /* end update EEprom for Readout Change */
        else
         if (Remote_Readout_Change)
          {
           write_eeprom(REMOTE_ADDR,Selected_Readout_Remote);
           Remote_Readout_Change = 0;
          } /* end update EEprom for Remote Readout Change */
         else
          if (Ramp_Change)
           {
            write_eeprom(RAMP_TIME_ADDR,Ramp_Counter);
            Ramp_Change = 0;
           }
		  else
		   if (Zero_Speed_Change)
		    {
		     write_eeprom(ZERO_SPEED_ADDR,Zero_Speed_Rate);
		     Zero_Speed_Change = 0;
		    }
		   else
		    if (Electrode_Width_Change)
		     {
		      write_eeprom(ELECTRODE_WIDTH_ADDR,(unsigned int)Electrode_Width);
		      Electrode_Width_Change = 0;
		     }
		    else
			 if (Prop_Speed_Change_Hi)
			  {
               write_eeprom(PROP_SPEED_ADDR_HI,(unsigned int)(Prop_Speed_Slope/0x00010000));
			   Prop_Speed_Change_Hi = 0;
			  }
			 else
			  if (Prop_Speed_Change_Lo)
			   {
                write_eeprom(PROP_SPEED_ADDR_LO,(unsigned int)(Prop_Speed_Slope & 0x0000FFFF));
			    Prop_Speed_Change_Lo = 0;
			   }
			  else
               if (Watt_Density_Change)
                {
                 write_eeprom(WATT_DENSITY_ADDR,(unsigned int)Watt_Density_Setpoint);
                 Watt_Density_Change = 0;
                }
	}

   Shift_Input = shift_register_in(CS_DIP);

   /********** READING INPUTS FROM CONTROL BOARD **********/

   LED_Col[0] = ~(shift_register_in(CS_LED1));
   LED_Col[1] = ~(shift_register_in(CS_LED2));

   if (!Electrode_A && !Electrode_B) 
    {
     Interlock_Fault = 1;
	 if (Inverter_On)
	  {
	   Stop_Active = 2;
	   Start_Relay = START_OFF;
	   Stop_Relay = STOP_ON;
 	   Ramping = 0;
	  }
	}

   if (ZSpeed_Disable) Auto_Start = 1;		// not using encoder, force output on, station zero speed is in series with it

   if (ZSpeed_Enable && (Encoder_Rate <= Zero_Speed_Rate))
    {
	 Auto_Start = 0;
     if (AStart_Disable) 
      {
       Interlock_Fault = 1;
	   if (Inverter_On)
	    {
	     Stop_Active = 2;
	     Start_Relay = START_OFF;
	     Stop_Relay = STOP_ON;
	     Ramping = 0;
	    }
	  }
	}

   if (ZSpeed_Enable && (Encoder_Rate > Zero_Speed_Rate))		// Rev. B removed AStart_Enable would not start with auto start disabled
    Auto_Start = 1;

   if (PLCRun_Enable && !PLC_Start && Inverter_On)		// B stop if run contact not made!
	  {
	   Stop_Active = 2;
	   Start_Relay = START_OFF;
	   Stop_Relay = STOP_ON;
	   Ramping = 0;
	   Controlled_Stop = 1;								 // Disable the LTI since the user shut down the treater
	  }

   if (!PLC_Start && PLC_Start_Previous && !Inverter_On)   // Rev. F monitor PLC_Start signal, energize Stop even if not running.  
	  {													   // This will turn off autostart on control board.
	   Stop_Active = 2;
	   Start_Relay = START_OFF;
	   Stop_Relay = STOP_ON;
	   Ramping = 0;
	  }

   PLC_Start_Previous = PLC_Start;						// Rev. F

  /* if (PLCRun_Enable && !PLC_Start && ZSpeed_Disable)	// E stop if run contact not made even if inverter off, this will turn off the autostart on control bd.
	  {													// F remove this, this is causing a maintained stop which is not allowing the Remote to Start
	   Stop_Active = 2;
	   Start_Relay = START_OFF;
	   Stop_Relay = STOP_ON;
	   Ramping = 0;
	  }*/


   if (High_Temp_Fault || Interlock_Fault || DC_Bus_Trip || Over_Volt_Trip || Current_Trip)
	{
     Start_ButtonHit = 0;		// don't autostart if stopped because of fault
	 Stop_ButtonHit = 1;
	}

   if (PLCRun_Enable && !PLC_Start && !High_Temp_Fault && !Interlock_Fault && !DC_Bus_Trip && !Over_Volt_Trip && !Current_Trip)
    Stop_ButtonHit = 0;		    // Rev. A 

   if (!Inverter_On && !Auto_Start && Start_ButtonHit && ZSpeed_Enable && AStart_Enable && !Interlock_Fault)	// B flash to indicate could start automatically
    Inverter_On_Flash = 1;		// flash Inverter On led if the unit will start automatically 
   else							// when zero speed is reached
    Inverter_On_Flash = 0;	    

   if (PLCRun_Enable && PLC_Start && !Stop_ButtonHit && (ZSpeed_Disable || (ZSpeed_Enable && Auto_Start)) && !Inverter_On)
    {
     Start_Active = 1;
     Stop_Relay = STOP_OFF;
     Start_Relay = START_ON;
	 Controlled_Stop = 0;
    }

   LED_Port[5] = ((LED_Col[0] & 0x03) | ((LED_Col[0] / 0x02) & 0x1C));
   LED_Port[6] = LED_Col[1] & 0x3F;
   switch(Mode)				// set to temporary mode LED
	{
	 case LOCAL_MODE:
	    LED_Port[5] |= 0x20;	
		 break;
	   case REMOTE_MODE:
	     LED_Port[5] |= 0x40;
	     break;
	   case EXTERNAL_MODE:
	     LED_Port[6] |= 0x40;
	   case LOC_EXT_MODE:
	     LED_Port[6] |= 0x40;
	     break;
	  }

   RLED_Port[5] = LED_Port[5];
   RLED_Port[6] = LED_Port[6];

   if (Message_Received)
    update_remote_keypad();     // read receive buffer
   else
    {                           // remote not responding
     Remote_Keyhit[0] = 0;      // no remote button presses
     Remote_Keyhit[1] = 0x80;   // disable remote
    }
   update_from_keypad();        // every 100ms act on button/key presses
   update_ADC();                // update ADC (meter readings) every 100ms

   update_LED_registers(&LED_Port, Selected_Readout, Readout_Timer, Display_Upper_Digits);
   update_LED_registers(&RLED_Port, Selected_Readout_Remote, RReadout_Timer, Display_Upper_Digits_Remote);
   update_remote_LED();         // send new LED values to remote
   alarm_check();     			// check LTI
  } /* end every 100ms */
 else
  {
   if ((Counter_25ms % 2) == 0) // satisfys condition every 100ms
    {
	 if (Mode==LOC_EXT_MODE)
	  power_setpoint();
     update_DAC();
	}
  }

} /* end timer 0 interrupt */

/****************************************************************************/
/*      TITLE:: UPDATE_FROM_KEYPAD                                          */
/*      DESCRIPTION::   This function checks if a key has been held down    */
/*                      for a certain length of time and then performs      */
/*                      the appropriate function if it has.                 */
/*  TYPE::              void                                                */
/*      ARGUMENTS::     none                                                */
/*      RETURNS::       nothing                                             */
/*  CALLS::             none                                                */      
/*  AUTHOR::    Janet Peterson                                              */
/*  DATE::      November 3, 1997                                            */
/*  REVISION::                                                              */
/****************************************************************************/

void update_from_keypad (void)
{
 static unsigned char idata DB_Readout_Active = 0, KWH_Button_Held = 0, RKWH_Button_Held = 0;
 static unsigned int i=0, j=0, k=0, m=0;   
 static unsigned int idata Prop_Setpoint = 0;            

 if (Ramp_Start_Active > 0)
  { 
   Ramp_Start_Active++;
   if (Ramp_Start_Active>5)
    Ramp_Start_Active = 0;
  }
 
 if (DB_Readout_Active>0)	// double button
  DB_Readout_Active++;
 if (DB_Readout_Active>20)
  DB_Readout_Active=0;
 
 if (Shift_Active > 0)		// Shift_Active gets set to 1 when alarm silence button pressed
  {
   Shift_Active++;
   if (Shift_Active > 5)
    Shift_Active = 0;
  }

 if (RShift_Active > 0)		// RShift_Active gets set to 1 when remote alarm silence button pressed
  {
   RShift_Active++;
   if (RShift_Active > 5)
    RShift_Active = 0;
  }

 if (Start_Active > 0)	
  {
   Start_Active++;
   if (Start_Active == 6)
    {
     Start_Active = 0;
     Start_Relay = START_OFF;
    }
  }       
 if (Stop_Active > 0)
  {
   Stop_Active++;                 /* this routine is entered every 50ms */
   if (Stop_Active == 2)         // find new mode!
    {
	 power_setpoint();
     set_mode();                  // set relays for proper mode 
     Mode_Change = 1;             // flag to update eeprom
    } /* end if Stop_Active == 2 */
   if (Stop_Active == 6)  		// if Stop_Relay has been on for 500ms turn off
    {
     Stop_Active = 0;
     Stop_Relay = STOP_OFF;
    } /* end if Stop_Active == 11) */
 } /* end if Stop_Active > 0 */

 Button_Held = 0;
/********** Button 11 & Remote Button 11, Function ALARM SILENCE ***********/
 if ((Keypad_Hit [2] [2] >= VALID_KEYHIT) || (Rem_Sil_ButtonHit))
  {
   Button_Held = 1;
   if (Rem_Sil_ButtonHit) 
    RShift_Active = 1;
   else
    Shift_Active = 1;
   Lti_Relay = LTI_OFF;
  }

/********** Button 13 & Remote Button 13, Function STOP ***************************************/
 if ((Keypad_Hit [3] [0] >= VALID_KEYHIT) || (Rem_Stop_ButtonHit) || (Aux_Stop && PLCRun_Disable))
  {
   Start_Relay = START_OFF;		// Rev. A
   Stop_Relay = STOP_ON;        /* if button is pressed, turn on relay! */
   Ramping = 0;
   Stop_ButtonHit = 1;		// may no longer plc start
   Start_ButtonHit = 0;		// may no longer autostart
   Controlled_Stop = 1;		// Disable the LTI since the user shut down the treater
   Button_Held = 1;
   if ((Shift_Active>0) && (Keypad_Hit[3][0]>=VALID_KEYHIT) && ZSpeed_Enable)
	{
     Zero_Speed_Rate = Encoder_Rate;
	 if (Zero_Speed_Rate < ZERO_SPEED_MIN) Zero_Speed_Rate = ZERO_SPEED_MIN;
	 Selected_Readout = ZERO_INDEX;
	 Readout_Timer = 1;
	 Zero_Speed_Change = 1;
	}
   if ((RShift_Active>0) && Rem_Stop_ButtonHit && ZSpeed_Enable)
	{
     Zero_Speed_Rate = Encoder_Rate;
	 if (Zero_Speed_Rate < ZERO_SPEED_MIN) Zero_Speed_Rate = ZERO_SPEED_MIN;
	 Selected_Readout_Remote = ZERO_INDEX;
	 RReadout_Timer = 1;
	 Zero_Speed_Change = 1;
	}
   return;
  }
 else
  if (Stop_Active == 0)
  {
   Stop_Relay = STOP_OFF; 		/* make sure it turns off if button not pressed */
  }

/*********** Button 1, Function Power Readout Selection *********************/
 if (Keypad_Hit [0] [0] >= VALID_KEYHIT)      
  {
   if (Mode!=REMOTE_MODE)
        Ramp_Start_Active = 1;
   Selected_Readout = POWER_INDEX;      // display power
   if (!Inverter_On)                    // Only display set point if not running
    Readout_Timer = 1;
   Readout_Change = 1;                  // flag to save selected readout to eeprom
   Button_Held = 1;
  }

/*********** Remote Button 1, Function Power Readout Selection ***************/
 if (Rem_Pow_ButtonHit)      
  {
   if (Mode!=LOCAL_MODE)
    Ramp_Start_Active = 1;
   Selected_Readout_Remote = POWER_INDEX;     // display power
   if (!Inverter_On)                    // Only display set point if not running
    RReadout_Timer = 1;
   Remote_Readout_Change = 1;           // flag to save selected readout to eeprom
   Button_Held = 1;
  }

/********** Button 2, Function Voltage Readout Selection *******************/
 if (Keypad_Hit [0] [1] >= VALID_KEYHIT)
 { 
  Selected_Readout = VOLTAGE_INDEX;     // display voltage
  Readout_Change = 1;                   // flag to save selected readout to eeprom
  Button_Held = 1;
 }

/********** Remote Button 2, Function Voltage Readout Selection ************/
 if (Rem_Volt_ButtonHit)
 { 
  Selected_Readout_Remote = VOLTAGE_INDEX;      // display voltage
  Remote_Readout_Change = 1;                    // flag to save selected readout to eeprom
  Button_Held = 1;
 }

/********** Button 3, Function Current Readout Selection *******************/
 if (Keypad_Hit [0] [2] >= VALID_KEYHIT)
  {
   Selected_Readout = CURRENT_INDEX;    // display current
   Readout_Change = 1;                  // flag to save selected readout to eeprom
   Button_Held = 1;  
  }

/********** Remote Button 3, Function Current Readout Selection ************/
 if (Rem_Cur_ButtonHit)
  {
   Selected_Readout_Remote = CURRENT_INDEX;     // display current
   Remote_Readout_Change = 1;                   // flag to save selected readout to eeprom
   Button_Held = 1;
  }

/********** Button 4, Function Frequency Readout Selection *****************/
  if ((Keypad_Hit [0] [3] >= VALID_KEYHIT)&&(DB_Readout_Active==0))
  {
   if (Shift_Active > 0)
	{
     Selected_Readout = ENCODER_INDEX;	// display encoder frequency
	 Readout_Timer = 1;
	}
   else
    Selected_Readout = FREQ_INDEX;   	// display frequency
   Readout_Change = 1;					// flag to save selected readout to eeprom
   Button_Held = 1;
  }

/********** Remote Button 4, Function Frequency Readout Selection **********/
  if ((Rem_Freq_ButtonHit)&&(DB_Readout_Active==0))
  {
   if (RShift_Active > 0)
	{
     Selected_Readout_Remote = ENCODER_INDEX;	// display encoder frequency
	 RReadout_Timer = 1;
	}
   else
    Selected_Readout_Remote = FREQ_INDEX;	// display frequency
   Remote_Readout_Change = 1;		// flag to save selected readout to eeprom
   Button_Held = 1;   
  }


//********** Button 5, Function KWHour Readout Selection *****************
 if (Keypad_Hit [1] [0] >= VALID_KEYHIT)
  {

   if (Shift_Active==0) 			// not looking at hours
   	{
     KWH_Button_Held++;
     if (KWH_Button_Held == 0)
      KWH_Button_Held = 0xFF;
     if (KWH_Button_Held == 30)		// button held down for 3 seconds
	  {
	   KW_Minutes = 0;				// reset KW Hours
	   Time_Change = 1;
	  }
	}
   else
   KWH_Button_Held = 0;    
   Readout_Timer = 1;
   Selected_Readout = KWH_INDEX; 
   Display_Upper_Digits = 1;
   if (Shift_Active > 0) Selected_Readout = HOUR_INDEX;
   Button_Held = 1;   
  }
 else
  {
   Display_Upper_Digits = 0;
   KWH_Button_Held = 0;
  }

//********** Remote Button 5, Function KWHour Readout Selection **********
 if (Rem_Hour_ButtonHit)			// do nothing
  {
   if (RShift_Active==0) 			// not looking at hours
   	{
     RKWH_Button_Held++;
     if (RKWH_Button_Held == 0)
      RKWH_Button_Held = 0xFF;
     if (RKWH_Button_Held == 30)		// button held down for 3 seconds
	  {
	   KW_Minutes = 0;				// reset KW Hours
	   Time_Change = 1;
	  }
	}
   else
    RKWH_Button_Held = 0;
   RReadout_Timer = 1;
   Selected_Readout_Remote = KWH_INDEX; 
   Display_Upper_Digits_Remote = 1;	   
   if (RShift_Active > 0) Selected_Readout_Remote = HOUR_INDEX;
   Button_Held = 1;
  }
 else
  {
   RKWH_Button_Held = 0;
   Display_Upper_Digits_Remote = 0;
  }

//******* Freq. and Ramp Time Up simultaneously, increase Electrode Width *****
 if ((((Keypad_Hit [0] [3] >= VALID_KEYHIT)&&(Keypad_Hit [1] [2] >= VALID_KEYHIT)&&(Mode != REMOTE_MODE)) 
 	 || ((Rem_Aup_ButtonHit)&&(Rem_Freq_ButtonHit)&&(Mode != LOCAL_MODE))) && WattDensity_Enable)
  {    
   Button_Held = 1;
   DB_Readout_Active = 1;
   if (Electrode_Width < ELECTRODE_WIDTH_MAX)	// don't increment if at limit
    { 
     i++;
     if ((i % 4 == 0) || (i > 21))  		// starts off slow then speeds up
      {
	   if (Electrode_Width < 1000)
        Electrode_Width += 5; 				// increase in 0.5" units
	   else
	    Electrode_Width += 10;              // increase in 1.0" units
       Electrode_Width_Change = 1;     		// flag to update eeprom
      } // end if incrementing electrode width point
    } // end if Current trip setpoint < 99.9A
   if (!Rem_Aup_ButtonHit)					// then must be local display doing the changing
    {
     Selected_Readout = ELECTRODE_INDEX;	// display electrode width setpoint 
     Readout_Change = 1;				// flag to save selected readout to eeprom
     Readout_Timer = 1;
    }
   else
    {
     Selected_Readout_Remote = ELECTRODE_INDEX;	// display current trip setpoint
     Remote_Readout_Change = 1;					// flag to save selected readout to eeprom
     RReadout_Timer = 1;
    }
   return; // return so we don't do a ramp time increase
  } // end current trip arrow up key hit 

//******* Freq. and Ramp Time Down simultaneously, decrease Electrode Width ******
 if ((((Keypad_Hit [0] [3] >= VALID_KEYHIT)&&(Keypad_Hit [2] [0] >= VALID_KEYHIT)&&(Mode != REMOTE_MODE)) 
 	 || ((Rem_Adwn_ButtonHit)&&(Rem_Freq_ButtonHit)&&(Mode != LOCAL_MODE))) && WattDensity_Enable)
  {    
   Button_Held = 1;
   DB_Readout_Active = 1;
   if (Electrode_Width > ELECTRODE_WIDTH_MIN)	// don't decrement if at limit
    { 
     i++;
     if ((i % 4 == 0) || (i > 21))  		// starts off slow then speeds up
      {
	   if (Electrode_Width > 1000)
	    Electrode_Width -= 10;					// decrease by units of 1.0"
	   else
        Electrode_Width -= 5;					// decrease by units of 0.5"
       Electrode_Width_Change = 1;     		// flag to update eeprom
      } // end if incrementing Electrode Width 
    } // end if Electrode Width > 5"
   if (!Rem_Adwn_ButtonHit)				// then must be local display doing the changing
    {
     Selected_Readout = ELECTRODE_INDEX;	// display electrode width
     Readout_Change = 1;				// flag to save selected readout to eeprom
     Readout_Timer = 1;
    }
   else
    {
     Selected_Readout_Remote = ELECTRODE_INDEX;	// display electrode width
     Remote_Readout_Change = 1;			 	// flag to save selected readout to eeprom
     RReadout_Timer = 1;
    }
    return;	// return so that we don't do a power setpoint decrease
  } // end current trip arrow up key hit




/********** Button 6 & Remote Button 6, Function POWER ARROW UP ************/
 if ((DB_Readout_Active==0)&&(((Keypad_Hit [1] [1] >= VALID_KEYHIT) && ((Mode == LOCAL_MODE)||(Mode == EXTERNAL_MODE)))
     || (Rem_Pup_ButtonHit && ((Mode == REMOTE_MODE)||(Mode == EXTERNAL_MODE)))))
  {
   Button_Held = 1;
   if (Power_Set_KW < Inverter_Power[Size])     /* don't increment if at limit */
    { 
     i++;
     if ((i % 4 == 0) || (i > 21))  /* starts off slow then speeds up */
      {
       Power_Set_KW++;          /* increment by 100 W */
       power_setpoint();        /* determine 8 bit DAC value */
       EE_Power_Change = 1;     /* flag to update DAC */
      } /* end if incrementing KW */
    } /* end if Power_Set_KW < Inverter Size */
   if (!Rem_Pup_ButtonHit)              // if not remote button must be local
    {
	 if (Selected_Readout != POWER_INDEX)
	  Readout_Change = 1;
     Selected_Readout = POWER_INDEX;    /* display power                */
     if (!Inverter_On)                  /* Only display set point if not running */
      {
       Readout_Timer = 1;
      }
    } /* end if Mode == LOCAL or EXTERNAL*/
   else
    {
	 if (Selected_Readout_Remote != POWER_INDEX)
	  Remote_Readout_Change = 1;
     Selected_Readout_Remote = POWER_INDEX;     /* display power                */
     if (!Inverter_On)                          /* Only display set point if not running */
      RReadout_Timer = 1;
    } /* end if Mode == REMOTE */
   return;
  } /* end if Power Up Arrow hit */
 else
  {
    // if in External Mode, Power Setpoint changes the prop speed or watt density setpoints
   if ((DB_Readout_Active==0)&&(((Keypad_Hit [1] [1] >= VALID_KEYHIT) || Rem_Pup_ButtonHit) && (Mode == LOC_EXT_MODE)))
    {
     Button_Held = 1;
     if (WattDensity_Disable)
      {
	   if (PropSpeed_Enable)
	    {
	     i++;
		 if (i==0) i=0xff;
	     if ((i % 4 == 0) || (i > 21))	// starts off slowly then speeds up
		  {
		   if (i==4)
		    Prop_Setpoint = (unsigned int)(((unsigned long)Encoder_Rate * Prop_Speed_Slope)/8000);
		   Prop_Setpoint++;		// increment by 100W
		   if (Prop_Setpoint > Inverter_Power[Size])
		    Prop_Setpoint = Inverter_Power[Size];
		   if (Encoder_Rate == 0)
		    Prop_Speed_Slope = 0;
		   else
		    Prop_Speed_Slope = (unsigned long)(((unsigned long)Prop_Setpoint*8000)/(unsigned long)Encoder_Rate)+1;
		   Prop_Speed_Change_Hi = 1;
		   Prop_Speed_Change_Lo = 1;
		   //power_setpoint();   	// don't need to update in EXTERNAL MODE get done automatically every 100ms
          }		 
	    } // end proportional speed enabled
	  } // end watt density disabled
	 else	// Watt Density enabled
	  {
	   if (Watt_Density_Setpoint < WATT_DENSITY_LIMIT)
	    {
		 i++;
         if ((i % 4 == 0) || (i > 21))  // starts off slow then speeds up
          {
           Watt_Density_Setpoint ++;
           Watt_Density_Change = 1;        // flag to update DAC
          } // end if incrementing Watt Density
	    } // end Watt_Density_Setpoint less than limit
	  } // end Watt Density enabled
	 if (!Rem_Pup_ButtonHit)
	  {
	   Selected_Readout = POWER_INDEX;   	// display power
       if (!Inverter_On || WattDensity_Enable)			// Only display set point if not running
        Readout_Timer = 1;
	  }
	 else
	  {
       Selected_Readout_Remote = POWER_INDEX;   	// display power
       if (!Inverter_On || WattDensity_Enable)			// Only display set point if not running
        RReadout_Timer = 1;
	  }
	 return;
    } // end prop speed or watt density
   } // end else

/********** Button 7, Function RAMP TIME ARROW UP ******************************/
 if ((((Keypad_Hit [1] [2] >= VALID_KEYHIT) && (Mode != REMOTE_MODE)) 
     || (Rem_Aup_ButtonHit && (Mode != LOCAL_MODE))) 
     && (!Ramping) && (!Inverter_On) && (DB_Readout_Active==0))        
  {
   Button_Held = 1;
   if (!Rem_Aup_ButtonHit)
    {
     Selected_Readout = RAMP_INDEX;
     Readout_Timer = 1;
    }
   else
    {
     Selected_Readout_Remote = RAMP_INDEX;
     RReadout_Timer = 1;
    } // end if mode == REMOTE    

    if (Ramp_Counter < RAMP_TIME_MAX)
     {
      j++;
      if (j==0) j=0xff;
      if ((j % 4 == 0) || (j > 21))
       { 
        Ramp_Counter += 600;        // increment by minutes
        if (Ramp_Counter > RAMP_TIME_MAX)
         Ramp_Counter = RAMP_TIME_MAX;
        Ramp_Change = 1;
       }
     } // end if not ramp time not maxed out
  } // end ramp time arrow up
 else
  j = 0;


/********** Button 8 & Remote Button 8, Function POWER ARROW DOWN **********/
 if ((DB_Readout_Active==0)&&(((Keypad_Hit [1] [3] >= VALID_KEYHIT) && ((Mode == LOCAL_MODE) || (Mode == EXTERNAL_MODE)))
     || (Rem_Pdwn_ButtonHit && ((Mode == REMOTE_MODE)||(Mode==EXTERNAL_MODE)))))
  {
   Button_Held = 1;
   if (Power_Set_KW > 0 )
    {
     k++;
	 if (k==0) k=0xff;
     if ((k % 4 == 0) || (k > 21))  /* starts off slow then speeds up */
      {
       Power_Set_KW--;          /* decrement by 100 W */
       power_setpoint();        /* determine 8 bit DAC value */
       EE_Power_Change = 1;        /* flag to update DAC */
      } /* end decrementing Power */
    } /* end if Power_Set_KW > 0 */
   if (!Rem_Pdwn_ButtonHit)     // if not on remote display must be local
    {
	 if (Selected_Readout != POWER_INDEX)
	  Readout_Change = 1;
     Selected_Readout = POWER_INDEX;  /* display power  value on 7-seg displays */
     if (!Inverter_On)                /* Only display set point if not running */
      Readout_Timer = 1;
    }
   else /* mode == REMOTE */
    {
	 if (Selected_Readout_Remote != POWER_INDEX)
	  Remote_Readout_Change = 1;
     Selected_Readout_Remote = POWER_INDEX;  /* display power   value on 7-seg displays */
     if (!Inverter_On)                  /* Only display set point if not running */
      RReadout_Timer = 1;
    } /* end else mode == remote */
	return;
  } /* end if Power down key hit */
 else
  {
    // if in External Mode, Power Setpoint changes the prop speed or watt density setpoints
   if ((DB_Readout_Active==0)&&(((Keypad_Hit [1] [3] >= VALID_KEYHIT) || Rem_Pdwn_ButtonHit) && (Mode == LOC_EXT_MODE)))
    {
    Button_Held = 1;
    if (WattDensity_Disable)
     {
	  if (PropSpeed_Enable)
	   {
	    k++;
		if (k==0) k=0xff;
	    if ((k % 4 == 0) || (k > 21))	// starts off slowly then speeds up
		 {
		  if (k==4)
		   Prop_Setpoint = (unsigned int)(((unsigned long)Encoder_Rate * Prop_Speed_Slope)/8000);
		  if (Prop_Setpoint > 0)
		   Prop_Setpoint--;		// increment by 100W
		  if (Encoder_Rate == 0)
		   Prop_Speed_Slope = 0;
		  else
		   Prop_Speed_Slope = (unsigned long)((unsigned long)Prop_Setpoint*8000)/(unsigned long)Encoder_Rate;
		  Prop_Speed_Change_Hi = 1;
		  Prop_Speed_Change_Lo = 1;
		  //power_setpoint();	// don't need to update in EXTERNAL MODE get done automatically every 100ms
         }		 
	   } // end proportional speed enabled
	  } // end watt density disabled
	 else	// Watt Density enabled
	  {
	   if (Watt_Density_Setpoint < WATT_DENSITY_LIMIT)
	    {
		 k++;
         if ((k % 4 == 0) || (k > 21))  // starts off slow then speeds up
          {
           Watt_Density_Setpoint --;
           Watt_Density_Change = 1;        // flag to update DAC
		   //power_setpoint();	// don't need to update in EXTERNAL MODE get done automatically every 100ms
          } // end if incrementing Watt Density
	    } // end Watt_Density_Setpoint less than limit
	  } // end Watt Density enabled
	 if (!Rem_Pup_ButtonHit)
	  {
	   Selected_Readout = POWER_INDEX;   	// display power
       if (!Inverter_On || WattDensity_Enable)			// Only display set point if not running
        Readout_Timer = 1;
	  }
	 else
	  {
       Selected_Readout_Remote = POWER_INDEX;   	// display power
       if (!Inverter_On || WattDensity_Enable)			// Only display set point if not running
        RReadout_Timer = 1;
	  }
	 return;
    } // end prop speed or watt density
   } // end else



/********** Button 9, Function RAMP TIME ARROW DOWN ****************************/
 if ((((Keypad_Hit [2] [0] >= VALID_KEYHIT) && (Mode != REMOTE_MODE)) 
     || (Rem_Adwn_ButtonHit && (Mode != LOCAL_MODE))) 
     && (!Ramping) && (!Inverter_On) && (DB_Readout_Active==0))        
  {
   Button_Held = 1;
   if (!Rem_Adwn_ButtonHit)
    {
     Selected_Readout = RAMP_INDEX;
     Readout_Timer = 1;
    }
   else
    {
     Selected_Readout_Remote = RAMP_INDEX;
     RReadout_Timer = 1;
    } // end if mode == REMOTE    
   
   if (Ramp_Counter > RAMP_TIME_MIN)
    {
     m++;
     if (m==0) m=0xff;
     if ((m % 4 == 0) || (m > 21))
      { 
       Ramp_Counter -= 600;        // increment by minutes
       if (Ramp_Counter < RAMP_TIME_MIN)
        Ramp_Counter = RAMP_TIME_MIN;
       Ramp_Change = 1;
      }
    } // end if not ramp time not maxed out
  } // end ramp time arrow down
 else
  m = 0;


/********** Button 10 & Remote Button 10, Function MODE ***************/
 if ((Keypad_Hit [2] [1] >= VALID_KEYHIT) || (Rem_Mod_ButtonHit))
  { 		  
   Button_Held = 1;
   if (Mode_Button_Held == 0) 
	{
	 Mode_Was = Mode;
     switch_modes();	// rev c. switch modes immediately
	}
   Mode_Button_Held++;					// rev c. 1 increment of button held is 100ms
   if (Mode_Button_Held==30)			// switch modes every 4 sec.
	{
     switch_modes();
	 Mode_Button_Held = 1;				// start count over
	}

  } // end Mode button hit
 else
  {
   if (Mode_Button_Held!=0)
	{
	 if (((Mode == EXTERNAL_MODE) || (Mode_Was == EXTERNAL_MODE) || (Mode == LOC_EXT_MODE) || (Mode_Was == LOC_EXT_MODE)) && 
	      (Mode != Mode_Was) && (Stop_Active == 0))  // Stop if we are going to/from external but not if we're not changing
      {                            		/* changing state of AUX relay          */
       Stop_Active = 1;					// stop inverter is setting to external mode
	   Start_Relay = START_OFF;
       Stop_Relay = STOP_ON;
	   Ramping = 0;
	   Stop_ButtonHit = 1;
       Start_ButtonHit = 0;		// may no longer autostart
      }                   // do not switch mode again until button is released
//	 else					// Rev. F  not changing setpoint when switching to/from external mode while running
//	  {
	   power_setpoint();
       set_mode();
	   Mode_Change = 1;
//	  }
	}
   Mode_Button_Held = 0;      // button release, reset 
  }


/********** Button 12 & Remote Button 12, Function START *******************/
 if (((Keypad_Hit [2] [3] >= VALID_KEYHIT) && (Mode != REMOTE_MODE)) || 
    (Rem_Strt_ButtonHit && (Mode != LOCAL_MODE)) || (Aux_Start && PLCRun_Disable)) 
  {
   Button_Held = 1;
   if (((Ramp_Start_Active > 0)||(HCC_Auto_Enable))&&(!Ramping))
   {	// 5/26/00 B JMP added HCC_Auto DIP Switch for Sonoco
        Ramp_Set = Power_Set/10;                // start at 10% of power setpoint
        Ramp_Timer_Increment = Ramp_Counter/(Power_Set - Ramp_Set);
        Ramping = 1;
        Ramp_Timer = 0;
        Number_of_CT = 0;
        update_DAC();
   }
   if (!High_Temp_Fault && !Interlock_Fault && !DC_Bus_Trip && !Over_Volt_Trip && !Current_Trip)	// B Need run contact made to start
    Start_Relay = START_ON;      /* if button is pressed, turn on relay! */
   Start_ButtonHit = 1;		// flag used for autostart
   Stop_ButtonHit = 0;		// flag used for plc start
   Controlled_Stop = 0;		// flag for a user controlled stop state to disable the LTI
  }
 else
  {
    if (Start_Active == 0)
     Start_Relay = START_OFF; 	/* make sure it turns off if button not pressed */
  }
 i=0;
 k=0;
} /* end update_from_keypad */

/****************************************************************************/
/*  TITLE:: UPDATE_ADC                                                      */
/*  DESCRIPTION::   This function reads the 5 8-bit A/D Conversions         */
/*                  from the ADC8038 and saves them in Readout array.       */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     none                                                    */
/*  RETURNS::       none                                                    */
/*  CALLS::         shift_in                                                */
/*  AUTHOR::    Janet Peterson                                              */
/*  DATE::      November 3, 1997                                            */
/****************************************************************************/
void update_ADC (void)
{
 Clk = 0;

 shift_out_cs(CS_ADC);  // enable ADC
 Do = 1;        /* Start bit */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;        /* Single ended */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 0;        /* Address 001 - Channel 2 (Current) */
 Do = 0;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;       /* Mux settling time */
 Clk = 1;
 Readout[CURRENT_INDEX] = shift_in();
 shift_out_cs(CS_NONE); // disable ADC

 shift_out_cs(CS_ADC);  // enable ADC
 Do = 1;        /* Start bit */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;        /* Single ended */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;        /* Address 100 - Channel 1 (Voltage) */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 0;
 Do = 0;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;        /* Mux settling time */
 Clk = 1;
 Readout[VOLTAGE_INDEX] = shift_in();
 shift_out_cs(CS_NONE);         // disable ADC

 shift_out_cs(CS_ADC);          // enable ADC
 Do = 1;        /* Start bit */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;        /* Single ended */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;        /* Address 101 - Channel 3 (Freq) */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 0;
 Do = 0;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;      /* Mux settling time */
 Clk = 1;
 Readout[FREQ_INDEX] = shift_in();
 shift_out_cs(CS_NONE);         // disable ADC

 shift_out_cs(CS_ADC);          // enable ADC
 Do = 1;        /* Start bit */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;        /* Single ended */
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 0;        /* Address 010 - Channel 4 (Power Set) */
 Do = 0;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 0;
 Do = 0;
 Clk = 1;
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;       /* Mux settling time */
 Clk = 1;
 Power_Set_Feedback = shift_in();
 shift_out_cs(CS_NONE);         // disable ADC

 shift_out_cs(CS_ADC);  // enable ADC
 Do = 1;        /* Start bit */
 Do = 1;
 Clk = 1;       /* 1 */
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 1;        /* Single ended */
 Do = 1;
 Clk = 1;       /* 2 */
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Do = 0;        /* Address 000 - Channel 0 (Power) */
 Do = 0;
 Clk = 1;       /* 3 */
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;       /* 4 */
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;       /* 5 */
 Clk = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;       /* Mux settling time * / /* 5 */    
 Clk = 1;
 Readout[POWER_INDEX] = shift_in();
 shift_out_cs(CS_NONE); // disable ADC

}

/****************************************************************************/
/*  TITLE:: UPDATE_DAC                                                      */
/*  DESCRIPTION::   This function writes the 8-bit Power Set Point          */
/*                  to the DAC8054 and saves to the eeprom.                 */
/*  TYPE::              void                                                */
/*  ARGUMENTS::     none                                                    */
/*  RETURNS::       none                                                    */
/*  CALLS::                                                                 */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	November 3, 1997                                        */
/*  REV::                                                                   */
/****************************************************************************/
void update_DAC(void)
{
 unsigned char DAC_Value;

 if (Ramping)
  DAC_Value = Ramp_Set;
 else
  DAC_Value = Power_Set;

 if ((!Electrode_A || !Electrode_B) && (DAC_Value>127))
    DAC_Value = 127;											// limit to half power*/

 shift_out_cs(CS_DAC);    /* select DAC */
 Clk = 1;
 Clk = 1;
 Do = 0;
 Do = 0;
 Clk = 0;
 Clk = 0;
 Clk = 1;						// send out A2
 Clk = 1;
 Do = 0;
 Do = 0;
 Clk = 0;
 Clk = 0;
 Clk = 1;						// send out A1
 Clk = 1;
 Do = 0;
 Do = 0;
 Clk = 0;
 Clk = 0;
 Clk = 1;						// send out A0
 Clk = 1;
 shift_out(DAC_Value);
 shift_out_cs(CS_NONE);         /* disable DAC */
 Clk = 0;

 shift_out_cs(CS_DAC);    /* select DAC */
 Clk = 1;
 Clk = 1;
 Do = 0;
 Do = 0;
 Clk = 0;
 Clk = 0;
 Clk = 1;						// send out A2
 Clk = 1;
 Do = 0;
 Do = 0;
 Clk = 0;
 Clk = 0;
 Clk = 1;						// send out A1
 Clk = 1;
 Do = 1;
 Do = 1;
 Clk = 0;
 Clk = 0;
 Clk = 1;						// send out A0
 Clk = 1;
 if (Auto_Start)
  shift_out((unsigned char)AUTOSTART_ON);
 else
  shift_out((unsigned char)AUTOSTART_OFF);
 shift_out_cs(CS_NONE);         /* disable DAC */
 Clk = 0;

}

/****************************************************************************/
/*  TITLE:: UPDATE_LED_REGISTERS                                            */
/*  DESCRIPTION::   This function sets the LED registers to the updated     */
/*                  values, depending on the most recent analog reading     */
/*                  and the latest readout selection button pressed.        */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     none                                                    */
/*  RETURNS::       none                                                    */
/*  CALLS::         none                                                    */
/*  AUTHOR::        Janet Peterson                                          */
/*  DATE::          November 3, 1997                                        */
/*  REVISION::                                                              */
/****************************************************************************/
void update_LED_registers ( unsigned char *Led, unsigned char Readout_Index, unsigned char Timer, bit Disp_Uppr_Dig)
{
 static unsigned char flash_counter = 0;
 unsigned long temp = 0;
 unsigned char digit_100 = 0;
 unsigned char digit_10 = 0;
 unsigned char digit_1 = 0;
 bit KHz = 0;
 bit hundreds = 0;
 static unsigned char Upper_Count = 0xFF;
 bit No_Upper = 0;

 if (Disp_Uppr_Dig) Upper_Count = 0;
 Upper_Count++;
 if (Upper_Count == 0) Upper_Count = 0xFF;


 switch(Readout_Index)     
  {
   case POWER_INDEX:
	  if ((Timer>0) && (Mode == LOC_EXT_MODE) && (WattDensity_Enable))
	   temp = (unsigned long)Watt_Density_Setpoint;
	  else
	   if ((Timer>0) && (Mode == LOC_EXT_MODE) && (WattDensity_Disable) && (PropSpeed_Enable) && (!Inverter_On))
		temp = Alarm_Setpoint;
	   else
	    if ((Timer>0)&&(!Inverter_On))
	     temp = (unsigned long)Power_Set_Feedback;
        else
	     temp = (unsigned long)Readout[POWER_INDEX];

	  if (!((Mode==LOC_EXT_MODE)&&(WattDensity_Enable)&&(Timer>0)))
	   {
        if (((temp * Inverter_Power[Size]) % 0xFF) > 0x7F)
         temp =  (temp * Inverter_Power[Size])/0xFF + 1;
        else
         temp =  (temp * Inverter_Power[Size])/0xFF;
	   }
      break;

   case VOLTAGE_INDEX:
      temp = (unsigned long)Readout[VOLTAGE_INDEX];
      if (((temp * Inverter_Voltage[Size]) % 0xFF) > 0x7F)
       temp =  (temp * Inverter_Voltage[Size])/0xFF + 1;
      else
       temp = (temp * Inverter_Voltage[Size])/0xFF;
      break;

   case CURRENT_INDEX:
	  temp = (unsigned long)Readout[CURRENT_INDEX];
      if (((temp * Inverter_Current[Size]) % 0xFF) > 0x7F)
       temp = (temp * Inverter_Current[Size])/0xFF + 1;
      else
       temp = (temp * Inverter_Current[Size])/0xFF;
      break;

   case FREQ_INDEX:
	  temp = (unsigned long)Readout[FREQ_INDEX];
      if (((temp * MAX_FREQ) % 0xFF) > 0x7F)
       temp = (temp * MAX_FREQ)/0xFF + 1;
      else
       temp = (temp * MAX_FREQ)/0xFF;
      break;

   case ENCODER_INDEX:
      temp = (unsigned long)Encoder_Rate;		
      if (temp > 999) 
       {
        temp /= 10;
        KHz = 1;
       }
      break;

   case ZERO_INDEX:
      temp = (unsigned long)Zero_Speed_Rate;	// units in 50Hz, need value with 100Hz resolution
      if (temp > 999) 
       {
        temp /= 10;
        KHz = 1;
       }
      break;

   case HOUR_INDEX:
      temp = On_Time/60;	// display hours
      if (temp < 1000) No_Upper = 1;
      if ((Upper_Count < DISPLAY_UPPER_LIMIT)&&(!No_Upper))
       temp /= 1000;	// display upper digits
      else
	   {
	    Upper_Count = 0xFF;
	    temp -= (temp/1000) * 1000;	   // display lower digits
	   } 
	  break;

   case KWH_INDEX:
      temp = KW_Minutes/6000; // display KW hours
      if (temp < 1000) No_Upper = 1;
      if ((Upper_Count < DISPLAY_UPPER_LIMIT)&&(!No_Upper))
       temp /= 1000;	// display upper digits
      else
	   {
	    Upper_Count = 0xFF;
	    temp -= (temp/1000) * 1000;	   // display lower digits
	   }
	  break;

   case ELECTRODE_INDEX:
      temp = (unsigned long)Electrode_Width;	
	  if (temp>=1000)
	   {
		temp/=10;
		hundreds=1;
	   }
	  break;

   case RAMP_INDEX:
      temp = (unsigned long)Ramp_Counter/600;             // display minutes
	  break;
   }

 while (temp >= 100)
 {
  digit_100++;
  temp -= 100;
 }
 while (temp >= 10)
 {
  digit_10++;   
  temp -=10;
 }
 digit_1 = (unsigned char)temp;
  Led[3] &= ALARMFAULT;
  Led[4] = NO_UNITS;
  switch(Readout_Index)
   {
        case POWER_INDEX:
			 if (digit_100 == 0)
			  Led[2] = 0;
			 else
			  Led[2] = LED_Segment[ digit_100 ];
			 Led[1] = (LED_Segment[ digit_10 ] | 0x80);		// xx.x kw
			 Led[0] = LED_Segment[ digit_1 ];
             Led[3] |= POWER; 
             if ((Timer>0)&&(Mode == LOC_EXT_MODE)&&(WattDensity_Enable))
			  Led[4] = NO_UNITS;
			 else
			  Led[4] = KW;
             break;
        case VOLTAGE_INDEX:
			 Led[2] = (LED_Segment[ digit_100 ] | 0x80);	// x.xx kv
			 Led[1] = LED_Segment[ digit_10 ];
			 Led[0] = LED_Segment[ digit_1 ];
             Led[3] |= VOLTAGE;
			 Led[4] = KV;
             break;
        case CURRENT_INDEX:
			 if (digit_100 == 0)							// xxx amp
			  {
		       Led[2] = 0;
			   if (digit_10 == 0)
			    Led[1] = 0;
			   else
				Led[1] = LED_Segment[ digit_10 ];
			  }
			 else
			  {
			   Led[2] = LED_Segment[ digit_100 ];
			   Led[1] = LED_Segment[ digit_10 ];
			  }
			 Led[0] = LED_Segment[ digit_1 ];
             Led[3] |= CURRENT;
			 Led[4] = AMP;
             break;
        case FREQ_INDEX:
			 if (digit_100 == 0)							// xxx khz
			  {
		       Led[2] = 0;
			   if (digit_10 == 0)
			    Led[1] = 0;
			   else
				Led[1] = LED_Segment[ digit_10 ];
			  }
			 else
			  {
			   Led[2] = LED_Segment[ digit_100 ];
			   Led[1] = LED_Segment[ digit_10 ];
			  }
			 Led[0] = LED_Segment[ digit_1 ];
             Led[3] |= FREQ;
			 Led[4] = KHZ;
             break;
        case ENCODER_INDEX:
	         if (KHz)
		      {
       	       Led[2] = (LED_Segment[ digit_100 ]|0x80);	// x.xx Kfpm
		       Led[4] = KHZ;
	  	       Led[1] = LED_Segment[ digit_10 ];
   	           Led[0] = LED_Segment[ digit_1 ]; 
		      }
		     else
		      {
     	       Led[2] = LED_Segment[ digit_100 ];	// xxx fpm
	  	       Led[1] = LED_Segment[ digit_10 ];
   	 	       Led[0] = LED_Segment[ digit_1 ]; 
	           if (digit_100 == 0)
		        {
		         Led[2] = 0;			// turn off leading zero
		         if (digit_10 == 0)
		          Led[1] = 0;
		         else
		          Led[1] = LED_Segment[ digit_10 ];
		        }
		      }
     	    break;
        case HOUR_INDEX:
	        if (digit_100 == 0)
		     {
		      Led[2] = 0;			// turn off leading zero
		      if (digit_10 == 0)
		       Led[1] = 0;
		      else
		       Led[1] = LED_Segment[ digit_10 ];
		     }
       	    else
		     {
       	      Led[2] = LED_Segment[ digit_100 ];
   	 	      Led[1] = LED_Segment[ digit_10 ];	
		     }
   	 	    Led[0] = LED_Segment[ digit_1 ]; 
            Led[3] |= HOUR;
			Led[4] = NO_UNITS;
            break;
	    case KWH_INDEX:
	        if (No_Upper || ((Upper_Count < DISPLAY_UPPER_LIMIT) && (!No_Upper)))
		     {
	          if (digit_100 == 0)
		       {
		        Led[2] = 0;			// turn off leading zero
		        if (digit_10 == 0)
		         Led[1] = 0;
		        else
		         Led[1] = LED_Segment[ digit_10 ];
		       }
       	      else
		       {
       	        Led[2] = LED_Segment[ digit_100 ];
   	 	        Led[1] = LED_Segment[ digit_10 ];	
		       }
   	 	      Led[0] = LED_Segment[ digit_1 ]; 
	 	      Led[3] |= HOUR;
			  Led[4] = NO_UNITS;
		     }
		    else
		     {
   	          Led[2] = LED_Segment[ digit_100 ];
   	 	      Led[1] = LED_Segment[ digit_10 ];	
		      Led[0] = LED_Segment[ digit_1 ]; 
	 	      Led[3] |= HOUR;
			  Led[4] = NO_UNITS;
		     }
            break;
	    case ZERO_INDEX:
			if (KHz)
		     {
       	      Led[2] = (LED_Segment[ digit_100 ]|0x80);	// x.xx KHz
		      Led[4] = KHZ;
	  	      Led[1] = LED_Segment[ digit_10 ];
   	          Led[0] = LED_Segment[ digit_1 ]; 
		     }
		    else
		     {
     	      Led[2] = LED_Segment[ digit_100 ];	// xxx Hz
	  	      Led[1] = LED_Segment[ digit_10 ];
   	 	      Led[0] = LED_Segment[ digit_1 ]; 
	          if (digit_100 == 0)
		       {
		        Led[2] = 0;			// turn off leading zero
		        if (digit_10 == 0)
		         Led[1] = 0;
		       }
			  Led[3] |= FREQ;
			  Led[4] = NO_UNITS;
		     }
     	    break;
		case ELECTRODE_INDEX:
			 if (digit_100 == 0)
			  Led[2] = 0;
			 else
			  Led[2] = LED_Segment[ digit_100 ];
			 if (!hundreds)
			  Led[1] = (LED_Segment[ digit_10 ] | 0x80);		// xx.x kw
			 else
              Led[1] = LED_Segment[ digit_10 ];		// xxx kw
			 Led[0] = LED_Segment[ digit_1 ];
             Led[3] |= NO_UNITS;        
			 Led[4] = NO_UNITS;
             break;
		case RAMP_INDEX:
     	     Led[2] = LED_Segment[ digit_100 ];	// xxx
	  	     Led[1] = LED_Segment[ digit_10 ];
   	 	     Led[0] = LED_Segment[ digit_1 ]; 
	         if (digit_100 == 0)
		      {
		       Led[2] = 0;			// turn off leading zero
		       if (digit_10 == 0)
		        Led[1] = 0;
		      }
			 Led[3] |= NO_UNITS;
			 Led[4] = NO_UNITS;
			 break;
        default:
			Led[2] = 0;
			Led[1] = 0;
			Led[0] = 0;
            Led[3] |= NO_UNITS;
			Led[4] = NO_UNITS;
   } // end switch readout_index

 if (Ramping || (Readout_Index == ZERO_INDEX) || Inverter_On_Flash)                /* hour meter has exceeded limit */
 {
  flash_counter++;
  if (flash_counter < 8)
  {
   if (Ramping)
    {
     switch(Readout_Index)          // if soft start/ramping flash readout selection LED
      {
       case POWER_INDEX:
            Led[3] &= ~POWER;       
            break;
       case VOLTAGE_INDEX:
            Led[3] &= ~VOLTAGE;
            break;
       case CURRENT_INDEX:
            Led[3] &= ~CURRENT;
            break;
       case FREQ_INDEX:
            Led[3] &= ~FREQ;
            break;
	   case ENCODER_INDEX:
		    Led[3] &= ~FREQ;
		    break;
       case HOUR_INDEX:
            Led[3] &= ~HOUR;
			break;
	   case KWH_INDEX:
	        Led[3] &= ~HOUR;
			break;
      } // end switch readout_index
    } // end if ramping*/
   if (Readout_Index == ZERO_INDEX)
    Led[3] &= ~FREQ;
   } // end if flash_counter < 8
  else
   {
	if (Inverter_On_Flash)
     Led[5] |= 0x02;
    if (flash_counter > 14)       /* Display normal meter info. for half time */
   	 flash_counter = 0;
   }
 } // end if ramping
} // end update LED

/****************************************************************************/
/*  TITLE:: POWER_SETPOINT                                                  */
/*  DESCRIPTION::   This function determines the 8 bit power set point      */
/*                  value that is to be sent to the A/D converter           */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     none                                                    */
/*  RETURNS::       none                                                    */
/*  CALLS::         none                                                    */
/*  AUTHOR::    Janet Peterson                                              */
/*  DATE::      June 3, 1997                                                */
/*  REVISION::                                                              */
/****************************************************************************/
void power_setpoint ( void )
{
 float ftemp=0;
 unsigned int remainder = 0;
 if ((Mode==LOCAL_MODE)||(Mode==REMOTE_MODE)||(Mode==EXTERNAL_MODE))
  ftemp = (float)Power_Set_KW * (float)255;
 else
  if (WattDensity_Enable)
   ftemp = ((float)Watt_Density_Setpoint * (float)Encoder_Rate * (float)Electrode_Width * 187)/ 175000; 
  else
   ftemp = (((float)Encoder_Rate * (float)Prop_Speed_Slope * (float)255)/(float)8000);
 Alarm_Setpoint = (unsigned int)(ftemp/(float)Inverter_Power[Size]);
 if (Alarm_Setpoint > 255)
  Power_Set = 255;
 else
  {
   Power_Set = (unsigned char)Alarm_Setpoint;
   remainder = (unsigned int)((unsigned long)ftemp % Inverter_Power[Size]);
   if ((remainder > (Inverter_Power[Size]/2))&&(Power_Set < 255))
    Power_Set++;
  }
}

/************************************************************************/
/* TITLE::      ALARM_CHECK                                             */
/* DESCRIPTION::This function determines whether the actual power       */
/*              is within a set limit of the set point                  */
/* TYPE::       void                                                    */
/* ARGUMENTS::  none                                                    */
/* RETURNS::    none                                                    */
/* CALLS::      none                                                    */
/* AUTHOR::     Janet Peterson                                          */
/* DATE::       November 1997                                           */
/* REVISION::                                                           */
/************************************************************************/
void alarm_check (void)
{
 unsigned int Power_High = 0;
 unsigned int Power_Low = 0;

 if (Mode_Button_Held == 0)
  {
   if (Mode==LOC_EXT_MODE)
    {
     Power_High = Alarm_Setpoint + ALARM_ON;
     if (Alarm_Setpoint < ALARM_ON)
      Power_Low = 0;
     else
      Power_Low = Alarm_Setpoint - ALARM_ON;
    }
   else
    {
     Power_High = (unsigned int)Power_Set_Feedback + ALARM_ON;
     if (Power_Set_Feedback < ALARM_ON)
      Power_Low = 0;
     else
      Power_Low = (unsigned int)Power_Set_Feedback - ALARM_ON;
    }


   if ((((unsigned int)Readout[POWER_INDEX] > Power_High) || ((unsigned int)Readout[POWER_INDEX] < Power_Low)) && (Inverter_On)) // 1/6/98 JMP Inverter On not necessary
   /* ALARM!!! */
    {
     LTI_Counter++;
     if (LTI_Counter == 0)
      LTI_Counter = 0xff;
     if ((LTI_Counter > LTI_COUNT_MAX) && ((LED_Port[3] & ALARMFAULT) == 0) && (!Ramping))
      {
       Lti_Relay = LTI_ON;        /* this is a new fault -> activate relay */
       LED_Port[3] |= ALARMFAULT;         /* turn the alarm fault led ON */
       RLED_Port[3] |= ALARMFAULT;        /* turn the remote alram fault ON */
      } /* end if Alarm Fault LED not already on */
    } /* end LTI fault */
   else
    {
     if (((High_Temp_Fault) || (Interlock_Fault) || (DC_Bus_Trip) || (Over_Volt_Trip) || (Current_Trip)) && ((LED_Port[3] & ALARMFAULT) == 0))
      { // turn on alarm for trip!!!
       if (Controlled_Stop == 0)
       	Lti_Relay = LTI_ON;        /* this is a new fault -> activate relay */
	   if (Controlled_Stop == 1)
		Lti_Relay = LTI_OFF;       
       LED_Port[3] |= ALARMFAULT;         /* turn the alarm fault led ON */
       RLED_Port[3] |= ALARMFAULT;        /* turn the remote alram fault ON */
      } 
     else
      {
       LTI_Counter = 0;

       if (Mode==LOC_EXT_MODE)
        {
         Power_High = Alarm_Setpoint + ALARM_OFF;
         if (Alarm_Setpoint < ALARM_OFF)
          Power_Low = 0;
         else
          Power_Low = Alarm_Setpoint - ALARM_OFF;
        }
       else
        {
         Power_High = (unsigned int)Power_Set_Feedback + ALARM_OFF;
         if (Power_Set_Feedback < ALARM_OFF)
          Power_Low = 0;
         else
          Power_Low = (unsigned int)Power_Set_Feedback - ALARM_OFF;
        }

       if (((Power_High >= (unsigned int)Readout[POWER_INDEX]) && (Power_Low <= (unsigned int)Readout[POWER_INDEX]))||(Ramping)||(!Inverter_On))           /* 1/6/98 JMP do not need inverter on condition */
        {
         if ((!High_Temp_Fault) && (!Interlock_Fault) && (!DC_Bus_Trip) && (!Over_Volt_Trip) && (!Current_Trip))
          {
           Lti_Relay = LTI_OFF;             /* make sure relay turns OFF */
           LED_Port[3] &= 0xDF;         /* not in alarm, turn OFF Alarm Fault LED */
           RLED_Port[3] &= 0xDF;    /* turn OFF remote Alarm Fault LED */
          } /* end control board not in fault or trip state */
        } /* end LTI not in fault */
      } /* end else */
    } /* end else */
  } /* end don't check if switching modes */
} /* end alarm check */

/****************************************************************************/
/*  TITLE:: 		SET_MODE                                                */
/*  DESCRIPTION::   This function sets the relays to the mode               */
/*                  determined by the Mode                                  */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     void                                                    */
/*  RETURNS::       none                                                    */
/*  CALLS::         none                                                    */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	October 28, 1997                                        */
/*  REVISION::                                                              */
/****************************************************************************/
void set_mode ( void )
{
   //           RESET RELAY     AUX RELAY
   // LOCAL         OFF           OFF
   // REMOTE        ON            OFF
   // EXTERNAL      OFF           ON 
  switch(Mode)
   {
    case REMOTE_MODE:
         Reset_Relay = RESET_ON;
         Aux_Relay = AUX_OFF;
         break;
    case EXTERNAL_MODE:
         Reset_Relay = RESET_OFF;
         Aux_Relay = AUX_ON;
         break;
    case LOC_EXT_MODE:    // LOCAL/EXTERNAL MODE
         Reset_Relay = RESET_OFF;
         Aux_Relay = AUX_OFF;
		 break;
    default:    //LOCAL MODE
         Reset_Relay = RESET_OFF;
         Aux_Relay = AUX_OFF;
         Mode = LOCAL_MODE;
         break;
   }
}


/****************************************************************************/
/*  TITLE:: 		SWITCH_MODES                                            */
/*  DESCRIPTION::   This function determines the next mode depending on     */
/*                  order and availablility of the mode.                    */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     void                                                    */
/*  RETURNS::       none                                                    */
/*  CALLS::         none                                                    */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	March 21, 2001                                          */
/*  REVISION::                                                              */
/****************************************************************************/
void switch_modes ( void )
{
   switch(Mode)
    {
     case LOCAL_MODE:           //  LOCAL -> REMOTE -> EXTERNAL/LOC_EXT
      if (!Remote_Disable)      //  if all modes disabled, local is default	
       Mode = REMOTE_MODE;
      else
       if (External_Enable)
	    {
		 if (WattDensity_Disable && PropSpeed_Disable)
          Mode = EXTERNAL_MODE;
		 else
		  Mode = LOC_EXT_MODE;
		}
      break;

      case REMOTE_MODE:         // REMOTE -> EXTERNAL/LOC_EXT -> LOCAL
       if (External_Enable)
	    {
		 if (WattDensity_Disable && PropSpeed_Disable)
          Mode = EXTERNAL_MODE;
		 else
		  Mode = LOC_EXT_MODE;
		}
       else
        {if (Local_Enable)
          Mode = LOCAL_MODE;
         else
          if (Remote_Disable)   // if all modes disabled, default is LOCAL
           Mode = LOCAL_MODE;}
       break;

      case EXTERNAL_MODE:       // EXTERNAL -> LOCAL -> REMOTE
       if (Local_Enable)
        Mode = LOCAL_MODE;
       else
        {if (!Remote_Disable)
          Mode = REMOTE_MODE;
         else
          if (External_Disable)
           Mode = LOCAL_MODE;}  // default is LOCAL
       break;

      case LOC_EXT_MODE:       // LOC_EXT -> LOCAL -> REMOTE
       if (Local_Enable)
        Mode = LOCAL_MODE;
       else
        {if (!Remote_Disable)
          Mode = REMOTE_MODE;
         else
          if (External_Disable)
           Mode = LOCAL_MODE;}  // default is LOCAL
       break;

    
      default:
       Mode = LOCAL_MODE;       // if Mode not valid, default to LOCAL
    }

 }


// WAS SERIAL.C
/****************************************************************************/
/*  TITLE:: 		SHIFT_OUT                                               */
/*  DESCRIPTION::   shifts a byte out on the MICROWIRE bus using            */
/*                  the Clk and Do pins                                     */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     send_byte (unsigned char)                               */
/*  RETURNS::       nothing                                                 */
/*  CALLS::         nothing                                                 */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	July 17, 1996                                           */
/****************************************************************************/
 void shift_out (unsigned char send_byte)
{
 unsigned char i;
 for (i=0; i<8; i++)
 {
  Clk = 0;
  Clk = 0;
  Clk = 0;
  if ((send_byte & 0x80) == 0x80)       /* start with the MSB and put it on */
  {Do = 1;                              /* the Do pin */
   Do = 1;
   Do = 1;}
  else 
  {Do = 0;
   Do = 0;
   Do = 0;}
  
  Clk = 1;
  Clk = 1;
  Clk = 1;                              /* Clock it */
  send_byte = _crol_(send_byte, 1);     /* shift the byte to the left */
 }
}

/****************************************************************************/
/*  TITLE:: 		SHIFT_OUT_CS                                            */
/*  DESCRIPTION::   shifts a byte out to the shift register using the       */
/*                  the Cs_Clk and Cs_Do pins                               */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     send_byte (unsigned char)                               */
/*  RETURNS::       nothing                                                 */
/*  CALLS::         nothing                                                 */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	July 17, 1996                                           */
/****************************************************************************/
 void shift_out_cs (unsigned char send_byte)
{
 unsigned char i;
if (send_byte==CS_DAC)
 {
 DAC_Chip_Select=Chip_Select_On;
 send_byte=CS_NONE;
 }
else
 {
 DAC_Chip_Select=Chip_Select_Off;
 }
 Do = 0;
 for (i=0; i<8; i++)
 {
  Cs_Clk = 0;
  if ((send_byte & 0x80) == 0x80)       /* start with the MSB and put it on */
  {Cs_Do = 1;                           /* the Do pin */
   Cs_Do = 1;}
  else 
  {Cs_Do = 0;
   Cs_Do = 0;}
  
  Cs_Clk = 1;                              /* Clock it */
  send_byte = _crol_(send_byte, 1);     /* shift the byte to the left */
 }
}

 
/****************************************************************************/
/*  TITLE:: 		SHIFT_IN                                                */
/*  DESCRIPTION::   shifts a byte in on the MICROWIRE bus using             */
/*                  the Clk and Di pins                                     */
/*  TYPE::          unsigned char                                           */
/*  ARGUMENTS::     void                                                    */
/*  RETURNS::       send_byte                                               */
/*  CALLS::         nothing                                                 */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	July 17, 1996                                           */
/****************************************************************************/
 unsigned char shift_in (void)
{
 unsigned char i, send_byte;
 Clk = 0;
 Clk = 0;
 send_byte = 0xff;
 for (i=0; i<8; i++)
 {
  send_byte = _crol_(send_byte,1);  // shift to the left 1 bit     
  Clk = 1;
  Clk = 1;
  if (Di == 0)
   send_byte &=0xfe;                // sets LSB to zero
  Clk = 0;
  Clk = 0;
 }
 return(send_byte);
}

/****************************************************************************/
/*  TITLE::	 		SET_EEPROM_DEFAULTS                                     */
/*  DESCRIPTION::   sets eeprom data to default setting                     */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     none                                                    */
/*  RETURNS::       nothing                                                 */
/*  CALLS::         shift_out, shift_in                                     */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	July 18, 1996                                           */
/*  REVISION::                                                              */
/****************************************************************************/
void set_eeprom_defaults(void)
{
 unsigned char i;
 write_eeprom(ID_ADDR, EEPROM_ID);
 write_eeprom(POWER_ADDR, POWERSET_DEFAULT);
 write_eeprom(HOUR_METER_ADDR_HI, HOUR_METER_DEFAULT_HI);
 write_eeprom(HOUR_METER_ADDR_LO, HOUR_METER_DEFAULT_LO);
 write_eeprom(READOUT_ADDR, POWER_INDEX);
 write_eeprom(MODE_ADDR, LOCAL_MODE);
 write_eeprom(RAMP_TIME_ADDR, RAMP_TIME_DEFAULT);
 write_eeprom(ZERO_SPEED_ADDR, ZERO_SPEED_DEFAULT);
 write_eeprom(KWH_METER_ADDR_LO, KWH_ADDR_DEFAULT_LO);
 write_eeprom(KWH_METER_ADDR_HI, KWH_ADDR_DEFAULT_HI);
 write_eeprom(ELECTRODE_WIDTH_ADDR, ELECTRODE_WIDTH_DEFAULT);
 write_eeprom(PROP_SPEED_ADDR_HI, PROP_SPEED_HI_DEFAULT);
 write_eeprom(PROP_SPEED_ADDR_LO, PROP_SPEED_LO_DEFAULT);
 write_eeprom(WATT_DENSITY_ADDR, WATT_DENSITY_DEFAULT);
 		
 for (i=17; i<64; i++)   // set remaining eeprom to zeros
  write_eeprom(i, 0);
 Mode = LOCAL_MODE;
 Power_Set = POWERSET_DEFAULT;
 Ramp_Counter = RAMP_TIME_DEFAULT;
 Power_Set_KW = POWERSET_DEFAULT;
 Selected_Readout = POWER_INDEX;
 Zero_Speed_Rate = ZERO_SPEED_DEFAULT;
 KW_Minutes = 0;
 Electrode_Width = ELECTRODE_WIDTH_DEFAULT;
 Watt_Density_Setpoint = WATT_DENSITY_DEFAULT;
 Prop_Speed_Slope = 0;
 
}

/****************************************************************************/
/*  TITLE:: 		WRITE_EEPROM                                            */
/*  DESCRIPTION::   writes value to address of eeprom                       */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     address, value                                          */
/*  RETURNS::       nothing                                                 */
/*  CALLS::         shift_out, disable_prog_eeprom, enable_prog_eeprom      */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	July 18, 1996                                           */
/****************************************************************************/
void write_eeprom (unsigned char address, unsigned int value)
{
 unsigned int temp = 0;

 enable_prog_eeprom();
 Clk = 0;                    // clock must be low before CS goes high
 Clk = 0;
 Clk = 0;
 shift_out_cs(CS_EE);        // enable EEprom
 Clk = 0;                    // send Start bit
 Clk = 0;
 Clk = 0;
 Do = 1;
 Do = 1;
 Do = 1;
 Clk = 1;      
 Clk = 1;
 Clk = 1;
 address |= 0x40;            // send WRITE instruction and address
                             // 01XX XXXX (XX XXXX = address)
 shift_out(address);
 shift_out((unsigned char)((value & 0xff00)/0x100));
 shift_out((unsigned char)(value & 0x00ff));
 Clk = 0;
 Clk = 0;
 Clk = 0;
 shift_out_cs(CS_NONE);      // disable EEprom
 shift_out_cs(CS_EE);        // enable EEprom
 while ((Di == 0) && (temp < 2050))  // wait until eeprom is ready (aprox. 10 ms)
 { temp++;}                   // if eeprom not working don't wait forever
 shift_out_cs(CS_EE);        // disable EEprom
 disable_prog_eeprom();
}

/****************************************************************************/
/*  TITLE:: 		ENABLE_PROG_EEPROM                                      */
/*  DESCRIPTION::   Erase/Write Enable (WEN) instruction is sent to         */
/*                  eeprom.  All programming modes must be proceded         */
/*                  by this instruction.                                    */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     none                                                    */
/*  RETURNS::       nothing                                                 */
/*  CALLS::         shift_out                                               */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	July 18, 1996                                           */
/****************************************************************************/ 
void enable_prog_eeprom ( void )
{
 Clk = 0;                 // Clk must be low before CS goes high
 Clk = 0;
 Clk  = 0;
 shift_out_cs(CS_EE);     // enable EEprom
 Clk = 0;                 // send Start bit
 Clk = 0;
 Clk = 0;
 Do = 1;
 Do = 1;
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 1;
 shift_out(0x3F);         // send WEN instruction (0011XXXX)
                          // enables all programming modes
 shift_out_cs(CS_NONE);   // disable EEprom 
}

/****************************************************************************/
/*  TITLE:: DISABLE_PROG_EEPROM                                             */
/*  DESCRIPTION::   Erase/Write Disable (WDS) instruction is sent to        */
/*                  eeprom to protect against accidental data disturb.      */
/*                  WDS disables all programming modes and should           */
/*                  follow all programming operations.                      */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     none                                                    */
/*  RETURNS::       nothing                                                 */
/*  CALLS::         shift_out                                               */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	July 18, 1996                                           */
/****************************************************************************/
void disable_prog_eeprom ( void )
{
 
 Clk = 0;                 // Clk must be low before CS goes high
 Clk = 0;
 Clk = 0;
 shift_out_cs(CS_EE);     // select EEPROM 
 Clk = 0;                 // send Start bit
 Clk = 0;
 Clk = 0;
 Do = 1;
 Do = 1;
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 1;
 shift_out(0x0F);         // send WDS instruction (0000XXXX)
                          // enables all programming modes
 shift_out_cs(CS_NONE);   // disable EEPROM
}

/****************************************************************************/
/*  TITLE:: 		GET_EEPROM                                              */
/*  DESCRIPTION::   Retrieves data from EEprom at given address.            */
/*  TYPE::          unsigned char                                           */
/*  ARGUMENTS::     address (unsigned char)                                 */
/*  RETURNS::       shift_in                                                */
/*  CALLS::         shift_out, shift_in                                     */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	July 17, 1996                                           */
/****************************************************************************/
unsigned int get_eeprom ( unsigned char address )
{
 unsigned int value = 0; 
 unsigned char temp_counter = 0;
 address |= 0x80;         // set opcode to READ value:: 10XX XXXX (2 MSB) 
 Clk = 0;                 // clock must be low before CS goes high
 Clk = 0;
 Clk = 0;
 shift_out_cs(CS_EE);     // enable EEprom
 Clk = 0;                 // send Start bit
 Clk = 0;
 Clk = 0;
 Do = 1;
 Do = 1;
 Do = 1;
 Clk = 1;
 Clk = 1;
 Clk = 1;
 shift_out (address);     // send opcode and address
 if (Di == 1)
  {
   Clk = 0;
   Clk = 0;
  }

 while ((Di== 1) && (temp_counter < 150))  // wait for Di to be pulled low
 {temp_counter++;}
 value = shift_in() * 0x100;              // read high byte of word (don't care what this is)   
 value += shift_in();
 shift_out_cs(CS_NONE);   // disable EEprom
 return(value);           // read low and high byte of word and return value
 
}

/****************************************************************************/
/*  TITLE:: 		SHIFT_REGISTER_IN                                       */
/*  DESCRIPTION::   shifts a byte in on the MICROWIRE bus using             */
/*                  the Clk and Di pins.  This is specifically for          */
/*                  for the 74ACT166 shift register chip.                   */
/*  TYPE::          unsigned char                                           */
/*  ARGUMENTS::     unsigned char chip_select                               */
/*  RETURNS::       send_byte                                               */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	November 3, 1997                                        */
/****************************************************************************/
unsigned char shift_register_in (unsigned char chip_select)
{ 
 unsigned char i, send_byte;
 Clk = 1;
 Clk = 1;
 Do = 1;
 Do = 1;
 shift_out_cs(chip_select);   /* set chip select to read DIP */
 Do = 0;        /* Load parallel inputs */
 Do = 0;
 Clk = 0;
 Clk = 0;
 Clk = 1;
 Clk = 1;       /* Rising edge of clock loads */
 Clk = 0;
 Clk = 0;
 Do = 1;
 Do = 1;        /* Shift mode */

 send_byte = 0xff;
 if (Di == 0)
  send_byte = 0xfe;
 for (i=0; i<7; i++)
 {
  send_byte = _crol_(send_byte,1);  // shift to the left 1 bit     
  Clk = 1;
  Clk = 1;
  if (Di == 0)
   send_byte &=0xfe;                // sets LSB to zero
  Clk = 0;
  Clk = 0;
 }
 if (chip_select == CS_DIP)
  {
   DIP_Switch = send_byte;
   Clk = 1;
   Clk = 1;
   send_byte = 0xff;
    if (Di == 0)
    send_byte = 0xfe;
   Clk = 0;
   Clk = 0;
   for (i=0; i<7; i++)
    {
	 send_byte = _crol_(send_byte,1);	// shift to the left 1 bit
	 Clk = 1;
	 Clk = 1;
	 if (Di == 0)
	  send_byte &= 0xfe;				// shift LSB to zero
	 Clk = 0;
	 Clk = 0;
	}
   Clk = 1;
   Clk = 1;
  }
 Clk = 1;
 Clk = 1;
 Do = 0; 
 Do = 0;
 shift_out_cs(CS_NONE);             // disable bus
 return(send_byte);
} 

/****************************************************************************/
/*  TITLE::	 		LRC                                                     */
/*  DESCRIPTION::   Creates a check sum using the Longitudinal              */
/*                  Redundancy Check, which is calculated by adding         */
/*                  together all of the 8 bit bytes in the message,         */
/*                  discarding any carries and twos complementing the       */
/*                  result.                                                 */
/*  TYPE::  		unsigned char                                           */
/*  ARGUMENTS::     unsigned char Msg - pointer to Message Block            */
/*                  unsigned char Length - number of bytes in message       */
/*  RETURNS::       static unsigned char - checksum                         */
/*  AUTHOR::        Janet Peterson                                          */
/*  DATE::          October 29, 1997                                        */
/****************************************************************************/

unsigned char lrc(Msg, Length)

unsigned char *Msg ;
unsigned char Length ;

{
 unsigned char checksum = 0;            // LRC char initialized
 
 while (Length--)                       // pass through message buffer
 {
  checksum += (*Msg & 0x7F);            // add buffer, msb doesn't count (7 bit ascii)
  Msg++;                                // increment address
 }

 return ((unsigned char)((~(checksum) + 1))) ; // return twos complement
 }

/****************************************************************************/
/*  TITLE:: 		HEX_TO_ASCII                                            */
/*  DESCRIPTION::   Converts an 8-bit byte to 2 7 bit ASCII characters      */
/*                  the 8th bit will be ones (STOP bits) and will           */
/*                  the high ascii byte will be stored in the address       */
/*                  provided by the calling routine and the low byte        */
/*                  will be stored in the next consecutive address.         */
/*  TYPE::  void                                                            */
/*  ARGUMENTS::     unsigned char hex_byte - hex byte to be converted       */
/*                  to 2 ASCII bytes                                        */
/*                  address where result will be stored                     */
/*  RETURNS::       nothing                                                 */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	October 29, 1997                                        */
/****************************************************************************/

void hex_to_ascii (unsigned char hex_byte, unsigned char *send_packet)
{
 unsigned char ascii_byte = 0;

 ascii_byte = ((0xF0 & hex_byte)/0x10) + 0xB0;   // move upper nibble to lower
                                        // byte and make ascii w/STOP bit
 if (ascii_byte > 0xB9)                 // for A - F
  ascii_byte += 0x07;
 *send_packet = ascii_byte;             // put high ascii byte in buffer
 send_packet++;                         // increment address
 
 ascii_byte = (0x0F & hex_byte) + 0xB0; // look at lower nibble, add 0x30
                                        // for ascii and 0x80 8th bit STOP 
 if (ascii_byte > 0xB9)                 // for ascii A - F add 0x07 (A == 0x41)
  ascii_byte += 0x07;           

 *send_packet = ascii_byte;             // put low ascii byte in buffer 
 
}

/****************************************************************************/
/*  TITLE:: 		ASCII_TO_HEX                                            */
/*  DESCRIPTION::   Converts 2 7 bit ASCII bytes to an unsigned char        */
/*  TYPE::                                                                  */
/*  ARGUMENTS::     address of 2 bytes to convert                           */
/*  RETURNS::       unsigned char - hex_byte                                */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	October 30, 1997                                        */
/****************************************************************************/

unsigned char ascii_to_hex (unsigned char *conversion )
{
 unsigned char ascii_byte;
 unsigned char hex_byte;                                

 ascii_byte = conversion[0];      // look at high byte
 ascii_byte &= 0x7F;            // don't care about msb
 ascii_byte -= 0x30;            // unasciize it
 if (ascii_byte > 0x09)
  ascii_byte -= 0x07;           // subtract more for A-F
 if (ascii_byte > 0x0F)
  return(0);                    // error
 hex_byte = ascii_byte * 0x10;  // shift to upper nibble
 ascii_byte = conversion[1];  // look at low ascii byte
 ascii_byte &= 0x7F;            // don't care about msb
 ascii_byte -= 0x30;            // unasciize it
 if (ascii_byte > 0x09)
  ascii_byte -= 0x07;           // subtract more for A-F
 if (ascii_byte > 0x0F)
  return(0);                    // error
 hex_byte +=  ascii_byte;
 return(hex_byte);
}

/****************************************************************************/
/*  TITLE:: UPDATE_REMOTE_LED                                               */
/*  DESCRIPTION::   This function fills the communication buffer with       */
/*                  the Master Query that tells the remote that the         */
/*                  data following is LED port information and to           */
/*                  respond with button and dip switch status.              */
/*  TYPE::          void                                                    */
/*  ARGUMENTS::     void                                                    */
/*  RETURNS::       none                                                    */
/*  CALLS::         none                                                    */
/*  AUTHOR::    	Janet Peterson                                          */
/*  DATE::      	November 6, 1997                                        */
/*  REVISION::                                                              */
/****************************************************************************/

void update_remote_LED ( void )
{
 unsigned long temp = 0;
 
 if (Lti_Relay == LTI_ON)
  RLED_Port[3] |= 0x80;                 /* set msb to turn on remote LTI */
 else
  RLED_Port[3] &= 0x7F;                 /* clr msb to turn off remote LTI */

 Comm_Buffer[0] = COLON;                /* start of message */
 Comm_Buffer[1] = REMOTE_ADDR_HI;       /* high byte of remote address */
 Comm_Buffer[2] = REMOTE_ADDR_LO;       /* low byte of remote address */
 Comm_Buffer[3] = FUNC_CODE_HI;         /* high byte of function code */
 Comm_Buffer[4] = FUNC_CODE_LO;         /* low byte of function code */
 
 /* Transmit Power */
 temp = (unsigned long)Readout[POWER_INDEX];
 if (((temp * Inverter_Power[Size]) % 0xFF) > 0x7F)
  temp =  (temp * Inverter_Power[Size])/0xFF + 1;
 else
  temp =  (temp * Inverter_Power[Size])/0xFF;

hex_to_ascii((temp >> 8), &Comm_Buffer[5]);
hex_to_ascii(temp, &Comm_Buffer[7]);
 
 /* Transmit Voltage. */
  temp = (unsigned long)Readout[VOLTAGE_INDEX];
  if (((temp * Inverter_Voltage[Size]) % 0xFF) > 0x7F)
   temp =  (temp * Inverter_Voltage[Size])/0xFF + 1;
  else
   temp = (temp * Inverter_Voltage[Size])/0xFF;

hex_to_ascii((temp >> 8), &Comm_Buffer[9]);
hex_to_ascii(temp, &Comm_Buffer[11]);

 /* Transmit Current. */
	  temp = (unsigned long)Readout[CURRENT_INDEX];
      if (((temp * Inverter_Current[Size]) % 0xFF) > 0x7F)
       temp = (temp * Inverter_Current[Size])/0xFF + 1;
      else
       temp = (temp * Inverter_Current[Size])/0xFF;
      
hex_to_ascii((temp >> 8), &Comm_Buffer[13]);
hex_to_ascii(temp, &Comm_Buffer[15]);

	/* Transmit Frequency. */
	temp = (unsigned long)Readout[FREQ_INDEX];
	if (((temp * MAX_FREQ) % 0xFF) > 0x7F)
		temp = (temp * MAX_FREQ)/0xFF + 1;
	else
		temp = (temp * MAX_FREQ)/0xFF;
	
	
hex_to_ascii((temp >> 8), &Comm_Buffer[17]);
hex_to_ascii(temp, &Comm_Buffer[19]);
	
	/* Transmit faults. */
	temp = 0;

	if(High_Temp_Fault)
		temp |= 0x01;
	
	if(Interlock_Fault)
		temp |= 0x02;
	
	if(DC_Bus_Trip)
		temp |= 0x04;
	
	if(Over_Volt_Trip)
		temp |= 0x08;
	
	if(Current_Trip)
		temp |= 0x10;

	if(Inverter_On)
		temp |= 0x20;
	
	hex_to_ascii( temp, &Comm_Buffer[21]);
	
// hex_to_ascii( RLED_Port[0], &Comm_Buffer[5]);
 //hex_to_ascii( RLED_Port[1], &Comm_Buffer[7]);
 //hex_to_ascii( RLED_Port[2], &Comm_Buffer[9]);
 //hex_to_ascii( RLED_Port[3], &Comm_Buffer[21]);
 //hex_to_ascii( RLED_Port[4], &Comm_Buffer[13]);
 //hex_to_ascii( RLED_Port[5], &Comm_Buffer[15]);
 //hex_to_ascii( RLED_Port[6], &Comm_Buffer[17]);
 //hex_to_ascii( (lrc(&Comm_Buffer[1],18)), &Comm_Buffer[19]);
 Comm_Buffer[23] = CR;
 Comm_Buffer[24] = LF;
 De = TRANSMIT_ENABLE;                  /* tell RS485 chip we want to transmit */
 REN = 0;                               /* disable reception */
 TI = 0;                                /* clear transmit interrupt flag */
 SBUF = Comm_Buffer[0];                 /* start serial transmission */
 Buffer_Index  = 1;                     /* indicate next byte to transmit */
 Message_Received = 0;                  /* have not received a response to our query */
} /* end send_remote_LED */

/***************************************************************************/
/*  TITLE:: 		UPDATE_REMOTE_KEYPAD                                   */
/*  DESCRIPTION::   This function reads the communication buffer           */
/*  TYPE::          void                                                   */
/*  ARGUMENTS::     void                                                   */
/*  RETURNS::       none                                                   */
/*  CALLS::         none                                                   */
/*  AUTHOR::    	Janet Peterson                                         */
/*  DATE::      	November 6, 1997                                       */
/*  REVISION::                                                             */
/***************************************************************************/
void update_remote_keypad ( void )
{
 if ((Comm_Buffer[0] == COLON) && (Comm_Buffer[1] == REMOTE_ADDR_HI) && 
     (Comm_Buffer[2] == REMOTE_ADDR_LO) && (Comm_Buffer[3] == FUNC_CODE_HI) &&
     (Comm_Buffer[4] == FUNC_CODE_LO) && (Comm_Buffer[11] == CR) && 
     (Comm_Buffer[12] == LF))
  {
   if (lrc(&Comm_Buffer[1],8) == ascii_to_hex(&Comm_Buffer[9]))
    {
     Remote_Keyhit[0] = ascii_to_hex(&Comm_Buffer[5]);
     Remote_Keyhit[1] = ascii_to_hex(&Comm_Buffer[7]);
    } /* end if lrc ok */
   else
    {
     Remote_Keyhit[1] = 0x80;      
     Remote_Keyhit[0] = 0x00;
    } /* end if check sum didn't compute */
  } /* end if everything passes muster */
 else
  {
   Remote_Keyhit[1] = 0x80;      
   Remote_Keyhit[0] = 0x00;
  } /* there must have been problems */
} /* end update_remote_keypad */

/****************************************************************************/
/* SERIAL_IO - This interrupt routine is called whenever a serial           */
/*             interrupt occurs.  It handles sending and rcving packets.    */
/*             It will initiate a checksum error packet in reply to a       */
/*             garbled packet.  It will also initiate an ACK packet in      */
/*             response to reception of certain commands.                   */
/* Returns:    none/ interrupt routine                                      */
/* Arguments:  none/ interrupt routine                                  	*/
/* Calls:                                                               	*/
/* Limitations:                                                         	*/
/* Gary Sutcliffe                                                       	*/
/* Date: 12 FEB 95                                                      	*/
/* Revisions:                                                           	*/
/****************************************************************************/
void serial_io () interrupt 4 using 1
{
 unsigned char i;
 if(RI == 1)  /* we just received another byte */
  {
   RI=0;                             /* clear receive interrupt flag */
   Comm_Buffer[Buffer_Index] = SBUF; /* store byte received */
   if (Comm_Buffer[Buffer_Index] == COLON)
    {
     Comm_Buffer[0] = COLON;
     Buffer_Index = 0;
    }
   if (Comm_Buffer[Buffer_Index] == LF)
    Message_Received = 1;
   else
    {
     Buffer_Index++;
     if (Buffer_Index > 24)
      Buffer_Index = 24;
    }
  } /* end of serial receive handler */

 if(TI == 1)
  {
   TI = 0;                              /* enable transmit interrupt */
   if (Buffer_Index == 0)
    {                                                   // 3/6/98 JMP
     for (i = 0; i<25; i++)             // fill buffer with zeros and stall
     {Comm_Buffer[i] = 0;}              // to make sure done transmitting
                                                        
     REN = 1;                           /* done sending, enable reception */
     RI = 0;                            /* enable receive interrupt */      
     De = RECEIVE_ENABLE;               /* tell RS485 chip to receive */
    }
   else         /* not done sending */
    {
     SBUF = Comm_Buffer[Buffer_Index];  
     if (Comm_Buffer[Buffer_Index] == LF)
      Buffer_Index = 0;                 /* LF indicates end of transmission */
     else
      Buffer_Index++;
    }
  } /* end of serial transmit handler */
}  /*end of serial_io() */

/****************************************************************************/
/*	TITLE::	ENCODER                                                     	*/
/*	DESCRIPTION::	This function is controlled by external interrupt 0.	*/
/*	TYPE::			interrupt                                          		*/
/*	ARGUMENTS::		none         				   	   						*/
/*	RETURNS::		none                                               		*/
/* 	CALLS::			none     				   	   							*/	
/*  AUTHOR::    	Janet Peterson                                     		*/
/*  DATE::      	June 15, 2001                                  			*/
/*	REVISION::							   									*/
/****************************************************************************/
void encoder () interrupt 0 using 3
{
Tics++;
}


