var searchData=
[
  ['payload',['PAYLOAD',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a14aa1c5c4852ea2d61eef4d73772ea65',1,'SampleLabelEmbedder.cpp']]],
  ['payload_5falias',['PAYLOAD_ALIAS',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a6efaaea40a9e42c54e598116e9bc3983',1,'SampleLabelEmbedder.cpp']]],
  ['payload_5ftype',['PAYLOAD_TYPE',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a2e14a9f2e83ca4bc5abbd14c4a85bd7b',1,'SampleLabelEmbedder.cpp']]],
  ['price',['PRICE',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39ae41f8c159d4b4a027f86f32d112a94bd',1,'SampleLabelEmbedder.cpp']]]
];
