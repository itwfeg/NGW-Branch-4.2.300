var searchData=
[
  ['pageorder_2edox',['PageOrder.dox',['../PageOrder_8dox.html',1,'']]],
  ['payload',['PAYLOAD',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a14aa1c5c4852ea2d61eef4d73772ea65',1,'SampleLabelEmbedder.cpp']]],
  ['payload_5falias',['PAYLOAD_ALIAS',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a6efaaea40a9e42c54e598116e9bc3983',1,'SampleLabelEmbedder.cpp']]],
  ['payload_5ftype',['PAYLOAD_TYPE',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a2e14a9f2e83ca4bc5abbd14c4a85bd7b',1,'SampleLabelEmbedder.cpp']]],
  ['payloadhelper_2eh',['PayloadHelper.h',['../PayloadHelper_8h.html',1,'']]],
  ['pdata',['pData',['../structDSM__DATADESC.html#affa0ff006e438920f7c9b4a9c30648b4',1,'DSM_DATADESC']]],
  ['pimagedesc',['pImageDesc',['../structDSM__GENERATOR__OPTIONS.html#a05433900f51c5fc0ad3554ef642f2bb9',1,'DSM_GENERATOR_OPTIONS']]],
  ['pkeepoutregionarray',['pKeepOutRegionArray',['../structDSM__EMBEDDER__OPTIONS.html#ad0ccbfeed42f8d6e691696e2f993d0d1',1,'DSM_EMBEDDER_OPTIONS']]],
  ['ppayload',['pPayload',['../structDSM__GENERATOR__OPTIONS.html#a22879fb67019ad6db329a1a2ecc9bd20',1,'DSM_GENERATOR_OPTIONS::pPayload()'],['../structDSM__EMBEDDER__OPTIONS.html#a4f1632fdc79b19a5c65f608e6da9388e',1,'DSM_EMBEDDER_OPTIONS::pPayload()']]],
  ['price',['PRICE',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39ae41f8c159d4b4a027f86f32d112a94bd',1,'SampleLabelEmbedder.cpp']]]
];
