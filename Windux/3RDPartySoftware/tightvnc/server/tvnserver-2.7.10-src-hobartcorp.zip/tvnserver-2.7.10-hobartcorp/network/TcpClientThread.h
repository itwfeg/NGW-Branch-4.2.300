// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _TCP_CLIENT_THREAD_H_
#define _TCP_CLIENT_THREAD_H_

#include "thread/Thread.h"

#include "socket/SocketIPv4.h"

/**
 * Thread owning incoming tcp connection.
 *
 * Solves problem with code duplicates (see destructor and onTerminate() method)
 * and some memory leaks.
 *
 * @remark it can be used as superclass in
 * HttpClientThread, RfbClientThread, ControlClientThread classes for example).
 */
class TcpClientThread : public Thread
{
public:
  /**
   * Creates new tcp client thread.
   * @param socket incoming connection socket.
   */
  TcpClientThread(SocketIPv4 *socket);
  /**
   * Deletes socket that was passed to constructor (see above).
   */
  virtual ~TcpClientThread();

protected:
  /**
   * Inherited from Thread class.
   * Shutdowns and closes socket.
   */
  virtual void onTerminate();

protected:
  /**
   * Socket for owning.
   */
  SocketIPv4 *m_socket;
};

#endif
