// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _HTTP_CLIENT_H_
#define _HTTP_CLIENT_H_

#include "network/TcpClientThread.h"

#include "network/socket/SocketIPv4.h"

#include "io-lib/Channel.h"
#include "io-lib/DataInputStream.h"
#include "io-lib/DataOutputStream.h"
#include "log-writer/LogWriter.h"

class HttpClient : public TcpClientThread
{
public:
  HttpClient(SocketIPv4 *socket, LogWriter *log);
  virtual ~HttpClient();

protected:
  virtual void execute();

protected:
  Channel *m_stream;
  // Wrappers around socket stream.
  DataInputStream *m_dIS;
  DataOutputStream *m_dOS;

  LogWriter *m_log;
};

#endif
