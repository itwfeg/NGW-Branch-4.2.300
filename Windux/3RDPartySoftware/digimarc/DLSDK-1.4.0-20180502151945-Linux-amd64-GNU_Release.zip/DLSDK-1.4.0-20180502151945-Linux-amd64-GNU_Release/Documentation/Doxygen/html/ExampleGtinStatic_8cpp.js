var ExampleGtinStatic_8cpp =
[
    [ "main", "ExampleGtinStatic_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "MyWriteImageToPGMFile", "ExampleGtinStatic_8cpp.html#ad5029e04a563b879a1f3ddee01d23b80", null ]
];