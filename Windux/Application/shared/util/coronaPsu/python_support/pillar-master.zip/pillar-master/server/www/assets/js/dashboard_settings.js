/**
 * Created by collin on 11/12/17.
 */
/* Make a request for the basic data from the machine. */
$.get('info', function (data) {
    console.log(data);
    var metadata = JSON.parse(data);
    console.log('Name is ' + metadata.name);
    $('#device-name-label').text(metadata.name);
    $('#device-type-label').text(metadata.type);
    $('#opc-endpoint-label').text(metadata.opc_endpoint);
    // if(metadata.enableOPC) {
    //     $('#opcEnable-checkbox')[0].checked = "checked";
    // }
    // else {
    //     $('#opcEnable-checkbox')[0].checked = "";
    // }
});

// window.onload = function() {
//
//     $('#opcEnable-checkbox').on('change', function(){
//         alert('opcEnable-Checkbox changed!');
//     });
// };