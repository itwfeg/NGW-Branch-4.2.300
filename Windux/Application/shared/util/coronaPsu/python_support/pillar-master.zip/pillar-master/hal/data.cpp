//
// Created by collin on 11/2/17.
//

#include <cstdlib>
#include <cstring>
#include "data.h"
#include "cJSON.h"


Datapoint::Datapoint(double voltage,
                     double frequency,
                     double power,
                     double current,
                     int faults) : voltage(voltage), frequency(frequency), power(power), current(current),
                                   faults(faults)
{

}

Datapoint::Datapoint(const Datapoint &datapoint) : voltage(datapoint.voltage), frequency(datapoint.frequency),
                                                   power(datapoint.power), current(datapoint.current),
                                                   faults(datapoint.faults)
{
}

Datapoint::Datapoint(const std::vector<Datapoint> datapoints):voltage(0), frequency(0),
                                                              power(0), current(0),
                                                              faults(0)
{
    /* Average all of the items in the datapoint vector. */
    for(auto& datapoint : datapoints)
    {
        voltage += datapoint.voltage;
        current += datapoint.current;
        frequency += datapoint.frequency;
        power += datapoint.power;
        faults |= datapoint.faults;//combine all of the faults & flags.
    }

    /* Average all of the readings provided. */
    voltage /= datapoints.size();
    current /= datapoints.size();
    frequency /= datapoints.size();
    power /= datapoints.size();
}

Datapoint::~Datapoint()
{
}

void Datapoint::serialize(cJSON** serialized)
{
    *serialized = cJSON_CreateObject();

    cJSON_AddNumberToObject(*serialized, "voltage", this->voltage);
    cJSON_AddNumberToObject(*serialized, "current", this->current);
    cJSON_AddNumberToObject(*serialized, "frequency", this->frequency);
    cJSON_AddNumberToObject(*serialized, "power", this->power);
    cJSON_AddBoolToObject(*serialized, "highTempFault", this->isHighTempFault());
    cJSON_AddBoolToObject(*serialized, "interlockFault", this->isInterlockFault());
    cJSON_AddBoolToObject(*serialized, "DCBusFault", this->isDCBusFault());
    cJSON_AddBoolToObject(*serialized, "overvoltFault", this->isOverVoltFault());
    cJSON_AddBoolToObject(*serialized, "currentFault", this->isCurrentFault());
    cJSON_AddBoolToObject(*serialized, "inverterOn", this->isInverterOn());
}

int Datapoint::serialize_binary(void* output)
{
    /* Write the data into the output. */
    datapoint_bin_serial* serialized = (datapoint_bin_serial*)output;

    serialized->voltage = this->voltage;
    serialized->current = this->current;
    serialized->frequency = this->frequency;
    serialized->power = this->power;
    serialized->fault = this->faults;

    return sizeof(datapoint_bin_serial);
}

int Datapoint::deserialize_binary(const void *serialized)
{
    datapoint_bin_serial deserial;
    memcpy(&deserial, (const datapoint_bin_serial*)serialized, sizeof(datapoint_bin_serial));

    this->voltage = deserial.voltage;
    this->current = deserial.current;
    this->frequency = deserial.frequency;
    this->power = deserial.power;
    this->faults = deserial.fault;

    return sizeof(datapoint_bin_serial);
}


