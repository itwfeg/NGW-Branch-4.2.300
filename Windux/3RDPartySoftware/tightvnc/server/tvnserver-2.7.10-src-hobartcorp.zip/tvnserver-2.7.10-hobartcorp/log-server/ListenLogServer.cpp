// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "ListenLogServer.h"

ListenLogServer::ListenLogServer(const TCHAR *publicPipeName,
                                 ConnectionListener *connListener)
: m_connListener(connListener)
{
  m_pipeSecurity.shareToAllUsers();
  m_listenPipe = new PipeServer(publicPipeName);
  resume();
}

ListenLogServer::~ListenLogServer()
{
  terminate();
  m_timer.notify();
  m_listenPipe->close();
  wait();
  delete m_listenPipe;
}

void ListenLogServer::execute()
{
  while (!isTerminating()) {
    try {
      NamedPipe *pipe = m_listenPipe->accept();
      m_connListener->onNewConnection(pipe);
    } catch (...) {
      if (!isTerminating()) {
        m_timer.waitForEvent(1000); // Pause
      }
    }
  }
}
