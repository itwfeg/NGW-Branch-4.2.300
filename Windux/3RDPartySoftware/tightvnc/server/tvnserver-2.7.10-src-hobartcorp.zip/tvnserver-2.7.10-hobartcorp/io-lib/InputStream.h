// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _INPUT_STREAM_H_
#define _INPUT_STREAM_H_

#include "IOException.h"

/**
 * Input stream interface (abstract class).
 */
class InputStream
{
public:
  virtual ~InputStream();

  /**
   * Read some bytes from stream.
   * @param buffer [out] target buffer to receive data.
   * @param len bytes to read.
   * @return count of bytes read.
   * @throws any exception on fail(type of exception depends on
   * implementation of input stream).
   */
  virtual size_t read(void *buffer, size_t len) = 0;
};

#endif
