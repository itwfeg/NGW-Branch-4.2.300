
function dw_action_register()
	local reg = {}
	reg.Key="SAMPLELUAACTION"
	reg.Name="Sample Lua Action"
	reg.Group="Lua Scripting"
	return reg
end

function dw_action_query_metadata()
	local mdata = {}
	local input = nil
	local output = nil
	
	mdata.Inputs = {}
	mdata.Outputs = {}
	
	input = {}
	input.Name="In1"
	input.Type="INT4"
	input.Count=1
	mdata.Inputs[1]=input
	
	input = {}
	input.Name="In2"
	input.Type="STRING"
	input.Count=1
	input.Length=32
	mdata.Inputs[2]=input
	
	output = {}
	output.Name="Out1"
	output.Type="INT2"
	output.Count=1
	mdata.Outputs[1]=output
	
	return mdata
end

function dw_action_notify()
	dw.log.debug("INFO","[In1]: "..DWInput.In1)
	dw.log.debug("INFO","[In2]: "..DWInput.In2)
	DWOutput.Out1=DWInput.In1
	return 0
end
