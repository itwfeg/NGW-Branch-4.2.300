const fs = require('fs');

var unix = require('unix-dgram');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var http = require('http').Server(app);
// var io = require('socket.io')(http);

/* Process arguments. */
var socket_path = 'iot_hal.unix';
var socket_in_path = 'iot_hal_in.unix';
var machine_config = 'config.json';
var port = 8080;

for (var k = 0; k < process.argv.length; k++) {

    var val = process.argv[k];

    if (val.indexOf('--socket:') >= 0) {
        var tokens = val.split('--socket:');
        socket_path = tokens[tokens.length - 1];
        console.log('[OPTION ENABLED]: Selected ' + socket_path + ' as the IPC socket.');
    }

    if (val.indexOf('--socketin:') >= 0) {
        var tokens = val.split('--socketin:');
        socket_in_path = tokens[tokens.length - 1];
        console.log('[OPTION ENABLED]: Selected ' + socket_in_path + ' as the IPC HAL incoming socket.');
    }

    if (val.indexOf('--config:') >= 0) {
        var tokens = val.split('--config:');
        machine_config = tokens[tokens.length - 1];
        console.log('[OPTION ENABLED]: Selected ' + machine_config + ' as the machine configuration.');
    }
}

var config_data = {};

/* Load the config data. */
var buf = fs.readFileSync(machine_config);
config_data = JSON.parse(buf.toString('ascii'));
console.log('Read config data:');
console.log(JSON.stringify(config_data));

var opc_server = require('./opcua.js');

/* Start the OPC server. */
var dataObject = {
    voltage: 0,
    current: 0,
    frequency: 0,
    power: 0,
    highTempFault: false,
    interlockFault: false,
    DCBusFault: false,
    overvoltFault: false,
    currentFault: false,
    inverterOn: false
};

var opc = opc_server(dataObject);
if(config_data.enableOPC){
    opc.start();
}

/* Start the client side IPC transmitter. */
var client = unix.createSocket('unix_dgram');

client.on('connect', function(){
    console.log('connected client unix socket.');

    /* Get basic data on standard interval. */
    setInterval(function(){
        console.log('Sending UNIX data...');
        var buffer = new Buffer('Test');
        client.send(buffer);
    }, 1000);
});

client.on('error', function(err){
    console.error(err);
});

console.log('starting client unix socket @ ' + socket_in_path);
client.connect(socket_in_path);


/** -------------- Host Web contents ----------------- */
app.use(express.static('www'));
app.use(bodyParser.urlencoded({ extended: false }));// parse application/x-www-form-urlencoded
app.use(bodyParser.json()); // parse application/json

http.listen(port, function () {
    console.log('Web Host Listening on port ' + port + '.');
});

app.get('/livedata', function(req, res){
    /* Return the current data in the response. */
    res.write(JSON.stringify(dataObject));
    res.end();
});

app.get('/info', function(req, res){

    var info = config_data;
    info.opc_endpoint = opc.endpoint;

   /* Get data about the machine type. */
    res.write(JSON.stringify(info));
    res.end();
});


/** -------------- Construct Unix Socket sink. ----------------- */
var server = unix.createSocket('unix_dgram', function (buf) {
    var command = JSON.parse(buf.toString('ascii'));

   // console.log(JSON.stringify(command));
    if(command) {
        if(command.cmd && (command.cmd === 'livedata')) {
            dataObject = command.data;
            opc.update(dataObject);
        }
    }
});

fs.access(socket_path, function (err) {
    if (!err) {
        fs.unlinkSync(socket_path);//delete the file before stumbling over it to create the new server file.
    }
    server.bind(socket_path);//create the new server.
});


/* Cleanup the unix server. */
function exitHandler(options, err) {

    if (options.cleanup) {
        server.close();
        fs.unlinkSync(socket_path);
    }
    if (err) console.log(err.stack);
    if (options.exit) process.exit();
}

//do something when app is closing
process.on('exit', exitHandler.bind(null, {cleanup: true}));

//catches ctrl+c event
process.on('SIGINT', exitHandler.bind(null, {exit: true}));

//catches uncaught exceptions
process.on('uncaughtException', exitHandler.bind(null, {exit: true}));