
namespace BnWasp
{
	/// <summary>
	/// Feedback type.
	/// </summary>
	public enum FeedbackEventType
	{
		/// <summary> Feedback should be shown to the user </summary>
		Usr,
		/// <summary> Feedback can optionally be shown to the user </summary>
		Inf,
		/// <summary> Error/exception message </summary>
		Err,
		/// <summary> Technical information </summary>
		Dbg,
		/// <summary> Data dump </summary>
		Dmp,
		/// <summary> Progress information </summary>
		Pgs,
	}
}
