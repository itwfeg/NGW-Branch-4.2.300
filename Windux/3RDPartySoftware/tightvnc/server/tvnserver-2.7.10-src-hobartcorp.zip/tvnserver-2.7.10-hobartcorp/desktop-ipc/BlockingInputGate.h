// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __BLOCKINGINPUTGATE_H__
#define __BLOCKINGINPUTGATE_H__

#include "io-lib/DataInputStream.h"
#include "thread/LocalMutex.h"

class BlockingInputGate : public LocalMutex, public DataInputStream
{
public:
  BlockingInputGate(InputStream *inputStream);
  virtual ~BlockingInputGate();
};

#endif // __BLOCKINGINPUTGATE_H__
