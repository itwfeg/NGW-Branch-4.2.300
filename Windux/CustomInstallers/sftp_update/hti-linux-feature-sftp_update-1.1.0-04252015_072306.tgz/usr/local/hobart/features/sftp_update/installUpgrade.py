# -*- coding: utf-8 -*-

import os
import re
import osUtils
import sys
import shellCommand
import tarfile
import glob
import shutil
import string
import sendDeviceEventMessage
import socket
import languageSettings
import select
import messageBox
import usbQuery
import configInfo
import stat
import license
import md5checksum
from sftpProtocol import SFTPClient
import fileSysStatistics
import installUtils
import installFilePatterns
import subprocess

MONOLITHIC_CORE_PREINSTALL_VERSION="06032015_114048"

#
def installFPC(upgradeFile):

    try:
        # copy file to download diredtory which will trigger chobart_d to install

        if os.name == 'posix':
            cmd = []
            cmd.append("/bin/tar")
            cmd.append("xvzf")
            cmd.append(upgradeFile)
            cmd.append("-C")
            cmd.append(os.path.join('/', 'lib', 'firmware', 'fpc'))
            exitCode, stdout,stderr = shellCommand.execute(cmd)

            cmd = []
            cmd.append("/bin/tar")
            cmd.append("xvzf")
            cmd.append(upgradeFile)
            cmd.append("-C")
            cmd.append(os.path.join('/', 'usr', 'local', 'hobart', 'download'))
            exitCode, stdout, stderr =shellCommand.execute(cmd)

            cmd = []
            cmd.append("bin/sync")
            shellCommand.execute(cmd)

        elif os.name == 'nt':
            tar = tarfile.open(upgradeFile, 'r')
            tar.extractall(os.path.join("c:\\","Program Files","hobart","download"))

        sendDeviceEventMessage.sendMessage(server='localhost', port=6000, message="RTDO" + chr(0x1F) + "TNCheckForDownload" + chr(0x1E))

        return exitCode

    except:
        return 1

def installLicense(licenseFile, language, serverHost=None, username=None, password=None, uploadFolder=None):

    # See if the USB drive mounted contains a feature license key and if so activate license
    try:
        serialNumber = None

        if serverHost == None:
            # get list of attached USB drives, only one USB thumb drive can be inserted in scale when installing licenses
            usbDevices = usbQuery.UsbDeviceQuery()
            devices = usbDevices.findDevicesInClass(usbDevices.DEVICE_TYPE_USB)
            for dev in devices:
                serialNumber = usbDevices.getSerialNumber(dev)
                # only compute serial number for first USB device found
                break

        else:

            ipAddressRegExp = re.compile("\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")

            # If serverHost is not an IP address get IP by hostName
            if ipAddressRegExp.match(serverHost):
                serialNumber = serverHost
            else:
                # get ip address of hostname
                serialNumber = socket.gethostbyname(serverHost)

        # do not compute mac address since this is a scale device
        macAddress = license.NULL_MAC_ADDRESS

        # if the USB thumb drive has a serial number
        if serialNumber != None:

            # get elements in license file
            status, individualName, companyName, companyAddress, productNames, licenseType, licenseActivationDate, licenseAllotment, licenseTimeout, licenseKey = license.getLicenseElements(licenseFile)

            # if read of license file and elements extracted ok
            if status == 'success':

                # if current license file being processed contains a scale product/feature
                if license.containsScaleProducts(productNames):

                    # for all products/features in license
                    for i in xrange(0, len(productNames)):

                        # get the type of feature and if a scale feature process it
                        if license.getFeatureType(productNames[i]) == 'scale':

                            # check if license file on thumb drive is valid, mac address of 0 is used for scale products
                            if license.validLicenseKey(licenseFile, productNames[i], license.NULL_MAC_ADDRESS, serialNumber):

                                # read the flash key buffer
                                xmlLicenseBuffer = license.readFlashKeyBuffer()

                                if xmlLicenseBuffer == None:
                                    xmlLicenseBuffer = license.xmlCreateInitialLicenseBuffer()

                                addLicense = False
                                needToReboot = False

                                # see if products in license are already licensed
                                for i in xrange(0, len(productNames)):
                                    if not license.isProductLicensed(xmlLicenseBuffer, productNames[i]):
                                        # did not find product name so add license
                                        addLicense = True
                                    if productNames[i] in license.HTS_DISABLED_PRODUCTS:
                                        needToReboot = True
                                    if 'SCALE_REMOTE_MONITOR' == productNames[i]:
                                        needToReboot = True

                                # at least one product not licensed in flash so need to add license
                                if addLicense:

                                    # update xml license buffer with new key
                                    xmlLicenseBuffer = license.xmlAddLicenseToBuffer(xmlLicenseBuffer, individualName, companyName, companyAddress, productNames, licenseType, licenseActivationDate, licenseAllotment, licenseTimeout, licenseKey)

                                    # set number of licenses to the integer equivalent
                                    numLicenses = int(licenseAllotment)

                                    # if the number of licenses > 0
                                    if numLicenses > 0:

                                        numLicenses = numLicenses - 1
                                        licenseAllotment = str(numLicenses)

                                        # write the flash key buffer
                                        status,  message = license.writeFlashKeyBuffer(xmlLicenseBuffer)

                                        if status == 'success':

                                            # rewrite the license file on the thumb drive or in local folder for transmission to server
                                            # so that one license is used
                                            status, reason, licenseData = license.createLicenseFile(licenseFile, individualName, companyName, companyAddress, productNames, licenseType, licenseActivationDate, licenseAllotment, licenseTimeout, None, None, licenseKey)

                                            if status == 'success':

                                                # if license is a server ip address liceense type
                                                if licenseType == 'SERVER_IP_ADDRESS':

                                                    # SFTP the license file back to server
                                                    SFTPClnt = SFTPClient(username=username, password=password, host=serverHost)
                                                    connectResult = SFTPClnt.connect()

                                                    # if connection via SFTP was not successful
                                                    if not connectResult == "success" and not connectResult == "alreadyConnected":
                                                        print 'Failed to connect to SFTPClient@%s with user:%s pass:%s' % (serverHost, username, password)
                                                        return 1
                                                    else:
                                                        # upload file and check status
                                                        if SFTPClnt.uploadFile(uploadFolder, licenseFile).split('|')[0] != 'success':
                                                            return 1

                                                        if language == 'spanish':
                                                            message = "Clave de licencia instalada."

                                                        elif language == 'french':
                                                            message = "La clé de licence installée."
                                                        else:
                                                            message = "License key installed."

                                                        if needToReboot:
                                                            os.system("/sbin/reboot")

                                                        exitCode,  mbId = messageBox.display(message, timer=5)
                                                        return 0

                                                else:
                                                    if language == 'spanish':
                                                        message = "Clave de licencia instalada."
                                                    elif language == 'french':
                                                        message = "La clé de licence installée."
                                                    else:
                                                        message = "License key installed."
                                                    exitCode,  mbId = messageBox.display(message, timer=5)

                                                    if needToReboot:
                                                        os.system("/sbin/reboot")

                                                    return 0

                                            else:
                                                if language == 'spanish':
                                                    message = "Un error al actualizar el archivo de licencia"
                                                elif language == 'french':
                                                    message = "Erreur mise à jour le fichier de licence."
                                                else:
                                                    message = "Error updating license file"
                                                exitCode,  mbId = messageBox.display(message, timer=5)
                                                return 1

                                        else:
                                            if language == 'spanish':
                                                message = "Error al escribir licencia para flash."
                                            elif language == 'french':
                                                message = "Erreur d'écriture licence à clignoter."
                                            else:
                                                message = "Error writing license to flash."
                                            exitCode,  mbId = messageBox.display(message, timer=5)
                                            return 1

                                    else:
                                        if language == 'spanish':
                                            message = "Adjudicación de licencias es 0, no se puede instalar la licencia."
                                        elif language == 'french':
                                            message = "Licence attribution est de 0, ne peut pas installer la licence."
                                        else:
                                            message = "Licenses allotment is 0, can not install license"

                                        exitCode,  mbId = messageBox.display(message, timer=5)
                                        return 1

                                    # license was added or no more licenses issue
                                    # so break out of processing products loop
                                    break

                            else:
                                if language == 'spanish':
                                    message = "Clave de licencia no es válida."
                                elif language == 'french':
                                    message = "La clé de licence n'est pas valide."
                                else:
                                    message = "License key is not valid."

                                exitCode,  mbId = messageBox.display(message, timer=5)
                                return 1
        return 0
    except Exception as err:
        return 1

def removeUpgradeSource(upgradeFilename):
    try:
        if os.path.exists(upgradeFilename):
            os.remove(upgradeFilename)
        md5Path = md5checksum.md5PathFromFilename(upgradeFilename)
        if os.path.exists(md5Path):
            os.remove(md5Path)
    except:
        pass

def displayNotEnoughSpaceMessage(language, whichPartition, availableSpace, neededSpace):
    if language == 'spanish':
        if whichPartition == 'recovery':
            message = "Partición de recuperación está lleno. La actualización ha sido abortada. Espacio disponible: "
        elif whichPartition == 'live':
            message = "Partición en vivo está lleno. La actualización ha sido abortada. Espacio disponible: "
        message += str( availableSpace )  + " Bytes \nCantidad necesaria: "
        message += str( neededSpace )  +  " Bytes"

    elif language == 'french':
        if whichPartition == 'recovery':
            message = "Partition de récupération est plein. La mise à niveau a été abandonnée. L'espace disponible: "
        elif whichPartition == 'live':
            message = "Partition Live est plein. La mise à niveau a été abandonnée. L'espace disponible: "
        message += str( availableSpace )  + " Octets \nQuantité nécessaire: "
        message += str( neededSpace ) +  " Octets"
    else:
        if whichPartition == 'recovery':
            message = "Recovery partition is full. The upgrade has been aborted. \nSpace available: "
        elif whichPartition == 'live':
            message = "Live partition is full. The upgrade has been aborted. \nSpace available: "
        message += str( availableSpace )  +   " Bytes \nAmount needed: "
        message += str( neededSpace ) + " Bytes"

    exitCode,  mbId = messageBox.display(message=message,timer=60)

def saveRestoreCronJobs(restoreScriptFile, restorePath):
    cmd = []
    cmd.append('schtasks')
    cmd.append('/Query')
    cmd.append('/FO')
    cmd.append('LIST')
    exitCode, stdout, stderror = shellCommand.execute(cmd=cmd)

    if exitCode == 0:
        tasks = re.split('\r\n', stdout)

        for i in xrange(0, len(tasks)):
            SPLIT_TASKNAME = 'TaskName:[ ]+'

            taskname = re.split(SPLIT_TASKNAME, tasks[i])

            if len(taskname) > 1:

                # TODO - need to make sure there are no '\' in name
                # TODO - need to check exitCode
                # Do not save off the standard Microsoft schedules
                if not re.search('Microsoft', taskname[1]):
                    # Note: We need to use Popen as shellCommand.Execute doubles up on any '\' in the text of the params
                    p = subprocess.Popen('schtasks /Query /TN \"' + taskname[1] + '\" /XML', stdout=subprocess.PIPE)
                    out = p.stdout.read()

                    try:
                        f = open(os.path.join(restorePath, taskname[1] + '.xml'), 'w')
                        f.write(out)
                        f.close()

                        restoreScriptFile.write('schtasks /Create /TN \"' + taskname[1] + '\" /XML \"' + os.path.join(restorePath, taskname[1] + '.xml\n'))
                    except:
                        pass

def installUpgrade(upgradeFilename, serverHost=None,  username=None,  password=None,  uploadFolder=None, removeUpgrade=False):
    sys.exit(installUpgradeNonTerminating(upgradeFilename,serverHost,username,password,uploadFolder,removeUpgrade))

def backupCriticalFiles(upgradeFilename, resources, restoreScript, scaleAppRestore, mbId,
                        language, db, dbBackupInPlace, live, liveHobart, isPatchUpgrade, removeUpgrade, dbRestore, coreTGZ,
                        removeResources=True):
    # remove anything in recovery resources directory
    if removeResources:
        if os.name == 'posix':
            os.system("/bin/rm -rf %s" % (os.path.join(resources, "*")))
        elif os.name == 'nt':
            filelist = os.listdir(resources)
            for f in filelist:
                try:
                    os.chmod(os.path.join(resources,f), stat.S_IWRITE)
                    os.remove(os.path.join(resources,f))
                except:
                    print 'error: Cannot remove file: ' + f

    try:
        # open a restore script file for stagingRecover.sh to call to restore after upgrade
        restoreScriptFile = open(restoreScript, 'w')
        if os.name == 'posix':
            restoreScriptFile.write('#!/bin/bash\n')
            restoreScriptFile.write('PATH=/usr/bin:/bin:/usr/sbin:/sbin\n')

    except IOError, exception_details:
        print 'error: Can not open file: ' + restoreScript + ', Reason:' + exception_details[1]
        return 1

    # if rootfs.tar.gz already in recovery area
    if os.path.exists(os.path.join(scaleAppRestore, coreTGZ)):
        try:
            # delete it
            os.chmod(os.path.join(scaleAppRestore, coreTGZ), stat.S_IWRITE)
            os.remove(os.path.join(scaleAppRestore, coreTGZ))
        except exception_details:
            print 'error: Cannot remove backup file, Reason: ' + exception_details[1]

    messageBox.destroy(mbId)

    if language == 'spanish':
        message = "Actualización de Aplicación y SO\n\nCopiando actualización desde dispositivo fuente\nPor favor espere…"
    elif language == 'french':
        message = "Mise à niveau de l\'application et du SE (Étape 1) \n\n Copie de la mise à niveau à partir du \ndispositif source Veuillez patienter…"
    else:
        message = "Application and OS Upgrade (Stage 1)\n\nCopying Upgrade from Source Device\nPlease wait..."

    exitCode,  mbId = messageBox.display(message)

    # copy the file via shell, shutil is VERY SLOW on large files and this is large
    if os.name == 'posix':
        os.system('/bin/cp -f %s %s' % (upgradeFilename, os.path.join(scaleAppRestore,"hte.tar.gz")))
    elif os.name == 'nt':
        if not os.path.exists(scaleAppRestore):
            os.mkdir(scaleAppRestore)
        shutil.copy(upgradeFilename, os.path.join(scaleAppRestore, coreTGZ))
        os.chmod(os.path.join(scaleAppRestore, coreTGZ), stat.S_IWRITE)

    # if we are told to remove the upgrade file source
    if removeUpgrade:
        # remove the file since we just got done copying it to the recovery partition and putting it into
        # the upgrade file
        removeUpgradeSource(upgradeFilename)

    messageBox.destroy(mbId)

    if language == 'spanish':
        message = "Actualización de Aplicación y SO (Etapa 1)\n\nRespaldando la Base de Datos y Configuración..."
    elif language == 'french':
        message = "Mise à niveau de l\'application et du SE (Étape 1)\n\nSauvegarde de la Base de Données et de Configuration..."
    else:
        message = "Application and OS Upgrade (Stage 1)\n\nBacking up Scale DB and Configuration..."

    exitCode,  mbId = messageBox.display(message)

    if os.name == 'posix':
        # backup the database, use wildcard for last character since db is evolving
        #matches = glob.glob(os.path.join(db,"scale","dbfiles","dbft?.db"))
        #if len(matches) > 0:
        #    shutil.copy(matches[0], dbRestore)
        #    restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(dbRestore,os.path.basename(matches[0])), os.path.join(db, "scale","dbfiles")))

        if os.path.exists(os.path.join(db,"settingswizard")):
            shutil.copytree(os.path.join(db, "settingswizard"), os.path.join(resources,"settingswizard"), symlinks=False, ignore=None)
            restoreScriptFile.write('/bin/cp -f --recursive %s %s\n' % (os.path.join(resources,"settingswizard"), db))

        if os.path.exists(os.path.join("/","var","spool", "cron","crontabs", "root")):
            # cronjob backup
            shutil.copy(os.path.join("/","var","spool", "cron","crontabs", "root"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources,"root"), os.path.join("/","var","spool", "cron","crontabs", "root")))

        # if DB backup implementation in place
        if dbBackupInPlace:

            # need to export sql db from old db to new format
            # send message to chobart_d to backup DB to HTDF
            sendDeviceEventMessage.sendMessage(server='localhost', port=6000, message="RTDO" + chr(0x1F) + "TNBackupEntireDB" + chr(0x1E))

            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

            server_address = ('localhost', 5079)
            server.bind(server_address)
            server.listen(5)

            inputs = [server]
            outputs = []

            # timeout waiting from message from chobart_d
            # after 20 minutes
            timeout = 20.0 * 60.0

            # wait for chobart_d to respond with message
            messageReceived = False

            while not messageReceived:

                readable, writable, exceptional = select.select(inputs, outputs, inputs, timeout)

                # check if timeout reached
                if readable == [] and writable == [] and exceptional == []:
                    # timeout reached so backup of db not possible
                    break
                else:
                    # received message from chobart_d
                    for s in readable:

                        # socket message coming in to process
                        if s is server:

                            # accept network connection
                            connection, client_address = s.accept()
                            data = connection.recv(1024)
                            connection.close()
                            messageReceived = True

                            if data == 'htdfBackupSuccess':

                                if os.path.exists(os.path.join("/","etc","hobart", "verIndData")):
                                    shutil.copy(os.path.join("/","etc","hobart", "verIndData"),
                                                    resources)
                                    restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "verIndData"), os.path.join(live,"etc", "hobart", "verIndData")))

                # close server
            server.close()

        if os.path.exists(os.path.join("/","etc","timezone")):
            # backup time data
            shutil.copy(os.path.join("/","etc","timezone"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "timezone"), os.path.join(live,"etc", "timezone")))

        if os.path.exists(os.path.join("/","root","ssactive.lock")):
            # self service mode
            shutil.copy(os.path.join("/","root","ssactive.lock"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "ssactive.lock"), os.path.join(live,"root", "ssactive.lock")))

        if os.path.exists(os.path.join("/","usr","local", "hobart", "info.log")):
            # health agent file
            shutil.copy(os.path.join("/","usr","local", "hobart", "info.log"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "info.log"), os.path.join(live,"usr", "local", "hobart", "info.log")))

        if os.path.exists(os.path.join("/","usr","local", "hobart", "python", "cronjobs")):
            # backup store logo
            shutil.copy(os.path.join("/","usr","local", "hobart", "python", "cronjobs"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "cronjobs"), os.path.join(live,"usr", "local", "hobart", "python", "cronjobs")))
            restoreScriptFile.write('/usr/bin/crontab %s\n' % (os.path.join(live,"usr", "local", "hobart", "python", "cronjobs")))

        if os.path.exists(os.path.join("/","usr","local", "hobart", "layouts", "storelogo.png")):
            # backup store logo
            shutil.copy(os.path.join("/","usr","local", "hobart", "layouts", "storelogo.png"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "storelogo.png"), os.path.join(live,"usr", "local", "hobart", "layouts", "storelogo.png")))

        if os.path.exists(os.path.join("/","usr","local", "hobart", "playlists", "playlist.txt")):
            # backup playlist.txt
            shutil.copy(os.path.join("/","usr","local", "hobart", "playlists", "playlist.txt"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "playlist.txt"), os.path.join(live,"usr", "local", "hobart", "playlists", "playlist.txt")))

        cmd = []
        cmd.append('/usr/bin/readlink')
        cmd.append('/etc/localtime')
        exitCode,stdout,stderr = shellCommand.execute(cmd)

        if exitCode == 0:
            # remove current /etc/localtime
            restoreScriptFile.write("/bin/rm -f %s\n" % (os.path.join(live,"etc","localtime")))
            # write link command to relink /etc/localtime to correct timezone
            restoreScriptFile.write('/bin/ln -s %s %s\n' % (os.path.join(live,string.strip(stdout)),os.path.join(live,"etc","localtime")))

        if os.path.exists(os.path.join("/","etc","hostname")):
            # backup hostname
            shutil.copy(os.path.join("/","etc","hostname"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "hostname"), os.path.join(live,"etc", "hostname")))

        if os.path.exists(os.path.join("/","etc","openssh","ssh_host_key")):
            # backup sshd keys
            shutil.copy(os.path.join("/","etc","openssh","ssh_host_dsa_key"),resources)
            shutil.copy(os.path.join("/","etc","openssh","ssh_host_dsa_key.pub"),resources)
            shutil.copy(os.path.join("/","etc","openssh","ssh_host_ecdsa_key"),resources)
            shutil.copy(os.path.join("/","etc","openssh","ssh_host_ecdsa_key.pub"),resources)
            shutil.copy(os.path.join("/","etc","openssh","ssh_host_key"),resources)
            shutil.copy(os.path.join("/","etc","openssh","ssh_host_key.pub"),resources)
            shutil.copy(os.path.join("/","etc","openssh","ssh_host_rsa_key"),resources)
            shutil.copy(os.path.join("/","etc","openssh","ssh_host_rsa_key.pub"),resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "ssh_host_dsa_key"), os.path.join(live,"etc", "openssh","ssh_host_dsa_key")))
            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "ssh_host_dsa_key.pub"), os.path.join(live,"etc", "openssh","ssh_host_dsa_key.pub")))
            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "ssh_host_ecdsa_key"), os.path.join(live,"etc", "openssh","ssh_host_ecdsa_key")))
            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "ssh_host_ecdsa_key.pub"), os.path.join(live,"etc", "openssh","ssh_host_ecdsa_key.pub")))
            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "ssh_host_key"), os.path.join(live,"etc", "openssh","ssh_host_key")))
            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "ssh_host_key.pub"), os.path.join(live,"etc", "openssh","ssh_host_key.pub")))
            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "ssh_host_rsa_key"), os.path.join(live,"etc", "openssh","ssh_host_rsa_key")))
            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "ssh_host_rsa_key.pub"), os.path.join(live,"etc", "openssh","ssh_host_rsa_key.pub")))

        if ((os.path.exists(os.path.join("/","etc","passwd"))) and (os.path.exists(os.path.join("/","etc","shadow")))):
            # backup passwords
            shutil.copy(os.path.join("/","etc","passwd"),resources)
            shutil.copy(os.path.join("/","etc","shadow"),resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "passwd"), os.path.join(live,"etc", "passwd")))
            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "shadow"), os.path.join(live,"etc", "shadow")))

        if (os.path.exists(os.path.join("/","usr","local", "hobart","hobart.key"))):
            # backup password of user hobart
            shutil.copy(os.path.join("/","usr","local", "hobart","hobart.key"),resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "hobart.key"), os.path.join(liveHobart,"hobart.key")))

        # copy language file if it exists
        if os.path.exists(os.path.join("/","usr","local", "hobart","lang")):
            # backup language file
            shutil.copy(os.path.join("/","usr","local", "hobart","lang"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "lang"), os.path.join(liveHobart,"lang")))

        # copy lang file to recovery partition
        shutil.copy(os.path.join("/","usr","local","hobart", "lang"),
                        os.path.join("/","media","mmcblk0p2","usr", "local","hobart","lang"))

        # copy /usr/bin/mb if not already installed on fielded scales
        if not os.path.exists(os.path.join("/","media","mmcblk0p2","usr","bin", "mb")):
            # backup hostname
            shutil.copy(os.path.join("/","usr","bin", "mb"),
                            os.path.join("/","media","mmcblk0p2","usr","bin", "mb"))

        # copy new /etc/init.d/hwclock if not already installed on fielded scales
        if os.path.exists(os.path.join("/","media","mmcblk0p2","etc","init.d")):
            # copy new hwclock script to recovery partition
            shutil.copy(os.path.join("/","etc","init.d", "hwclock"),
                            os.path.join("/","media","mmcblk0p2","etc","init.d", "hwclock"))

        # copy new /etc/init.d/rc if not already installed on fielded scales
        if os.path.exists(os.path.join("/","media","mmcblk0p2","etc","init.d")):
            # copy new rc script to recovery partition
            shutil.copy(os.path.join("/","etc","init.d", "rc"),
                            os.path.join("/","media","mmcblk0p2","etc","init.d", "rc"))

        if os.path.exists(os.path.join("/","etc","hobart", "configc.dat")):
            # backup configc.dat
            shutil.copy(os.path.join("/","etc","hobart", "configc.dat"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "configc.dat"), os.path.join(live,"etc", "hobart", "configc.dat")))

        # save network interfaces

        if os.path.isdir(os.path.join("/","etc","network")):
            # Save entire /etc/network directory
            shutil.copytree(os.path.join("/","etc","network"),os.path.join(resources,"network"), symlinks=False, ignore=None)
            restoreScriptFile.write('/bin/cp -f --recursive %s %s\n' % (os.path.join(resources, "network"), os.path.join(live, "etc")))


        if os.path.exists(os.path.join("/","etc","resolv.conf")):
            # save DNS network settings
            shutil.copy(os.path.join("/","etc","resolv.conf"),
                        resources)

        restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "resolv.conf"), os.path.join(live,"etc", "resolv.conf")))

        if os.path.exists(os.path.join("/","etc","eGtouch0.param")):
            # save display calibration data
            shutil.copy(os.path.join("/","etc","eGTouch0.param"),
                        resources)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "eGTouch0.param"), os.path.join(live,"etc", "eGTouch0.param")))

        # create upgrade boot file for startup sequence on subsequent reboot so scale settings before
        # upgrade are used versus setting default time based on scale epoch
        restoreScriptFile.write("/bin/touch %s\n" % (os.path.join(live,"etc","upgradeBoot")))

        # copy wireless settings if configured
        if os.path.exists(os.path.join("/","etc","wpa_supplicant.conf")):
            shutil.copy(os.path.join("/","etc","wpa_supplicant.conf"),
                        resources)
            restoreScriptFile.write('/bin/cp -f %s %s\n' % (os.path.join(resources, "wpa_supplicant.conf"), os.path.join(live,"etc", "wpa_supplicant.conf")))

        local_path = os.path.join("/", "usr", "local", "hobart", "features", "monolithic_core", "startupSequence.py")
        resources_path = os.path.join(resources, 'startupSequence.py')
        # if a monolithic_core startupSequence.py exists copy it to resources so it can be restored to live for subsequent upgrade
        if os.path.exists(local_path):
            if os.path.exists(resources_path):
                os.remove(os.path.join(resources_path))

            shutil.copy(local_path, resources_path)

            restoreScriptFile.write('/bin/cp -f %s %s\n' % (resources_path, os.path.join(live, 'usr', 'local', 'hobart', 'python', 'startupSequence.py')))

        # close restore script
        restoreScriptFile.close()

        # make script executable
        os.system("/bin/chmod ugo+rx %s" % (restoreScript))

    elif os.name == 'nt':
        # backup the database, use wildcard for last character since db is evolving
        matches = glob.glob(os.path.join(db,"scale","dbfiles","dbft?.db"))
        if len(matches) > 0:
            for par, dir, files in os.walk(dbRestore):
                for myfile in files:
                    os.chmod(os.path.join(par, myfile), stat.S_IWRITE)
            shutil.copy(matches[0], dbRestore)
            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(dbRestore,os.path.basename(matches[0])), os.path.join(db, "scale","dbfiles")))

        if os.path.exists(os.path.join(db,"settingswizard","scalesettings")):
            # backup scale settings
            shutil.copyfile(os.path.join(db,"settingswizard","scalesettings"),
                        os.path.join(resources,"scalesettings"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources,"scalesettings"), os.path.join(db,"settingswizard","scalesettings")))

        # Save/restore Network Settings

        if os.path.exists(os.path.join(db,"settingswizard","networkSettings.cfg")):
            # backup scale settings
            shutil.copyfile(os.path.join(db,"settingswizard","networkSettings.cfg"),
                        os.path.join(resources,"networkSettings.cfg"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources,"networkSettings.cfg"), os.path.join(db,"settingswizard","networkSettings.cfg")))

        if os.path.exists(os.path.join(db,"settingswizard","EAPUserName.xml")):
            # backup network settings
            shutil.copyfile(os.path.join(db,"settingswizard","EAPUserName.xml"),
                        os.path.join(resources,"EAPUserName.xml"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources,"EAPUserName.xml"), os.path.join(db,"settingswizard","EAPUserName.xml")))

        if os.path.exists(os.path.join(db,"settingswizard","WirelessProfile.xml")):
            # backup network settings
            shutil.copyfile(os.path.join(db,"settingswizard","WirelessProfile.xml"),
                        os.path.join(resources,"WirelessProfile.xml"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources,"WirelessProfile.xml"), os.path.join(db,"settingswizard","WirelessProfile.xml")))

        # Get timezone and save to restoreScriptFile
        cmd = []
        cmd.append("tzutil")
        cmd.append("/g")

        exitCode, stdout, stderr = shellCommand.execute(cmd)

        if (exitCode == 0):
            restoreScriptFile.write('tzutil /s \"%s\"\n' % stdout)

        infologpath = os.path.join(configInfo.getRootFolder(), "log")
        if os.path.exists(os.path.join(infologpath, "info.log")):
            # health agent file
            shutil.copyfile(os.path.join(infologpath, "info.log"),
                        os.path.join(resources,"info.log"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources, "info.log"), os.path.join(infologpath, "info.log")))

        saveRestoreCronJobs(restoreScriptFile, resources)

        if os.path.exists(os.path.join(configInfo.getRootFolder(), "layouts", "storelogo.png")):
            # backup store logo
            shutil.copyfile(os.path.join(configInfo.getRootFolder(), "layouts", "storelogo.png"),
                        os.path.join(resources,"storelogo.png"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources, "storelogo.png"), os.path.join(configInfo.getRootFolder(), "layouts", "storelogo.png")))

        if os.path.exists(os.path.join(configInfo.getRootFolder(), "playlists", "playlist.txt")):
            # backup playlist.txt
            shutil.copyfile(os.path.join(configInfo.getRootFolder(), "playlists", "playlist.txt"),
                        os.path.join(resources,"playlist.txt"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources, "playlist.txt"), os.path.join(configInfo.getRootFolder(), "playlists", "playlist.txt")))

        import getHostname
        exitCode, hostname = getHostname.getHostname()
        restoreScriptFile.write('c:\\Python27\python \"%s\" %s\n' % (os.path.join(configInfo.getRootFolder(), 'python', "setHostname.py"), hostname))

        if os.path.exists(os.path.join(configInfo.getRootFolder(),"hobsshd.rsa")):
            # backup sshd keys
            shutil.copyfile(os.path.join(configInfo.getRootFolder(),"hobsshd.rsa"),os.path.join(resources, "hobsshd.rsa"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources, "hobsshd.rsa"), os.path.join(configInfo.getRootFolder())))

        # copy language file if it exists
        if os.path.exists(os.path.join(configInfo.getRootFolder(),"lang")):
            # backup language file
            shutil.copyfile(os.path.join(configInfo.getRootFolder(),"lang"),
                        os.path.join(resources, "lang"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources, "lang"), os.path.join(configInfo.getRootFolder(),"lang")))

        if os.path.exists(os.path.join(configInfo.getRootFolder(), "configc.dat")):
            # backup configc.dat
            shutil.copyfile(os.path.join(configInfo.getRootFolder(), "configc.dat"),
                        os.path.join(resources, "configc.dat"))

            restoreScriptFile.write('xcopy /y /r \"%s\" \"%s\"\n' % (os.path.join(resources, "configc.dat"), os.path.join(configInfo.getRootFolder(), "configc.dat")))

        # TODO - Verify with BCD this is where the calibration info is saved
        cmd = []
        cmd.append("reg")
        cmd.append("query")
        cmd.append("HKLM\\System\\CurrentControlSet\\services\\xtouch\\DeviceDefault")
        cmd.append("/v")
        cmd.append("CalInfo")

        exitCode, stdout, stderr = shellCommand.execute(cmd)

        # Extract the binary data from the output for reg query
        if exitCode == 0:
            tokens = stdout.split('REG_BINARY')
            if len(tokens) > 1:
                strBinaryData = tokens[1]
                strBinaryData = strBinaryData.strip()

                restoreScriptFile.write('reg add HKLM\\System\\CurrentControlSet\\services\\xtouch\\DeviceDefault /v CalInfo /f /t REG_BINARY /d %s\n' % strBinaryData)

        # create upgrade boot file for startup sequence on subsequent reboot so scale settings before
        # upgrade are used versus setting default time based on scale epoch
        restoreScriptFile.write('echo \"Upgrade\" > c:\\upgradeBoot')
        restoreScriptFile.write('del firstBoot')

        # restoreScriptFile.write("/bin/touch %s\n" % (os.path.join(live,"etc","upgradeBoot")))

        # close restore script
        restoreScriptFile.close()

    messageBox.destroy(mbId)

    if language == 'spanish':
        message = "Actualización de Aplicación y SO (Etapa 1)\n\nInicializando Etapa 2..."
    elif language == 'french':
        message = "Mise à niveau de l\'application et du SE (Étape 1)\n\nInitialisation Étape 2..."
    else:
        message = "Application and OS Upgrade (Stage 1)\n\nInitiating Stage 2..."

    exitCode,  mbId = messageBox.display(message)

    if os.name == 'posix':
        os.system("/bin/sync")

    return exitCode

def enoughFreeSpaceToInstall(upgradeSize, partition):

    # get free space on partition
    partitionAvailableSpace = fileSysStatistics.availableSpace(partition)

    if upgradeSize >= partitionAvailableSpace:
        return (False, partitionAvailableSpace)
    else:
        return (True, partitionAvailableSpace)

def installUpgradeNonTerminating(upgradeFilename, serverHost=None,  username=None,  password=None,  uploadFolder=None, removeUpgrade=False):

    if os.name == 'posix':
        dbBackupInPlace = True
    elif os.name == 'nt':
        dbBackupInPlace = False

    # if specified upgrade filename exists
    if os.path.exists(upgradeFilename):

        # get current scale language
        language = languageSettings.currentLanguage()

        if os.name == 'posix':
            regexPattern = '^.*/%s$'
        elif os.name == 'nt':
            regexPattern = '^.*\\%s$'

        CORE_UPGRADE_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.CORE_UPGRADE_FILENAME_REGEX))
        BOOTLOADER_UPGRADE_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.BOOTLOADER_UPGRADE_FILENAME_REGEX))
        RECOVERY_UPGRADE_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.RECOVERY_UPGRADE_FILENAME_REGEX))
        LANGUAGE_UPGRADE_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.LANGUAGE_UPGRADE_FILENAME_REGEX))
        FPC_UPGRADE_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.FPC_UPGRADE_FILENAME_REGEX))
        FEATURE_UPGRADE_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.FEATURE_UPGRADE_FILENAME_REGEX))
        LICENSE_INSTALL_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.LICENSE_INSTALL_FILENAME_REGEX))

        PATCH_UPGRADE_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.PATCH_UPGRADE_FILENAME_REGEX))
        BACKEND_UPGRADE_FILENAME_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.BACKEND_UPGRADE_FILENAME_REGEX))
        BACKEND_UPGRADE_NEW_FILENAME_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.BACKEND_UPGRADE_NEW_FILENAME_REGEX))

        CORE_UPGRADE_OLD_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.CORE_UPGRADE_OLD_FILENAME_REGEX))
        BOOTLOADER_UPGRADE_OLD_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.BOOTLOADER_UPGRADE_OLD_FILENAME_REGEX))
        RECOVERY_UPGRADE_OLD_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.RECOVERY_UPGRADE_OLD_FILENAME_REGEX))
        LANGUAGE_UPGRADE_OLD_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.LANGUAGE_UPGRADE_OLD_FILENAME_REGEX))
        FPC_UPGRADE_OLD_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.FPC_UPGRADE_OLD_FILENAME_REGEX))
        FEATURE_UPGRADE_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.FEATURE_UPGRADE_FILENAME_REGEX))
        FEATURE_UPGRADE_OLD_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.FEATURE_UPGRADE_OLD_FILENAME_REGEX))
        FEATURE_UPGRADE_OSAGNOSTIC_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.FEATURE_UPGRADE_OSAGNOSTIC_FILENAME_REGEX))
        MONOLITHIC_UPGRADE_REGEX_COMPILED = re.compile(regexPattern % (installFilePatterns.MONOLITHIC_UPGRADE_FILENAME_REGEX))

        if os.name == 'posix':
            recoveryPartition = os.path.join("/","media","mmcblk0p2")
            recovery = os.path.join(recoveryPartition,"usr","local","hobart")
            resources = os.path.join(recovery,"resources")
            restoreScript = os.path.join(resources,"restore.sh")
            scaleAppRestore = os.path.join(recovery,"scaleApp")
            coreTGZ = "hte.tar.gz"

            live = os.path.join("/","media","mmcblk0p1")
            liveHobart = os.path.join(live,"usr","local","hobart")
            db = os.path.join(liveHobart, "db")
            dbRestore = os.path.join(recovery,"db")
        elif os.name == 'nt':
            recoveryPartition = os.path.join("R:\\")
            recovery = os.path.join(recoveryPartition,"Program Files","hobart")
            resources = os.path.join(recovery,"resources")
            restoreScript = os.path.join(resources,"restore.cmd")
            scaleAppRestore = os.path.join(recovery,"scaleApp")
            coreTGZ = "hte.tgz"

            live = os.path.join("c:\\")
            liveHobart = os.path.join(live,"Program Files","hobart")
            db = os.path.join(liveHobart, "db")
            dbRestore = os.path.join(recovery,"db")

            # Create key directories in recovery partition, if they do not already exist
            if not os.path.exists(recovery):
                os.makedirs(recovery)

            if not os.path.exists(resources):
                os.makedirs(resources)

            if not os.path.exists(dbRestore):
                os.makedirs(dbRestore)

            if not os.path.exists(os.path.join(recovery,'bios')):
                os.makedirs(os.path.join(recovery,'bios'))

        # check filename to see if we need to check checksum of file
        fileComponents = os.path.splitext(os.path.basename(upgradeFilename))

        # make sure there is a basename and extension in filename
        if len(fileComponents) == 2:

            # if a license file is not being installed must check md5 of file
            if fileComponents[1] != '.lic':

                if not md5checksum.md5FilenameFromInstallerFilenameExists(upgradeFilename):
                    if language == 'spanish':
                        message = "Archivo MD5 Checksum para la actualización de firmware no se encuentra, la instalación abortada."
                    elif language == 'french':
                        message = "Fichier MD5 checksum pour la mise à jour du firmware n'est pas trouvé, l'installation abandonnée."
                    else:
                        message = "MD5 Checksum file for firmware update not found, installation aborted."

                    exitCode,  mbId = messageBox.display(message=message,timer=5)

                    if removeUpgrade:
                        removeUpgradeSource(upgradeFilename)

                    return

                if language == 'spanish':
                    message = "Comprobación de integridad del archivo de actualización ..."
                elif language == 'french':
                    message = "Vérification de l'intégrité du fichier de mise à jour ..."
                else:
                    message = "Checking integrity of upgrade file..."

                exitCode,  mbId1 = messageBox.display(message=message)

                if not md5checksum.md5ValidBasedOnChecksumFile(upgradeFilename):

                    messageBox.destroy(mbId1)

                    if language == 'spanish':
                        message = "Archivo de actualización de firmware está dañado, la instalación no coincide la suma de comprobación abortado."
                    elif language == 'french':
                        message = "Fichier de mise à jour du micrologiciel est corrompu, l'installation contrôle d'incompatibilité annulée."
                    else:
                        message = "Firmware update file is corrupt, checksum mismatch installation aborted."

                    exitCode,  mbId = messageBox.display(message=message, timer=5)

                    if removeUpgrade:
                        removeUpgradeSource(upgradeFilename)

                    return

                messageBox.destroy(mbId1)

        else:
            if language == 'spanish':
                message = "Nombre del archivo de firmware no tiene extensión, instalación abortada."
            elif language == 'french':
                message = "Firmware nom de fichier n'a pas d'extension, l'installation avortée."
            else:
                message = "Firmware filename has no extension, installation aborted."
            exitCode,  mbId = messageBox.display(message=message, timer=5)

            if removeUpgrade:
                removeUpgradeSource(upgradeFilename)
            return

        # if upgrade file is core a complete scale app/OS upgrade then
        if CORE_UPGRADE_REGEX_COMPILED.match(upgradeFilename) or CORE_UPGRADE_OLD_REGEX_COMPILED.match(upgradeFilename) or PATCH_UPGRADE_REGEX_COMPILED.match(upgradeFilename):

            isPatchUpgrade = False

            if PATCH_UPGRADE_REGEX_COMPILED.match(upgradeFilename):
                isPatchUpgrade = True

            # get size of resources directory we are about to remove
            resourcesDirSize = fileSysStatistics.directorySize(resources)

            # get size of last upgrade recovery tarball in recovery partition that we are about to remove
            recoveryTarballSize = fileSysStatistics.fileSize(os.path.join(scaleAppRestore, coreTGZ))

            # get size of tarball we are about to extract and install
            upgradeFileSize = fileSysStatistics.fileSize(upgradeFilename)

            # get free space on recovery partition
            recoveryPartitionAvailableSpace = fileSysStatistics.availableSpace(recoveryPartition)

            # get the used space on the recovery partition
            recoveryPartitionUsedSpace = fileSysStatistics.usedSpace(recoveryPartition)

            # get the live /usr/local/hobart directory size since it is not removed when this upgrade occurs
            # which means that when the upgrade is extracted the contents of this directory is retained
            # with potentially overwrites of files based on what is in tarball for application/OS upgrade
            liveHobartDirSize = fileSysStatistics.directorySize(liveHobart)

            # get the live partition size
            livePartitionTotalSize = fileSysStatistics.totalSize(live)

            # TODO:
            # I am estimating that the worst case HTDF file backup of a DB is 50 MB
            # is that enough?
            # db backup HTDF file worst case size 50 MB
            dbBackupHtdfWorstCaseFileSize = 50 * 1024 * 1024

            print 'bytes needed: ' + str(upgradeFileSize + dbBackupHtdfWorstCaseFileSize )
            print 'bytes available: ' + str(recoveryPartitionAvailableSpace + resourcesDirSize + recoveryTarballSize)

            # TODO:
            # Assume worst case tar ball extract size is 2 times the tarball size compressed
            # May not be the greatest assumption
            # check if recovery partition has enough free space
            enoughSpace, partitionFreeSpace = enoughFreeSpaceToInstall(upgradeFileSize + dbBackupHtdfWorstCaseFileSize, recoveryPartition)

            if not enoughSpace:
                displayNotEnoughSpaceMessage(language=language,
                                             whichPartition='recovery',
                                             availableSpace=partitionFreeSpace + resourcesDirSize + recoveryTarballSize,
                                             neededSpace=upgradeFileSize + dbBackupHtdfWorstCaseFileSize)
                return 1

            print 'partition needed: ' + str((upgradeFileSize * 2) + liveHobartDirSize + dbBackupHtdfWorstCaseFileSize)
            print 'partition available: ' + str(livePartitionTotalSize)

            enoughSpace, partitionFreeSpace = enoughFreeSpaceToInstall((upgradeFileSize * 2) + liveHobartDirSize + dbBackupHtdfWorstCaseFileSize, live)

            if not enoughSpace:
                displayNotEnoughSpaceMessage(language=language,
                                             whichPartition='live',
                                             availableSpace=partitionFreeSpace,
                                             neededSpace=((upgradeFileSize * 2) + liveHobartDirSize + dbBackupHtdfWorstCaseFileSize))
                return 1

            if language == 'spanish':
                message = "Actualización de Aplicación y SO (Etapa 1)\n\nInicializando..."
            elif language == 'french':
                message = "Mise à niveau de l\'application et du SE (Étape 1)\n\nInitialisation..."
            else:
                message = "Application and OS Upgrade (Stage 1)\n\nInitiating..."

            exitCode,  mbId = messageBox.display(message)

            backupCriticalFiles(upgradeFilename, resources, restoreScript, scaleAppRestore, mbId,
                                language, db, dbBackupInPlace, live, liveHobart, isPatchUpgrade, removeUpgrade, dbRestore, coreTGZ, True)
            # stage the upgrade
            if os.name == 'posix':
                cmd = []
                cmd.append(os.path.join("/", "etc","init.d","stageRecovery.sh"))
                if isPatchUpgrade:
                    cmd.append("patch_scale")
                else:
                    cmd.append("upgrade_scale")

                exitCode, stdout, stderr = shellCommand.execute(cmd)
            elif os.name == 'nt':
                cmd = []
                cmd.append(os.path.join(configInfo.getRootFolder(), "bin", "stageRecovery.cmd"))
                cmd.append("upgrade_scale")
                cmd.append(os.path.join(scaleAppRestore, coreTGZ))
                osUtils.winRunElevated(cmd)
            messageBox.destroy(mbId)
            return exitCode

        # u-boot upgrade
        elif BOOTLOADER_UPGRADE_REGEX_COMPILED.match(upgradeFilename) or BOOTLOADER_UPGRADE_OLD_REGEX_COMPILED.match(upgradeFilename):
            # get size of resources directory we are about to remove
            if os.name == 'posix':
                bootloaderDirSize = fileSysStatistics.directorySize(os.path.join(recovery,"u-boot"))
            elif os.name == 'nt':
                bootloaderDirSize = fileSysStatistics.directorySize(os.path.join(recovery,'bios'))

            # get size of tarball we are about to extract and install
            upgradeFileSize = fileSysStatistics.fileSize(upgradeFilename)

            enoughSpace, partitionFreeSpace = enoughFreeSpaceToInstall(upgradeFileSize + bootloaderDirSize, recoveryPartition)
            if not enoughSpace:
                displayNotEnoughSpaceMessage(language=language,
                                             whichPartition='recovery',
                                             availableSpace=partitionFreeSpace + bootloaderDirSize,
                                             neededSpace=upgradeFileSize+bootloaderDirSize)
                return 1

            if language == 'spanish':
                message = "Actualización de Bootloader (Etapa 1)\n\nCopiando actualización desde dispositivo fuente..."
            elif language == 'french':
                message = "Mise à niveau de Bootloader (Étape 1)\n\nCopie de la mise à niveau à partir du dispositif source..."
            else:
                message = "Boot Loader Upgrade (Stage 1)\n\nCopying Upgrade from Source Device..."

            exitCode,  mbId = messageBox.display(message)

            if os.name == 'posix':
                if os.path.exists(os.path.join(recovery,"u-boot","hte-uboot.tgz")):
                    os.remove(os.path.join(recovery,"u-boot","hte-uboot.tgz"))

                if os.path.exists(os.path.join(recovery,"u-boot","u-boot.imx")):
                    os.remove(os.path.join(recovery,"u-boot","u-boot.imx"))

                os.system('/bin/cp %s %s' % (upgradeFilename, os.path.join(recovery,"u-boot","hte-uboot.tgz")))

                # if told to remove the upgrade
                if removeUpgrade:
                    # remove the upgrade since we have copied to recovery partition
                    removeUpgradeSource(upgradeFilename)

                os.system('/bin/tar xvzf %s -C %s' % (os.path.join(recovery,"u-boot","hte-uboot.tgz"),
                                os.path.join(recovery,"u-boot")))
                os.remove(os.path.join(recovery,"u-boot",'hte-uboot.tgz'))

            elif os.name == 'nt':
                biosRecoveryPath = os.path.join(recovery, 'bios')
                if os.path.exists(os.path.join(biosRecoveryPath,'htx-bios.tgz')):
                    try:
                        os.chmod(os.path.join(biosRecoveryPath,'htx-bios.tgz'), stat.S_IWRITE)
                        os.remove(os.path.join(biosRecoveryPath,'htx-bios.tgz'))
                    except IOError, exception_details:
                        print 'error: Cannot remove file: ' + os.path.join(biosRecoveryPath,'htx-bios.tgz') + ', Reason: ' + exception_details[1]

                if os.path.exists(os.path.join(biosRecoveryPath,'bios.bin')):
                    try:
                        os.chmod(os.path.join(biosRecoveryPath,'bios.bin'), stat.S_IWRITE)
                        os.remove(os.path.join(biosRecoveryPath,'bios.bin'))
                    except exception_details:
                        print 'error: Cannot remove file: ' + os.path.join(biosRecoveryPath,'bios.bin') + ', Reason: ' + exception_details[1]

                shutil.copy(upgradeFilename, os.path.join(biosRecoveryPath, 'htx-bios.tgz'))

                # if told to remove the upgrade
                if removeUpgrade:
                    # remove the upgrade since we have copied to recovery partition
                    removeUpgradeSource(upgradeFilename)

                try:
                    tar = tarfile.open(os.path.join(biosRecoveryPath, 'htx-bios.tgz'), 'r')
                    tar.extractall(biosRecoveryPath)
                    os.chmod(os.path.join(recovery, 'bios','htx-bios.tgz'), stat.S_IWRITE)
                    os.remove(os.path.join(recovery, 'bios', 'htx-bios.tgz'))
                except:
                    pass

            messageBox.destroy(mbId)

            if language == 'spanish':
                message = "Actualización de Bootloader (Etapa 1)\n\nInicializando Etapa 2..."
            elif language == 'french':
                message = "Mise à niveau de Bootloader (Étape 1)\n\nInitialisation Étape 2..."
            else:
                message = "Boot Loader Upgrade (Stage 1)\n\nInitiating Stage 2..."

            exitCode,  mbId = messageBox.display(message)

            # copy lang file to recovery partition
            if os.name == 'posix':
                shutil.copy(os.path.join("/","usr","local","hobart", "lang"),
                                os.path.join("/","media","mmcblk0p2","usr", "local","hobart","lang"))

                os.system("/bin/sync")

                cmd = []
                cmd.append(os.path.join("/", "etc","init.d","stageRecovery.sh"))
                cmd.append("upgrade_u-boot")
                exitCode, stdout, stderr = shellCommand.execute(cmd)

            elif os.name == 'nt':
                shutil.copy(os.path.join(liveHobart, 'lang'), os.path.join(recovery, 'lang'))

                cmd = []
                cmd.append(os.path.join(configInfo.getRootFolder(), "bin", "stageRecovery.cmd"))
                cmd.append("upgrade_bios")
                cmd.append(os.path.join(recovery,'bios','bios.bin'))
                osUtils.winRunElevated(cmd)

            messageBox.destroy(mbId)
            return exitCode

        # language upgrade
        elif LANGUAGE_UPGRADE_REGEX_COMPILED.match(upgradeFilename) or LANGUAGE_UPGRADE_OLD_REGEX_COMPILED.match(upgradeFilename):

            if language == 'spanish':
                message = "Actualización de idioma\n\nCopiando actualización desde dispositivo fuente..."
            elif language == 'french':
                message = "Mise à niveau de langue\n\nCopie de la mise à niveau à partir du dispositif source..."
            else:
                message = "Language Upgrade\n\nCopying Upgrade from Source Device..."

            exitCode,  mbId = messageBox.display(message)

            if os.name == 'posix':
                os.system('/bin/tar xvzf %s -C %s' % (upgradeFilename,  live))

                # if told to remove the upgrade
                if removeUpgrade:
                    # remove the source upgrade since we have already extracted it to the live partition
                    removeUpgradeSource(upgradeFilename)

                os.system("/bin/sync")

            elif os.name == 'nt':
                try:
                    tar = tarfile.open(upgradeFilename, 'r')
                    tar.extractall(liveHobart)
                except:
                    pass

                # if told to remove the upgrade
                if removeUpgrade:
                    # remove the source upgrade since we have already extracted it to the live partition
                    removeUpgradeSource(upgradeFilename)

            messageBox.destroy(mbId)

            if language == 'spanish':
                message = "Instalación de la actualización del idioma es completa."
            elif language == 'french':
                message = "L\'installation de la mise à niveau de la langue est terminé."
            else:
                message = "Installation of Language Upgrade is complete."

            exitCode,  mbId = messageBox.display(message=message,  timer=5)
            return 0

        # feature upgrade
        elif FEATURE_UPGRADE_REGEX_COMPILED.match(upgradeFilename) or \
            FEATURE_UPGRADE_OLD_REGEX_COMPILED.match(upgradeFilename) or \
            FEATURE_UPGRADE_OSAGNOSTIC_REGEX_COMPILED.match(upgradeFilename):

            # get size of tarball we are about to extract and install
            upgradeFileSize = fileSysStatistics.fileSize(upgradeFilename)

            enoughSpace, partitionFreeSpace = enoughFreeSpaceToInstall(upgradeFileSize, live)
            if not enoughSpace:
                displayNotEnoughSpaceMessage(language=language,
                                             whichPartition='live',
                                             availableSpace=partitionFreeSpace,
                                             neededSpace=upgradeFileSize)
                return 1

            # do not display message box if this is a SM backend upgrade
            if not BACKEND_UPGRADE_FILENAME_REGEX_COMPILED.match(upgradeFilename) and \
                not BACKEND_UPGRADE_NEW_FILENAME_REGEX_COMPILED.match(upgradeFilename):
                if language == 'spanish':
                    message = "Actualización de característica\n\nCopiando actualización desde dispositivo fuente..."
                elif language == 'french':
                    message = "Mise à niveau de caractéristique\n\nCopie de la mise à niveau à partir du dispositif source..."
                else:
                    message = "Feature Upgrade\n\nCopying Upgrade from Source Device..."

                exitCode,  mbId = messageBox.display(message)

            # pick hte-feature_{name} out of .tgz tarball name by splitting it at dash
            upgradeFileElements = string.split(os.path.basename(upgradeFilename), "-")

            if FEATURE_UPGRADE_OLD_REGEX_COMPILED.match(upgradeFilename):
                # pick feature name out of feature section of file name by splitting at _
                featureNameElements = string.split(upgradeFileElements[1], '_')
                # set feature name to all the feature name elements except feature_
                featureName = string.join(featureNameElements[1:],'_')
            else:
                featureName = upgradeFileElements[3]

            # determine if feature already is installed and if so remove feature folder
            if os.name == 'posix':
                if MONOLITHIC_UPGRADE_REGEX_COMPILED.match(upgradeFilename):
                    # extract the main tarball with live, recovery, and uboot tarballs in it and an install file
                    installUtils.extractTarball(upgradeFilename, live)
                    # execute the install file to extract all tarballs and update uboot, recovery, and live
                    installUtils.executeInstallScript(featureName, live)
                    installUtils.reboot()
                else:
                    if FEATURE_UPGRADE_OSAGNOSTIC_REGEX_COMPILED.match(upgradeFilename):
                        # any os feature is installed at /usr/local since the prefix diretory is os specific
                        installUtils.extractTarball(upgradeFilename, os.path.join(live, "usr", "local"))
                        installUtils.executeInstallScript(featureName, live)
                    else:
                        installUtils.extractTarball(upgradeFilename, live)
                        installUtils.executeInstallScript(featureName, live)

            elif os.name == 'nt':
                if os.path.exists(os.path.join(liveHobart, "features", featureName)):
                    os.rmdir(os.path.join(liveHobart, "features", featureName))

                try:
                    tar = tarfile.open(upgradeFilename, 'r')
                    tar.extractall(live)
                except:
                    pass

                # if told to remove the upgrade
                if removeUpgrade:
                    # remove the source upgrade file since we have already extracted the feature
                    removeUpgradeSource(upgradeFilename)

                installUtils.executeInstallScript(featureName, live)

            # do not display message box if this is a SM backend upgrade
            if not BACKEND_UPGRADE_FILENAME_REGEX_COMPILED.match(upgradeFilename) and \
                not BACKEND_UPGRADE_NEW_FILENAME_REGEX_COMPILED.match(upgradeFilename):

                messageBox.destroy(mbId)

                if language == 'spanish':
                    message = "Instalación de la actualización del característica es completa."
                elif language == 'french':
                    message = "L\'installation de la mise à niveau de la caractéristique est terminé."
                else:
                    message = "Installation of Feature Upgrade is complete."

                exitCode,  mbId = messageBox.display(message=message,  timer=5)

            return 0

        elif LICENSE_INSTALL_REGEX_COMPILED.match(upgradeFilename):

            if language == 'spanish':
                message = "Actualización de la licencia\n\nCopiando actualización desde dispositivo fuente..."
            elif language == 'french':
                message = "mise à niveau de licence\n\nCopie de la mise à niveau à partir du dispositif source..."
            else:
                message = "License Upgrade\n\nCopying Upgrade from Source Device..."

            exitCode, mbId = messageBox.display(message, timer=5)

            exitCode = installLicense(licenseFile=upgradeFilename, language=language, serverHost=serverHost, username=username, password=password, uploadFolder=uploadFolder)

            # if told to remove the source upgrade
            if removeUpgrade:
                # remove it since we have installed the license
                removeUpgradeSource(upgradeFilename)

            if os.name == 'posix':
                os.system("/bin/sync")

            return exitCode

        elif FPC_UPGRADE_REGEX_COMPILED.match(upgradeFilename) or FPC_UPGRADE_OLD_REGEX_COMPILED.match(upgradeFilename):

            if language == 'spanish':
                message = "Actualización de la FPC\n\nCopiando actualización desde dispositivo fuente..."
            elif language == 'french':
                message = "mise à niveau de FPC\n\nCopie de la mise à niveau à partir du dispositif source..."
            else:
                message = "FPC Upgrade\n\nCopying Upgrade from Source Device..."

            exitCode,  mbId = messageBox.display(message, timer=5)

            exitCode = installFPC(upgradeFilename)

            # if told to remove the source upgrade
            if removeUpgrade:
                # remove it since we have installed FPC
                removeUpgradeSource(upgradeFilename)

            return exitCode

        elif RECOVERY_UPGRADE_REGEX_COMPILED.match(upgradeFilename) or RECOVERY_UPGRADE_OLD_REGEX_COMPILED.match(upgradeFilename):

            if language == 'spanish':
                message = "Actualización de recuperación\n\nCopiando actualización de recuperación desde dispositivo fuente..."
            elif language == 'french':
                message = "Mise à niveau de recouvrement\n\nCopie de la mise à niveau de\nrecouvrement du dispositif source..."
            else:
                message = "Recovery Upgrade\n\nCopying Recovery Upgrade from Source Device..."

            exitCode,  mbId = messageBox.display(message)

            if os.name == 'posix':
                os.system('/bin/cp -f %s %s' % (upgradeFilename,  os.path.join("/", "tmp", "recovery.tar.gz")))

                # if told to remove the upgrade
                if removeUpgrade:
                    # remove it since we copied it to recovery partition already
                    removeUpgradeSource(upgradeFilename)

                os.system("/bin/sync")

            elif os.name == 'nt':
                shutil.copy(upgradeFilename, os.path.join(recoveryPartition, 'recovery.tar.gz'))

                # if told to remove the upgrade
                if removeUpgrade:
                    # remove it since we copied it to recovery partition already
                    removeUpgradeSource(upgradeFilename)

            messageBox.destroy(mbId)

            if language == 'spanish':
                message = "Actualización de recuperación (Etapa 1)\n\nInicializando Etapa 2..."
            elif language == 'french':
                message = "Mise à niveau de recouvrement (Étape 1)\n\nInitialisation Étape 2..."
            else:
                message = "Recovery Upgrade (Stage 1)\n\nInitiating Stage 2..."

            exitCode,  mbId = messageBox.display(message=message)

            if os.name == 'posix':
                cmd = []
                cmd.append(os.path.join("/", "etc","init.d","stageRecovery.sh"))
                cmd.append("upgrade_recovery")
                exitCode, stdout, stderr = shellCommand.execute(cmd)
            elif os.name == 'nt':
                cmd = []
                cmd.append(os.path.join(configInfo.getRootFolder(), "bin", "stageRecovery.cmd"))
                cmd.append("upgrade_recovery")
                cmd.append(os.path.join(recoveryPartition, 'recovery.tar.gz'))
                osUtils.winRunElevated(cmd)

            messageBox.destroy(mbId)
            return exitCode

        else:
            if language == 'spanish':
                message = "Archivo de actualización no reconocido, Cheque nombre de archivo."
            elif language == 'french':
                message = "Fichier de mise à jour non reconnu, Chèque nom de fichier."
            else:
                message = "Unrecognized upgrade file, check filename."

            exitCode,  mbId = messageBox.display(message=message, timer=5)

    else:
        return 1

if __name__ == '__main__':
    if len(sys.argv) == 2:
        # this would be call from upgrade from USB thumb drive
        # and Qt land via a shell command
        installUpgrade(upgradeFilename=sys.argv[1])

    if os.name == 'posix':
        os.system("/bin/sync")
