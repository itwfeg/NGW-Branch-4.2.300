// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINAUTOMAPDXGISURFACE_H__
#define __WINAUTOMAPDXGISURFACE_H__

#include "region/Rect.h"

#include <d3d11.h>
#include <DXGI1_2.h>

#include "WinDxgiSurface.h"

// Calls IDXGISurface->Map() function at the constructor and Unmap() at the destructor.
class WinAutoMapDxgiSurface
{
public:
  // Surface will be created by the ID3D11Texture2D's QueryInterface() function call.
  WinAutoMapDxgiSurface(WinDxgiSurface *surface, UINT mapFlags);
  virtual ~WinAutoMapDxgiSurface();

  size_t getStride() const;
  char *getBuffer() const;

private:
  WinDxgiSurface *m_surface;
  DXGI_MAPPED_RECT m_mappedRect;
};

#endif // __WINAUTOMAPDXGISURFACE_H__
