# -*- coding: utf-8 -*-

# Copyright (c) 2002 - 2012 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module defining some informational strings.
"""

Program = 'eric4'
Version = '4.5.8 (r4410)'
Copyright = 'Copyright (c) 2002 - 2012 Detlev Offenbach <detlev@die-offenbachs.de>'
BugAddress = 'eric4-bugs@eric-ide.python-projects.org'
FeatureAddress = 'eric4-featurerequest@eric-ide.python-projects.org'
Homepage = "http://eric-ide.python-projects.org/index.html"
