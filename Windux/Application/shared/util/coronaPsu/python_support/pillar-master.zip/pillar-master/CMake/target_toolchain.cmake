# Target toolchain file for AM335x systems.
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR arm)

set(TOOLS_DIR /opt/gcc-linaro-arm-linux-gnueabihf/)
set(CMAKE_C_COMPILER ${TOOLS_DIR}/bin/arm-linux-gnueabihf-gcc)
set(CMAKE_CXX_COMPILER ${TOOLS_DIR}/bin/arm-linux-gnueabihf-g++)
set(CMAKE_FIND_ROOT_PATH ${TOOLS_DIR}/arm-linux-gnueabihf/libc/usr)
include_directories(${TOOLS_DIR}/arm-linux-gnueabihf/libc/usr/include)

