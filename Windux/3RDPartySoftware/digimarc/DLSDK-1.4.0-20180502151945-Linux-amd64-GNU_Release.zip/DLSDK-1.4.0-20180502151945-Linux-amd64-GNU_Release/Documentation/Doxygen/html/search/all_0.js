var searchData=
[
  ['bytesperrow',['BytesPerRow',['../structDSM__DATADESC.html#a773b08561a2ce6422ed9deab5b4bd285',1,'DSM_DATADESC']]]
];
