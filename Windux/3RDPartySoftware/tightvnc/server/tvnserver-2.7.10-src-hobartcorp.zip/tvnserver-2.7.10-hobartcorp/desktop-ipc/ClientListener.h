// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CLIENTLISTENER_H__
#define __CLIENTLISTENER_H__

#include "util/inttypes.h"
#include "desktop-ipc/BlockingGate.h"

class ClientListener
{
public:
  ClientListener();
  virtual ~ClientListener();

  virtual void onRequest(UINT8 reqCode, BlockingGate *backGate) = 0;
};

#endif // __CLIENTLISTENER_H__
