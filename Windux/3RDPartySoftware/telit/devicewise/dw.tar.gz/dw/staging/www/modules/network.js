var NetworkCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded NetworkCtrl');
  // Preperations
  lpApi.osNetworkGet();

  $('#loading').show();
  $('#content-container').addClass('ng-cloak');
  Debug.log('Loading display '+$('#loading').css('display'));
  $http.post(lpApi.getUrl(''), lpApi.getPayload())
    .error($scope.errorCallback).success(function(a,b,c,d){ $scope.successCallback(a,b,c,d); $scope.populateNetworkInfo();});

  // Properties
  $scope.mainActions = [{
    id : 'main-action-editNode',
    href: "#/editNetwork",
    aClasses: "gray-button",
    text: "Edit network"
  }];

  // Functions
  $scope.addDnsServer = function(elementPrefix,listElement) {
    var newDnsServer = $scope.assembleIpAddress(elementPrefix);
    if (newDnsServer.match(/[12]{0,1}[0-9]{1,2}\.[12]{0,1}[0-9]{1,2}\.[12]{0,1}[0-9]{1,2}\.[12]{0,1}[0-9]{1,2}/)) {
      $('#'+listElement).append("<option>" + newDnsServer + "</option>");
      for (var i = 0; i < 4; i++) {
        $("#"+elementPrefix+"-" + i).val("");
      }
    }
    else {
      alert("Invalid IP Address.");
    }
    return false;
  };

  $scope.assembleIpAddress = function(elementPrefix) {
    var ipAddress = $("#" + elementPrefix + "-0").val() + "." + $("#" + elementPrefix + "-1").val() + "." + $("#" + elementPrefix + "-2").val() + "." + $("#" + elementPrefix + "-3").val();
    if (ipAddress.match(/[12]{0,1}[0-9]{1,2}\.[12]{0,1}[0-9]{1,2}\.[12]{0,1}[0-9]{1,2}\.[12]{0,1}[0-9]{1,2}/)) {
      return ipAddress;
    }
    return '';
  };

  $scope.getInterfaceKeyArray = function() {
    var key_array= new Array;
    for (var key in $scope.osNetworkGet.params.interfaces) {
      key_array.push(key);
    }
    return key_array;
  };

  $scope.getInterfaceKeyByIndex = function(index) {
    var key_array = $scope.getInterfaceKeyArray();
    if (key_array[index] !== undefined) {
      return key_array[index];
    }
    return false;
  };

  $scope.isCheckedDhcp = function(id) {
    if ($('#'+id).is(':checked')) {
      return true;
    }
    return false;
  };

  $scope.populateNetworkInfo = function() {
    if ($scope.osNetworkGet !== undefined && $scope.osNetworkGet.params !== undefined) {
      var key_array = new Array;
      $scope.interfaces = new Array;
      key_array = $scope.getInterfaceKeyArray();
      for (var a=0; a<key_array.length; a++) {
        var obj = new Object;
        obj.key = $scope.getInterfaceKeyByIndex(a);
        obj.dhcp = $scope.osNetworkGet.params.interfaces[$scope.getInterfaceKeyByIndex(a)].dhcp;
        obj.name = $scope.osNetworkGet.params.interfaces[$scope.getInterfaceKeyByIndex(a)].name;
        obj.address = $scope.osNetworkGet.params.interfaces[$scope.getInterfaceKeyByIndex(a)].address;
        obj.gateway = $scope.osNetworkGet.params.interfaces[$scope.getInterfaceKeyByIndex(a)].gateway;
        obj.broadcast = $scope.osNetworkGet.params.interfaces[$scope.getInterfaceKeyByIndex(a)].broadcast;
        obj.mask = $scope.osNetworkGet.params.interfaces[$scope.getInterfaceKeyByIndex(a)].mask;
        obj.hwaddr = $scope.osNetworkGet.params.interfaces[$scope.getInterfaceKeyByIndex(a)].hwaddr;
        obj.dns = $scope.osNetworkGet.params.interfaces[$scope.getInterfaceKeyByIndex(a)].dns;
        obj.searchPath = $scope.osNetworkGet.params.interfaces[$scope.getInterfaceKeyByIndex(a)].searchPath;
        $scope.interfaces.push(obj);
      }
      return true;
    }
    return false;
  };

  $scope.removeDnsServer = function(element) {
    if ($('#'+element+' option:selected').length > 0) {
      $('#'+element+' option:selected').each(function(){$(this).remove();});
    }
    return false;
  };

  $scope.saveNetworkSettings = function(){
    if (confirm('Changes to the active connection may result in disconnection. Continue save?')){
      var os_network_dns_set_params = {
        hostname: $('#input-host-name').val(),
        searchPath: $('#input-search-path').val(),
        dns: new Array
      };

      $('#input-dns').children('option').each(function(){
        os_network_dns_set_params.dns.push($(this).html());
      });

      var os_network_iface_set = {
        interfaces: {}
      };

      var dns = new Array, dhcp = new Array, address = new Array, mask = new Array, gateway = new Array, broadcast = new Array, key = new Array, name = new Array, searchPath = new Array;
      $('.input-dhcp').each(function(){
        dhcp.push($(this).is('input:checked'));
      });

      $('.input-address').each(function(){
        var index = $(this).attr('id').substring(13,$(this).attr('id').lastIndexOf('-')), octet = $(this).attr('id').substring($(this).attr('id').lastIndexOf('-')+1);
        if (address[index] === undefined){
          address.push(new Array);
          if (address[index][octet] === undefined){
            address[index].push();
          }
        }
        else {
          if (address[index][octet] === undefined){
            address[index].push();
          }
        }
        if ($(this).val().length>0) {
          address[index][octet] = $(this).val();
        }
        if (octet === 3 && address[index][octet] !== undefined){
          address[index] = address[index].join('.');
        }
        else if (octet === 3) {
          address[index] = '';
        }
      });

      $('.input-mask').each(function(){
        var index = $(this).attr('id').substring(10,$(this).attr('id').lastIndexOf('-')), octet = $(this).attr('id').substring($(this).attr('id').lastIndexOf('-')+1);
        if (mask[index] === undefined){
          mask.push(new Array);
          if (mask[index][octet] === undefined){
            mask[index].push();
          }
        }
        else {
          if (mask[index][octet] === undefined){
            mask[index].push();
          }
        }
        if ($(this).val().length>0) {
          mask[index][octet] = $(this).val();
        }
        if (octet === 3 && mask[index][octet] !== undefined){
          mask[index] = mask[index].join('.');
        }
        else if (octet === 3) {
          mask[index] = '';
        }
      });

      $('.input-gateway').each(function(){
        var index = $(this).attr('id').substring(13,$(this).attr('id').lastIndexOf('-')), octet = $(this).attr('id').substring($(this).attr('id').lastIndexOf('-')+1);
        if (gateway[index] === undefined){
          gateway.push(new Array);
          if (gateway[index][octet] === undefined){
            gateway[index].push();
          }
        }
        else {
          if (gateway[index][octet] === undefined){
            gateway[index].push();
          }
        }
        if ($(this).val().length>0) {
          gateway[index][octet] = $(this).val();
        }
        if (octet === 3 && gateway[index][octet] !== undefined){
          gateway[index] = gateway[index].join('.');
        }
        else if (octet === 3) {
          gateway[index] = '';
        }
      });

      $('.input-broadcast').each(function(){
        var index = $(this).attr('id').substring(13,$(this).attr('id').lastIndexOf('-')), octet = $(this).attr('id').substring($(this).attr('id').lastIndexOf('-')+1);
        if (broadcast[index] === undefined){
          broadcast.push(new Array);
          if (broadcast[index][octet] === undefined){
            broadcast[index].push();
          }
        }
        else {
          if (broadcast[index][octet] === undefined){
            broadcast[index].push();
          }
        }
        if ($(this).val().length>0) {
          broadcast[index][octet] = $(this).val();
        }
        if (octet === 3 && broadcast[index][octet] !== undefined){
          broadcast[index] = broadcast[index].join('.');
        }
        else if (octet === 3) {
          broadcast[index] = '';
        }
      });

      $('.input-key').each(function(){
        key.push($(this).val());
      });

      $('.input-name').each(function(){
        name.push($(this).val());
      });

      $('.input-dns').each(function(){
        var options = new Array;
        $(this).children('option').each(function(){
          options.push($(this).html());
        });
        dns.push(options);
      });

      $('.input-search-path').each(function(){
        searchPath.push($(this).val());
      });

      for (var a = 0; a < key.length; a++) {
        if (key[a].length > 0){
          os_network_iface_set.interfaces[key[a]] = {
            address: address[a],
            gateway: gateway[a],
            broadcast: broadcast[a],
            dhcp: dhcp[a],
            mask: mask[a],
            name: name[a],
            dns: dns[a],
            searchPath: searchPath[a]
          };
          if (dns.length > 0 && searchPath.length > 0) {
            os_network_iface_set.interfaces[key[a]].dns = dns[a];
            os_network_iface_set.interfaces[key[a]].searchPath = searchPath[a];
          }
        }
      }

      lpApi.osNetworkDnsSet(os_network_dns_set_params);
      lpApi.osNetworkIfaceSet(os_network_iface_set);

      $resultScope = lpApi.go('', $scope);
      var msg, msgType;
      if ($resultScope.osNetworkDnsSet.success === true && $resultScope.osNetworkIfaceSet.success === true) {
        msg = 'Network Settings Saved Successfully!';
        msgType = 'success';
      }
      else if ($resultScope.osNetworkDnsSet.success === false || $resultScope.osNetworkIfaceSet.success === false ) {
        msg = 'Network Settings Not Saved Succefully!';
        msgType = 'error';
        if ($resultScope.osNetworkDnsSet.success === false) {
            msg += ' '+$resultScope.osNetworkDnsSet.errorMessage;
        }
        if ($resultScope.osNetworkIfaceSet.success === false) {
            msg += ' '+$resultScope.osNetworkIfaceSet.errorMessage;
        }
      }
      Debug.log([msg, msgType],'saveNetworkSettings');
      $scope.setSystemMsg(msg, msgType);
    }
  };

  // Executions
  $scope.clearSystemMsg();
  $scope.assertAuthentication();
  $scope.menuItemSelect($scope, 'gateway');
  $scope.populateNetworkInfo();
};

NetworkCtrl.$inject = ['$scope', 'lpApi', '$http'];

NetworkCtrl.prototype.ctrlActions = {
  items : [{
    href : '',
    template : ''
  }]
};

NetworkCtrl.prototype.mainActions = {
  items : [{
    href : '/editNetwork',
    template : 'partials/editNetwork.html'
  }]
};

NetworkCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};
