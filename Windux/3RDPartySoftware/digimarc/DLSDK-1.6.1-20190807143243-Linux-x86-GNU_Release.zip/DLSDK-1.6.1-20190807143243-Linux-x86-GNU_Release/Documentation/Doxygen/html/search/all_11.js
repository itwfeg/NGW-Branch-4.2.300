var searchData=
[
  ['watermark_5fresolution',['WATERMARK_RESOLUTION',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39abf428007aa2b1614c65bc70c7c09667f',1,'SampleLabelEmbedder.cpp']]],
  ['weight_5fin_5fkilograms',['WEIGHT_IN_KILOGRAMS',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39ac3ffaa909676550e86c174ada37316fe',1,'SampleLabelEmbedder.cpp']]],
  ['weight_5fin_5fpounds',['WEIGHT_IN_POUNDS',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a6203020799251aa8ae42ca5bcd333d23',1,'SampleLabelEmbedder.cpp']]],
  ['width',['Width',['../structDSM__DATADESC.html#a6514151f7ceb0e472bf701112d06bfe0',1,'DSM_DATADESC::Width()'],['../structDSM__KEEP__OUT__REGION.html#a30bb79e10cd737848fc7994cbed2af37',1,'DSM_KEEP_OUT_REGION::Width()']]]
];
