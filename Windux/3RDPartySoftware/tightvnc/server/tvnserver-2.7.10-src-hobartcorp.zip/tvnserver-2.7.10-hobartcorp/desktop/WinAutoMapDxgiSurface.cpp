// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "util/Exception.h"

// The header including of this cpp file must be at last place to avoid build conflicts.
#include "WinAutoMapDxgiSurface.h"

WinAutoMapDxgiSurface::WinAutoMapDxgiSurface(WinDxgiSurface *surface, UINT mapFlags)
: m_surface(surface)
{
  HRESULT hr = m_surface->getSurface()->Map(&m_mappedRect, mapFlags);
  if (FAILED(hr)) {
    StringStorage errMess;
    errMess.format(_T("Can't IDXGISurface->Map, error code = %l"), (long)hr);
    throw Exception(errMess.getString());
  }
}

WinAutoMapDxgiSurface::~WinAutoMapDxgiSurface()
{
  m_surface->getSurface()->Unmap();
}

size_t WinAutoMapDxgiSurface::getStride() const
{
  if (m_mappedRect.Pitch < 0) {
    throw Exception(_T("DXGI_MAPPED_RECT::Pitch is negative"));
  }
  return (size_t)m_mappedRect.Pitch;
}

char *WinAutoMapDxgiSurface::getBuffer() const
{
  return (char *)m_mappedRect.pBits;
}
