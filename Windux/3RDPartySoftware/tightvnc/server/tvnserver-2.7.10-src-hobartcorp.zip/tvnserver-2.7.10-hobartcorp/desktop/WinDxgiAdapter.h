// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDXGIADAPTER_H__
#define __WINDXGIADAPTER_H__

#include "WinDxgiDevice.h"

#include <d3d11.h>
#include <DXGI1_2.h>

class WinDxgiAdapter
{
public:
  WinDxgiAdapter(WinDxgiDevice *winDxgiDevice);
  virtual ~WinDxgiAdapter();

  // This function try to get output for iOutput from the adapter.
  // Throws the WinDxRecoverableException exception if output not found,
  // and throws WinDxCriticalException on other errors.
  void getDxgiOutput(UINT iOutput, IDXGIOutput **iDxgiOutput);

private:
  IDXGIAdapter *m_dxgiAdapter;
};

#endif // __WINDXGIADAPTER_H__
