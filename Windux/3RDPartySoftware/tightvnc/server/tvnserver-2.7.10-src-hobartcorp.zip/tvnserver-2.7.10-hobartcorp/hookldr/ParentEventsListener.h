// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __PARENTEVENTSLISTENER_H__
#define __PARENTEVENTSLISTENER_H__

class ParentEventsListener
{
public:
  virtual void onParentTerminate() = 0;
};

#endif // __PARENTEVENTSLISTENER_H__
