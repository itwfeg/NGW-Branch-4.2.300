var files =
[
    [ "dsmsdk.h", "dsmsdk_8h.html", "dsmsdk_8h" ],
    [ "ExampleExpandedFresh.cpp", "ExampleExpandedFresh_8cpp.html", "ExampleExpandedFresh_8cpp" ],
    [ "ExampleExpandedFreshWeightRange2.cpp", "ExampleExpandedFreshWeightRange2_8cpp.html", "ExampleExpandedFreshWeightRange2_8cpp" ],
    [ "ExampleGtin.cpp", "ExampleGtin_8cpp.html", "ExampleGtin_8cpp" ],
    [ "ExampleKeepOutRegions.cpp", "ExampleKeepOutRegions_8cpp.html", "ExampleKeepOutRegions_8cpp" ],
    [ "ExampleUpce.cpp", "ExampleUpce_8cpp.html", "ExampleUpce_8cpp" ],
    [ "PayloadHelper.h", "PayloadHelper_8h.html", "PayloadHelper_8h" ],
    [ "SampleLabelEmbedder.cpp", "SampleLabelEmbedder_8cpp.html", "SampleLabelEmbedder_8cpp" ]
];