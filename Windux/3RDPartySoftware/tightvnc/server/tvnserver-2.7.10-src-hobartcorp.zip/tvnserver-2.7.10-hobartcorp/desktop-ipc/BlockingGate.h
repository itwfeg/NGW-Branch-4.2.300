// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _BLOCKING_GATE_H_
#define _BLOCKING_GATE_H_

#include "thread/LocalMutex.h"
#include "io-lib/Channel.h"
#include "io-lib/DataOutputStream.h"
#include "io-lib/DataInputStream.h"

class BlockingGate : public LocalMutex, public DataOutputStream,
                     public DataInputStream
{
public:
  BlockingGate(Channel *stream);
  virtual ~BlockingGate();
};

#endif // _BLOCKING_GATE_H_
