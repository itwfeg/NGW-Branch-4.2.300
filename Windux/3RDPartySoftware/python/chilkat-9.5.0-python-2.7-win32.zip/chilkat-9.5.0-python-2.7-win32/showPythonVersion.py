# Displays the Python version.

import sys

print("version", sys.version)

