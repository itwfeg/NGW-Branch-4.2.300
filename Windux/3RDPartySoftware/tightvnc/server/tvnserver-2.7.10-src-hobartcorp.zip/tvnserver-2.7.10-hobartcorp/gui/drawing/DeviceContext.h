// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _DEVICE_CONTEXT_H_
#define _DEVICE_CONTEXT_H_

#include "util/CommonHeader.h"
#include "gui/PaintWindow.h"

class DeviceContext
{
public:
  // Create device context linked to window DC.
  DeviceContext(HWND window);
  // Create device context complatible with other DC.
  DeviceContext(DeviceContext* compatibleDevice);
  // Destroys device context.
  virtual ~DeviceContext();

private:
  // Initialize class from PaintWindow
  DeviceContext(class PaintWindow * pntWnd);

  friend class PaintWindow;

protected:
  // Selects an object into this device context.
  HGDIOBJ selectObject(HGDIOBJ object);

protected:
  HDC m_dc;
  HWND m_wnd;
  bool m_hasOwnDC;

  friend class Graphics;
  friend class BitmapGraphics;
};

#endif
