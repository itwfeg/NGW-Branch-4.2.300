/*
 * errlog.h
 *
 *  Created on: Oct 27, 2013
 *      Author: collin
 */

#include <iostream>

#ifndef ERRLOG_H_
#define ERRLOG_H_


#define LOG_ERROR(status, message)\
	if(status < 0)\
	{\
		std::cerr << "ERROR (" << status << ") @ " << __FILE__ << "." << __LINE__ << "-> ";\
		std::cerr << message << std::endl;\
	}

#ifdef DEBUG
#define _ASSERT(op) if(!(op))\
{\
	std::cerr << "ASSERT Failure @ " << __FILE__ << "." << __LINE__ << "-> ";\
	std::cerr << #op << " failed." << std::endl;\
}

#else
#define _ASSERT()
#endif


#endif /* ERRLOG_H_ */
