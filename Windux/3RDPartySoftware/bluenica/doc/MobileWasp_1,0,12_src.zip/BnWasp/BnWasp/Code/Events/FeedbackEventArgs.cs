﻿using System;

namespace BnWasp
{
	public class FeedbackEventArgs : EventArgs
	{
		public FeedbackEventType FType { get; private set; }
		public string Message { get; private set; }

		public FeedbackEventArgs(FeedbackEventType type, string text)
		{
			FType = type;
			Message = text;
		}
	}
}
