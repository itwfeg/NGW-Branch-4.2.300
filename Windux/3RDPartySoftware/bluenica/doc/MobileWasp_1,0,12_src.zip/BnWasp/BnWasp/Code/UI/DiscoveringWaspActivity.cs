﻿using System;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;

namespace BnWasp
{
	[Activity(Label = "Discovering Wasp")]			
	public class DiscoveringWaspActivity : Activity
	{
		private const int MenuIdClear = 100;

		private Button m_stopButton;
		private TextView m_cycleLabel;
		private TextView m_statusLabel;
		private TextView m_logText;

		private static PowerManager.WakeLock m_wakeLock;

		protected override void OnCreate(Bundle savedInstanceState)
		{
			base.OnCreate(savedInstanceState);

			SetContentView(Resource.Layout.DiscoveringWasp);
			PrepareNavigationBar();

			// UI bindings
			m_stopButton = FindViewById<Button>(Resource.Id.DiscoveringWaspStopButton);
			m_cycleLabel = FindViewById<TextView>(Resource.Id.DiscoveringWaspCycleLabel);
			m_logText = FindViewById<TextView>(Resource.Id.DiscoveringWaspLogText);
			m_statusLabel = FindViewById<TextView>(Resource.Id.DiscoveringWaspStatusLabel);

			ClearLog();

			PowerManager pm = (PowerManager)Application.Context.GetSystemService(Context.PowerService);
			m_wakeLock = pm.NewWakeLock(WakeLockFlags.Partial, "DoNotSleepPlease");
		}

		private void GoBack()
		{
			DiscoveringWaspWorker.Instance.Stop();

			SetResult(Result.Ok);
			Finish();
		}

		protected override void OnResume()
		{
			base.OnResume();

			WireupLocalHandlers();
			WireupExternalHandlers();

			if (m_wakeLock != null)
				m_wakeLock.Acquire();

			// start
			DiscoveringWaspWorker.Instance.Start();
		}

		protected override void OnPause()
		{
			base.OnPause();

			// unwire external event handlers (memory leaks)
			RemoveExternalHandlers();

			if (m_wakeLock != null)
				m_wakeLock.Release();
		}


		#region ActionBar

		private void PrepareNavigationBar()
		{
			ActionBar.NavigationMode = ActionBarNavigationMode.Standard;
			ActionBar.Title = "Discovering Wasp";
			ActionBar.SetDisplayShowTitleEnabled(true);
			ActionBar.SetDisplayHomeAsUpEnabled(true);
		}

		public override bool OnCreateOptionsMenu(IMenu menu)
		{
			IMenuItem item = menu.Add(Menu.None, MenuIdClear, Menu.None, "Clear");
			item.SetShowAsAction(ShowAsAction.Always);

			return base.OnCreateOptionsMenu(menu);
		}

		public override bool OnOptionsItemSelected(IMenuItem item)
		{
			switch (item.ItemId)
			{
				case Android.Resource.Id.Home:
					GoBack();
					break;

				case MenuIdClear:
					ClearLog();
					break;
			}

			return base.OnOptionsItemSelected(item);
		}

		#endregion

		#region Event handlers

		protected void WireupLocalHandlers()
		{
			m_stopButton.Click -= StopButtonClickHandler;

			m_stopButton.Click += StopButtonClickHandler;
		}

		protected void WireupExternalHandlers()
		{
			RemoveExternalHandlers();

			DiscoveringWaspWorker.Instance.Feedback += HandleFeedback;
			DiscoveringWaspWorker.Instance.Cycle += HandleNextCycle;
			DiscoveringWaspWorker.Instance.Status += HandleStatus;
		}

		protected void RemoveExternalHandlers()
		{
			DiscoveringWaspWorker.Instance.Feedback -= HandleFeedback;
			DiscoveringWaspWorker.Instance.Cycle -= HandleNextCycle;
			DiscoveringWaspWorker.Instance.Status -= HandleStatus;
		}

		private void StopButtonClickHandler(object sender, EventArgs e)
		{
			DiscoveringWaspWorker.Instance.Stop();
		}

		private void HandleFeedback(object sender, FeedbackEventArgs e)
		{
			AddLogLine(e.Message);
		}

		private void HandleNextCycle(object sender, CycleEventArgs e)
		{
			RunOnUiThread(delegate
				{
					m_cycleLabel.Text = "Cycle: " + e.Number;
				});
		}

		private void HandleStatus(object sender, WorkerStatusEventArgs e)
		{
			ShowStatus(string.Format("Sensors: {0}, records: {1}", e.Tags, e.Records));			
		}

		private void ShowStatus(string text)
		{
			RunOnUiThread(delegate
				{
					m_statusLabel.Text = text;
				});
		}

		#endregion

		#region Text Log

		private void ClearLog()
		{
			RunOnUiThread(delegate
				{
					m_logText.Text = "";
				});
		}

		private void AddLogLine(string message)
		{
			RunOnUiThread(delegate
				{
					if (message != null)
					{
						StringBuilder sb = new StringBuilder(message);
						sb.Append("\n");
						sb.Append(m_logText.Text.Substring(0, Math.Min(m_logText.Text.Length, 1000)));
						m_logText.Text = sb.ToString();
					}
				});
		}

		private void AddLogLine<T>(string prefix, T value)
		{
			AddLogLine(string.Format("{0}: {1}", prefix, value));
		}

		#endregion

	}

}

