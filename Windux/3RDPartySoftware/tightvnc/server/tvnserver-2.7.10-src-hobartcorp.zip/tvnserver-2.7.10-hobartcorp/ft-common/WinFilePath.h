// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _WIN_FILE_PATH_H_
#define _WIN_FILE_PATH_H_

#include "util/StringStorage.h"

class WinFilePath : public StringStorage
{
public:
  WinFilePath();
  WinFilePath(const TCHAR *string);
  WinFilePath(const WinFilePath &stringBuffer);

  ~WinFilePath();

  //
  // Helper method
  // FIXME: May we we don't need this method
  //

  bool parentPathIsRoot();

  //
  // Override parent method
  //
  virtual void setString(const TCHAR *string);

  void operator = (const StringStorage &other);

  bool operator == (const StringStorage &str) const;
  bool operator < (const StringStorage &str) const;

private:
  bool m_parentPathIsRoot;
};

#endif
