// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CLIENTINPUTHANDLER_H__
#define __CLIENTINPUTHANDLER_H__

#include "RfbDispatcherListener.h"
#include "RfbCodeRegistrator.h"
#include "ClientInputEventListener.h"

class ClientInputHandler : public RfbDispatcherListener
{
public:
  ClientInputHandler(RfbCodeRegistrator *codeRegtor,
                     ClientInputEventListener *extEventListener,
                     bool viewOnly);
  virtual ~ClientInputHandler();

  void setViewOnlyFlag(bool value) { m_viewOnly = value; }

protected:
  // Listen function
  virtual void onRequest(UINT32 reqCode, RfbInputGate *input);

  ClientInputEventListener *m_extEventListener;
  bool m_viewOnly;
};

#endif // __CLIENTINPUTHANDLER_H__
