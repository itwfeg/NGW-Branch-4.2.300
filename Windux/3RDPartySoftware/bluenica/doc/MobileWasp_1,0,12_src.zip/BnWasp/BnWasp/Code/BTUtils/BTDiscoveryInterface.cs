﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using Android.Bluetooth;
using Android.Content;


namespace BnWasp
{
	public class BTDiscoveryInterface : Java.Lang.Object, BluetoothAdapter.ILeScanCallback
	{
		public int DiscoveryTimeoutMSecs { get; set; }

		public BNDevice ConnectedDevice;

		public event EventHandler ScanComplete = delegate {};
		public event EventHandler<DeviceDiscoveredEventArgs> DeviceDiscovered = delegate {};
		public event EventHandler<FeedbackEventArgs> Feedback = delegate {};

		protected BluetoothManager Manager;
		protected BluetoothAdapter Adapter;
		protected GattCallback LeGattCallback;

		private static BTDiscoveryInterface m_current;
		private bool m_isScanning = false;
		private readonly List<BNDevice> m_discoveredDevices = new List<BNDevice>();


		static BTDiscoveryInterface()
		{
			m_current = new BTDiscoveryInterface();
		}

		#region Accessors

		public static BTDiscoveryInterface Current
		{
			get { return m_current; }
		}


		/// <summary>
		/// Whether or not we're currently scanning for peripheral devices
		/// </summary>
		/// <value><c>true</c> if this instance is scanning; otherwise, <c>false</c>.</value>
		public bool IsScanning
		{
			get { return m_isScanning; }
		}

		/// <summary>
		/// Gets the discovered peripherals.
		/// </summary>
		/// <value>The discovered peripherals.</value>
		public List<BNDevice> DiscoveredDevices
		{
			get { return m_discoveredDevices; }
		}

		#endregion

		protected BTDiscoveryInterface()
		{
			Context appContext = Android.App.Application.Context;

			// get a reference to the bluetooth system service
			Manager = (BluetoothManager)appContext.GetSystemService("bluetooth");
			Adapter = Manager.Adapter;

			LeGattCallback = new GattCallback(this);

			DiscoveryTimeoutMSecs = 5000;
		}

		private void OnFeedbackDbg(string text)
		{
			Feedback(this, new FeedbackEventArgs(FeedbackEventType.Dbg, text));
		}

		#region Discovery

		public async Task BeginScanningForDevices()
		{
			OnFeedbackDbg("BTCentralInterface: Starting a scan for devices.");

			// clear out the list
			m_discoveredDevices.Clear();

			// start scanning
			m_isScanning = true;
			Adapter.StartLeScan(this);

			// in n seconds, stop the scan
			await Task.Delay(DiscoveryTimeoutMSecs);

			// if we're still scanning
			if (m_isScanning)
			{
				OnFeedbackDbg("BTCentralInterface: Scan timeout has elapsed.");
				Adapter.StopLeScan(this);
				ScanComplete(this, new EventArgs());
			}
		}

		/// <summary>
		/// Stops the Central Bluetooth Manager from scanning for more devices.
		/// Automatically called after scan timeout to prevent battery drain. 
		/// </summary>
		public void StopScanningForDevices()
		{
			OnFeedbackDbg("BTCentralInterface: Stopping the scan for devices.");
			m_isScanning = false;	
			Adapter.StopLeScan(this);
		}

		public void OnLeScan(BluetoothDevice device, int rssi, byte[] scanRecord)
		{
			Console.WriteLine("LeScanCallback: " + device.Name);
			if (!DeviceExistsInDiscoveredList(device))
			{
				BNDevice dev = new BNDevice(device, scanRecord, rssi);
				m_discoveredDevices.Add(dev);
				DeviceDiscovered(this, new DeviceDiscoveredEventArgs { Device = device, Rssi = rssi, ScanRecord = scanRecord });
				OnFeedbackDbg(string.Format("HB: {0} ({1})", AddressUtils.LongToHex(dev.Address), dev.Name));
			}
		}

		protected bool DeviceExistsInDiscoveredList(BluetoothDevice device)
		{
			foreach (BNDevice d in m_discoveredDevices)
			{
				long realAddress = AddressUtils.HexToLong(device.Address);
				if (realAddress == d.PhysicalAddress)
					return true;
			}
			return false;
		}

		protected BNDevice GetDiscoveredDevice(long address)
		{
			foreach (BNDevice d in m_discoveredDevices)
			{
				if (address == d.PhysicalAddress)
					return d;
			}
			return null;
		}

		#endregion


		#region Event arguments

		public class DeviceDiscoveredEventArgs : EventArgs
		{
			public BluetoothDevice Device;
			public int Rssi;
			public byte[] ScanRecord;

			public DeviceDiscoveredEventArgs()
				: base()
			{
			}
		}

		public class DeviceConnectedArgs : EventArgs
		{
			public BNDevice ConnectedDevice = null;
			public bool Success = false;

			public DeviceConnectedArgs(BNDevice connectedDevice, bool success)
			{
				ConnectedDevice = connectedDevice;
				Success = success;
			}
		}

		public class ServicesDiscoveredEventArgs : EventArgs
		{
			public BluetoothGatt Gatt;
			public bool Success;

			public ServicesDiscoveredEventArgs()
				: base()
			{
			}
		}

		#endregion

		#region GATT callbacks

		protected class GattCallback : BluetoothGattCallback
		{
			protected BTDiscoveryInterface Parent;

			public GattCallback(BTDiscoveryInterface parent)
			{
				Parent = parent;
			}

			public override void OnConnectionStateChange(BluetoothGatt gatt, GattStatus status, ProfileState newState)
			{
				Console.WriteLine("OnConnectionStateChange: ");
				base.OnConnectionStateChange(gatt, status, newState);

				switch (newState)
				{
					case ProfileState.Disconnected:
						Console.WriteLine("disconnected");
						//if (Parent.ConnectedDevices.ContainsKey(gatt.Device))
						//	Parent.ConnectedDevices.Remove(gatt.Device);
						break;

					case ProfileState.Connecting:
						Console.WriteLine("Connecting");
						break;

					case ProfileState.Connected:
						Console.WriteLine("Connected");

						//if (!Parent.m_connectedDevices.ContainsKey(gatt.Device))
						//{
						//	Parent.m_connectedDevices.Add(gatt.Device, gatt);
						//}
						//
						//BNDevice device = Parent.GetDiscoveredDevice(AddressUtils.HexToLong(gatt.Device.Address));
						//if (device == null)
						//{
						//	device = new BNDevice(gatt.Device, null, 0);
						//}
						//Parent.ConnectedDevice = device;
						//Parent.OnFeedbackDbg("Connected peripheral: " + device.Name);
						//Parent.InitializeDevice(gatt.Device);
						break;

					case ProfileState.Disconnecting:
						Console.WriteLine("Disconnecting");
						break;
				}
			}
		}

		#endregion

		#region Utilities

		/// <summary>
		/// Returns the IEEE Bluetooth Board Address of the host.
		/// </summary>
		/// <returns>The local address or 0 on error</returns>
		public static long GetLocalAddress()
		{
			long address;

			try
			{
				address = AddressUtils.HexToLong(BluetoothAdapter.DefaultAdapter.Address);	
			}
			catch (Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message);
				address = 0;
			}

			return address;
		}

		#endregion
	}

}
