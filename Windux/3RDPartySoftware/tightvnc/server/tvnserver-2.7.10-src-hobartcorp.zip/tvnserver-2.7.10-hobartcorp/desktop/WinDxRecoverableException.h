// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDXRECOVERABLEEXCEPTION_H__
#define __WINDXRECOVERABLEEXCEPTION_H__

#include "WinDxException.h"

class WinDxRecoverableException : public WinDxException
{
public:
  WinDxRecoverableException(const TCHAR *message, HRESULT errCode);
  virtual ~WinDxRecoverableException();
};

#endif // __WINDXRECOVERABLEEXCEPTION_H__
