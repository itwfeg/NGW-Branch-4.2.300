var LoginCtrl = function($scope, $http, lpApi) {
  Debug.log('Loaded LoginCtrl');
  // Properties
  $scope.unsupportedBrowsers = [{
      href: 'http://www.google.com/chrome',
      imgSrc: 'img/icon/32/browser-chrome.gif',
      imgClass: 'icon',
      imgTitle: 'Chrome'
    }, {
      href: 'http://windows.microsoft.com/en-US/internet-explorer/products/ie/home',
      imgSrc: 'img/icon/32/browser-msie.gif',
      imgClass: 'icon',
      imgTitle: 'Internet Explorer'
    }, {
      href: 'http://www.firefox.com/',
      imgSrc: 'img/icon/32/browser-firefox.gif',
      imgClass: 'icon',
      imgTitle: 'Firefox'
    }, {
      href: 'http://www.apple.com/safari',
      imgSrc: 'img/icon/32/browser-safari.gif',
      imgClass: 'icon',
      imgTitle: 'Safari'
    }];

  // Functions
  $scope.authenticate = function(username, password, $http){
    var data = {auth: {username: username, password: password}};
    $http.post(lpApi.getUrl('')+'/login', data)
      .error($scope.postError)
      .success($scope.setAuthState);
    return true;
  };

  $scope.login = function($scope, lpApi) {
    if($scope.isAuthenticated() && lpApi.logOff) {
      lpApi.logOff();
      $scope.setRouteReload('/login');
    }
    $scope.setLocalPortalContainer('container-small');
    $scope.setLoggedInStatus(false);
  };

  $scope.setAuthState = function(data, status, headers, config){
    lpApi.authState.sessionId = data.sessionId || null;
    lpApi.authState.roles = data.roles || null;
    lpApi.authState.requirePasswordChange = data.requirePasswordChange || null;
    lpApi.authState.success = data.success;
    if (data.success) {
      lpApi._setAuthTime(new Date().getTime());
      $scope.setLocalPortalContainer('container');
      $scope.setLoggedInStatus(true);
      $scope.setRoute('/home');
      var url = document.location.href;
Debug.log(url, "document.location.href");
      url = url.substring(0,url.indexOf('#'))+'#/home';
Debug.log(url, "document.location.href");
      document.location.assign(url);
      document.location.reload(true);
    }
    else {
      // output error message
      $scope.setSystemMsg(data.errorMessage[0], 'error');
    }
  };

  $scope.submit = function(){
    if ($scope.authenticate(this.input_username, this.input_password, $http)) {
      $('#loading').hide();
    }
  };

  $scope.login($scope, lpApi);
  $('#loading').hide();
};

LoginCtrl.$inject = ['$scope', '$http', 'lpApi'];
