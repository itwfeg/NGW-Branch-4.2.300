// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "WindowFinder.h"

struct WindowsParam
{
  std::vector<HWND> *hwndVector;
  StringVector *classNames;
};

BOOL CALLBACK WindowFinder::findWindowsByClassFunc(HWND hwnd, LPARAM lParam)
{
  if (IsWindowVisible(hwnd) != 0) {
    WindowsParam *windowsParam = (WindowsParam *)lParam;
    StringVector::iterator classNameIter;

    const size_t maxTcharCount = 256;
    TCHAR winName[maxTcharCount];
    if (GetClassName(hwnd, winName, maxTcharCount) != 0) {
      StringStorage nextWinName(winName);

      if (nextWinName.getLength() > 0 && hwnd != 0) {
        for (classNameIter = windowsParam->classNames->begin();
             classNameIter != windowsParam->classNames->end(); classNameIter++) {
          if (nextWinName.isEqualTo(&(*classNameIter))) {
            windowsParam->hwndVector->push_back(hwnd);
          }
        }
      }

      // Recursion
      EnumChildWindows(hwnd, findWindowsByClassFunc, (LPARAM) windowsParam);
    }
  }
  return TRUE;
}

void WindowFinder::findWindowsByClass(StringVector *classNames,
                                      std::vector<HWND> *hwndVector)
{
  hwndVector->clear();
  if (!classNames->empty()) {
    WindowsParam windowsParam;
    windowsParam.classNames = classNames;
    windowsParam.hwndVector = hwndVector;
    EnumWindows(findWindowsByClassFunc, (LPARAM)&windowsParam);
  }
}

BOOL CALLBACK WindowFinder::findWindowsByNameFunc(HWND hwnd, LPARAM lParam)
{
  if (IsWindowVisible(hwnd) != 0) {
    const size_t maxTcharCount = 256;
    TCHAR nameChars[maxTcharCount];
    if (GetWindowText(hwnd, nameChars, maxTcharCount) != 0) {
      StringStorage winName(nameChars);
      winName.toLowerCase();

      if (winName.getLength() > 0 && hwnd != 0) {
        WindowsParam *winParams = (WindowsParam *)lParam;
        StringStorage *substr = &(*(winParams->classNames)).front();
        if (_tcsstr(winName.getString(), substr->getString()) != 0) {
          (*(winParams->hwndVector)).push_back(hwnd);
          return FALSE;
        }
      }
    }
  }
  return TRUE;
}

HWND WindowFinder::findFirstWindowByName(const StringStorage *windowName)
{
  std::vector<HWND> hwndVector;
  StringVector winNameVector;
  winNameVector.push_back(*windowName);
  winNameVector[0].toLowerCase();
  WindowsParam winParams = { &hwndVector, &winNameVector };

  EnumWindows(findWindowsByNameFunc, (LPARAM)&winParams);
  if (hwndVector.size() != 0) {
    return hwndVector[0];
  } else {
    return 0;
  }
}
