
showPythonVersion.py

pause

