// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "JpegEncoder.h"

JpegEncoder::JpegEncoder(TightEncoder *tightEncoder)
: Encoder(tightEncoder->m_pixelConverter, tightEncoder->m_output),
  m_tightEncoder(tightEncoder)
{
}

JpegEncoder::~JpegEncoder()
{
}

int JpegEncoder::getCode() const
{
  return m_tightEncoder->getCode();
}

void JpegEncoder::splitRectangle(const Rect *rect,
                                 std::vector<Rect> *rectList,
                                 const FrameBuffer *serverFb,
                                 const EncodeOptions *options)
{
  int maxWidth = 2048;
  for (int x0 = rect->left; x0 < rect->right; x0 += maxWidth) {
    int x1 = (x0 + maxWidth <= rect->right) ? x0 + maxWidth : rect->right;
    rectList->push_back(Rect(x0, rect->top, x1, rect->bottom));
  }
}

void JpegEncoder::sendRectangle(const Rect *rect,
                                const FrameBuffer *serverFb,
                                const EncodeOptions *options)
{
  size_t bppServer = m_pixelConverter->getSrcBitsPerPixel();
  size_t bppClient = m_pixelConverter->getDstBitsPerPixel();
  bool goodColorResolution = (bppServer >= 16 && bppClient >= 16);

  if (options->jpegEnabled() && goodColorResolution) {
    m_tightEncoder->sendJpegRect(rect, serverFb, options);
  } else {
    m_tightEncoder->sendRectangle(rect, serverFb, options);
  }
}
