// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __LOGCONNAUTHLISTENER_H__
#define __LOGCONNAUTHLISTENER_H__

#include "LogConn.h"

class LogConnAuthListener
{
public:
  // @return a FileLogHandle value on success (may be zero) and zero on fail.
  virtual FileAccountHandle onLogConnAuth(LogConn *logConn, bool success,
                                          const TCHAR *fileName) = 0;
  virtual void onDisconnect(LogConn *logConn) = 0;
};

#endif // __LOGCONNAUTHLISTENER_H__
