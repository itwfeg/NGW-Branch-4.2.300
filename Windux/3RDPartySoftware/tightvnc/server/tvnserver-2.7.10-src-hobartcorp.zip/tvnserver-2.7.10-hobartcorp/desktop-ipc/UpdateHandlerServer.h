// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDATEHANDLERSERVER_H__
#define __UPDATEHANDLERSERVER_H__

#include "DesktopServerProto.h"
#include "desktop/UpdateHandlerImpl.h"
#include "DesktopSrvDispatcher.h"
#include "log-writer/LogWriter.h"
#include "desktop/Win32ScreenDriverFactory.h"

class UpdateHandlerServer: public DesktopServerProto, public ClientListener,
                           public UpdateListener
{
public:
  UpdateHandlerServer(BlockingGate *forwGate,
                      DesktopSrvDispatcher *dispatcher,
                      AnEventListener *extTerminationListener,
                      LogWriter *log);
  virtual ~UpdateHandlerServer();

  // Internal dispatcher
  virtual void onRequest(UINT8 reqCode, BlockingGate *backGate);

protected:
  virtual void onUpdate();

  // At first time server must get init information.
  void serverInit(BlockingGate *backGate);

  void extractReply(BlockingGate *backGate);
  void screenPropReply(BlockingGate *backGate);
  void receiveFullReqReg(BlockingGate *backGate);
  void receiveExcludingReg(BlockingGate *backGate);

  Win32ScreenDriverFactory m_scrDriverFactory;

  PixelFormat m_oldPf;

  UpdateHandlerImpl *m_updateHandler;
  AnEventListener *m_extTerminationListener;

  LogWriter *m_log;
};

#endif // __UPDATEHANDLERSERVER_H__
