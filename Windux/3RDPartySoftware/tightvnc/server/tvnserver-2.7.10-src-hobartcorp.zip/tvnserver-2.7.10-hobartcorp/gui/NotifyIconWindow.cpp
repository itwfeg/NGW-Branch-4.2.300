// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "NotifyIconWindow.h"

NotifyIconWindow::NotifyIconWindow()
: m_wph(0)
{
  //
  // Register window class
  //

  WNDCLASS wc;

  wc.style = 0;
  wc.lpfnWndProc = WindowProcHolder::defWindowProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 0;
  wc.hInstance = GetModuleHandle(0);
  wc.hIcon = NULL;
  wc.hCursor = NULL;
  wc.hbrBackground = NULL;
  wc.lpszMenuName = NULL;
  wc.lpszClassName = _T("NotifyIconWindowClass");

  ATOM atom = RegisterClass(&wc);

  //
  // Create window
  //

  m_window = CreateWindow((LPCTSTR)atom,
                          (LPCTSTR)_T("NotifyIconWindowTitle"),
                          WS_OVERLAPPED,
                          CW_USEDEFAULT, CW_USEDEFAULT,
                          CW_USEDEFAULT, CW_USEDEFAULT,
                          NULL, NULL, GetModuleHandle(0), NULL);

  SetWindowLongPtr(m_window, GWLP_USERDATA, (LONG_PTR)m_wph);
}

NotifyIconWindow::~NotifyIconWindow()
{
  setWindowProcHolder(NULL);

  //DestroyWindow(m_window);
}

HWND NotifyIconWindow::getWindow()
{
  return m_window;
}

void NotifyIconWindow::setWindowProcHolder(WindowProcHolder *wph)
{
  m_wph = wph;

  SetWindowLongPtr(m_window, GWLP_USERDATA, (LONG_PTR)m_wph);
}
