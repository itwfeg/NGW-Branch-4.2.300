var searchData=
[
  ['datadesctype',['DataDescType',['../structDSM__DATADESC.html#a4d0b15cc1a9f0b4bbbb09ea5f6ffbcf5',1,'DSM_DATADESC']]]
];
