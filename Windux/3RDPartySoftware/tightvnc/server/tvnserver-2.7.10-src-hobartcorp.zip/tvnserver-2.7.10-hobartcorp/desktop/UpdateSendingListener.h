// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDATESENDINGLISTENER_H__
#define __UPDATESENDINGLISTENER_H__

#include "rfb/CursorShape.h"
#include "rfb/FrameBuffer.h"
#include "UpdateContainer.h"

class UpdateSendingListener
{
public:
  virtual ~UpdateSendingListener() {}
  virtual void onSendUpdate(const UpdateContainer *updateContainer,
                            const CursorShape *cursorShape) = 0;
  virtual bool isReadyToSend() = 0;
};

#endif // __UPDATESENDINGLISTENER_H__
