// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WIN32SCREENDRIVERFACTORY_H__
#define __WIN32SCREENDRIVERFACTORY_H__

#include "ScreenDriverFactory.h"
#include "server-config-lib/ServerConfig.h"

class Win32ScreenDriverFactory : public ScreenDriverFactory
{
public:
  // The factory stores pointer to a ServerConfig object and will use it on
  // createScreenDriver() function calls.
  Win32ScreenDriverFactory(ServerConfig *srvConf);
  virtual ~Win32ScreenDriverFactory();

  virtual ScreenDriver *createScreenDriver(UpdateKeeper *updateKeeper,
                                             UpdateListener *updateListener,
                                             FrameBuffer *fb,
                                             LocalMutex *fbLocalMutex,
                                             LogWriter *log);
private:
  ScreenDriver *createStandardScreenDriver(UpdateKeeper *updateKeeper,
                                             UpdateListener *updateListener,
                                             FrameBuffer *fb,
                                             LocalMutex *fbLocalMutex,
                                             LogWriter *log);
  ScreenDriver *createMirrorScreenDriver(UpdateKeeper *updateKeeper,
                                           UpdateListener *updateListener,
                                           LocalMutex *fbLocalMutex,
                                           LogWriter *log);

  bool isMirrorDriverAllowed();

  ServerConfig *m_srvConf;
};

#endif // __WIN32SCREENDRIVERFACTORY_H__
