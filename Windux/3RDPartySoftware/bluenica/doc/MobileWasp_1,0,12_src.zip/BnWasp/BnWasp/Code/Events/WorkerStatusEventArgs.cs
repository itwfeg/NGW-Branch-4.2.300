﻿using System;

namespace BnWasp
{
	public class WorkerStatusEventArgs : EventArgs
	{
		public int Tags { get; private set; }
		public int Records { get; private set; }

		public WorkerStatusEventArgs(int tags, int records)
		{
			Tags = tags;
			Records = records;
		}
	}

}

