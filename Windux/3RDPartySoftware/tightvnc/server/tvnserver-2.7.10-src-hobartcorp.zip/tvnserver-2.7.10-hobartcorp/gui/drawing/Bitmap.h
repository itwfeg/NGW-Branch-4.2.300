// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __BITMAP_H__
#define __BITMAP_H__

#include "util/CommonHeader.h"

#include <string>
#include <sstream>

// Class manipulating windows HBITMAP object
// 
//
class Bitmap
{
public:
  // Creates empty bitmap with specified size.
  Bitmap(int width, int height);
  // Creates compatible with dc bitmap with specified size.
  Bitmap(HDC dc, int width, int height);
  // Creates bitmap from HBITMAP object.
  Bitmap(HBITMAP bitmap);
  // Destroys bitmap object.
  virtual ~Bitmap();

  // Returns bitmap width.
  int getWidth() const;
  // Returns bitmap height.
  int getHeight() const;
protected:
  HBITMAP m_bitmap;

  friend class Icon;
  friend class Graphics;
  friend class BitmapGraphics;
};

#endif
