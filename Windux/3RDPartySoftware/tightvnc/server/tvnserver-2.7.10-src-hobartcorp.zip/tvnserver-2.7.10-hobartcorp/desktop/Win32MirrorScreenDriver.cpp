// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "Win32MirrorScreenDriver.h"
#include "util/Exception.h"

Win32MirrorScreenDriver::Win32MirrorScreenDriver(UpdateKeeper *updateKeeper,
                                                 UpdateListener *updateListener,
                                                 LocalMutex *fbLocalMutex,
                                                 LogWriter *log)
: Win32ScreenDriverBaseImpl(updateKeeper, updateListener, fbLocalMutex, log),
  m_mirrorDriver(updateKeeper, updateListener, fbLocalMutex, log)
{
  // At this point the screen driver has valid screen properties.
}

Win32MirrorScreenDriver::~Win32MirrorScreenDriver()
{
  terminateDetection();
}

void Win32MirrorScreenDriver::executeDetection()
{
  Win32ScreenDriverBaseImpl::executeDetection();
  m_mirrorDriver.executeDetection();
}

void Win32MirrorScreenDriver::terminateDetection()
{
  Win32ScreenDriverBaseImpl::terminateDetection();
  m_mirrorDriver.terminateDetection();
}

Dimension Win32MirrorScreenDriver::getScreenDimension()
{
  return m_mirrorDriver.getScreenDimension();
}

FrameBuffer *Win32MirrorScreenDriver::getScreenBuffer()
{
  return m_mirrorDriver.getScreenBuffer();
}

bool Win32MirrorScreenDriver::grabFb(const Rect *rect)
{
  return m_mirrorDriver.grab(rect);
}

bool Win32MirrorScreenDriver::getScreenPropertiesChanged()
{
  return m_mirrorDriver.getPropertiesChanged();
}

bool Win32MirrorScreenDriver::getScreenSizeChanged()
{
  return m_mirrorDriver.getScreenSizeChanged();
}

bool Win32MirrorScreenDriver::applyNewScreenProperties()
{
  return m_mirrorDriver.applyNewProperties();
}
