// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDATEHANDLERIMPL_H__
#define __UPDATEHANDLERIMPL_H__

#include "UpdateHandler.h"
#include "ScreenDriver.h"
#include "ScreenDriverFactory.h"

// This class contain a base architecture implementation of the UpdateHandler class.
class UpdateHandlerImpl : public UpdateHandler, public UpdateListener
{
public:
  UpdateHandlerImpl(UpdateListener *externalUpdateListener, ScreenDriverFactory *scrDriverFactory,
                    LogWriter *log);
  virtual ~UpdateHandlerImpl();

  virtual void extract(UpdateContainer *updateContainer);
  virtual void setFullUpdateRequested(const Region *region);
  bool checkForUpdates(Region *region);

  virtual void setExcludedRegion(const Region *excludedRegion);

private:
  virtual void executeDetectors();
  virtual void terminateDetectors();

  void doUpdate()
  {
    if (m_externalUpdateListener) {
      m_externalUpdateListener->onUpdate();
    }
  }

  virtual void onUpdate();

  void applyNewScreenProperties();

  UpdateKeeper m_updateKeeper;
  ScreenDriver *m_screenDriver;
  UpdateFilter *m_updateFilter;
  UpdateListener *m_externalUpdateListener;

  Rect m_absoluteRect;

  LogWriter *m_log;

  bool m_fullUpdateRequested;
};

#endif // __UPDATEHANDLERIMPL_H__
