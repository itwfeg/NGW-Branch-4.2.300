// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __LOGLISTENER_H__
#define __LOGLISTENER_H__

#include "FileLogDefs.h"
#include "util/DateTime.h"

class LogListener
{
public:
  virtual void onLog(FileAccountHandle handle,
                     unsigned int processId,
                     unsigned int threadId,
                     const DateTime *dt,
                     int level,
                     const TCHAR *message) = 0;
  virtual void onAnErrorFromLogConn(const TCHAR *message) = 0;
};

#endif // __LOGLISTENER_H__
