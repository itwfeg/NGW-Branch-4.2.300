﻿using System;
using System.Collections.Generic;

namespace BnWasp
{
	public class DiscoveringWaspData
	{
		public int RecordsCount { get { return m_recordStorage.Count; } }

		public int TagsCount { get { return m_tagsLookup.Count; } }

		// 16 is the maximal possible size due to scan record limit of 31 bytes
		public const byte AdvRecDataSize = 16;
		public const byte AdvRecTotSize = 1 + 4 + 2 + AdvRecDataSize; // idx, utc, name, data

		// One byte in the data protocol limits the number of unique sensors to 256
		private const int MaxTags = 256;

		// A lookup dictionary of all discovered devices.
		// Each device gets assigned a unique one byte index.
		// This could be also implemented as a simple array of device addresses
		// where the array index is the assigned device one byte index.
		private readonly Dictionary<long, byte> m_tagsLookup;

		// Data records storage
		private readonly List<OneRecord> m_recordStorage;


		public DiscoveringWaspData()
		{
			m_tagsLookup = new Dictionary<long, byte>();
			m_recordStorage = new List<OneRecord>();
			Clear();
		}

		public void Clear()
		{
			m_tagsLookup.Clear();
			m_recordStorage.Clear();
		}

		public bool AddNewRecord(BNDevice device)
		{
			long address = device.Address;
			if (address <= 0)
				return false;

			int index = GetTagIndex(address);
			if (index < 0) // new device
			{
				index = AddNewTag(address);
			}

			if (index < 0)
				return false; // no space for more tags

			UInt32 recId = device.RecId;
			if (!CheckRecordExists((byte)index, recId))
			{
				DoAddRecord((byte)index, device);
				return true;
			}

			return false;
		}


		private int GetTagIndex(long address)
		{
			if (m_tagsLookup.ContainsKey(address))
			{
				return m_tagsLookup[address];
			}

			return -1;
		}

		/// <summary>
		/// Adds the new tag address to the lookup dictionary.
		/// Returns the index the Tag got assigned.
		/// </summary>
		/// <returns>Tag index</returns>
		/// <param name="address">Address.</param>
		private int AddNewTag(long address)
		{
			if (m_tagsLookup.Count >= MaxTags)
				return -1;

			m_tagsLookup.Add(address, (byte)m_tagsLookup.Count);
			return m_tagsLookup.Count - 1;
		}

		private bool CheckRecordExists(byte index, UInt32 recId)
		{
			foreach (OneRecord rec in m_recordStorage)
			{
				if (rec.TagIndex == index && rec.RecId == recId)
					return true;
			}

			return false;
		}

		private void DoAddRecord(byte index, BNDevice device)
		{
			OneRecord rec = new OneRecord();
			rec.TagIndex = index;
			rec.RecId = device.RecId;
			rec.Data = BuildDataBuffer(device.ManufacturerData);
			rec.Name[0] = (byte)device.Name[0]; // 1st and 3rd byte only, no need to store the mandatory "#"
			rec.Name[1] = (byte)device.Name[2];
			rec.Utc = DateTime.UtcNow;

			m_recordStorage.Add(rec);
		}

		/// <summary>
		/// Builds the data buffer containing the sensor payload.
		/// </summary>
		/// <returns>16 byte long buffer with sensor payload</returns>
		/// <param name="bytes">Manufacturer-specific data buffer starting right after LEN (23-25) and FF</param>
		byte[] BuildDataBuffer(byte[] bytes)
		{
			byte[] bff = new byte[AdvRecDataSize];

			const int startOffs = 8; // time since last download
			int offs;
			for (int i = 0; i < bff.Length; i++)
			{
				offs = startOffs + i;
				bff[i] = (offs < bytes.Length) ? bytes[offs] : (byte)0;
			}

			return bff;
		}

		public List<OneTag> GetTags()
		{
			List<OneTag> list = new List<OneTag>();

			foreach (KeyValuePair<long, byte> tag in m_tagsLookup)
			{
				list.Add(new OneTag(tag.Key, tag.Value));
			}

			return list;
		}

		public List<OneRecord> GetRecords()
		{
			return m_recordStorage;
		}

		public class OneTag
		{
			public long Address;
			public byte Index;

			public OneTag(long address, byte index)
			{
				Address = address;
				Index = index;
			}
		}

		public class OneRecord
		{
			public UInt32 RecId;
			public byte TagIndex;
			public DateTime Utc;
			public byte[] Data;
			public byte[] Name = new byte[2];
		}

	}

}

