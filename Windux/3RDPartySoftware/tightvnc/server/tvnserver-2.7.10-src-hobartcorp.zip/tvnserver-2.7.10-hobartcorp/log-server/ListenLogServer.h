// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __LISTENLOGSERVER_H__
#define __LISTENLOGSERVER_H__

#include "thread/Thread.h"
#include "win-system/PipeServer.h"
#include "ConnectionListener.h"

class ListenLogServer : private Thread
{
public:
  ListenLogServer(const TCHAR *publicPipeName,
                  ConnectionListener *connListener);
  virtual ~ListenLogServer();

private:
  virtual void execute();

  PipeServer *m_listenPipe;
  SecurityAttributes m_pipeSecurity;

  ConnectionListener *m_connListener;
  WindowsEvent m_timer;
};

#endif // __LISTENLOGSERVER_H__
