// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __DESKTOPCONFIGLOCAL_H__
#define __DESKTOPCONFIGLOCAL_H__

#include "InputBlocker.h"
#include "log-writer/LogWriter.h"

class DesktopConfigLocal
{
public:
  DesktopConfigLocal(LogWriter *log);
  virtual ~DesktopConfigLocal();

  virtual void updateByNewSettings();

  virtual bool isRemoteInputAllowed();
  virtual DateTime getLastInputTime() const;
  virtual void correctLastTime(DateTime newTime);

private:
  InputBlocker *m_inputBlocker;
};

#endif // __DESKTOPCONFIGLOCAL_H__
