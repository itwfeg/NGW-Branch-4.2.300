// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDXGISURFACE_H__
#define __WINDXGISURFACE_H__

#include <d3d11.h>
#include <DXGI1_2.h>

class WinDxgiSurface
{
public:
  // Surface will be created by the ID3D11Texture2D's QueryInterface() function call.
  WinDxgiSurface(ID3D11Texture2D *texture2D);
  virtual ~WinDxgiSurface();

  IDXGISurface *getSurface() const;

private:
  IDXGISurface *m_dxgiSurface;
};

#endif // __WINDXGISURFACE_H__
