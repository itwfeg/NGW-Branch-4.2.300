// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "DesktopConfigLocal.h"
#include "server-config-lib/Configurator.h"
#include "desktop/WindowsInputBlocker.h"

DesktopConfigLocal::DesktopConfigLocal(LogWriter *log)
{
  m_inputBlocker = new WindowsInputBlocker(log);
}

DesktopConfigLocal::~DesktopConfigLocal()
{
  delete m_inputBlocker;
}

void DesktopConfigLocal::updateByNewSettings()
{
  ServerConfig *srvConf = Configurator::getInstance()->getServerConfig();
  bool hardBlocking = srvConf->isBlockingLocalInput();
  m_inputBlocker->setKeyboardBlocking(hardBlocking);
  m_inputBlocker->setMouseBlocking(hardBlocking);

  bool softBlocking = srvConf->isLocalInputPriorityEnabled();
  unsigned int interval = srvConf->getLocalInputPriorityTimeout() * 1000;
  m_inputBlocker->setSoftKeyboardBlocking(softBlocking, interval);
  m_inputBlocker->setSoftMouseBlocking(softBlocking, interval);
}

bool DesktopConfigLocal::isRemoteInputAllowed()
{
  return m_inputBlocker->isRemoteInputAllowed();
}

DateTime DesktopConfigLocal::getLastInputTime() const
{
  return m_inputBlocker->getLastInputTime();
}

void DesktopConfigLocal::correctLastTime(DateTime newTime)
{
  m_inputBlocker->correctLastTime(newTime);
}
