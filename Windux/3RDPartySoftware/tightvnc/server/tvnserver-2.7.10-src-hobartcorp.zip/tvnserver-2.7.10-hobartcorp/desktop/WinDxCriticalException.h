// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDXCRITICALEXCEPTION_H__
#define __WINDXCRITICALEXCEPTION_H__

#include "WinDxException.h"

class WinDxCriticalException : public WinDxException
{
public:
  WinDxCriticalException(const TCHAR *message, HRESULT errCode);
  virtual ~WinDxCriticalException();
};

#endif // __WINDXCRITICALEXCEPTION_H__
