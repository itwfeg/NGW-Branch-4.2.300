// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _HTTP_REQUEST_HANDLER_H_
#define _HTTP_REQUEST_HANDLER_H_

#include "io-lib/DataInputStream.h"
#include "io-lib/DataOutputStream.h"
#include "log-writer/LogWriter.h"

class HttpRequestHandler
{
public:
  HttpRequestHandler(DataInputStream *dataInput, DataOutputStream *dataOutput, LogWriter *log,
                     const TCHAR *peerHost = 0);
  virtual ~HttpRequestHandler();

  // Reads HTTP request from input and sends responce to output.
  virtual void processRequest() throw(IOException);

protected:
  DataInputStream *m_dataInput;
  DataOutputStream *m_dataOutput;
  StringStorage m_peerHost;

  LogWriter *m_log;
};

#endif
