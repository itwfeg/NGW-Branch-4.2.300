import os
import shutil
import sys
import installUtils
import installUpgrade
import messageBox
PYTHON_PATH = '/usr/local/hobart/python'
sys.path.append(PYTHON_PATH)
import license
import getModelName
import time

FEATURE_NAME = 'wm_cake_labellic'
FEATURE_FILENAME = FEATURE_NAME + '.tgz'
FEATURE_INSTALLER_NAME = FEATURE_NAME + '_install.py'
FEATURE_INSTALL_PATH = os.path.join(installUtils.getFeatureRoot(), FEATURE_NAME)
DOWNLOAD_PATH = os.path.join('/','usr','local','hobart','download')
PENDING_PATH = os.path.join('/','usr','local','hobart','pending')
BACKEND_PATH = os.path.join('/','usr','local','hobart','backend')
DEVICE = 'hti'
SUPPORTED_SYSTEM = 'linux'

# feature file stuff
LICENSE_FILE = 'remote_printing.lic'

def installLicense(licenseFile):
    # read the flash key buffer
    xmlLicenseBuffer = license.readFlashKeyBuffer()

    if xmlLicenseBuffer == None:
         xmlLicenseBuffer = license.xmlCreateInitialLicenseBuffer()
     # get elements in license file
    #status, individualName, companyName, companyAddress, productNames, licenseType, licenseActivationDate, licenseAllotment, licenseTimeout, licenseKey = license.getLicenseElements(licenseFile)
    
    individualName = 'Wal-Mart Stores'
    companyName = 'WAL-MART INC.' 
    companyAddress = '805 MOBERLY LANE\nBENTONVILLE, AR 72716-0310' 
    productNames = ["SCALE_REMOTE_PRINTING"]
    licenseType = 'USB_SERIAL_NUMBER' 
    licenseActivationDate = '2019-04-01' 
    licenseAllotment = '1' 
    licenseTimeout = '0' 
    licenseKey = '023FC05B7B392D98DAAEFFA390801342007A95F0' 

    addLicense = False

    # see if products in license are already licensed
    for i in xrange(0, len(productNames)):
        if not license.isProductLicensed(xmlLicenseBuffer, productNames[i]):
            # did not find product name so add license
            addLicense = True

    myExitCode = 0
    # at least one product not licensed in flash so need to add license
    if addLicense:
        # update xml license buffer with new key
        xmlLicenseBuffer = license.xmlAddLicenseToBuffer(xmlLicenseBuffer, individualName, companyName, companyAddress, productNames, licenseType, licenseActivationDate, licenseAllotment, licenseTimeout, licenseKey)
        # write the flash key buffer
        status,  message = license.writeFlashKeyBuffer(xmlLicenseBuffer)
        if status == 'success':
              message = "License key installed."
        else: 
            message = 'License key could not be installed.'
        myExitCode,  mbId = messageBox.display(message, timer=2)
        messageBox.destroy(mbId)
    return myExitCode
    
# --- starting ---
    
exitCode = 0

exitCode |= installUtils.setPythonRoot()

# ----------------------
exit_code, process_id = messageBox.display('Installing application license')
exitCode = installLicense(os.path.join(FEATURE_INSTALL_PATH,LICENSE_FILE))
messageBox.destroy(process_id)

# sync filesystem and reboot
os.system("/bin/sync")

sys.exit(0)

