// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

// The header including of this cpp file must be at last place to avoid build conflicts.
#include "WinCustomD3D11Texture2D.h"

WinCustomD3D11Texture2D::Texture2DDescInitializer::Texture2DDescInitializer(UINT width, UINT height)
{
  m_desc.Width = width;
  m_desc.Height = height;
  m_desc.MipLevels = 1;
  m_desc.ArraySize = 1;
  m_desc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
  m_desc.SampleDesc.Count = 1;
  m_desc.SampleDesc.Quality = 0;
  m_desc.Usage = D3D11_USAGE_STAGING;
  m_desc.BindFlags = 0;
  m_desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
  m_desc.MiscFlags = 0;
}

D3D11_TEXTURE2D_DESC *WinCustomD3D11Texture2D::Texture2DDescInitializer::getDesc()
{
  return &m_desc;
}


WinCustomD3D11Texture2D::WinCustomD3D11Texture2D(ID3D11Device *device, UINT width, UINT height)
: m_textDescInitializer(width, height),
  m_textureWrapper(device, m_textDescInitializer.getDesc())
{
}

WinCustomD3D11Texture2D::~WinCustomD3D11Texture2D()
{

}

ID3D11Texture2D *WinCustomD3D11Texture2D::getTexture() const
{
  return m_textureWrapper.getTexture();
}
