// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDOWSMOUSEGRABBER_H__
#define __WINDOWSMOUSEGRABBER_H__

#include "CursorShapeGrabber.h"
#include "util/CommonHeader.h"
#include "win-system/Screen.h"

class WindowsCursorShapeGrabber : public CursorShapeGrabber
{
public:
  WindowsCursorShapeGrabber(void);
  virtual ~WindowsCursorShapeGrabber(void);

  virtual bool grab(const PixelFormat *pixelFormat);

  virtual bool isCursorShapeChanged();

private:
  bool grabPixels(const PixelFormat *pixelFormat);

  HCURSOR getHCursor();

  HCURSOR m_lastHCursor;
  Screen m_screen;
};

#endif // __WINDOWSMOUSEGRABBER_H__
