// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _COMMON_CONTROLS_EX_H_
#define _COMMON_CONTROLS_EX_H_

#include "util/Exception.h"

class CommonControlsEx
{
public:
  CommonControlsEx();
  virtual ~CommonControlsEx();

  static void init() throw(Exception);
};

#endif
