var searchData=
[
  ['company_5fprefix_5flength',['COMPANY_PREFIX_LENGTH',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a7648321db378897490dd5fa6d9670ea6',1,'SampleLabelEmbedder.cpp']]],
  ['count',['COUNT',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a2addb49878f50c95dc669e5fdbd130a2',1,'SampleLabelEmbedder.cpp']]]
];
