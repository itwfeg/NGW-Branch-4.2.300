var searchData=
[
  ['digimarclabelembedder',['DigimarcLabelEmbedder',['../namespaceDigimarcLabelEmbedder.html',1,'']]]
];
