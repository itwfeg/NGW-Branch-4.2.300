/*
 *
 *  DIGIMARC CORPORATION PROPRIETARY INFORMATION
 *  Copyright, Digimarc Corporation.  All Rights Reserved.
 *
 *  This software contains confidential information, including trade secrets,
 *  of Digimarc that is protected by the confidentiality agreement entered into
 *  between you and Digimarc.  It is important that this information be used only
 *  in accordance with your agreement with Digimarc.  Receipt of this software
 *  conveys no license under Digimarc's patent, trademark, trade secret, or
 *  copyright rights.  Use of this software - and the technology detailed therein -
 *  requires a license from Digimarc. The technology embodied in this software is
 *  protected by US and International Patents.
 *
 */

/**
 * @example ExampleGtinShared.cpp
 *

@section EGSH_library Static Library versus Shared Library
<div style="margin: .25in">
	@subsection EGSH_windows_library Windows
	The Windows Digimarc Label SDK static library is built with a specific Visual Studio Platform Toolset version.
	For compatibility with other versions of Visual Studio, it is recommended that you use the Digimarc Label SDK shared library DLL instead.
</div>

<div id="thick-hr"><hr></div>

 @section EGSH_link How to Link Shared Library
 <div style="margin: .25in">
 @subsection EGSH_link_windows Windows
 To link the shared library dlsdk_shared.dll, you will need to tell the compiler where the include files are
 and where the import library dlsdk_shared.lib is.

 For example, the following steps show you how to compile this example in 64-bit on command line in Visual Studio 2013.

 <ul>
   <li>First unzip the SDK package.</li>
   <li>Go to the <i>Sample Applications\\ExampleGtinShared</i> folder in the SDK package.</li>
   <li>On Windows comamnd prompt, set the appropriate path and environment variables for command line builds.
	   For example, for amd64 build, run the following:</li>
   <pre>
   "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\vsvarsall.bat" amd64
   </pre>
   <li>Then compile this example with the include path and the path to the shared library.</li>
   <pre>
   cl /EHsc /I ..\\..\\include dlsdk_shared.lib ExampleGtinShared.cpp
   </pre>
 </ul>

 @subsection EGSH_link_linux Linux
 To link the shared library libdlsdk_shared.so to your program, you will need to tell where the include files are
 and where the shared library is.

 For example, the following step show you how to compile and run this example in Linux using g++.
 <ul>
   <li>First unzip the SDK package.</li>
   <li>At shell prompt, go to the <i>Sample Applications/ExampleGtinShared</i> folder in the SDK package.</li>
   <li>Compile this example with the include path and the path to the shared library.</li>
   <pre>
   g++ -I ../../include/ ExampleGtinShared.cpp libdlsdk_shared.so
   </pre>
   <li>To run the compiled program, you will need to set the environment variable <i>LD_LIBRARY_PATH</i>.
	   Assuming the shared library libdlsdk_shared.so is in your current directory,
	   you can set the <i>LD_LIBRARY_PATH like this:</i></li>
   <pre>
   export LD_LIBRARY_PATH="./"
   </pre>
   <li>And then you can run this example like this:</li>
   <pre>
   ./ExampleGtinShared
   </pre>
 </ul>
 </div>

 <div id="thick-hr"><hr></div>

@section EGSH_setup Setup
<div style="margin: .25in">
	@subsection EGSH_setup_only_once Set Up Only Once
	Instead of opening and closing the embedder each time you embed a label, we recommend that you call @ref DSM_Open "DSM_Open" and @ref DSM_InitializeEmbedderOptions "DSM_InitializeEmbedderOptions"
	only once during initialization. And then you can call @ref DSM_EmbedSparseMark "DSM_EmbedSparseMark" to embed as many labels as you want.
	This helps reduce the overhead of setting up the embedder and is more efficient,
	especially if you are printing multiple labels at the same label settings.

	@subsection EGSH_includes Includes
	@snippet ExampleGtinShared.cpp includes

	@subsection EGSH_primary_objects Primary Objects
	The end goal of the setup process is to configure an instance of @ref DSM_DATADESC "DSM_DATADESC"
	and an instance of @ref DSM_EMBEDDER_OPTIONS "DSM_EMBEDDER_OPTIONS".

	@ref DSM_DATADESC "DSM_DATADESC" is used to describe image data.

	@ref DSM_EMBEDDER_OPTIONS "DSM_EMBEDDER_OPTIONS" is used to configure the embedder options.

	Declare an instance of @ref DSM_DATADESC "DSM_DATADESC" and an instance of @ref DSM_EMBEDDER_OPTIONS "DSM_EMBEDDER_OPTIONS"

	@snippet ExampleGtinShared.cpp creation

	@subsection EGSH_init Initialize Embedder Options
	Call @ref DSM_InitializeEmbedderOptions "DSM_InitializeEmbedderOptions" to initialize embedder options.

	@snippet ExampleGtinShared.cpp initialization

	@subsection EGSH_sdk_handle SDK Handle
	Create an instance of SDK handle @ref DSM_API "DSM_API". Then call @ref DSM_Open "DSM_Open" to initialize the SDK handle.

	@snippet ExampleGtinShared.cpp sdk_handle

</div>

<div id="thick-hr"><hr></div>

@section EGSH_configuration Configuration
<div style="margin: .25in">

	@subsection EGSH_image_data Image Data
	This is the buffer for the embedded image data. This image data will be overwritten or modified
	based on @ref DSM_EMBEDDER_OPTIONS::DSM_IMAGE_BLEND_MODE "DSM_IMAGE_BLEND_MODE".
	In the example below, a new image data buffer is created, but you can use your own image buffer instead.

	@snippet ExampleGtinShared.cpp image_data

	@subsection EGSH_configure_image_data_description Configure Image Data Description
	Configure the instance of @ref DSM_DATADESC "DSM_DATADESC" with user specified data.
	The image data @ref DSM_DATADESC::pData "DSM_DATADESC::pData" must match the rest of the image data description.

	@snippet ExampleGtinShared.cpp configure_image_data_description

	@subsection EGSH_configure_embedder_options Configure Embedder Options
	Configure the instance of @ref DSM_EMBEDDER_OPTIONS "DSM_EMBEDDER_OPTIONS" with user specified data

	@snippet ExampleGtinShared.cpp configure_embedder_options

	@subsection EGSH_converted_payload_buffer Buffer for Converted Payload
	Create a buffer to store the converted payload from @ref DSM_GetGtinJson "DSM_GetGtinJson".

	@snippet ExampleGtinShared.cpp converted_payload_buffer

	@subsection EGSH_convert_payload Convert Payload
	Call @ref DSM_GetGtinJson "DSM_GetGtinJson" to convert your user specified payload data
	to a properly formatted payload string.

	@snippet ExampleGtinShared.cpp convert_payload

	@subsection EGSH_set_payload Set Payload
	If user specified payload data has been converted successfully into a properly formatted payload string,
	then set @ref DSM_EMBEDDER_OPTIONS::pPayload "DSM_EMBEDDER_OPTIONS::pPayload" to the converted payload string.

	@snippet ExampleGtinShared.cpp set_payload

	The configuration is now complete.

</div>

<div id="thick-hr"><hr></div>

@section EGSH_embed Embed
<div style="margin: .25in">

	@subsection EGSH_embed_sub embed
	Call @ref DSM_EmbedSparseMark "DSM_EmbedSparseMark" to embed.
	You will need to pass the instance of @ref DSM_API "SDK handle",
	the instance of @ref DSM_DATADESC "DSM_DATADESC" and the instance of @ref DSM_EMBEDDER_OPTIONS "DSM_EMBEDDER_OPTIONS" as arguments.

	@snippet ExampleGtinShared.cpp embed

	@subsection EGSH_check_embed_result Check Embed Result
	Check the embed result.

	@snippet ExampleGtinShared.cpp check_embed_result

</div>

<div id="thick-hr"><hr></div>

@section EGSH_clean_up Clean Up
<div style="margin: .25in">

	@subsection EGSH_delete_image_buffer Delete Image Data Buffer as Needed
	Depending on how the image data buffer is allocated, you may want to delete the image data buffer.

	@snippet ExampleGtinShared.cpp delete_image_buffer

	@subsection EGSH_close_sdk_handle Close SDK Handle
	Call @ref DSM_Close "DSM_Close" to close the SDK Handle

	@snippet ExampleGtinShared.cpp close_sdk_handle

</div>


<div id="thick-hr"><hr></div>
@section EGSH_full_source Full Source
Below is a functioning example, including error handling.

 */

#include <fstream>

//! [includes]
#include <dsmsdk.h>
#include <PayloadHelper.h>
//! [includes]

bool MyWriteImageToPGMFile(const char* Filename, int& height, int& width, int& stride, const unsigned char*&  ImageData);

int main() {

	DSM_RESULT res = DSM_OK;

	// User specified data
	const char* gtin14 = "12345678901231";

	// User specified options
	const char* outputFile = "SampleImageOut.pgm";
	DSM_DATADESC_TYPE dataDescType = DSM_DATADESC_GRAYSCALE_INV;
	DSM_UINT16 imageResolution = 203;
	DSM_UINT32 imageWidth = 406;
	DSM_UINT32 imageHeight = 406;
	DSM_UINT32 imageStride = 406;
	DSM_UINT16 dotDensity = 35;
	DSM_UINT16 dotSize = 1;
	DSM_DOT_PATTERN dotPattern = DSM_DOT_PATTERN_CIRCULAR;
	DSM_UINT16 watermarkResolution = 150;
	DSM_IMAGE_BLEND_MODE imageBlendMode = DSM_IMAGE_BLEND_MODE_OVERWRITE;

	//! [converted_payload_buffer]
	// Buffer to store the converted payload
	char convertedPayload[MAX_PAYLOAD_OUT_BUFFER] = {'\0'};
	//! [converted_payload_buffer]

	//! [image_data]
	// Pointer to a buffer that holds the watermark image data
	unsigned char* imageData = NULL;
	imageData = new (std::nothrow) unsigned char[imageStride * imageHeight];
	if (imageData == NULL)
	{
		printf("Error: image buffer allocation failed.\n");
		res = DSM_MEMORY_ERROR;
		return res;
	}
	//! [image_data]

	//! [creation]
	// Create the primary SDK objects
	DSM_RESULT sdkResult = DSM_OK;			// Common way to catch results from various calls to the SDK
	DSM_DATADESC sdkImageDesc;			// An instance of image data descriptions
	DSM_EMBEDDER_OPTIONS sdkEmbedderOptions;	// An instance of embedder options
	//! [creation]

	//! [initialization]
	// Initialize Embedder Options
	sdkResult = DSM_InitializeEmbedderOptions(&sdkEmbedderOptions);
	if (sdkResult != DSM_OK)
	{
		printf("Error: DSM_InitializeEmbedderOptions() = %d.\n", res);
		return sdkResult;
	}
	//! [initialization]

	//! [sdk_handle]
	// SDK handle
	DSM_API hSDKHandle = NULL;			// Create an SDK handle
	sdkResult = DSM_Open(&hSDKHandle);	// Initialize the SDK handle
	if (sdkResult == DSM_OK)
	{
		// DSM_API handle was initialized.  DSM_Close() should be called later on.
		printf("DSM_Open() = %d\n", sdkResult);
	}
	else
	{
		// DSM_API handle was NOT initialized and was instead set to NULL.  DSM_Close() should NOT be called.
		printf("Error: DSM_Open() = %d\n", sdkResult);
		return(sdkResult);
	}
	//! [sdk_handle]

	//! [configure_image_data_description]
	// Assign user specified data to image descriptions
	sdkImageDesc.BytesPerRow = imageStride;
	sdkImageDesc.DataDescType = dataDescType;
	sdkImageDesc.Height = imageHeight;
	sdkImageDesc.pData = imageData;
	sdkImageDesc.Resolution = imageResolution;
	sdkImageDesc.Width = imageWidth;
	//! [configure_image_data_description]

	//! [configure_embedder_options]
	// Assign user specified options to embedder options
	sdkEmbedderOptions.nDotDensity = dotDensity;
	sdkEmbedderOptions.nDotSize = dotSize;
	sdkEmbedderOptions.eDotPattern = dotPattern;
	sdkEmbedderOptions.nWatermarkRes = watermarkResolution;
	sdkEmbedderOptions.eImageBlendMode = imageBlendMode;
	//! [configure_embedder_options]

	//! [convert_payload]
	// Call DSM_GetGtinJson() to convert user specified GTIN-14 data
	// to a properly formatted payload string.
	sdkResult = DSM_GetGtinJson(gtin14, convertedPayload);
	//! [convert_payload]

	//! [set_payload]
	// If payload has been properly converted, then set the payload in embedder options
	if(sdkResult == DSM_OK) {
		sdkEmbedderOptions.pPayload = convertedPayload;
	} else {
		printf("Error: Failed to convert provided payload and alias. Please check that the values are correct.\n");
		return sdkResult;
	}
	//! [set_payload]

	// Embed watermark
	printf("Calling DSM_EmbedSparseMark()\n");
	//! [embed]
	sdkResult = DSM_EmbedSparseMark(hSDKHandle, &sdkImageDesc, &sdkEmbedderOptions);
	//! [embed]

	//! [check_embed_result]
	// Check to see whether watermark is generated successfully
	printf("DSM_EmbedSparseMark() = %d\n", sdkResult);
	switch (sdkResult)
	{
		case DSM_OK:
			printf("Success\n");
			break;
		case DSM_INVALID_HANDLE:
			printf("Error: Invalid handle\n");
			break;
		case DSM_INVALID_ARGUMENT:
			printf("Error: Invalid argument\n");
			break;
		case DSM_IMAGE_RESOLUTION_OUT_OF_RANGE:
			printf("Erorr: Image resolution out of range\n");
			break;
		case DSM_WATERMARK_RESOLUTION_OUT_OF_RANGE:
			printf("Error: Watermark resolution out of range\n");
			break;
		case DSM_PAYLOAD_OUT_OF_RANGE:
			printf("Error: Payload out of range\n");
			break;
		case DSM_INVALID_DATA_DESC:
			printf("Error: Invalid data description\n");
			break;
		case DSM_MEMORY_ERROR:
			printf("Error: Memory error\n");
			break;
		case DSM_INTERNAL_ERROR:
			printf("Error: Internal error\n");
			break;
		default:
			printf("Error: Unknown error\n");
			break;
	}
	//! [check_embed_result]


	// If embed is successful,
	// then write the output image
	if (sdkResult == DSM_OK)
	{
		bool writeImageSuccessfully = MyWriteImageToPGMFile(outputFile, (int&)imageHeight, (int&)imageWidth, (int&)imageStride, (const unsigned char *&)imageData);
		if(writeImageSuccessfully)
		{
			printf("Write output image successful\n");
		}
		else
		{
			printf("Error: write output image unsuccessful\n");
		}
	}

	// Clean up
	//! [delete_image_buffer]
	delete[] imageData;
	imageData = NULL;
	//! [delete_image_buffer]

	// Close DSMSDK
	//! [close_sdk_handle]
	sdkResult = DSM_Close(&hSDKHandle);
	if (sdkResult == DSM_OK)
	{
		// DSM_API handle has been released and was set to NULL
		printf("DSM_Close() = %d\n", sdkResult);
	}
	else
	{
		// DSM_API handle has NOT been released and was probably invalid.
		printf("Error: DSM_Close() = %d\n", sdkResult);
	}
	//! [close_sdk_handle]

	return(sdkResult);
}


bool MyWriteImageToPGMFile(const char* Filename, int& height, int& width, int& stride, const unsigned char*& ImageData)
{
	std::ofstream pgmFile(Filename, std::ios_base::out | std::ios_base::binary);

	if (!pgmFile.is_open()) {
		return(false);
	}

	pgmFile << "P5" << std::endl;
	pgmFile << width << " " << height << std::endl;
	pgmFile << "255" << std::endl;

	for (int row = 0; row < height; row++) {
		pgmFile.write(reinterpret_cast<const char*>(ImageData + row * stride), width);
	}

	pgmFile.close();

	return(true);
}
