// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "SasUserInput.h"
#include "win-system/Environment.h"

#define XK_MISCELLANY
#include "rfb/keysymdef.h"

SasUserInput::SasUserInput(UserInputClient *client, LogWriter *log)
: m_client(client),
  m_ctrlPressed(false),
  m_altPressed(false),
  m_underVista(false),
  m_log(log)
{
  m_underVista = Environment::isVistaOrLater();
}

SasUserInput::~SasUserInput()
{
}

void SasUserInput::sendInit(BlockingGate *gate)
{
  m_client->sendInit(gate);
}

void SasUserInput::setMouseEvent(const Point *newPos, UINT8 keyFlag)
{
  m_client->setMouseEvent(newPos, keyFlag);
}

void SasUserInput::setNewClipboard(const StringStorage *newClipboard)
{
  m_client->setNewClipboard(newClipboard);
}

void SasUserInput::setKeyboardEvent(UINT32 keySym, bool down)
{
  bool delPressed = false;

  if (m_underVista) {
    switch (keySym) {
    case XK_Alt_L:
    case XK_Alt_R:
      m_altPressed = down;
      break;
    case XK_Control_L:
    case XK_Control_R:
      m_ctrlPressed = down;
      break;
    case XK_Delete:
      delPressed = down;
    }
  }

  if (m_ctrlPressed && m_altPressed && delPressed && m_underVista) {
    Environment::simulateCtrlAltDelUnderVista(m_log);
  } else {
    m_client->setKeyboardEvent(keySym, down);
  }
}

void SasUserInput::getCurrentUserInfo(StringStorage *desktopName,
                                         StringStorage *userName)
{
  m_client->getCurrentUserInfo(desktopName, userName);
}

void SasUserInput::getPrimaryDisplayCoords(Rect *rect)
{
  m_client->getPrimaryDisplayCoords(rect);
}

void SasUserInput::getDisplayNumberCoords(Rect *rect,
                                          unsigned char dispNumber)
{
  m_client->getDisplayNumberCoords(rect, dispNumber);
}

void SasUserInput::getNormalizedRect(Rect *rect)
{
  m_client->getNormalizedRect(rect);
}

void SasUserInput::getWindowCoords(HWND hwnd, Rect *rect)
{
  m_client->getWindowCoords(hwnd, rect);
}

HWND SasUserInput::getWindowHandleByName(const StringStorage *windowName)
{
  return m_client->getWindowHandleByName(windowName);
}

void SasUserInput::getApplicationRegion(unsigned int procId, Region *region)
{
  m_client->getApplicationRegion(procId, region);
}
