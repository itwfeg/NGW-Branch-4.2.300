// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "util/CommonHeader.h"
#include "util/StringParser.h"
#include "HookLoaderApplication.h"
#include "tvnserver-app/NamingDefs.h"

int APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                       LPTSTR lpCmdLine, int nCmdShow)
{
  try {
    HookLoaderApplication application(hInstance,
                                      WindowNames::WINDOW_CLASS_NAME,
                                      lpCmdLine);
    return application.run();
  } catch (...) {
    return 1;
  }
}
