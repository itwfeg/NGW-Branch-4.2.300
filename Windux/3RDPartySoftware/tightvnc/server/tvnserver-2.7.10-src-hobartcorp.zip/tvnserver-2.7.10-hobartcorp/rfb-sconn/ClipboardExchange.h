// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CLIPBOARDEXCHANGE_H__
#define __CLIPBOARDEXCHANGE_H__

#include "RfbDispatcherListener.h"
#include "RfbCodeRegistrator.h"
#include "desktop/Desktop.h"
#include "network/RfbOutputGate.h"
#include "log-writer/LogWriter.h"

class ClipboardExchange : public RfbDispatcherListener, public Thread
{
public:
  ClipboardExchange(RfbCodeRegistrator *codeRegtor, Desktop *desktop,
                    RfbOutputGate *output, bool viewOnly, LogWriter *log);
  virtual ~ClipboardExchange();

  void sendClipboard(const StringStorage *newClipboard);

protected:
  // Listen function
  virtual void onRequest(UINT32 reqCode, RfbInputGate *input);

  virtual void execute();
  virtual void onTerminate();

private:
  bool m_viewOnly;
  Desktop *m_desktop;
  RfbOutputGate *m_output;

  WindowsEvent m_newClipWaiter;

  StringStorage m_storedClip;
  bool m_hasNewClip;
  LocalMutex m_storedClipMut;

  LogWriter *m_log;
};

#endif // __CLIPBOARDEXCHANGE_H__
