// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDATEKEEPER_H__
#define __UPDATEKEEPER_H__

#include "thread/LocalMutex.h"
#include "region/Region.h"
#include "UpdateContainer.h"
#include "thread/AutoLock.h"

class UpdateKeeper : public Lockable
{
public:
  UpdateKeeper();
  UpdateKeeper(const Rect *borderRect);
  ~UpdateKeeper(void);

  virtual void lock()
  {
    m_updContLocMut.lock();
  }

  virtual void unlock()
  {
    m_updContLocMut.unlock();
  }

  void addChangedRegion(const Region *changedRegion);
  void addChangedRect(const Rect *changedRect);
  // Adds border rectangle to changed region.
  void dazzleChangedReg()
  {
    AutoLock al(&m_updContLocMut);
    addChangedRect(&m_borderRect);
  }

  void addCopyRect(const Rect *copyRect, const Point *src);

  void setBorderRect(const Rect *borderRect);

  void setScreenSizeChanged();
  void setCursorPosChanged(const Point *curPos);
  void setCursorPos(const Point *curPos);
  void setCursorShapeChanged();

  void setExcludedRegion(const Region *excludedRegion);

  void addUpdateContainer(const UpdateContainer *updateContainer);
  void getUpdateContainer(UpdateContainer *updCont);
  bool checkForUpdates(const Region *region);

  void extract(UpdateContainer *updateContainer);

private:
  Rect m_borderRect;

  Region m_excludedRegion;
  LocalMutex m_exclRegLocMut;

  UpdateContainer m_updateContainer;
  LocalMutex m_updContLocMut;
};

#endif // __UPDATEKEEPER_H__
