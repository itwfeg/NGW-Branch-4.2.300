var searchData=
[
  ['ndotdensity',['nDotDensity',['../structDSM__GENERATOR__OPTIONS.html#ad48e8ea20dc397bb7996db6e23056160',1,'DSM_GENERATOR_OPTIONS::nDotDensity()'],['../structDSM__EMBEDDER__OPTIONS.html#a6f358f76a8dd522ad0db1f164f40d2c7',1,'DSM_EMBEDDER_OPTIONS::nDotDensity()']]],
  ['ndotsize',['nDotSize',['../structDSM__GENERATOR__OPTIONS.html#aca4b766c8209383d586dae3b349e0413',1,'DSM_GENERATOR_OPTIONS::nDotSize()'],['../structDSM__EMBEDDER__OPTIONS.html#a4586ccdc0cfa95b304bafe77a8e4355f',1,'DSM_EMBEDDER_OPTIONS::nDotSize()']]],
  ['nnumkeepoutregions',['nNumKeepOutRegions',['../structDSM__EMBEDDER__OPTIONS.html#acd44cd7c5b9e311f04be33de0ec3263c',1,'DSM_EMBEDDER_OPTIONS']]],
  ['nwatermarkres',['nWatermarkRes',['../structDSM__GENERATOR__OPTIONS.html#a8ad5b6527612c7d4342bff3d1361588c',1,'DSM_GENERATOR_OPTIONS::nWatermarkRes()'],['../structDSM__EMBEDDER__OPTIONS.html#a1b5735db16689277e55d4ac0b7e18433',1,'DSM_EMBEDDER_OPTIONS::nWatermarkRes()']]]
];
