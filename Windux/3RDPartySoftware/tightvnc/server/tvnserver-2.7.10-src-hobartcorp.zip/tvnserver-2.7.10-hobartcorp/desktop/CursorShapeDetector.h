// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CURSORHAPEDETECTOR_H__
#define __CURSORHAPEDETECTOR_H__

#include "UpdateKeeper.h"
#include "CursorShapeGrabber.h"
#include "UpdateDetector.h"
#include "win-system/WindowsEvent.h"
#include "log-writer/LogWriter.h"

class CursorShapeDetector : public UpdateDetector
{
public:
  CursorShapeDetector(UpdateKeeper *updateKeeper,
                     UpdateListener *updateListener,
                     CursorShapeGrabber *mouseGrabber,
                     LocalMutex *mouseGrabLocMut,
                     LogWriter *log);
  virtual ~CursorShapeDetector();

protected:
  virtual void execute();
  virtual void onTerminate();

  CursorShapeGrabber *m_mouseGrabber;
  LocalMutex *m_mouseGrabLocMut;
  WindowsEvent m_sleepTimer;

  LogWriter *m_log;
};

#endif // __CURSORHAPEDETECTOR_H__
