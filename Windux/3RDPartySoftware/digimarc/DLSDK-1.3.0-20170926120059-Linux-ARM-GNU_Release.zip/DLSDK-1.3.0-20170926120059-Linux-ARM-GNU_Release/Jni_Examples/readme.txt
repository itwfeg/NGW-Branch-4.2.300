How To run JniExampleKeepOutRegions.jar

- Copy java/dlsdk.jar and lib/dlsdkjava.* to this folder.
- Run the following in command prompt or shell prompt.

Linux:

  java -classpath dlsdk.jar:JniExampleKeepOutRegions.jar -Djava.library.path=. com.digimarc.LabelEmbedder.example.JniExampleKeepOutRegions

Windows:

  java -classpath dlsdk.jar;JniExampleKeepOutRegions.jar -Djava.library.path=. com.digimarc.LabelEmbedder.example.JniExampleKeepOutRegions
