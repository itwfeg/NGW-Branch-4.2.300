// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDATECONTAINER_H__
#define __UPDATECONTAINER_H__

#include "region/Region.h"
#include "region/Point.h"

class UpdateContainer
{
public:
  UpdateContainer();
  ~UpdateContainer();

  UpdateContainer(const UpdateContainer& updateContainer) { *this = updateContainer; }
  UpdateContainer &operator=(const UpdateContainer& src);

  Region copiedRegion;
  Region changedRegion;
  Region videoRegion;
  bool screenSizeChanged;
  bool cursorPosChanged;
  bool cursorShapeChanged;
  Point copySrc;
  Point cursorPos;

  void clear();
  bool isEmpty() const;
};

#endif // __UPDATECONTAINER_H__
