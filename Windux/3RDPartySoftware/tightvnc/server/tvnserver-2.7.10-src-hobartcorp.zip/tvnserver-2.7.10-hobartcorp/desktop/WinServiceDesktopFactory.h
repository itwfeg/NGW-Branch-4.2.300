// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINSERVICEDESKTOPFACTORY_H__
#define __WINSERVICEDESKTOPFACTORY_H__

#include "DesktopFactory.h"

class WinServiceDesktopFactory : public DesktopFactory
{
public:
  WinServiceDesktopFactory();
  ~WinServiceDesktopFactory();

  virtual Desktop *createDesktop(ClipboardListener *extClipListener,
                                          UpdateSendingListener *extUpdSendingListener,
                                          AbnormDeskTermListener *extDeskTermListener,
                                          LogWriter *log);
};

#endif // __WINSERVICEDESKTOPFACTORY_H__
