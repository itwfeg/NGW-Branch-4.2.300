// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _RECTSERIALIZER_H_
#define _RECTSERIALIZER_H_

#include "util/CommonHeader.h"
#include "Rect.h"

class RectSerializer
{
public:
  // Converts to string value.
  static void toString(const Rect *rect, StringStorage *strOut);

  // Converts to Rect value.
  static Rect toRect(const StringStorage *strIn);
};

#endif
