// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _PEN_H_
#define _PEN_H_

#include "util/CommonHeader.h"

class Pen
{
public:
  const static int SOLID_TYPE = PS_SOLID;
  const static int DASH_TYPE = PS_DASH;
  const static int NULL_TYPE = PS_NULL;

public:
  Pen(int type, int width, COLORREF color);
  virtual ~Pen();

protected:
  HPEN m_pen;

  friend class Graphics;
};

#endif
