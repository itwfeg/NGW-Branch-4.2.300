// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __RFB_HEXTILE_ENCODER_H_INCLUDED__
#define __RFB_HEXTILE_ENCODER_H_INCLUDED__

#include "Encoder.h"

class HextileEncoder : public Encoder
{
public:
  HextileEncoder(PixelConverter *conv, DataOutputStream *output);
  virtual ~HextileEncoder();

  virtual int getCode() const;

  virtual void sendRectangle(const Rect *rect,
                             const FrameBuffer *serverFb,
                             const EncodeOptions *options) throw(IOException);

private:
  template <class PIXEL_T>
    void hextileFunction(const Rect &r,
                         const FrameBuffer *frameBuffer) throw(IOException);
};

#endif // __RFB_HEXTILE_ENCODER_H_INCLUDED__
