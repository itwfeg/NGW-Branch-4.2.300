import QtQuick 2.0
import com.froglogic.squish.qtquick 0.1

SquishHook {
    priority: 100

    function isLayoutType( item ) {
        return ( isQmlType( item, "Column" ) ||
                isQmlType( item, "Flow" ) ||
                isQmlType( item, "Grid" ) ||
                isQmlType( item, "Row" ) );
    }

    function containerFor( item ) {
        var parents = [];
        for ( var obj = item.parent; obj; obj = obj.parent ) {
            parents.push(obj);
            if ( isQmlType( obj, "Flickable" ) ) {
                // Only use flickable as a container if we are not
                // the only item inside. For single items, the flickable serves
                // as a scrollable area which is not useful for object names.
                if ( obj.model ) { // ListView, GridView or TableView backed by a model
                    if ( isQmlType( obj.model, "QAbstractItemModel" ) ||
                            obj.model.length > 1 ||
                            obj.model.count > 1 ) {
                        if ( parents.length > 2 ) {
                            // parents: [ ..., viewItem, contentItem, flickable ]
                            // item is a child of viewItem
                            var viewItem = parents[ parents.length - 3 ];
                            if ( viewItem !== item ) {
                                return viewItem;
                            }
                        } else {
                            // parents: [ contentItem, flickable ]
                            // item is a direct child of contentItem
                            return obj;
                        }
                    }
                } else if ( obj.contentItem ) {
                    var flickChildren = obj.contentItem.children;
                    if ( flickChildren.length > 1 ) {
                        return obj;
                    }
                    if ( flickChildren.length === 1 && isLayoutType( flickChildren[0] ) ) {
                        return obj;
                    }
                }
                // item is the only one inside the flickable
                return null;
            } else if ( isQmlType( obj, "Flipable" ) ) {
                return obj;
            }
        }
        return unhandled;
    }

    function isIgnored( item ) {
        // Ignore items that are marked as having no contents, they are not painted at all
        // One exception is scrollable views which may be interesting for keyboard input
        if ( !itemHasContents( item ) && !isQmlType( item, "Flickable" ) ) {
            return true;
        }

        // Completely ignore shader effects, applies to most types from QtGraphicalEffects module
        if ( isQmlType( item, "ShaderEffect" ) || isQmlType( item, "ShaderEffectSource" ) ) {
            return true;
        }

        // Keep items that have a custom type (declared at runtime)
        if ( isCustomQmlType( item ) ) {
            return false;
        }

        // Keep top-level items
        var itemParent = item.parent;
        if ( !itemParent ) {
            return false;
        }

        // Keep top-level items of delegates
        if ( isQmlType( itemParent, "GridView" ) ||
                isQmlType( itemParent, "ListView" ) ||
                isQmlType( itemParent, "PathView" ) ) {
            return false;
        }

        // Keep root object of a component.
        // When the source between item and parent changes, item is the top of a
        // component. When the item source is empty, it belongs to the parent
        // component.
        var itemUrl = source( item );
        var itemParentUrl = source( itemParent );
        if ( itemUrl && itemUrl.length && itemUrl !== itemParentUrl ) {
            return false;
        }

        // Keep what is not considered
        return unhandled;
    }

    function isItemReady( item ) {
        for (var p = item; p; p = p.parent) {
            if (isQmlType(p, "Flickable") && p.moving) {
                // An Item is not ready if it or one of its parents
                // is a flickable that is currently moving
                //console.log("Item " + item + " not ready: Flickable " + p + " is moving");
                return false;
            } else if (isQmlType(p, "PathView") && (p.moving || p.flicking)) {
                // Wait for flicked or dragged PathViews
                //console.log("Item " + item + " not ready: PathView " + p + " is moving or flicked");
                return false;
            }

            for (var i = 0; i < p.transitions.length; i++) {
                var trans = p.transitions[i];
                if (trans.enabled && trans.running) {
                    //console.log("Item " + item + " not ready: Parent " + p + " has running transition: " + trans);
                    return false;
                }
            }
        }
        return unhandled;
    }

    function listViewIndex( item ) {
        if ( item.parent ) {
            var view = item.parent.parent;
            if ( view && ( isQmlType( view, "ListView" ) ||
                          isQmlType( view, "GridView" ) ) ) {
                return view.indexAt( item.x, item.y );
            }
        }
        return -1;
    }

    function extraPropertiesFor( item ) {
        if ( listViewIndex( item ) !== -1 ) {
            return ['index'];
        }
        return unhandled;
    }

    function propertyFor( item, property ) {
        if ( property === 'backgroundcolor' ) {
            if ( isQmlType( item, 'Rectangle' ) ) {
                return unhandled;
            }
            for ( var obj = item.parent; obj; obj = obj.parent ) {
                if ( isQmlType( obj, 'Rectangle' ) ) {
                    return obj.color;
                }
            }
        } else if ( property ==='index' ) {
            var idx = listViewIndex( item );
            if ( idx !== -1 ) {
                return idx;
            }
        }
        return unhandled;
    }
}
