// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "WinDxException.h"

WinDxException::WinDxException(const TCHAR *message, HRESULT errCode)
: Exception(message),
  m_errCode(errCode)
{
}

WinDxException::~WinDxException()
{
}

HRESULT WinDxException::getErrorCode() const
{
  return m_errCode;
}
