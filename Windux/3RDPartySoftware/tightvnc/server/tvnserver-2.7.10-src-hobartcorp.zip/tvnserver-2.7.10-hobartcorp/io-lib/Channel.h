// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _CHANNEL_H_
#define _CHANNEL_H_

#include "util/Exception.h"

#include "InputStream.h"
#include "OutputStream.h"

/**
 * Channel interface (abstract class) that joins together
 * InputStream and OutputStream).
 */
class Channel : public InputStream, public OutputStream
{
public:
  /**
   * Destructor, does nothing.
   */
  virtual ~Channel();

  /**
   * Closes channel and break all blocking operation that executed at the moment of close() call.
   * @throw Exception on error.
   * @fixme why Exception, but not IOException?
   */
  virtual void close() throw(Exception)= 0;
};

#endif
