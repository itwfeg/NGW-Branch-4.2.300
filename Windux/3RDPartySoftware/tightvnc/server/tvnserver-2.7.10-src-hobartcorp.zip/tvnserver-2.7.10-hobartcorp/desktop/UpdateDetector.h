// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDATEDETECTOR_H__
#define __UPDATEDETECTOR_H__

#include "UpdateKeeper.h"
#include "thread/GuiThread.h"
#include "UpdateListener.h"

class UpdateDetector : public GuiThread
{
public:
  UpdateDetector(UpdateKeeper *updateKeeper,
                 UpdateListener *updateListener);
  virtual ~UpdateDetector();

  void setUpdateKeeper(UpdateKeeper *updateKeeper) { m_updateKeeper = updateKeeper; }
  UpdateKeeper *getUpdateKeeper() const { return m_updateKeeper; }

protected:
  void doUpdate()
  {
    if (m_updateListener) {
      m_updateListener->onUpdate();
    }
  }

  UpdateKeeper *m_updateKeeper;

  UpdateListener *m_updateListener;
};

#endif // __UPDATEDETECTOR_H__
