var ConnectivityCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded ConnectivityCtrl');
  // Api

  // Properties
  $scope.dnsAddress;

  $scope.pingAddress;

  $scope.tcpAddress;

  $scope.tcpPort;

  // Functions
  $scope.checkDns = function(){

    clearFieldErrors();

    var address = $("#dns-address").val().trim();

    if (address === ""){
      showFieldError("dns-address", "You must specify a host.");

    } else {
      $scope.doDnsCheck(address);
    }
    //stop normal event handling
    return false;
  };

  $scope.checkFullForm = function(){

    $scope.doPingCheck('4.2.2.1', 4, false);
    $scope.doTcpCheck('google.com:80', false);
    $scope.doDnsCheck('google.com',false);

    $resultScope = lpApi.go('',$scope);

    return false;
  };

  $scope.checkPing = function(){

    clearFieldErrors();

    var address = $.trim($scope.pingAddress);

    if (address === ""){
      showFieldError("ping-address", "You must specify a host.");
    } else {
      $scope.doPingCheck(address, 4);
    }

    //stop normal event handling
    return false;
  };

  $scope.checkTcp = function(){

    clearFieldErrors();

    var address = $.trim($scope.tcpAddress);
    Debug.log(address, "address");
    var tcpPort = $.trim($scope.tcpPort);
    Debug.log(tcpPort, "tcpPort");
    var noErrors = true;

    if (address === ""){
      showFieldError("tcp-address", "You must specify a host.");
      noErrors = false;
    } else if (tcpPort===""){
      showFieldError("tcp-port", "You must specify a port.");
      noErrors = false;
    }

    if (noErrors) {
      address = address + ":" + tcpPort;
      Debug.log(address, "full address");
      $scope.doTcpCheck(address);
    }

    return false;
  };

  $scope.doDnsCheck = function(address, now) {

    now = (typeof now === 'undefined' ? true : now);

    $.subscribe('network.check.dns', {"host":address}, $scope.showDnsResults);
    lpApi.networkCheckDns({"host":address});

    if (now){
      $resultScope = lpApi.go('',$scope);
    }
  };

  $scope.doPingCheck = function(address, count, now){

    now = (typeof now === 'undefined' ? true : now);

    $.subscribe('network.check.ping', {"host" : address}, $scope.showPingResults);
    lpApi.networkCheckPing({"address" : address, "count":count});

    if (now){
      $resultScope = lpApi.go('',$scope);
    }
  };

  $scope.doTcpCheck = function(address, now) {

    now = (typeof now === 'undefined' ? true : now);

    $.subscribe('network.check.tcp', {"host":address}, $scope.showTcpConnectResults);
    lpApi.networkCheckTcp({"address":address});

    if (now){
      $resultScope = lpApi.go('',$scope);
    }
  };

  /**
  * Event Handler Functions
  * @param object e
  * @param object data
  */

  $scope.showDnsResults = function(e,data){

    $.unsubscribe('network.check.dns');

    var resStr = "Resolving " + e.data.host + " ...\n\n";

    if (data.success){
      resStr += "Resolved " +e.data.host + " to " + data.params.ip;
    } else {
      resStr += "Error: " + data.errorMessage;
    }

    alert(resStr);
  };

  $scope.showPingResults = function(e,data){

    $.unsubscribe('network.check.ping');

    if (data.success){
      data = data.params.latency;

      //Debug.log(data.latency, 'showPingResults');
      var l = data.length;
      var resStr = 'Pinging ' + e.data.host + ":\n\n";

      for (var i = 0; i < l; i++){
        resStr += i + ") " + (data[i] >= 0 ? data[i] + " ms" : "failed") + "\n";
      }

      //Debug.log(resStr, 'showPingResults');
      alert(resStr);
    }
  };

  $scope.showTcpConnectResults = function(e,data){

    $.unsubscribe('network.check.tcp');

    var resStr = "Connecting to " + e.data.host + " ...\n\n";

    if(data.success){
      resStr += "Connected successfully in " + data.params.elapsed + " ms";

    } else {
      resStr += "Error: " + data.errorMessage;
    }

    alert(resStr);
  };

  // Executions
  $scope.clearSystemMsg();

  $scope.assertAuthentication();

  $scope.menuItemSelect($scope, 'gateway');
};

ConnectivityCtrl.$inject = ['$scope','lpApi','$http'];

ConnectivityCtrl.prototype.ctrlActions = {
  items : [{
    href : '',
    template : ''
  }]
};

ConnectivityCtrl.prototype.mainActions = {
  items : [{
    href : '',
    template : ''
  }]
};

ConnectivityCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};
