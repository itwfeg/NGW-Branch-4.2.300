// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "CommonControlsEx.h"

#include "util/CommonHeader.h"

CommonControlsEx::CommonControlsEx()
{
}

CommonControlsEx::~CommonControlsEx()
{
}

void CommonControlsEx::init()
{
  INITCOMMONCONTROLSEX iccsex = {0};

  iccsex.dwICC = ICC_LISTVIEW_CLASSES | ICC_NATIVEFNTCTL_CLASS |
                 ICC_PAGESCROLLER_CLASS | ICC_PROGRESS_CLASS |
                 ICC_TAB_CLASSES | ICC_TREEVIEW_CLASSES |
                 ICC_UPDOWN_CLASS | ICC_USEREX_CLASSES;

  iccsex.dwSize = sizeof(INITCOMMONCONTROLSEX);

  if (::InitCommonControlsEx(&iccsex) != TRUE) {
    throw Exception(_T("Cannot initialize common controls ex."));
  }
}
