// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __APPLICATIONDESKTOPFACTORY_H__
#define __APPLICATIONDESKTOPFACTORY_H__

#include "DesktopFactory.h"

class ApplicationDesktopFactory : public DesktopFactory
{
public:
  ApplicationDesktopFactory();
  ~ApplicationDesktopFactory();

  virtual Desktop *createDesktop(ClipboardListener *extClipListener,
                                          UpdateSendingListener *extUpdSendingListener,
                                          AbnormDeskTermListener *extDeskTermListener,
                                          LogWriter *log);
};

#endif // __APPLICATIONDESKTOPFACTORY_H__
