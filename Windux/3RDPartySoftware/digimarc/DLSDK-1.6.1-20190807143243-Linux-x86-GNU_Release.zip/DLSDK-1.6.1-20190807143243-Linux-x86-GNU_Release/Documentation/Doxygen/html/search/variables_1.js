var searchData=
[
  ['datadesctype',['DataDescType',['../structDSM__DATADESC.html#a4d0b15cc1a9f0b4bbbb09ea5f6ffbcf5',1,'DSM_DATADESC']]],
  ['dsm_5fgtin_5f13_5flength',['DSM_GTIN_13_LENGTH',['../PayloadHelper_8h.html#ac4f73c38e7c5073b7dd62ef756d72b76',1,'PayloadHelper.h']]],
  ['dsm_5fsellby_5fdate_5flength',['DSM_SELLBY_DATE_LENGTH',['../PayloadHelper_8h.html#ac38f07da8f2452870cd274f403ca928f',1,'PayloadHelper.h']]]
];
