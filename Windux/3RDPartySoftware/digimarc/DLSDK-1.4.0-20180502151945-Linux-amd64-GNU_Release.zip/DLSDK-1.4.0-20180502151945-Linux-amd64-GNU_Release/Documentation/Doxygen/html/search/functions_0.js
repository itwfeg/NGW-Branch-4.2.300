var searchData=
[
  ['dsm_5fclose',['DSM_Close',['../dsmsdk_8h.html#a8748fa95a54c7ba74616f1ecee24db8e',1,'dsmsdk.h']]],
  ['dsm_5fembedsparsemark',['DSM_EmbedSparseMark',['../dsmsdk_8h.html#af3b5aa1440b3fa6c11abcd958bba260b',1,'dsmsdk.h']]],
  ['dsm_5fgeneratesparsemark',['DSM_GenerateSparseMark',['../dsmsdk_8h.html#acef3b1cc533dc6811262b1a65c1733f2',1,'dsmsdk.h']]],
  ['dsm_5fgetexpandedfreshjson',['DSM_GetExpandedFreshJson',['../PayloadHelper_8h.html#a0b14cd8d259a09710e7eeca88d4b54ae',1,'PayloadHelper.h']]],
  ['dsm_5fgetexpandedfreshjson_5fweightrange2',['DSM_GetExpandedFreshJson_WeightRange2',['../PayloadHelper_8h.html#aee5e91ab84c0d555bd41202a6a2121ea',1,'PayloadHelper.h']]],
  ['dsm_5fgetgtinjson',['DSM_GetGtinJson',['../PayloadHelper_8h.html#a13df00d38bbd093f742729f5730cbae6',1,'PayloadHelper.h']]],
  ['dsm_5fgetsimpleproductidjson_5fgtin',['DSM_GetSimpleProductIdJson_Gtin',['../PayloadHelper_8h.html#abb2d123b0d62968bc43c283b4c314801',1,'PayloadHelper.h']]],
  ['dsm_5fgetsimpleproductidjson_5fupce',['DSM_GetSimpleProductIdJson_Upce',['../PayloadHelper_8h.html#a18425e1c8bb6fc8e78c8df85928d96de',1,'PayloadHelper.h']]],
  ['dsm_5fgetupcejson',['DSM_GetUpceJson',['../PayloadHelper_8h.html#aa61d844108ffa1fe5cff032f5a20b145',1,'PayloadHelper.h']]],
  ['dsm_5finitializeembedderoptions',['DSM_InitializeEmbedderOptions',['../dsmsdk_8h.html#a980b1a454f755ff40e33d9367c7019af',1,'dsmsdk.h']]],
  ['dsm_5fopen',['DSM_Open',['../dsmsdk_8h.html#ab4c7df41a3d646b7c4094dc185f26613',1,'dsmsdk.h']]]
];
