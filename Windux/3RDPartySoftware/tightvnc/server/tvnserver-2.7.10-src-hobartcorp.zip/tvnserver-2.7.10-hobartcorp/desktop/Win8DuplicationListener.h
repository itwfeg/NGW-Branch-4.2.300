// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WIN8DUPLICATIONLISTENER_H__
#define __WIN8DUPLICATIONLISTENER_H__

#include "region/Region.h"

class Win8DuplicationListener
{
public:
  // changedRegion in target FrameBuffer coordinates.
  virtual void onFrameBufferUpdate(const Region *changedRegion) = 0;
  // dstRect, srcX, srcY in target FrameBuffer coordinates.
  virtual void onCopyRect(const Rect *dstRect, int srcX, int srcY) = 0;

  virtual void onCursorPositionChanged(int x, int y) = 0;
  virtual void onCursorShapeChanged() = 0;

  // Calls when an error occurred which can be recover by object recreating.
  virtual void onRecoverableError(const TCHAR *reason) = 0;
  // Calls when an error occurred which can't be recover by object recreating.
  // Must be selected other way to duplicate desktop.
  virtual void onCriticalError(const TCHAR *reason) = 0;
};

#endif // __WIN8DUPLICATIONLISTENER_H__
