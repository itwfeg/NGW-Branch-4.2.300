// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "ConnectionTimer.h"
#include "thread/AutoLock.h"

ConnectionTimer::ConnectionTimer(TimerListener *timerListener,
                                 unsigned int timeOut)
: m_timerListener(timerListener),
  m_timeOut(timeOut),
  m_signalEnabled(true)
{
  resume();
}

ConnectionTimer::~ConnectionTimer()
{
  m_signalEnabled = false;
  terminate();
  wait();
}

void ConnectionTimer::onTerminate()
{
  m_timer.notify();
}

void ConnectionTimer::execute()
{
  m_timer.waitForEvent(m_timeOut);
  if (m_signalEnabled) {
    m_timerListener->onTimeTimer();
  }
}
