var namespaceDigimarcLabelEmbedder =
[
    [ "Information", "classDigimarcLabelEmbedder_1_1Information.html", "classDigimarcLabelEmbedder_1_1Information" ]
];