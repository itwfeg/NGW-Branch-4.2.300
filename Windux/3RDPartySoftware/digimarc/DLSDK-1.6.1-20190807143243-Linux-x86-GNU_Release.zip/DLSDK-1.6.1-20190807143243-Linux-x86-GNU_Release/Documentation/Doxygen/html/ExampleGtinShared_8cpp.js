var ExampleGtinShared_8cpp =
[
    [ "main", "ExampleGtinShared_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "MyWriteImageToPGMFile", "ExampleGtinShared_8cpp.html#ad5029e04a563b879a1f3ddee01d23b80", null ]
];