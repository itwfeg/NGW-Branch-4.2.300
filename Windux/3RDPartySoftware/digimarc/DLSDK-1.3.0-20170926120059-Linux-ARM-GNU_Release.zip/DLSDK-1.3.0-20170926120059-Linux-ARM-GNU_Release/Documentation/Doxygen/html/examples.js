var examples =
[
    [ "ExampleExpandedFresh.cpp", "ExampleExpandedFresh_8cpp-example.html", null ],
    [ "ExampleExpandedFreshWeightRange2.cpp", "ExampleExpandedFreshWeightRange2_8cpp-example.html", null ],
    [ "ExampleGtin.cpp", "ExampleGtin_8cpp-example.html", null ],
    [ "ExampleKeepOutRegions.cpp", "ExampleKeepOutRegions_8cpp-example.html", null ],
    [ "ExampleUpce.cpp", "ExampleUpce_8cpp-example.html", null ],
    [ "SampleLabelEmbedder.cpp", "SampleLabelEmbedder_8cpp-example.html", null ]
];