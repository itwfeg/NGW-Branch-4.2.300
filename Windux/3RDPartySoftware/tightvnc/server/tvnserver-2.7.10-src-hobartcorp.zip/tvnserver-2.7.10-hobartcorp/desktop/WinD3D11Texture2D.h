// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WIND3D11TEXTURE2D_H__
#define __WIND3D11TEXTURE2D_H__

#include <d3d11.h>
#include <DXGI1_2.h>

class WinD3D11Texture2D
{
public:
  WinD3D11Texture2D(ID3D11Device *device, D3D11_TEXTURE2D_DESC *deskTexture);
  // Texture will be created by the IDXGIResource->QueryInterface() function call.
  WinD3D11Texture2D(IDXGIResource *dxgiResource);

  virtual ~WinD3D11Texture2D();

  ID3D11Texture2D *getTexture() const;

private:
  ID3D11Texture2D *m_dxgiTexture;
};

#endif // __WIND3D11TEXTURE2D_H__
