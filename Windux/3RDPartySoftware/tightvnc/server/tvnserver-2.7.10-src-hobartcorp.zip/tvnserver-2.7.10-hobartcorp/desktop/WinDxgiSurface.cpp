// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "util/Exception.h"

// The header including of this cpp file must be at last place to avoid build conflicts.
#include "WinDxgiSurface.h"

WinDxgiSurface::WinDxgiSurface(ID3D11Texture2D *texture2D)
: m_dxgiSurface(0)
{
  HRESULT hr = texture2D->QueryInterface(__uuidof(IDXGISurface), (void **)&m_dxgiSurface);
  if (FAILED(hr) || m_dxgiSurface == 0) {
    StringStorage errMess;
    errMess.format(_T("Can't create IDXGISurface from ID3D11Texture2D, error code = %l"), (long)hr);
    throw Exception(errMess.getString());
  }
}

WinDxgiSurface::~WinDxgiSurface()
{
  if (m_dxgiSurface != 0) {
    m_dxgiSurface->Release();
    m_dxgiSurface = 0;
  }
}

IDXGISurface *WinDxgiSurface::getSurface() const
{
  return m_dxgiSurface;
}
