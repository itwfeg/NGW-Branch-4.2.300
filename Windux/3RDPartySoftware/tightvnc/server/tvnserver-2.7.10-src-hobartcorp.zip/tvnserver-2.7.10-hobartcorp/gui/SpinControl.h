// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _SPIN_CONTROL_H_
#define _SPIN_CONTROL_H_

#include "Control.h"
#include <commctrl.h>

class SpinControl : public Control
{
public:
  SpinControl();
  ~SpinControl();

  void setBuddy(Control *buddyControl);
  void setRange(short lower, short upper);
  void setRange32(int lower, int upper);
  void setAccel(UINT nSec, UINT nInc);

  //
  // Auto acceleration methods
  //

  //
  // Handler, call it on UDN_DELTAPOS notification
  //

  void autoAccelerationHandler(LPNMUPDOWN message);
  void enableAutoAcceleration(bool enabled);
  void setAutoAccelerationParams(const std::vector<int> *limitters,
                                 const std::vector<int> *deltas,
                                 int maxDelta);
protected:
  Control *m_buddy;

  //
  // Members needed for auto acceleration
  //

  bool m_isAutoAccelerationEnabled;
  std::vector<int> m_limitters;
  std::vector<int> m_deltas;
  int m_maxDelta;
};

#endif
