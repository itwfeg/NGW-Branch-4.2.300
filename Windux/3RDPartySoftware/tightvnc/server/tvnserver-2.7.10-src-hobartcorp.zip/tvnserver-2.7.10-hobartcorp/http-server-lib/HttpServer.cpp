// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "HttpServer.h"
#include "HttpClient.h"

#include "thread/ZombieKiller.h"

HttpServer::HttpServer(const TCHAR *bindHost, unsigned short bindPort, bool lockAddr, LogWriter *log)
: TcpServer(bindHost, bindPort, true, lockAddr),
  m_log(log)
{
  m_log->message(_T("Http server started"));
}

HttpServer::~HttpServer()
{
  m_log->message(_T("Http server stopped"));
}

void HttpServer::onAcceptConnection(SocketIPv4 *socket)
{
  TcpClientThread *clientThread = new HttpClient(socket, m_log);

  clientThread->resume();

  ZombieKiller::getInstance()->addZombie(clientThread);
}
