// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _HTTP_ARGUMENT_LIST_H_
#define _HTTP_ARGUMENT_LIST_H_

#include <map>
#include <string>

using namespace std;

class ArgList
{
public:
  ArgList(const char *argString);
  virtual ~ArgList();

  // Return arguments count.
  size_t getCount() const;

  // Returns key name with specified index or NULL if index out of range.
  // It can be used for enumerating keys.
  const char *getKey(size_t index);

  // Returns value of argument with specified key or NULL if no such
  // argument.
  const char *getValue(const char *key);

protected:
  void splitPair(const char *par, char delimitter, char *key, char *value);

  void htmlDecode(char *value) const;

protected:
  map<string, char *> m_args;
};

#endif
