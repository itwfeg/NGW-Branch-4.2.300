// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __VIEWPORT_H__
#define __VIEWPORT_H__

#include "ViewPortState.h"
#include "rfb/FrameBuffer.h"
#include "desktop/Desktop.h"
#include "thread/LocalMutex.h"
#include "util/DateTime.h"
#include "log-writer/LogWriter.h"

// This class calculates actual view port rectangle.
// Typical usage:
// // Initialisation
// ViewPort m_viewPort;
// ...
// ...
// m_viewPort.update(&frameBuffer->getDimension());
// Rect viewPort = m_viewPort.getViewPortRect();
class ViewPort
{
public:
  ViewPort(LogWriter *log);
  ViewPort(const ViewPortState *viewPortState, LogWriter *log);
  ~ViewPort();

  // Sets desktop interface that can be used in some mode to get
  // desktop info. The desktop interface uses only in the update() function.
  void initDesktopInterface(Desktop *desktop);

  // This function updates view port rectangle. The new view port rectangle
  // will be constrained by fbDimension.
  void update(const Dimension *fbDimension);

  // This function returns the view port rectangle.
  Rect getViewPortRect();

  // Returns true if checked share only application.
  bool getOnlyApplication();

  // Returns a region that has rectangles of application which was visible
  // window parts at latest calling of the update() function. The region
  // doesn't changes by the update function if checked mode isn't "shareapp".
  void getApplicationRegion(Region *region);

  // Assignes self values by an external state.
  void changeState(const ViewPortState *newState);

private:
  // Disable the copy operation and constructor.
  ViewPort(const ViewPort &);
  ViewPort & operator =(const ViewPort &);

  // Resolves a window name of the view port state to window handle.
  // On an error the function do nothing.
  void resolveWindowName();

  static const int RESOLVING_PERIOD = 3000;

  Desktop *m_desktop;

  ViewPortState m_state;
  Rect m_rect;
  Region m_appRegion;
  LocalMutex m_stateMutex;

  DateTime m_latestHwndResolvingTime;

  LogWriter *m_log;
};

#endif // __VIEWPORT_H__
