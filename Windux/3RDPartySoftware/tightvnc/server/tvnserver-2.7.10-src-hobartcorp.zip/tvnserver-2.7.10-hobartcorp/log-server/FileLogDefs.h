// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __FILE_LOG_DEFS_H__
#define __FILE_LOG_DEFS_H__

typedef size_t FileAccountHandle;

#endif // __FILE_LOG_DEFS_H__
