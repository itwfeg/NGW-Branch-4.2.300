var searchData=
[
  ['keep_5fout_5fregion_5f1_5fheight',['KEEP_OUT_REGION_1_HEIGHT',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39adbdebc7660e336ee8ea4041d3e4beb8d',1,'SampleLabelEmbedder.cpp']]],
  ['keep_5fout_5fregion_5f1_5ftop_5fleft_5fx',['KEEP_OUT_REGION_1_TOP_LEFT_X',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39ad71c3ee3527ea74c6c57e163ce9d8ef4',1,'SampleLabelEmbedder.cpp']]],
  ['keep_5fout_5fregion_5f1_5ftop_5fleft_5fy',['KEEP_OUT_REGION_1_TOP_LEFT_Y',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a2f150d9538644fdc8ab0c715a18190f3',1,'SampleLabelEmbedder.cpp']]],
  ['keep_5fout_5fregion_5f1_5fwidth',['KEEP_OUT_REGION_1_WIDTH',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39ac235a163c545ed3ef4f96d532464a537',1,'SampleLabelEmbedder.cpp']]],
  ['keep_5fout_5fregion_5f2_5fheight',['KEEP_OUT_REGION_2_HEIGHT',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a76346810f33e4930dfa39bd12972bb9c',1,'SampleLabelEmbedder.cpp']]],
  ['keep_5fout_5fregion_5f2_5ftop_5fleft_5fx',['KEEP_OUT_REGION_2_TOP_LEFT_X',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a93db4852184127a3c21095addb4dd0fc',1,'SampleLabelEmbedder.cpp']]],
  ['keep_5fout_5fregion_5f2_5ftop_5fleft_5fy',['KEEP_OUT_REGION_2_TOP_LEFT_Y',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a71c64d5577f2b8a69b233a727c043df9',1,'SampleLabelEmbedder.cpp']]],
  ['keep_5fout_5fregion_5f2_5fwidth',['KEEP_OUT_REGION_2_WIDTH',['../SampleLabelEmbedder_8cpp.html#a0ba79095c558cb72ea2e8b277be1da39a62cf937663d1cf1a152fe3c2428362c8',1,'SampleLabelEmbedder.cpp']]]
];
