// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "TextBox.h"

TextBox::~TextBox()
{
}

void TextBox::setCaretPos(int h, int v)
{
  SendMessage(m_hwnd, EM_LINESCROLL, h, v);
}

size_t TextBox::getTextLengthLimit()
{
  return SendMessage(m_hwnd, EM_GETLIMITTEXT, 0, 0);
}

void TextBox::setTextLengthLimit(size_t n)
{
  SendMessage(m_hwnd, EM_SETLIMITTEXT, n, 0);
}

int TextBox::getCurrentLineIndex()
{
  return (int)SendMessage(m_hwnd, EM_LINEINDEX, -1, 0);
}

int TextBox::getLineCount()
{
  return (int)SendMessage(m_hwnd, EM_GETLINECOUNT, 0, 0);
}

//
// FIXME: Unimplemented
//

int TextBox::getCaretPos()
{
  return 0;
}

void TextBox::selectText(size_t startPos, size_t endPos)
{
  SendMessage(getWindow(), EM_SETSEL, startPos, endPos);
}

void TextBox::showBalloonTip(Tooltip *tip)
{
  tip->showTooltip(this);
}

