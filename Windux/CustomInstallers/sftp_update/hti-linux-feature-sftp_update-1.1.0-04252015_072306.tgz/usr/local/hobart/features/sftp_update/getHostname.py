######################################################
##
##       PROLOGUE
##  AUTHOR  : Todd Davis
##  COMPANY : ITW Hobart
##  DATE    : October 15, 2012
##  OVERVIEW: This script reports the macAddress of the scale.
##  REQS    : None
##  RETURNS : Qmx or Qmt based on os.name
######################################################

# Preprocessor directives
##########################
import sys
import os
import string
import shellCommand

# TODO:
# Need to change this script to just use python socket module, no shell command required
# It would be alot faster and works on Windows and Linux
# import socket
# socket.gethostname()

def getHostname():
    if os.name == "posix":
        # LINUX OS
        try:
            hostnameFileHandle = open("/etc/hostname", 'r')
            line = hostnameFileHandle.readline()
            hostnameFileHandle.close()
            hostname = string.strip(line)
            exitCode = 0
        except:
            exitCode = 1
    else:
        # WINDOWS OS
        cmd = []
        cmd.append("hostname")
        exitCode, stdout, stderr = shellCommand.execute(cmd)
        hostname = string.strip(stdout)

    return (exitCode, hostname)


if __name__=='__main__':
    exitCode, hostname = getHostname()
    print hostname
    sys.exit(exitCode)

