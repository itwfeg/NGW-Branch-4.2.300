// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __HOOKUPDATETIMER_H__
#define __HOOKUPDATETIMER_H__

#include "thread/Thread.h"
#include "UpdateListener.h"
#include "win-system/WindowsEvent.h"

// This class is a timer that after calling the sear() function
// wait a time interval after that it notifies to an update listener
// for update/updates catching. It's should to help the HooksupdateDetector
// to wait an time interval because the HooksupdateDetector can't wait
// directly by sleep. Usage of this class is questionable.
class HookUpdateTimer : public Thread
{
public:
  // @param updateListener - pointer to an UpdateListener object
  HookUpdateTimer(UpdateListener *updateListener);
  virtual ~HookUpdateTimer();

  // This function start a timer after that will calling onUpdate()
  // function of the update listener
  void sear();

protected:
  virtual void execute();
  virtual void onTerminate();

  WindowsEvent m_updateWaiter;
  WindowsEvent m_timer;
  UpdateListener *m_updateListener;
};

#endif // __HOOKUPDATETIMER_H__
