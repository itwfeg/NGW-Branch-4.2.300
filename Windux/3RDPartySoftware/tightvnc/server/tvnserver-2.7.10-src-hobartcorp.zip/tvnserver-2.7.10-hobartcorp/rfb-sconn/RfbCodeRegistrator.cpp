// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "RfbCodeRegistrator.h"

RfbCodeRegistrator::RfbCodeRegistrator(RfbDispatcher *dispatcher,
                                       CapContainer *srvToClCaps,
                                       CapContainer *clToSrvCaps,
                                       CapContainer *encCaps)
: m_dispatcher(dispatcher),
  m_srvToClCaps(srvToClCaps),
  m_clToSrvCaps(clToSrvCaps),
  m_encCaps(encCaps)
{
}

RfbCodeRegistrator::~RfbCodeRegistrator()
{
}

void RfbCodeRegistrator::regCode(UINT32 code, RfbDispatcherListener *listener)
{
  m_dispatcher->registerNewHandle(code, listener);
}

void RfbCodeRegistrator::addSrvToClCap(UINT32 code, const char *vendorSignature,
                                       const char *nameSignature)
{
  m_srvToClCaps->addCap(code, vendorSignature, nameSignature);
}

void RfbCodeRegistrator::addClToSrvCap(UINT32 code, const char *vendorSignature,
                                       const char *nameSignature)
{
  m_clToSrvCaps->addCap(code, vendorSignature, nameSignature);
}

void RfbCodeRegistrator::addEncCap(UINT32 code, const char *vendorSignature,
                                   const char *nameSignature)
{
  m_encCaps->addCap(code, vendorSignature, nameSignature);
}
