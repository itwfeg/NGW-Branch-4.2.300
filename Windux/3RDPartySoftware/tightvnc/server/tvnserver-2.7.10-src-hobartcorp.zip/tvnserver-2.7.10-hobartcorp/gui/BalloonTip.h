// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _BALLOON_TIP_H_
#define _BALLOON_TIP_H_

#include "Tooltip.h"
#include "util/CommonHeader.h"
#include <commctrl.h>

/**
 * @deprecated, use ToolTip instead.
 */
class BalloonTip : public Tooltip
{
public:
  BalloonTip(const TCHAR *text, const TCHAR *caption);
  BalloonTip();
  virtual ~BalloonTip();

  void showTooltip(Control *control);

  void setText(const TCHAR *text);
  void setTitle(const TCHAR *caption);

  void getText(StringStorage *text) const;
  void getTitle(StringStorage *title) const;

  void setIconType(int iconType);
  int getIconType() const;

protected:
  StringStorage m_text;
  StringStorage m_title;
};

#endif
