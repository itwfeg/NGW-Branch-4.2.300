// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _TRACKBAR_H_
#define _TRACKBAR_H_

#include "Control.h"

class Trackbar : public Control
{
public:
  Trackbar();
  virtual ~Trackbar();

  // Sets the range of minimum and maximum logical positions for the slider.
  void setRange(long min, long max);

  // Sets the current logical position of the slider.
  void setPos(long pos);

  // Returns the current logical position of the slider.
  long getPos();
};

#endif
