﻿using System;

namespace BnWasp
{
	public class CycleEventArgs : EventArgs
	{
		public int Number { get; private set; }

		public CycleEventArgs(int number)
		{
			Number = number;
		}
	}
}
