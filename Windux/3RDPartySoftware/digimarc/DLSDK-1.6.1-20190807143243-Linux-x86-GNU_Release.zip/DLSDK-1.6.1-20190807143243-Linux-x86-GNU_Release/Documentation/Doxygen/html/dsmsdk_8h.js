var dsmsdk_8h =
[
    [ "DSM_DATADESC", "structDSM__DATADESC.html", "structDSM__DATADESC" ],
    [ "DSM_KEEP_OUT_REGION", "structDSM__KEEP__OUT__REGION.html", "structDSM__KEEP__OUT__REGION" ],
    [ "DSM_GENERATOR_OPTIONS", "structDSM__GENERATOR__OPTIONS.html", "structDSM__GENERATOR__OPTIONS" ],
    [ "DSM_EMBEDDER_OPTIONS", "structDSM__EMBEDDER__OPTIONS.html", "structDSM__EMBEDDER__OPTIONS" ],
    [ "DSM_API_METHOD", "dsmsdk_8h.html#a65e000bdb282c26fcf62c7d3bd506acf", null ],
    [ "DSM_API", "dsmsdk_8h.html#a992635d69e1e048651d635d74fa741ba", null ],
    [ "DSM_UINT16", "dsmsdk_8h.html#a434079304bb6e7b714b0b8867f36c872", null ],
    [ "DSM_UINT32", "dsmsdk_8h.html#ae8251dcb4c8a12124ce0fd1d69482ebc", null ],
    [ "DSM_DATADESC_TYPE", "dsmsdk_8h.html#a13fbdca3ed1aadc6e59ddda6d8962d12", [
      [ "DSM_DATADESC_GRAYSCALE", "dsmsdk_8h.html#a13fbdca3ed1aadc6e59ddda6d8962d12a712fc77b127ee00c4dd2c707dc8e53e7", null ],
      [ "DSM_DATADESC_GRAYSCALE_INV", "dsmsdk_8h.html#a13fbdca3ed1aadc6e59ddda6d8962d12a073ed68eb9fe803c89e75c2d379a3925", null ],
      [ "DSM_DATADESC_ONE_BPP", "dsmsdk_8h.html#a13fbdca3ed1aadc6e59ddda6d8962d12a1087e48db0ed1aebf38dace201bec457", null ]
    ] ],
    [ "DSM_DOT_PATTERN", "dsmsdk_8h.html#a340a23c177f71904ab02d6819faf1d11", [
      [ "DSM_DOT_PATTERN_CIRCULAR", "dsmsdk_8h.html#a340a23c177f71904ab02d6819faf1d11aa5c7fe2fe1b7363b0417c14380f6f242", null ],
      [ "DSM_DOT_PATTERN_CHECKERBOARD", "dsmsdk_8h.html#a340a23c177f71904ab02d6819faf1d11a5551a42ee1a61e3861851eba8404a1cf", null ]
    ] ],
    [ "DSM_IMAGE_BLEND_MODE", "dsmsdk_8h.html#a0fd55dc403447cbf5f88f43b6cf267c0", [
      [ "DSM_IMAGE_BLEND_MODE_OVERWRITE", "dsmsdk_8h.html#a0fd55dc403447cbf5f88f43b6cf267c0a786dc2c66a984b31217fd4c6b3a569f6", null ],
      [ "DSM_IMAGE_BLEND_MODE_MERGE", "dsmsdk_8h.html#a0fd55dc403447cbf5f88f43b6cf267c0a327c042fe837137a56a4f5c74b571324", null ],
      [ "DSM_IMAGE_BLEND_MODE_DILATE", "dsmsdk_8h.html#a0fd55dc403447cbf5f88f43b6cf267c0a046fc7e7cacc7e3409ec968644344da4", null ]
    ] ],
    [ "DSM_RESULT", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16e", [
      [ "DSM_OK", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16eadaac5fd119a417508e5893f0f1413cfb", null ],
      [ "DSM_INVALID_HANDLE", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16eada3cebaca4008e5a9b5bbce0b6b41e53", null ],
      [ "DSM_INVALID_ARGUMENT", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16ea92b1ef2844ded0d34bbc540c8c51adf5", null ],
      [ "DSM_IMAGE_RESOLUTION_OUT_OF_RANGE", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16ea25af11f85e37ff2649317ab0007b49d3", null ],
      [ "DSM_WATERMARK_RESOLUTION_OUT_OF_RANGE", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16eaa1096db8ec2a245acadc6c31e31fb5de", null ],
      [ "DSM_PAYLOAD_OUT_OF_RANGE", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16ea48a5d7bf305f9e6518c98cb6f836266e", null ],
      [ "DSM_INVALID_DATA_DESC", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16ea36a3325962a6088d4663cdbde4c2a119", null ],
      [ "DSM_MEMORY_ERROR", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16ea4a2dc50c3bbdc8ea59daabb01198b79e", null ],
      [ "DSM_INTERNAL_ERROR", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16ea8c70fc971b21ea13acb3c73eea115f0e", null ],
      [ "DSM_INVALID_PAYLOAD_ALIAS", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16eaef8e07c7ecb1c11ffb4534d9199c1b1d", null ],
      [ "DSM_INVALID_PAYLOAD_DATA", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16ea7876bb67d07da0271e006f4e1c37d9d6", null ],
      [ "DSM_PAYLOAD_BUFFER_NULL", "dsmsdk_8h.html#affc079bbe4e7c847b5148abe41d7c16ea684fec39d22414b46e2db45a3be2786e", null ]
    ] ],
    [ "DSM_Close", "dsmsdk_8h.html#a8748fa95a54c7ba74616f1ecee24db8e", null ],
    [ "DSM_EmbedSparseMark", "dsmsdk_8h.html#af3b5aa1440b3fa6c11abcd958bba260b", null ],
    [ "DSM_GenerateSparseMark", "dsmsdk_8h.html#acef3b1cc533dc6811262b1a65c1733f2", null ],
    [ "DSM_InitializeEmbedderOptions", "dsmsdk_8h.html#a980b1a454f755ff40e33d9367c7019af", null ],
    [ "DSM_Open", "dsmsdk_8h.html#ab4c7df41a3d646b7c4094dc185f26613", null ]
];