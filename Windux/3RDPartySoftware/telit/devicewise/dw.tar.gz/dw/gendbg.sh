cd /opt/dw
                                                                                                    
mkdir dwdbg
date > dwdbg/datestamp
cp  dwversion dwdbg/dwversion
cp  version dwdbg/version
cp  staging/pppd.log dwdbg/pppd.log
cp  staging/dialer.log dwdbg/dialer.log                                                                                                    
cp  staging/config.properties.atstart dwdbg/config.properties.atstart                                                                                                    
mkdir dwdbg/dwcore
mkdir dwdbg/dwcore/logs
cp dwcore/dwcore.properties dwdbg/dwcore/dwcore.properties
if [ -f dwcore/dwcore.platform.properties ];
then
	cp dwcore/dwcore.platform.properties dwdbg/dwcore/dwcore.platform.properties
fi
cp dwcore/log.properties dwdbg/dwcore/log.properties
cp dwcore/logs/*.* dwdbg/dwcore/logs/.
cp dwcore/core* dwdbg/dwcore/.
                                                                                          
mkdir dwdbg/dwrun
cp dwrun/dwrun.conf dwdbg/dwrun/dwrun.conf
cp dwrun/*.log dwdbg/dwrun/.
                                                                                                    
mkdir dwdbg/db
cp db/*.* dwdbg/db/.

dmesg > dwdbg/dmesg.txt
uptime > dwdbg/uptime.txt
df -k > dwdbg/df.txt
uname -a > dwdbg/uname.txt

#DATETIME=`date +%Y%m%d-%H%M%S`
#tar zvcf staging/dwdbg.$DATETIME.tar.gz dwdbg
tar zvcf staging/dwdbg.tar.gz dwdbg /var/log/messages*
rm -fR dwdbg
