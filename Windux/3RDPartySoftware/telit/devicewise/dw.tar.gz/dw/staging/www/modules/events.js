var EventsCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded EventsCtrl','events');
  lpApi.loggingQuery({'limit':'100', 'page':'0'});

  // Resource Api
  $('#loading').show();
  $('#content-container').addClass('ng-cloak');
  Debug.log('Loading shown '+$('#loading').css('display'),'events');
  $http.post(lpApi.getUrl(''), lpApi.getPayload())
    .error($scope.errorCallback).success(function(a,b,c,d) { $scope.successCallback(a,b,c,d); $scope.eventList = $scope.loggingQuery; });

  // Properties

  // Functions
  $scope.showEvents = function() {
    if ($scope.eventList.params != undefined && $scope.eventList.params.result.length > 0) {
      return '';
    }
    return 'display: none;';
  };

  $scope.showNoEvents = function() {
    if ($scope.eventList.params == undefined || $scope.eventList.params.result.length == 0) {
      return '';
    }
    return 'display: none;';
  };
  
  // Executions
  $scope.clearSystemMsg();
  
  $scope.assertAuthentication();
  
  $scope.menuItemSelect($scope, 'gateway');
};

EventsCtrl.$inject = ['$scope','lpApi','$http'];

EventsCtrl.prototype.ctrlActions = {
  items : [{
    href : '',
    template : ''
  }]
};

EventsCtrl.prototype.mainActions = {
  items : [{
    href : '',
    template : ''
  }]
};

EventsCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};