var opcua = require("node-opcua");

/* Construct the OPC-UA server */
var server = new opcua.OPCUAServer({
    port: 4334,
    resourcePath: "UA/PillarTech",
    buildInfo: {
        productName: "IoTConceptServer",
        buildNumber: "1000",
        buildDate: new Date(2017, 11, 8)
    }
});

/* Initialize the server. */
module.exports = function (dataObject) {

    var obj = {
        data: dataObject,
        update: function (updated) {
            this.data = updated;
        },
        endpoint: '',
        start: function () {

            server.start(function () {
                console.log("Server is running ...");
                console.log("Port " + server.endpoints[0].port);

                var endpointUrl = server.endpoints[0].endpointDescriptions()[0].endpointUrl;
                console.log("Endpoint: ", endpointUrl);
                obj.endpoint = endpointUrl;
            });
        },

        stop: function() {
            server.shutdown();
        }
    }


    server.initialize(function () {
        console.log("OPC UA Server Initialized.");

        /* Construct an address space for the device. */
        var addressSpace = server.engine.addressSpace;
        var device = addressSpace.addObject({
            organizedBy: addressSpace.rootFolder.objects,
            browseName: "P6000"
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "Voltage",
            dataType: "Double",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Double, value: obj.data.voltage});
                },
            }
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "Current",
            dataType: "Double",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Double, value: obj.data.current});
                },
            }
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "Power",
            dataType: "Double",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Double, value: obj.data.power});
                },
            }
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "Frequency",
            dataType: "Double",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Double, value: obj.data.frequency});
                },
            }
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "InverterOn",
            dataType: "Boolean",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Boolean, value: obj.data.inverterOn});
                },
            }
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "HighTempFault",
            dataType: "Boolean",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Boolean, value: obj.data.highTempFault});
                },
            }
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "InterlockFault",
            dataType: "Boolean",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Boolean, value: obj.data.interlockFault});
                },
            }
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "DCBusFault",
            dataType: "Boolean",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Boolean, value: obj.data.DCBusFault});
                },
            }
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "OvervoltFault",
            dataType: "Boolean",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Boolean, value: obj.data.overvoltFault});
                },
            }
        });

        addressSpace.addVariable({
            componentOf: device,
            browseName: "CurrentTripFault",
            dataType: "Boolean",
            value: {
                get: function () {
                    return new opcua.Variant({dataType: opcua.DataType.Boolean, value: obj.data.currentFault});
                },
            }
        });
    });

    return obj;
};