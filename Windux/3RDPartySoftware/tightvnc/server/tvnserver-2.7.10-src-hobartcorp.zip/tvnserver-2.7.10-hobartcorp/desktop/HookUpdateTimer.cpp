// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "HookUpdateTimer.h"

HookUpdateTimer::HookUpdateTimer(UpdateListener *updateListener)
: m_updateListener(updateListener)
{
  resume();
}

HookUpdateTimer::~HookUpdateTimer()
{
  terminate();
  wait();
}

void HookUpdateTimer::onTerminate()
{
  m_updateWaiter.notify();
  m_timer.notify();
}

void HookUpdateTimer::execute()
{
  while (!isTerminating()) {
    m_updateWaiter.waitForEvent();
    m_timer.waitForEvent(100);
    m_updateListener->onUpdate();
  }
}

void HookUpdateTimer::sear()
{
  m_updateWaiter.notify();
}
