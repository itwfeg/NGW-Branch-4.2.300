// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __SECURITYPIPECLIENT_H__
#define __SECURITYPIPECLIENT_H__

#include "io-lib/Channel.h"

// The SecurityPipeClient class gets new security pipe connection by
// a granted temporary channel.
class SecurityPipeClient
{
public:
  // @param tempPublChan is a channel object connected to a server  from that
  // we receive the security pipe channel.
  // After successful creating this object take the security channel by
  // the getChannel() function to own.
  // @throw Exception on an error, the security channel at this case will be
  // destroyed.
  SecurityPipeClient(Channel *tempPublChan);
  virtual ~SecurityPipeClient();

  // Call this function at once to take the security channel. After calling
  // the function the object becomes to useless and may be destroyed.
  Channel *getChannel();

private:
  Channel *m_secChannel;
};

#endif // __SECURITYPIPECLIENT_H__
