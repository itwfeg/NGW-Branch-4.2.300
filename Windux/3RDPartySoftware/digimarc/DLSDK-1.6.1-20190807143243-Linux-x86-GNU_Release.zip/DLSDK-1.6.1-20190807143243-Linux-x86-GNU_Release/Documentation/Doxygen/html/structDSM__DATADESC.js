var structDSM__DATADESC =
[
    [ "BytesPerRow", "structDSM__DATADESC.html#a773b08561a2ce6422ed9deab5b4bd285", null ],
    [ "DataDescType", "structDSM__DATADESC.html#a4d0b15cc1a9f0b4bbbb09ea5f6ffbcf5", null ],
    [ "Height", "structDSM__DATADESC.html#a36d9047646e98372bae29fcb02e92a4f", null ],
    [ "pData", "structDSM__DATADESC.html#affa0ff006e438920f7c9b4a9c30648b4", null ],
    [ "Resolution", "structDSM__DATADESC.html#a2e5f971445d298411973f7e2b91ae740", null ],
    [ "Width", "structDSM__DATADESC.html#a6514151f7ceb0e472bf701112d06bfe0", null ]
];