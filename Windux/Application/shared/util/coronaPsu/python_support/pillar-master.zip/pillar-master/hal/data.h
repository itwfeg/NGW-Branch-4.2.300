//
// Created by collin on 11/2/17.
//

#include <string>
#include <vector>
#include "cJSON.h"

#ifndef PILLAR_DATA_H
#define PILLAR_DATA_H


#define HIGH_TEMP_FAULT     0x01
#define INTERLOCK_FAULT     0x02
#define DC_BUS_FAULT        0x04
#define OVER_VOLT_FAULT     0x08
#define CURRENT_TRIP_FAULT  0x10
#define INVERTER_ON         0x20

typedef struct {
    double voltage;
    double current;
    double frequency;
    double power;
    int fault;
}datapoint_bin_serial;

#define DATAPOINT_BINARY_SERIALIZATION_SIZE sizeof(datapoint_bin_serial)



class Datapoint
{
protected:
    double voltage;
    double frequency;
    double power;
    double current;
    int faults;

public:
    Datapoint(double voltage,
              double frequency,
              double power,
              double current,
              int faults);

    Datapoint(const Datapoint &datapoint);

    Datapoint(const std::vector<Datapoint> datapoints);

    virtual ~Datapoint();

    void serialize(cJSON** serialized);

    int serialize_binary(void* output);

    int deserialize_binary(const void* serialized);

    double getVoltage() const
    {
        return voltage;
    }

    double getFrequency() const
    {
        return frequency;
    }

    double getPower() const
    {
        return power;
    }

    double getCurrent() const
    {
        return current;
    }

    int getFaults() const
    {
        return faults;
    }

    bool isHighTempFault() const
    { return (faults & HIGH_TEMP_FAULT) > 0; }

    bool isInterlockFault() const
    { return (faults & INTERLOCK_FAULT) > 0; }

    bool isDCBusFault() const
    { return (faults & DC_BUS_FAULT) > 0; }

    bool isOverVoltFault() const
    { return (faults & OVER_VOLT_FAULT) > 0; }

    bool isCurrentFault() const
    { return (faults & CURRENT_TRIP_FAULT) > 0; }

    bool isInverterOn() const
    { return (faults & INVERTER_ON) > 0; }

};


#endif //PILLAR_DATA_H
