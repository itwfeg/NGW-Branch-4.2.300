var structDSM__EMBEDDER__OPTIONS =
[
    [ "eImageBlendMode", "structDSM__EMBEDDER__OPTIONS.html#a82a2c9e2fb9302ee93c9f47b21110577", null ],
    [ "nDotDensity", "structDSM__EMBEDDER__OPTIONS.html#a6f358f76a8dd522ad0db1f164f40d2c7", null ],
    [ "nDotSize", "structDSM__EMBEDDER__OPTIONS.html#a4586ccdc0cfa95b304bafe77a8e4355f", null ],
    [ "nNumKeepOutRegions", "structDSM__EMBEDDER__OPTIONS.html#acd44cd7c5b9e311f04be33de0ec3263c", null ],
    [ "nWatermarkRes", "structDSM__EMBEDDER__OPTIONS.html#a1b5735db16689277e55d4ac0b7e18433", null ],
    [ "pKeepOutRegionArray", "structDSM__EMBEDDER__OPTIONS.html#ad0ccbfeed42f8d6e691696e2f993d0d1", null ],
    [ "pPayload", "structDSM__EMBEDDER__OPTIONS.html#a4f1632fdc79b19a5c65f608e6da9388e", null ]
];