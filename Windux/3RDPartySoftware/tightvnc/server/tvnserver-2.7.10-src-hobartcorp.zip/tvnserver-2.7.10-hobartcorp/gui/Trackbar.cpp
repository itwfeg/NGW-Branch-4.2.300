// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "Trackbar.h"

Trackbar::Trackbar()
{
}

Trackbar::~Trackbar()
{
}

void Trackbar::setRange(long min, long max)
{
  SendMessage(m_hwnd, TBM_SETRANGEMIN, FALSE, min);
  SendMessage(m_hwnd, TBM_SETRANGEMAX, TRUE, max);
}

void Trackbar::setPos(long pos)
{
  SendMessage(m_hwnd, TBM_SETPOS, TRUE, pos);
}

long Trackbar::getPos()
{
  return (long)SendMessage(m_hwnd, TBM_GETPOS, 0, 0);
}
