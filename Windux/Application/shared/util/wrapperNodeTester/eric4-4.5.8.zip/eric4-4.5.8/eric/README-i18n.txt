README for the eric4 IDE's translations
    
    Installation of translations
    
        Translations of the eric4 IDE are available as separate downloads. There
        are two ways to install them.
        
        The first possibility is to install them together with eric4. In order
        to do that, simply extract the downloaded archives into the same place
        as the eric4 archive and follow the installation instructions of the
        eric4 README.
        
        The second possibility is to install them separately. Extract the
        downloaded archives and execute the install-i18n.py script (type
        python install-i18n.py -h for some help). This way you can make the
        translations available to everybody or just to the user executing the
        installation command (if using the -p switch).
