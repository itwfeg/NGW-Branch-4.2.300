// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "ParentWatcher.h"

ParentWatcher::ParentWatcher(ParentEventsListener *parentEventListener)
: m_parentEventListener(parentEventListener)
{
  resume();
}

ParentWatcher::~ParentWatcher()
{
  terminate();
  wait();
}

void ParentWatcher::onTerminate()
{
  m_timer.notify();
}

void ParentWatcher::execute()
{
  while (!isTerminating()) {
    if (!m_parentProcess.isAlive()) {
      m_parentEventListener->onParentTerminate();
    }
    m_timer.waitForEvent(1000);
  }
}
