// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CAPCONTAINER_H__
#define __CAPCONTAINER_H__

#include <vector>
#include "util/inttypes.h"
#include "io-lib/DataOutputStream.h"

// FIXME: The same structure is used in the viewer named RfbCapabilityInfo.
struct Cap
{
  UINT32 code;
  char vendorSignature[4];
  char nameSignature[8];
};

typedef std::vector<Cap> CapVector;
typedef std::vector<Cap>::const_iterator CapVectorConstIter;

class CapContainer
{
public:
  CapContainer();
  virtual ~CapContainer();

  void addCap(UINT32 code, const char *vendorSignature,
              const char *nameSignature);

  unsigned int getCapCount() const;
  void sendCaps(DataOutputStream *output) const;

  bool includes(UINT32 code) const;

private:
  CapVector m_caps;
};

#endif // __CAPCONTAINER_H__
