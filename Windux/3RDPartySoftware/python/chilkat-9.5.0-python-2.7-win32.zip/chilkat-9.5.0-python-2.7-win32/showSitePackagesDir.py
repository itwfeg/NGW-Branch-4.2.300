# Show the site-packages directory
import site

print(site.getsitepackages())
