// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __SECURITYPIPESERVER_H__
#define __SECURITYPIPESERVER_H__

#include "io-lib/Channel.h"
#include "TimerListener.h"

// The SecurityPipeServer class generates new security pipe connection by
// a granted temporary channel.
class SecurityPipeServer : private TimerListener
{
public:
  // @param tempPublChan is a channel object connected to a client that
  // requires the security pipe channel.
  // @throw Exception on an error.
  // After successful creating this object take the security channel by
  // the getChannel() function to own.
  SecurityPipeServer(Channel *tempPublChan);
  virtual ~SecurityPipeServer();

  // Call this function at once to take the security channel. After calling
  // the function the object becomes to useless and may be destroyed.
  Channel *getChannel();

private:
  virtual void onTimeTimer();

  HANDLE assignHandleFor(unsigned int procId, HANDLE srcHandle);
  void generateSecConnection(Channel *tempPublChan);
  void makeSure();

  Channel *m_secChannel;
};

#endif // __SECURITYPIPESERVER_H__
