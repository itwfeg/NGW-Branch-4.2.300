var searchData=
[
  ['vendor',['Vendor',['../classDigimarcLabelEmbedder_1_1Information.html#ac97aa5184b2035563c3a6c0bad211bec',1,'DigimarcLabelEmbedder::Information']]],
  ['versionbuild',['VersionBuild',['../classDigimarcLabelEmbedder_1_1Information.html#a5da5639d9f5f7fbb30c362fc2e6769a6',1,'DigimarcLabelEmbedder::Information']]],
  ['versionconstructed',['VersionConstructed',['../classDigimarcLabelEmbedder_1_1Information.html#a0185584f88d4553235a98dd393d8cf16',1,'DigimarcLabelEmbedder::Information']]],
  ['versionmajor',['VersionMajor',['../classDigimarcLabelEmbedder_1_1Information.html#a80551ae0baaf2f31dc9e14d924186488',1,'DigimarcLabelEmbedder::Information']]],
  ['versionminor',['VersionMinor',['../classDigimarcLabelEmbedder_1_1Information.html#a12b10329315362248777ec7e28bd694e',1,'DigimarcLabelEmbedder::Information']]],
  ['versionpatch',['VersionPatch',['../classDigimarcLabelEmbedder_1_1Information.html#ae26d7a3b9b28f5268a3d827bca1b95c2',1,'DigimarcLabelEmbedder::Information']]]
];
