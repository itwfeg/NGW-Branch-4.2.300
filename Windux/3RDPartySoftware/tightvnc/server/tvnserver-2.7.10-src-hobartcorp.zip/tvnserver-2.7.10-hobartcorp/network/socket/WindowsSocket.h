// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _WINSOCK_CLASS_H_
#define _WINSOCK_CLASS_H_

#include "util/CommonHeader.h"
#include "util/Exception.h"

//
// Class that startup and cleanup Windows Sockets subsystem.
//
class WindowsSocket
{
public:
  // Initializes Windows sockets subsystem.
  // Throws exception if winsock already initialized or
  // if was error during winsock startup.
  static void startup(BYTE loVer, BYTE hiVer) throw(Exception);

  //  Deinitializes Windows sockets subsystem.
  // Throws exception if winsock does not initialized or
  // if was error during winsock cleanup.
  static void cleanup() throw(Exception);

protected:
  static bool m_isStarted;
};

#endif
