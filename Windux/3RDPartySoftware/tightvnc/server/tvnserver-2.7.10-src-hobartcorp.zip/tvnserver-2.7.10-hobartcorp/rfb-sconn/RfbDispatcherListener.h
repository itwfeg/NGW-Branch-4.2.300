// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __RFBDISPATCHERLISTENER_H__
#define __RFBDISPATCHERLISTENER_H__

#include "network/RfbInputGate.h"

class RfbDispatcherListener
{
public:
  virtual ~RfbDispatcherListener() {};
  virtual void onRequest(UINT32 reqCode, RfbInputGate *input) = 0;
};

#endif // __RFBDISPATCHERLISTENER_H__
