// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "ScreenGrabber.h"

ScreenGrabber::ScreenGrabber(void)
{
}

ScreenGrabber::~ScreenGrabber(void)
{
}

bool ScreenGrabber::applyNewProperties()
{
  if (!applyNewPixelFormat() || !applyNewFullScreenRect()) {
    return false;
  }

  return true;
}

void ScreenGrabber::setWorkRect(Rect *workRect)
{
  m_offsetFrameBuffer.x = workRect->left;
  m_offsetFrameBuffer.y = workRect->top;
  m_workFrameBuffer.setEmptyDimension(workRect);
}

bool ScreenGrabber::setWorkRectDefault()
{
  // Set workRect to full screen by default
  if (!applyNewFullScreenRect()) {
    return false;
  }

  setWorkRect(&m_fullScreenRect);

  return true;
}
