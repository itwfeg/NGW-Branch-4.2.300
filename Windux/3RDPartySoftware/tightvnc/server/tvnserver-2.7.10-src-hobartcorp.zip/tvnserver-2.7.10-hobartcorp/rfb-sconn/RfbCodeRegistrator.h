// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __RFBCODEREGISTRATOR_H__
#define __RFBCODEREGISTRATOR_H__

#include "RfbDispatcher.h"
#include "CapContainer.h"

class RfbCodeRegistrator
{
public:
  RfbCodeRegistrator(RfbDispatcher *dispatcher,
                     CapContainer *srvToClCaps,
                     CapContainer *clToSrvCaps,
                     CapContainer *encCaps);
  virtual ~RfbCodeRegistrator();

  void regCode(UINT32 code, RfbDispatcherListener *listener);
  void addSrvToClCap(UINT32 code, const char *vendorSignature,
                     const char *nameSignature);
  void addClToSrvCap(UINT32 code, const char *vendorSignature,
                     const char *nameSignature);
  void addEncCap(UINT32 code, const char *vendorSignature,
                 const char *nameSignature);

private:
  RfbDispatcher *m_dispatcher;
  CapContainer *m_srvToClCaps;
  CapContainer *m_clToSrvCaps;
  CapContainer *m_encCaps;
};

#endif // __RFBCODEREGISTRATOR_H__
