// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "UpdSenderMsgDefs.h"

const char UpdSenderClientMsgDefs::RFB_VIDEO_FREEZE_SIG[] = "VD_FREEZ";
