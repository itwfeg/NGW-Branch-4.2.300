// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WIN8CURSORSHAPE_H__
#define __WIN8CURSORSHAPE_H__

#include "rfb/CursorShape.h"

// This class is wrapper for CursorShape class to extend it behaviour for the Win8 desktop
// duplication model.
class Win8CursorShape
{
public:
  Win8CursorShape();
  virtual ~Win8CursorShape();

  const CursorShape *getCursorShape() const;

  CursorShape *getCursorShapeForWriting();

  // threadOwner is a number of latest thread which call this function.
  void setVisibility(bool value, int threadOwner);

  bool getIsVisible() const;

private:
  int m_threadOwner;

  bool m_isVisible;
  CursorShape m_emptyDimensionCursorShape;
  CursorShape m_cursorShape;
};

#endif // __WIN8CURSORSHAPE_H__
