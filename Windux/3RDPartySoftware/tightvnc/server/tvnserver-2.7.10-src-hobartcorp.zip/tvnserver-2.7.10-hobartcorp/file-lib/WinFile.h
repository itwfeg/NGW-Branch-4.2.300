// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINFILE_H__
#define __WINFILE_H__

#include "util/CommonHeader.h"

enum DesiredAccess
{
  F_READ,
  F_WRITE,
  F_READ_WRITE
};

enum FileMode
{
  // Opens a file, always.
  // If the specified file does not exist and is a valid path to a writable
  // location, a function creates a file.
  FM_APPEND,
  // Creates a new file, always.
  // If the specified file exists and is writable, a function overwrites
  // the file, a function succeeds.
  FM_CREATE,
  // Creates a new file, only if it does not already exist.
  // If the specified file exists, a function fails with an Exception.
  FM_CREATE_NEW,
  // Opens a file, only if it exists.
  // If the specified file does not exist, a function fails with an Exception.
  FM_OPEN,
  // Opens a file, always.
  // If the specified file does not exist and is a valid path to a writable
  // location, a function creates a file.
  FM_OPEN_OR_CREATE,
  // Opens a file and truncates it so that its size is zero bytes,
  // only if it exists.
  // If the specified file does not exist, a function fails.
  FM_TRUNCATE
};

class WinFile
{
public:
  WinFile(const TCHAR *pathToFile, DesiredAccess dAcc, FileMode fMode,
          bool shareToRead = false);
  WinFile();

  virtual ~WinFile();

  // Call this function after this object creation by the default constructor.
  void open(const TCHAR *pathToFile, DesiredAccess dAcc, FileMode fMode,
            bool shareToRead = false);

  // Closes handle to a file if handle is valid.
  void close();

  // @throw exception on a system error.
  virtual size_t read(void *buff, size_t count);

  // @throw exception on a system error.
  virtual size_t write(const void *buff, size_t count);

  // Return true if object is valid. The object will be valid if
  // after by default constructor creation the initialize function has been
  // called successfully.
  bool isValid();

  // Return valid path name to a file.
  void getPathName(StringStorage *pathName);

  // Set file pointer to specified position starting from current
  // file pointer position. Can move forward and backward.
  void seek(INT64 n);

private:
  HANDLE m_hFile;
  StringStorage m_pathToFile;
};

#endif // __WINFILE_H__
