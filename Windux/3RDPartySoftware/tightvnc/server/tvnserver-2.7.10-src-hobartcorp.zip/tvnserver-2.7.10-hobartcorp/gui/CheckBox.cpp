// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "CheckBox.h"

bool CheckBox::isChecked()
{
  return (SendMessage(m_hwnd, BM_GETCHECK, NULL, NULL) != 0);
}

void CheckBox::check(bool checked)
{
  SendMessage(m_hwnd, BM_SETCHECK, (checked) ? 1 : 0, NULL);
}
