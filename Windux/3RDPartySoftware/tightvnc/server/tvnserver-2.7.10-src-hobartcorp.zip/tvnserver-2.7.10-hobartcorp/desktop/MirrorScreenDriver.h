// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __MIRRORSCREENDRIVER_H__
#define __MIRRORSCREENDRIVER_H__

#include "MirrorDriverClient.h"
#include "win-system/RegistryKey.h"
#include "DisplayEsc.h"
#include "thread/GuiThread.h"
#include "win-system/WindowsEvent.h"
#include "UpdateDetector.h"

class MirrorScreenDriver : public UpdateDetector
{
public:
  MirrorScreenDriver(UpdateKeeper *updateKeeper,
                     UpdateListener *updateListener,
                     LocalMutex *fbLocalMutex,
                     LogWriter *log);
  virtual ~MirrorScreenDriver();

  // Starts screen update detection if it not started yet.
  virtual void executeDetection();

  // Stops screen update detection.
  virtual void terminateDetection();

  virtual Dimension getScreenDimension();
  virtual FrameBuffer *getScreenBuffer();
  virtual bool grab(const Rect *rect = 0);

  virtual bool getPropertiesChanged();
  virtual bool getScreenSizeChanged();

  virtual bool applyNewProperties();

private:
  void initFrameBuffer();

  void startUpdateSearching();

  virtual void execute();
  virtual void onTerminate();

  MirrorDriverClient *m_mirrorClient;
  unsigned long m_lastCounter;
  FrameBuffer m_frameBuffer;
  // TO THINK: One may use a self mutex here, because do not
  // use external objects here.
  LocalMutex *m_fbMutex;

  WindowsEvent m_updateTimeout;

  LogWriter *m_log;
};

#endif // __MIRRORSCREENDRIVER_H__
