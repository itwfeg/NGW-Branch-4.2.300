//
// Created by collin on 9/21/17.
//

#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>
#include <sys/uio.h>

#include <string>
#include <iostream>
#include <atomic>
#include "hal_interface.h"

#include "datastructures/circular_buffer.h"

#define MAX_LINE_LENGTH 256

hal_interface::hal_interface() : serial_fd(-1)
{
    modbus_listener_run.clear();
}

hal_interface::~hal_interface()
{
    if (serial_fd >= 0)
    {
        close(serial_fd);
        serial_fd = -1;
    }
}

int hal_interface::connect(const std::string &port)
{
    std::cout << "Opening port " << port << std::endl;

    if (serial_fd != -1)
        return -EALREADY;

    int fd = open(port.c_str(), O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0)
        return -errno;

    std::cout << "Opened, fd=" << fd << std::endl;
    fcntl(fd, F_SETFL, 0);

    /* Configure the port with baud rate, etc... */
    struct termios tty;
    memset(&tty, 0, sizeof tty);
    if (tcgetattr(fd, &tty) != 0)
    {
        close(fd);
        return -errno;
    }

    cfsetospeed(&tty, B19200);
    cfsetispeed(&tty, B19200);

    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;     // 8-bit chars
    // disable IGNBRK for mismatched speed tests; otherwise receive break
    // as \000 chars
    tty.c_iflag = 0;                        // no remapping or delays.
    tty.c_lflag = 0;                        // no signaling chars, no echo, no canonical processing
    tty.c_oflag = 0;                        // no remapping, no delays
    tty.c_cc[VMIN] = 16;                     // read expects at least 6 bytes
    tty.c_cc[VTIME] = 1;                    // 0.1 seconds read timeout
    tty.c_iflag &= ~(IXON | IXOFF | IXANY); // shut off xon/xoff ctrl
    tty.c_cflag |= (CLOCAL | CREAD);        // ignore modem controls, enable reading
    tty.c_cflag &= ~(PARENB | PARODD);      // shut off parity
    //tty.c_cflag |= parity;
    tty.c_cflag &= ~CSTOPB;                 //1 stop bit

    if (tcsetattr(fd, TCSANOW, &tty) != 0)
    {
        close(fd);
        return -errno;
    }

    this->serial_fd = fd;
    std::cout << "Completed serial port connect" << std::endl;
    return 0;
}

int hal_interface::get_modbus_packet(std::string &packet)
{
    /* Verify the port is open. */
    if (serial_fd < 0)
        return -EBADFD;

    /* Start reading data until a whole line is read in. */
    char line[MAX_LINE_LENGTH];
    memset(line, 0, sizeof(line));
    size_t buffer_length_remaining = sizeof(line);

    char *eol = NULL;
    char *ptr = line;

    const char line_ending[] = { (char)0x8D, (char)0x8A, 0x00};

    while (eol == NULL && buffer_length_remaining > 0)
    {
        /* Read some data into the line. */
        std::cout << "Starting port read..." << std::endl;
        int sz = read(this->serial_fd, ptr, buffer_length_remaining);
        printf("sz = %d\n", sz);
        if (sz < 0)
            return -EIO;

        if(sz > 0)
        {
//            std::cout << "Read " << sz << " bytes: '" << ptr << "'" << std::endl;

            /* See if it's the end of the line. */
            eol = strstr(line, line_ending);

            for(int k = 0;k < sz;k++)
            {
                printf("%0.2X ", ptr[k]);
            }

            printf("eol=%p \n", eol);

            ptr += sz;
            buffer_length_remaining -= sz;
        }
        else
        {
            usleep(50000);
        }


    }
    packet= line;

    return packet.length();
}

#define BUFFER_SIZE 128
/**
 * Run the modbus listener thread.
 *
 * Executes a callback when a new line is received on the modbus. To minimize threading issues, the callback function
 * will be executed synchronously with other callbacks. (That is, only a single callback can be made at a time, per object)
 *
 * Requires a filedescriptor to the port where MODBUS data will be received and a runnable flag. If the flag
 * is set to false, the listener will exit so the thread can be joined.
 *
 * @param fd        The file descriptor to read raw MOBUS data from.
 * @param run       An atomic flag to indicate the desired run state of the listener thread
 * @param callback  A callback to execute when a new line is received.
 */
static void _modbus_listener_thread(int fd, std::atomic_flag* run, modbus_callback callback)
{
    selene::circular_buffer buffer(2 * BUFFER_SIZE);

    char ptr[BUFFER_SIZE];
    memset(ptr, 0, sizeof(ptr));

    int sz = 0;
    std::string line;

    while(run->test_and_set())
    {
        /* Read some data. */
        memset(ptr, 0, sizeof(ptr));
        sz = read(fd, ptr, sizeof(ptr));

        /* Validate. */
        if (sz < 0)
            break;//goto thread cleanup

        /* Strip extra stop bit. */
        for(int k = 0;k < sz;k++)
        {
            ptr[k] &= 0x7F;
        }

        /* Save the data. */
        buffer.push(ptr, sz);

        /* Try to read a line from the data. */
        int line_length = buffer.getline(line, (char)0x0A);
        if(line_length > 0)
        {
//            std::cout << "Got a line: " << line.length() << std::endl;
            callback(line);//execute the callback with the extracted line data.
        }

        usleep(50 * 1000);//wait enough time for another line to come in.
    }

}

int hal_interface::modbus_start_listen(modbus_callback callback)
{
    /* Check if we're already listening */
    if(modbus_listener.joinable() || modbus_listener_run.test_and_set())
    {
        modbus_listener_run.clear();
        return -EALREADY;
    }

    modbus_listener_run.clear();//maintain the listener state in case any other error conditions exit the function before starting the thread.

    /* Verify the port is open. */
    if (this->serial_fd < 0)
        return -EBADFD;

    /* Start the listener. */
    this->modbus_listener_run.test_and_set();
    this->modbus_listener = std::thread(_modbus_listener_thread, this->serial_fd, &this->modbus_listener_run, callback);

    return 0;
}

int hal_interface::modbus_stop_listen()
{
    /* See if the listener is running. */
    if(!modbus_listener.joinable())
        return -EALREADY;

    /* If it is, cancel the operation and join the thread. */
    this->modbus_listener_run.clear();
    this->modbus_listener.join();

    this->modbus_listener_run.clear();

    return 0;
}


