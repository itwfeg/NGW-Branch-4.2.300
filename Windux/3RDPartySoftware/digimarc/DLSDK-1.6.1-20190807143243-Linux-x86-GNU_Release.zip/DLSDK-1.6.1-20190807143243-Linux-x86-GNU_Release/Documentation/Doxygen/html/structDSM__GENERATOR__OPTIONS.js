var structDSM__GENERATOR__OPTIONS =
[
    [ "nDotDensity", "structDSM__GENERATOR__OPTIONS.html#ad48e8ea20dc397bb7996db6e23056160", null ],
    [ "nDotSize", "structDSM__GENERATOR__OPTIONS.html#aca4b766c8209383d586dae3b349e0413", null ],
    [ "nWatermarkRes", "structDSM__GENERATOR__OPTIONS.html#a8ad5b6527612c7d4342bff3d1361588c", null ],
    [ "pImageDesc", "structDSM__GENERATOR__OPTIONS.html#a05433900f51c5fc0ad3554ef642f2bb9", null ],
    [ "pPayload", "structDSM__GENERATOR__OPTIONS.html#a22879fb67019ad6db329a1a2ecc9bd20", null ]
];