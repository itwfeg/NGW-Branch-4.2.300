// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __POLLER_H__
#define __POLLER_H__

#include "UpdateDetector.h"
#include "ScreenGrabber.h"
#include "rfb/FrameBuffer.h"
#include "region/Rect.h"
#include "win-system/WindowsEvent.h"
#include "log-writer/LogWriter.h"

#define DEFAULT_SLEEP_TIME 1000

class Poller : public UpdateDetector
{
public:
  Poller(UpdateKeeper *updateKeeper,
         UpdateListener *updateListener,
         ScreenGrabber *screenGrabber,
         FrameBuffer *backupFrameBuffer,
         LocalMutex *frameBufferCriticalSection,
         LogWriter *log);

  virtual ~Poller();

protected:
  virtual void execute();
  virtual void onTerminate();

private:
  ScreenGrabber *m_screenGrabber;
  FrameBuffer *m_backupFrameBuffer;
  LocalMutex *m_fbMutex;
  Rect m_pollingRect;
  WindowsEvent m_intervalWaiter;

  LogWriter *m_log;
};

#endif // __POLLER_H__
