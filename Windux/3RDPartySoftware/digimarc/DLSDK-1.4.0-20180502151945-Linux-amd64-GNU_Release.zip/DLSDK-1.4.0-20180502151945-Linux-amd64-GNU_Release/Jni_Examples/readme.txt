How To run JniExampleKeepOutRegions.jar

Linux:

- Copy java/dlsdk.jar and java/libdlsdkjava.* to this folder.
- Run the following in shell prompt:

  java -classpath dlsdk.jar:JniExampleKeepOutRegions.jar -Djava.library.path=. com.digimarc.LabelEmbedder.example.JniExampleKeepOutRegions

Windows:

- Copy java\dlsdk.jar and java\dlsdkjava.* to this folder.
- Run the following in command prompt:

  java -classpath dlsdk.jar;JniExampleKeepOutRegions.jar -Djava.library.path=. com.digimarc.LabelEmbedder.example.JniExampleKeepOutRegions
