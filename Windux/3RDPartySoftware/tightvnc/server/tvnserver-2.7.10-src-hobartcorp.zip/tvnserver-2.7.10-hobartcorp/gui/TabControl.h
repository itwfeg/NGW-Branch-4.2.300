// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _TAB_CONTROL_H_
#define _TAB_CONTROL_H_

#include "Control.h"
#include "Tab.h"
#include "TabContainer.h"

using namespace std;

class TabControl : public Control
{
public:
  TabControl();
  ~TabControl();

  //
  // Tab access members
  //

  TabContainer &getTabs() { return m_tabContainer; }
  Tab *getTab(int index);
  void addTab(BaseDialog *dialog, const TCHAR *caption);
  void showTab(int index);
  void showTab(const BaseDialog *dialog);
  void deleteAllTabs();
  void removeTab(int index);

  //
  // Return selected tab number
  //

  int getSelectedTabIndex();

  //
  // Tab work rect methods
  //

  void adjustRect(RECT *rect);

protected:
  TabContainer m_tabContainer;
};

#endif
