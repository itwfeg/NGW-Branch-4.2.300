var searchData=
[
  ['pdata',['pData',['../structDSM__DATADESC.html#affa0ff006e438920f7c9b4a9c30648b4',1,'DSM_DATADESC']]],
  ['pimagedesc',['pImageDesc',['../structDSM__GENERATOR__OPTIONS.html#a05433900f51c5fc0ad3554ef642f2bb9',1,'DSM_GENERATOR_OPTIONS']]],
  ['pkeepoutregionarray',['pKeepOutRegionArray',['../structDSM__EMBEDDER__OPTIONS.html#ad0ccbfeed42f8d6e691696e2f993d0d1',1,'DSM_EMBEDDER_OPTIONS']]],
  ['ppayload',['pPayload',['../structDSM__GENERATOR__OPTIONS.html#a22879fb67019ad6db329a1a2ecc9bd20',1,'DSM_GENERATOR_OPTIONS::pPayload()'],['../structDSM__EMBEDDER__OPTIONS.html#a4f1632fdc79b19a5c65f608e6da9388e',1,'DSM_EMBEDDER_OPTIONS::pPayload()']]]
];
