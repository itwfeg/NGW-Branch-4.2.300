// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDXGIACQUIREDFRAME_H__
#define __WINDXGIACQUIREDFRAME_H__

#include "WinDxgiOutputDuplication.h"

#include <d3d11.h>
#include <DXGI1_2.h>

class WinDxgiAcquiredFrame
{
public:
  WinDxgiAcquiredFrame(WinDxgiOutputDuplication *outDupl, UINT timeOutMilliSec);
  virtual ~WinDxgiAcquiredFrame();

  bool wasTimeOut();

  IDXGIResource *getDxgiResource();
  DXGI_OUTDUPL_FRAME_INFO *getFrameInfo();

private:
  WinDxgiOutputDuplication m_outDupl;

  DXGI_OUTDUPL_FRAME_INFO m_frameInfo;
  IDXGIResource *m_desktopResource;
  bool m_wasTimeOut;
};

#endif // __WINDXGIACQUIREDFRAME_H__
