// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __UPDATELISTENER_H__
#define __UPDATELISTENER_H__

#include "thread/LocalMutex.h"

class UpdateListener
{
public:
  UpdateListener(void);
  virtual ~UpdateListener(void);

  // Interface function
  virtual void onUpdate() = 0;
};

#endif // __UPDATELISTENER_H__
