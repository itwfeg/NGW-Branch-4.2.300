// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINFILECHANNEL_H__
#define __WINFILECHANNEL_H__

#include "FileChannel.h"
#include "WinFile.h"

class WinFileChannel : public FileChannel
{
public:
  // Creates a channel with opens or creates a file with desired access.
  // See WinFile for detail.
  WinFileChannel(const TCHAR *pathName, DesiredAccess dAcc, FileMode fMode,
                 bool sharedToRead = true);
  ~WinFileChannel();

  // Inherited from FileChannel.
  virtual void seek(INT64 n);

  // Inherited from Channel.
  virtual size_t read(void *buffer, size_t len);

  // Inherited from Channel.
  virtual size_t write(const void *buffer, size_t len);

  // Inherited from Channel.
  virtual void close() throw(Exception);

private:
  WinFile m_winFile;
};

#endif // __WINFILECHANNEL_H__
