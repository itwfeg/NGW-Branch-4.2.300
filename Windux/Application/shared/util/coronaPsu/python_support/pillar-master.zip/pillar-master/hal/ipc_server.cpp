//
// Created by collin on 8/10/17.
//

#include "ipc_server.h"

ipc_server::ipc_server(const std::string &file) : socket_filename(file), s_local(-1), handler_callback(NULL)
{
    if (socket_filename.empty())
    {
        this->socket_filename = DEFAULT_SOCKET_FILENAME;
    }
}

ipc_server::~ipc_server()
{

}

int ipc_server::start()
{
    struct sockaddr_un local;

    /* Ensure that the local socket is in the expected condition before starting. */
    if (s_local != -1 && !server_thread.joinable())
        return -EALREADY;

    /* See if the Unix file already exists (and another server is already running). If it is, check if another server is running, delete it if not. */
    if (access(socket_filename.c_str(), F_OK) == 0)
    {
        /* If the file exists, try to connect a socket. (Test if another server is active). */
        struct sockaddr_un remote;
        int unix_fd = socket(AF_UNIX, SOCK_SEQPACKET, 0);
        if (unix_fd < 0)
            return -1;

        remote.sun_family = AF_UNIX;
        strcpy(remote.sun_path, socket_filename.c_str());
        int status = connect(unix_fd, (struct sockaddr *) &remote, sizeof(struct sockaddr_un)); //try to connect
        int err = errno;
        close(unix_fd); //cleanup

        if (status < 0 && ((err != EADDRINUSE) || (err == ECONNREFUSED)))
        {
            /* No other server is running, unlink the file and continue to open a new one. */
            unlink(socket_filename.c_str());
        } else
        {
            /* Someone else is running a server. */
            return -EADDRINUSE;
        }
    }

    /* Create the UNIX socket. */
    s_local = socket(AF_UNIX, SOCK_SEQPACKET, 0);
    if (s_local < 0)
    {
        LOG_ERROR(s_local, "An error occurred while binding the local socket: [" << errno << "] " << strerror(errno));
        return s_local;
    }

    /* Bind the socket to the file address. */
    local.sun_family = AF_UNIX;
    strcpy(local.sun_path, socket_filename.c_str());
    int status = bind(s_local, (struct sockaddr *) &local, sizeof(struct sockaddr_un));
    if (status < 0)
    {
        LOG_ERROR(status, "An error occurred while binding the local socket: [" << errno << "] " << strerror(errno));

        close(s_local);
        s_local = -1; //reset the socket to a default value.
        return status;
    }

    /* Start listening for a connection. */
    listen(s_local, 5);

    /* Start a thread to connect new remotes. */
    server_thread = std::thread(ipc_server::serve_remotes, this, s_local);

    return 0;
}

int ipc_server::stop()
{
    return 0;
}

void ipc_server::serve_remotes(ipc_server *server, int s_local)
{
    struct sockaddr_un remote;

    while (true)
    {
        int len = sizeof(struct sockaddr_un);
        int s_remote = accept(s_local, (struct sockaddr *) &remote, (socklen_t *) &len);
        int err = errno;

        if ((s_remote < 0) && ((err == EBADF) || (err == EINVAL)))
            return;//exit the thread when the connection/socket is closed.

        /* Got a new remote connection! Add it to the list of remotes. */
        if (s_remote >= 0)
        {
            std::unique_lock<std::mutex> remote_lock(server->remote_mutex);
            server->remotes.insert(std::pair<int, std::thread *>(s_remote,
                                                                 new std::thread(listen_remote, server, s_remote)));
        }
    }
}

void ipc_server::listen_remote(ipc_server *server, int s_remote)
{
    /* Validate the s_remote */
    if (s_remote < 0)
        return;

    /* Receive data continuously. */
    ssize_t n = 0;
    char *buffer = (char *) malloc(MAX_BUFFER_SZ);

    bool exit = false;
    while (!exit)
    {
        n = recv(s_remote, buffer, MAX_BUFFER_SZ, 0);

        if (n <= 0 && (errno != EINTR)) //An error occurred (socket may have closed on the other side)
        {
            exit = true;
        } else
        {
            /* Call the RX handler, if installed. */
            std::unique_lock<std::mutex> handler_lock(server->handler_mutex);
            if (server->handler_callback != NULL)
            {
                server->handler_callback(s_remote, buffer, n);
            }
        }
    }

    free(buffer);//clean-up
}

int writeDataToSocket(int fd, char *data, int dataLen)
{
    dataLen = dataLen < 0 ? 0 : dataLen;                        //clamp the size
    dataLen = dataLen > MAX_BUFFER_SZ ? MAX_BUFFER_SZ : dataLen;    //clamp the size

    /* Send the data. */
    ssize_t status = -1;
    while (status != dataLen)
    {
        status = send(fd,
                      data,
                      dataLen,
                      MSG_NOSIGNAL | MSG_DONTWAIT |
                      MSG_EOR); //this is likely in a mutex-locked critical section. Don't wait for a failure.

        if (status == -1)
        {
            if (errno == EINTR)
                continue;    //interrupted, try again

            return -errno;//something else happened, return a descriptive error
        }

        if (status != dataLen)
        {
            return (int)status;
        }
    }

    return 0;
}

int ipc_server::broadcast(const void *data, int len)
{
    /* Transmit to all clients. */
    std::unique_lock<std::mutex> remote_lock(remote_mutex);
    for (auto &remote : remotes)
    {
        writeDataToSocket(remote.first, (char *) data, len);
    }

    return 0;
}
