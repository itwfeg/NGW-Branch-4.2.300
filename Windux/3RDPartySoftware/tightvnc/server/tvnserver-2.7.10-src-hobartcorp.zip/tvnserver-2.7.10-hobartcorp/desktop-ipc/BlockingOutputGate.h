// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __BLOCKINGOUTPUTGATE_H__
#define __BLOCKINGOUTPUTGATE_H__

#include "io-lib/DataOutputStream.h"
#include "thread/LocalMutex.h"

class BlockingOutputGate : public LocalMutex, public DataOutputStream
{
public:
  BlockingOutputGate(OutputStream *outputStream);
  virtual ~BlockingOutputGate();
};

#endif // __BLOCKINGOUTPUTGATE_H__
