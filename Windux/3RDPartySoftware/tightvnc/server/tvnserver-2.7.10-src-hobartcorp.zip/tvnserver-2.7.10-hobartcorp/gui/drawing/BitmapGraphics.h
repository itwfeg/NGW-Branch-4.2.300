// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _BITMAP_GRAPHICS_H_
#define _BITMAP_GRAPHICS_H_

#include "Graphics.h"
#include "Bitmap.h"

//
// Object that creates bitmap with specified size and allow to
// draw into in through Graphics class methods.
class BitmapGraphics : public Graphics
{
public:
  // Creates BitmapGraphics object with bitmap complatible with specified dc and
  // with specified size.
  BitmapGraphics(DeviceContext *complatibleDC, int width, int height);
  // Destroys bitmap and graphics object.
  virtual ~BitmapGraphics();

  // Returns target bitmap that we paint.
  Bitmap *getBitmap();

  void beginPaint();
  void endPaint();

protected:
  bool m_isPainting;
  Bitmap *m_bitmap;
  HGDIOBJ m_oldBitmap;
};

#endif
