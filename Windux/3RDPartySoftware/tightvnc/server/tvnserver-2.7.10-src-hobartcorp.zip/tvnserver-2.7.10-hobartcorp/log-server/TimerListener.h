// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __TIMERLISTENER_H__
#define __TIMERLISTENER_H__

class TimerListener
{
public:
  virtual void onTimeTimer() = 0;
};

#endif // __TIMERLISTENER_H__
