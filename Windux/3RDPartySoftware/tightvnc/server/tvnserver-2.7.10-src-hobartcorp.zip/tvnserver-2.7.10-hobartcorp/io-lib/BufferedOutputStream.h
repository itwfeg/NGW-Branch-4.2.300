// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _BUFFERED_OUTPUT_STREAM_H_
#define _BUFFERED_OUTPUT_STREAM_H_

#include "OutputStream.h"
#include "DataOutputStream.h"

/**
 * Buffered output stream class (decorator pattern).
 * Adds bufferization feature to output stream.
 * @remark size of buffer now is fixed and equals to 1400 bytes.
 */
class BufferedOutputStream : public OutputStream
{
public:
  /**
   * Creates new buffered output stream.
   * @param output real output stream.
   */
  BufferedOutputStream(OutputStream *output);
  virtual ~BufferedOutputStream();

  /**
   * Writes data to output stream (with buffering).
   * @remark method can write data to inner buffer, not to real output stream.
   * data will be written to real output stream it inner buffer will overflow.
   * @throw IOException on error.
   * @fixme really it can throw any kind of exception.
   */
  virtual size_t write(const void *buffer, size_t len) throw(IOException);

  /**
   * Writes content of inner buffer to real output stream.
   * @throws IOException on error.
   * @fixme really it can throw any kind of exception.
   */
  void flush() throw(IOException);

protected:
  DataOutputStream *m_output;

  char m_buffer[1400];

  size_t m_dataLength;
};

#endif
