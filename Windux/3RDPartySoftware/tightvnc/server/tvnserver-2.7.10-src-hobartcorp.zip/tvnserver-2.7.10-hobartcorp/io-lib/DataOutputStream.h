// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _DATA_OUTPUT_STREAM_H_
#define _DATA_OUTPUT_STREAM_H_

#include "util/inttypes.h"
#include "OutputStream.h"
#include "IOException.h"

/**
 * Data output stream (decorator pattern).
 * Adds feature to write typezied data to output stream.
 */
class DataOutputStream : public OutputStream
{
public:
  /**
   * Creates new data output stream.
   * @param outputStream real output stream.
   */
  DataOutputStream(OutputStream *outputStream);
  virtual ~DataOutputStream();

  /**
   * Inherited from superclass.
   * @remark just delegates call to real output stream.
   */
  virtual size_t write(const void *buffer, size_t len) throw(IOException);

  /**
   * Writes exacly specified count of bytes to stream.
   * @param buffer source buffer.
   * @param len count of bytes to write.
   * @throws IOException on error.
   * @fixme really it can throw any kind of exception (depends on implementation
   * of output stream passed to costructor of DataOutputStream).
   */
  void writeFully(const void *buffer, size_t len) throw(IOException);

  void writeUInt8(UINT8 x) throw(IOException);
  void writeUInt16(UINT16 x) throw(IOException);
  void writeUInt32(UINT32 x) throw(IOException);
  void writeUInt64(UINT64 x) throw(IOException);

  void writeInt8(INT8 x) throw(IOException);
  void writeInt16(INT16 x) throw(IOException);
  void writeInt32(INT32 x) throw(IOException);
  void writeInt64(INT64 x) throw(IOException);

  void writeUTF8(const TCHAR *string) throw(IOException);

  /**
   * Flushes inner output stream.
   */
  virtual void flush() throw(IOException);
protected:
  OutputStream *m_outStream;
};

#endif
