// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _FILTERED_TEXT_BOX_H_
#define _FILTERED_TEXT_BOX_H_

#include "TextBox.h"
#include "BalloonTip.h"
#include "StringFilter.h"
#include "util/StringStorage.h"

class FilteredTextBox : public TextBox
{
public:
  FilteredTextBox();
  ~FilteredTextBox();

  // Override Control::setWindow method
  void setWindow(HWND hwnd);
  void setText(TCHAR *text);
  void setErrorBalloonTip(BalloonTip *tip);
  void setStringFilter(StringFilter *filter);
  LRESULT makeCheck();

protected:
  virtual bool isStringValid(const TCHAR *string);
  virtual LRESULT onKeyDown(WPARAM code, LPARAM params);

  static LRESULT CALLBACK windowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

protected:
  LONG_PTR m_oldWindowProc;
  StringStorage m_text;
  BalloonTip *m_tip;
  StringFilter *m_filter;
};

#endif
