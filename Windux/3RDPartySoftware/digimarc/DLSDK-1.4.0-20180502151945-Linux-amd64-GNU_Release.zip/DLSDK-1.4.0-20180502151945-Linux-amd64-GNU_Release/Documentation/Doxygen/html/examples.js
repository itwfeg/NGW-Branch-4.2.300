var examples =
[
    [ "ExampleExpandedFresh.cpp", "ExampleExpandedFresh_8cpp-example.html", null ],
    [ "ExampleExpandedFreshWeightRange2.cpp", "ExampleExpandedFreshWeightRange2_8cpp-example.html", null ],
    [ "ExampleGtinShared.cpp", "ExampleGtinShared_8cpp-example.html", null ],
    [ "ExampleGtinStatic.cpp", "ExampleGtinStatic_8cpp-example.html", null ],
    [ "ExampleKeepOutRegions.cpp", "ExampleKeepOutRegions_8cpp-example.html", null ],
    [ "ExampleMultipleEmbed.cpp", "ExampleMultipleEmbed_8cpp-example.html", null ],
    [ "ExampleSimpleProductIdGtin.cpp", "ExampleSimpleProductIdGtin_8cpp-example.html", null ],
    [ "ExampleSimpleProductIdUpce.cpp", "ExampleSimpleProductIdUpce_8cpp-example.html", null ],
    [ "ExampleUpce.cpp", "ExampleUpce_8cpp-example.html", null ],
    [ "SampleLabelEmbedder.cpp", "SampleLabelEmbedder_8cpp-example.html", null ]
];