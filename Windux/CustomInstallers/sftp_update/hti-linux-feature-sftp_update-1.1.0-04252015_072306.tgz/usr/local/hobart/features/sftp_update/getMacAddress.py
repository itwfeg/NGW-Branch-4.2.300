import sys
import os
import re
import string
import shellCommand

if os.name == 'posix':
    import dbus, fcntl, socket, struct
    def linuxGetMacAddress(ifname):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            info = fcntl.ioctl(s.fileno(), 0x8927,  struct.pack('256s', ifname[:15]))
            return ''.join(['%02x:' % ord(char) for char in info[18:24]])[:-1]
        except:
            return None

def getMacAddressRemoteHostByIp(ipAddress):
    macAddress = None

    cmd = []
    cmd.append("arp")
    cmd.append("-a")
    exitCode, stdout, stderr = shellCommand.execute(cmd)
    if exitCode == 0:
        if stdout is not None:
            if sys.platform in ['linux','linux2']:
                item = stdout.split("\n")
                for line in item:
                    lineItems = line.split()
                    if ipAddress in lineItems:
                        macAddress = lineItems[1].replace(':', '')

            elif sys.platform in ['win32']:
                item =  stdout.split("\n")
                for line in item:
                    lineItems = line.split()
                    if ipAddress in lineItems:
                        macAddress = lineItems[1].replace('-', '')
    return macAddress

def getMacAddress(lanType='wire'):
    macAddress = None
    exitCode = 1

    if os.name == "posix":
        if lanType == 'wire':
            try:
                macAddress = linuxGetMacAddress('eth0')
                exitCode = 0
            except:
                pass

        elif lanType == 'wireless':
            try:
                macAddress = linuxGetMacAddress('wlan0')
                exitCode = 0
            except:
                pass

    else:
        import ntNetworkUtils
        if lanType == 'wire':
            try:
                macAddress = ntNetworkUtils.getMacAddress('lan')
                exitCode = 0
            except:
                pass

        elif lanType == 'wireless':
            try:
                macAddress = ntNetworkUtils.getMacAddress('wlan')
                exitCode = 0
            except:
                pass

    return (exitCode,  macAddress)

if __name__ == "__main__":
    wiredMacAddress = None
    wirelessMacAddress = None

    exitCode,  wiredMacAddress = getMacAddress(lanType='wire')
    exitCode,  wirelessMacAddress = getMacAddress(lanType='wireless')

    if wiredMacAddress == None:
        wiredMacAddress = "No Device"

    if wirelessMacAddress == None:
        wirelessMacAddress = "No Device"

    print wiredMacAddress + "|" + wirelessMacAddress
    print getMacAddressRemoteHostByIp('10.3.177.89')
    sys.exit(exitCode)
