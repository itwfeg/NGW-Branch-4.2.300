// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "WindowsSocket.h"

bool WindowsSocket::m_isStarted = false;

void WindowsSocket::startup(BYTE loVer, BYTE hiVer)
{
  if (m_isStarted) {
    throw Exception(_T("WindowsSocket already initialized."));
  }

  WSAData wsaData;

  if (WSAStartup(MAKEWORD(loVer, hiVer), &wsaData) != 0) {
    throw Exception(_T("Failed to initialize WindowsSocket."));
  }

  m_isStarted = true;
}

void WindowsSocket::cleanup()
{
  if (!m_isStarted) {
    throw Exception(_T("WindowsSocket don't initialized."));
  }

  m_isStarted = false;

  if (WSACleanup() == SOCKET_ERROR) {
    throw Exception(_T("Failed to deinitialize WindowsSocket."));
  }
}
