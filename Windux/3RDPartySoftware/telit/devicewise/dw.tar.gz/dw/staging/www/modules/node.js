var NodeCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded NodeCtrl');
  lpApi.systemNodeinfo();

  $('#loading').show();
  $('#content-container').addClass('ng-cloak');
  Debug.log('Loading display '+$('#loading').css('display'));
  $http.post(lpApi.getUrl(''), lpApi.getPayload())
    .error($scope.errorCallback).success(function (a,b,c,d) { $scope.successCallback(a,b,c,d); });

  // Properties
  $scope.ctrlActions = [{
    liId:  "li-gatewayReboot",
    liStyle: "display: block;",
    href: "#/gateway/reboot",
    aId: "menu-item-rebootGateway",
    imgSrc: "/img/icon/16/rebootGateway.png",
    imgClass: "icon",
    imgAlt: "",
    text: "Reboot gateway"
  }];

  $scope.mainActions = [{
    href: "#/editNode",
    aClasses: "gray-button",
    text: "Edit node"
  }];

  //$scope.secondaryActions = [{}];

  // Functions
  $scope.updateNode = function() {
    lpApi.systemNodeset($scope.systemNodeinfo.params.nodeName, $scope.systemNodeinfo.params.nodeDescription);

    $resultScope = lpApi.go('', $scope);

    var msg, msgType;
    if ($resultScope.systemNodeset.success === true) {
      msg = 'Node Setting Saved Successfully!';
      msgType = 'success';
    }
    else {
      msg = 'Node Settings Not Saved! '+$resultScope.systemNodeset.errorMessage;
      msgType = 'error';
    }
    Debug.log(msg,'node');
    $scope.setSystemMsg(msg, msgType);
  };

  // Execution
  $scope.clearSystemMsg();

  $scope.assertAuthentication();

  $scope.menuItemSelect($scope, 'gateway');
};

NodeCtrl.$inject = ['$scope', 'lpApi', '$http'];

NodeCtrl.prototype.ctrlActions = {
  items : [{
    href : '',
    template : ''
  }]
};

NodeCtrl.prototype.mainActions = {
  items : [{
    name : 'Edit node',
    classes : '',
    id : 'main-action-editNode',
    href : '/editNode',
    template : 'partials/editNode.html'
  }]
};

NodeCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};
