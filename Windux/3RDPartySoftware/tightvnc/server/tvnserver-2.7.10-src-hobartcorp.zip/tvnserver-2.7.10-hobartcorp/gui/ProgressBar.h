// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _PROGRESS_BAR_H_
#define _PROGRESS_BAR_H_

#include "Control.h"

class ProgressBar : public Control
{
public:
  ProgressBar();
  ~ProgressBar();
  
  void setRange(WORD min, WORD max);
  void setPos(WORD pos);
};

#endif
