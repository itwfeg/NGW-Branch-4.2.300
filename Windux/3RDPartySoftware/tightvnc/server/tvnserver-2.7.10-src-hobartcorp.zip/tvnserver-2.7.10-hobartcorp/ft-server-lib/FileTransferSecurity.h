// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _FT_SECURITY_H_
#define _FT_SECURITY_H_

#include "util/Exception.h"
#include "util/Singleton.h"
#include "log-writer/LogWriter.h"

#include "win-system/Impersonator.h"

#include "desktop/Desktop.h"

class FileTransferSecurity : private Impersonator
{
public:
  FileTransferSecurity(Desktop *desktop, LogWriter *log);
  virtual ~FileTransferSecurity();

  // Sets access rights for calling process for execution
  // file transfer request handler code.
  void beginMessageProcessing();
  // Checks result and throws exception if caller
  // must not execute file transfer code and return error
  // to client.
  void throwIfAccessDenied() throw(Exception);
  // Sets previous (before startMessageProcessing call) access rights
  // for calling process.
  void endMessageProcessing();

protected:
  bool m_hasAccess;

  Desktop *m_desktop;

  LogWriter *m_log;
};

#endif
