// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __RECONNECTIONLISTENER_H__
#define __RECONNECTIONLISTENER_H__

#include "io-lib/Channel.h"

class ReconnectionListener
{
public:
  ReconnectionListener() {}
  virtual ~ReconnectionListener() {}

  virtual void onReconnect(Channel *newChannelTo, Channel *newChannelFrom) = 0;
};

#endif // __RECONNECTIONLISTENER_H__
