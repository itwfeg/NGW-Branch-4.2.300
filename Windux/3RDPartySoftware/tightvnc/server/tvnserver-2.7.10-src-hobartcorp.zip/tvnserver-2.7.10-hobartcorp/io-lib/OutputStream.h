// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _OUTPUT_STREAM_H_
#define _OUTPUT_STREAM_H_

#include "IOException.h"

/**
 * Output stream interface (abstract class).
 */
class OutputStream
{
public:
  virtual ~OutputStream();

  /**
   * Writes data to stream.
   * @param buffer buffer with data to write.
   * @param len count of bytes to write.
   * @return count of written bytes.
   * @throws any kind of exception (depends on implementation).
   */
  virtual size_t write(const void *buffer, size_t len) = 0;

  /**
   * Flushes inner buffer to real output stream.
   *
   * flush method of OutputStream does nothing, it can be override
   * by subclasses which uses bufferization.
   */
  virtual void flush();
};

#endif
