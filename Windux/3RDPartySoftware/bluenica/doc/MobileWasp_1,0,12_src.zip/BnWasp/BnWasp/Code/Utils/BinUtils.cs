﻿using System;

namespace BnWasp
{
	/// <summary>
	/// Bluenica-specific binary data conversion utilities.
	/// Usually used in HB data communication.
	/// </summary>
	public static class BinUtils
	{

		#region HB Payload parsers

		public static DateTime PayloadEpochToDateTime(byte[] bytes, int ofs, out UInt32 seconds)
		{
			seconds = (UInt32)(bytes[ofs + 3] * 256 * 256 * 256 + bytes[ofs + 2] * 256 * 256 + bytes[ofs + 1] * 256 + bytes[ofs + 0]);

			DateTime epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			DateTime converted = epoch.AddSeconds(seconds);

			// dates containing "1B" escape sequence fix (WizFi210/2210 are affected)
			DateTime utcNow = DateTime.UtcNow;
			double tot = (converted - utcNow).TotalDays;
			if (tot > 500 && tot < 516)
			{
				converted = converted.AddDays(-514);
			}

			return converted;
		}

		// Order in bytes: 10 30 00 00 E0 BE
		public static long PayloadBytesToTagId(byte[] bytes, int ofs)
		{
			long cff = 1;
			long id = 0;
			for (int i = 0; i < 6; i++)
			{
				id += bytes[ofs + i] * cff;
				cff *= 256;
			}
			return id;
		}

		// Order in bytes: BE E0 00 00 30 10
		public static long PayloadBytesRevToTagId(byte[] bytes, int ofs)
		{
			long cff = 1;
			long id = 0;
			for (int i = 5; i >= 0; i--)
			{
				id += bytes[ofs + i] * cff;
				cff *= 256;
			}
			return id;
		}

		/// <summary>
		/// Extracts the temperarture stored on two bytes: the integer and the decimal parts.
		/// </summary>
		/// <param name="bytes"></param>
		/// <param name="ofs"></param>
		/// <param name="tagId">The sensor the data come from</param>
		/// <returns></returns>
		public static float PayloadBytesTo2ByteTemperature(byte[] bytes, int ofs, long tagId)
		{
			float temp = 0;

			if (bytes == null || bytes.Length < ofs + 2)
				return temp;

			// Sensors BE.E0.00-00.00.00 to BE.E0.00-00.15.00 incorrectly encode the decimal part
			if (tagId >= 209869281951744 && tagId < 209869281957120)
			{
				// old-style sensor with incorrect unsigned decimal part
				temp = (sbyte)bytes[ofs];
				if (temp < 0)
					temp -= bytes[ofs + 1] / 100.0F;
				else
					temp += bytes[ofs + 1] / 100.0F;
			}
			else
			{
				// new-style sensor with signed decimal part
				temp = (sbyte)bytes[ofs] + (sbyte)bytes[ofs + 1] / 100.0F;
			}

			return temp;
		}

		public static UInt16 PayloadBytesToUInt16(byte[] bytes, int ofs)
		{
			return (UInt16)(bytes[ofs] + bytes[ofs + 1] * 256);
		}

		public static UInt32 PayloadBytesToUInt24(byte[] bytes, int ofs)
		{
			return (UInt32)(bytes[ofs] + bytes[ofs + 1] * 256 + bytes[ofs + 2] * 256 * 256);
		}

		public static UInt32 PayloadBytesToUInt32(byte[] bytes, int ofs)
		{
			UInt32 cff = 1;
			UInt32 val = 0;
			for (int i = 0; i < 4; i++)
			{
				val += bytes[ofs + i] * cff;
				cff *= 256;
			}
			return val;
		}

		public static float PayloadBytesToFloat(byte[] bytes, int ofs)
		{
			float ret = BitConverter.ToSingle(bytes, ofs);

			return ret;
		}

		#endregion

		#region HB Payload builders

		public static void UInt16ToPayloadBytes(UInt16 value, byte[] bytes, int ofs)
		{
			bytes[ofs+0] = (byte)(value & 0xFF);
			bytes[ofs+1] = (byte)((value & 0xFF00) >> 8);
		}

		public static void UInt32ToPayloadBytes(UInt32 value, byte[] bytes, int ofs)
		{
			bytes[ofs+0] = (byte)((value & 0x000000FF));
			bytes[ofs+1] = (byte)((value & 0x0000FF00) >> 8);
			bytes[ofs+2] = (byte)((value & 0x00FF0000) >> 16);
			bytes[ofs+3] = (byte)((value & 0xFF000000) >> 24);
		}

		public static void FloatToPayloadBytes(float value, byte[] bytes, int ofs)
		{
			Array.Copy(BitConverter.GetBytes(value), 0, bytes, ofs, 4);
		}

		// Order in bytes: 10 30 00 00 E0 BE
		public static void TagIdToPayloadBytes(long address, byte[] bytes, int ofs)
		{
			if (ofs + 6 > bytes.Length)
				return;

			long id = address;
			byte b;
			for (int i = 0; i < 6; i++)
			{
				b = (byte)(id & 0xFF);
				bytes[ofs + i] = b;
				id >>= 8;
			}
		}

		// Order in bytes: BE E0 00 00 30 10
		public static void TagIdToPayloadBytesRev(long address, byte[] bytes, int ofs)
		{
			if (ofs + 6 > bytes.Length)
				return;

			long id = address;
			byte b;
			for (int i = 5; i >= 0; i--)
			{
				b = (byte)(id & 0xFF);
				bytes[ofs + i] = b;
				id >>= 8;
			}
		}

		// Encodes the temperature for storing in the temperature record/advertising data
		// tempInt: the integer part (signed)
		// tempDec: the decimal part * 100  (signed)
		// Examples:
		//    15.74 =>  15,  74
		//    -0.23 =>   0, -23
		//   -15.74 => -15, -74
		public static void EncodeTemperatureOn2Bytes(float crrTemp, out byte tempInt, out byte tempDec)
		{
			float dec = (crrTemp - (byte)crrTemp) * 100.0F;

			tempInt = (byte)crrTemp;
			tempDec = (byte)dec;
		}

		#endregion

		#region Utilities

		/// <summary>
		/// Reverses bytes in a 4-byte integer.
		/// </summary>
		/// <returns>Integer with swapped order of bytes.</returns>
		/// <param name="n">Number to convert.</param>
		public static UInt32 SwapEndianness(UInt32 n)
		{
			return ((n & 0x000000ff) << 24) + 
				((n & 0x0000ff00) << 8) + 
				((n & 0x00ff0000) >> 8) + 
				((n & 0xff000000) >> 24);
		}

		/// <summary>
		/// Byteses to tag identifier in rev order.
		/// IEEE addresses in most communications are presented in reverse order:
		/// 34.10.00-00.E0.BE
		/// </summary>
		/// <returns>Tag id as a number.</returns>
		/// <param name="bytes">Byte array containing the address</param>
		/// <param name="offs">Address offset in the array</param>
		public static UInt64 BytesToTagIdRevOrder(byte[] bytes, int offs)
		{
			UInt64 tagId = 0;
			UInt64 cff = 1;

			for (int i = 0; i < 6; i++)
			{
				UInt64 v = bytes[i + offs] * cff;
				tagId += v;
				cff *= 256;
			}

			return tagId;
		}

		/// <summary>
		/// Byteses to tag identifier in natural order.
		/// IEEE addresses in print usually appear in the natural order:
		/// BE.E0.00-00.10.34
		/// </summary>
		/// <returns>Tag id as a number.</returns>
		/// <param name="bytes">Byte array containing the address</param>
		/// <param name="offs">Address offset in the array</param>
		public static UInt64 BytesToTagIdNatOrder(byte[] bytes, int offs)
		{
			UInt64 tagId = 0;
			UInt64 cff = 1;

			for (int i = 6 - 1; i >= 0; i--)
			{
				UInt64 v = bytes[i + offs] * cff;
				tagId += v;
				cff *= 256;
			}

			return tagId;
		}

		#endregion

	}

}

