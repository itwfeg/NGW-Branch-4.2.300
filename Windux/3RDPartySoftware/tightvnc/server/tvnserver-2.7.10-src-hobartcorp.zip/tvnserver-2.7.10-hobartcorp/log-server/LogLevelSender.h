// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __LOGLEVELSENDER_H__
#define __LOGLEVELSENDER_H__

#include "thread/Thread.h"
#include "win-system/WindowsEvent.h"
#include "io-lib/DataOutputStream.h"

class LogLevelSender : public Thread
{
public:
  LogLevelSender();
  virtual ~LogLevelSender();

  // Starts log level sender. If LogLevelSender still was not called then
  // the updateLevel() function calling will be ignored.
  void startSender(OutputStream *outStream);

  // Signals to the self thread for update available.
  void updateLevel(unsigned char newLevel);

private:
  virtual void execute();
  virtual void onTerminate();

  WindowsEvent m_sleeper;

  OutputStream *m_outStream;
  bool m_updateAvailable;
  unsigned char m_logLevel;
  LocalMutex m_updateMutex;
};

#endif // __LOGLEVELSENDER_H__
