// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __TEXTBOX_H_
#define __TEXTBOX_H_

#include "Control.h"
#include "Tooltip.h"

class TextBox : public Control
{
public:
  ~TextBox();
public:

  //
  // Text limit
  //

  size_t getTextLengthLimit();
  void setTextLengthLimit(size_t limit);

  //
  // Methods for multiline textboxes
  //

  int getCurrentLineIndex();
  int getLineCount();

  //
  // Get / set caret position
  //

  int getCaretPos();
  void setCaretPos(int h, int v);

  //
  // Text selection
  //

  void selectText(size_t startPos, size_t endPos);

  //
  // Tooltip methods
  //

  void showBalloonTip(Tooltip *tip);
};

#endif
