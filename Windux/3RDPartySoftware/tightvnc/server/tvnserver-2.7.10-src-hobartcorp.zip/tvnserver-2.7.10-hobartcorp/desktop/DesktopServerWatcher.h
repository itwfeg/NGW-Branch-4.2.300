// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __DESKTOPSERVERWATCHER_H__
#define __DESKTOPSERVERWATCHER_H__

#include "thread/Thread.h"
#include "win-system/Process.h"
#include "log-writer/LogWriter.h"
#include "desktop-ipc/ReconnectionListener.h"
#include "win-system/SharedMemory.h"

/**
 * Thread that used to execute desktop server application.
 *
 * @behavour:
 *   Thread in infinity loop executes (and waits until it dies) desktop
 *   server application.
 *   It will break only if thread will be terminated.
 */
class DesktopServerWatcher : public Thread
{
public:
  DesktopServerWatcher(ReconnectionListener *recListener, LogWriter *log);
  virtual ~DesktopServerWatcher();

protected:
  virtual void execute();
  virtual void onTerminate();

  // Runs desktop server with XP trick if it's needed.
  void start();

  // Changes active physical session to session0 and locks workstation.
  // @throws SystemException on fail.
  void doXPTrick();

  Process *m_process;
  ReconnectionListener *m_recListener;

  SharedMemory *m_sharedMem;
  StringStorage m_shMemName;

  LogWriter *m_log;
};

#endif // __DESKTOPSERVERWATCHER_H__
