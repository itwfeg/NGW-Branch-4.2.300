// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _BRUSH_H_
#define _BRUSH_H_

#include "util/CommonHeader.h"

class Brush
{
public:
  Brush();
  virtual ~Brush();

protected:
  void release();

protected:
  HBRUSH m_brush;

  friend class Graphics;
};

#endif
