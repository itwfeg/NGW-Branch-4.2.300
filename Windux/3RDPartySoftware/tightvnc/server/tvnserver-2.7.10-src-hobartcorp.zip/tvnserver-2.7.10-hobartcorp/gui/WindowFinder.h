// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINDOWFINDER_H__
#define __WINDOWFINDER_H__

#include "util/CommonHeader.h"
#include <vector>
#include "util/StringVector.h"

class WindowFinder
{
public:
  // hwndVector parameter will be cleared before adding new items
  static void findWindowsByClass(StringVector *classNames,
                                 std::vector<HWND> *hwndVector);

  // Find first of windows that name contain the string.
  // It is not case sensitive.
  static HWND findFirstWindowByName(const StringStorage *windowName);

protected:
  static BOOL CALLBACK findWindowsByClassFunc(HWND hwnd, LPARAM lParam);
  static BOOL CALLBACK findWindowsByNameFunc(HWND hwnd, LPARAM lParam);
};

#endif // __WINDOWFINDER_H__
