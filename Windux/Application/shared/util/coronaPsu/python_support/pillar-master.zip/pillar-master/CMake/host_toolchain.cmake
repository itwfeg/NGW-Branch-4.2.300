# Host toolchain file for Sigora Smart Meter
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_VERSION 1)

add_definitions(-DHOST_DEBUG)
