// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#include "RfbInputGate.h"

RfbInputGate::RfbInputGate(Channel *stream)
: DataInputStream(stream)
{
}

RfbInputGate::~RfbInputGate()
{
}
