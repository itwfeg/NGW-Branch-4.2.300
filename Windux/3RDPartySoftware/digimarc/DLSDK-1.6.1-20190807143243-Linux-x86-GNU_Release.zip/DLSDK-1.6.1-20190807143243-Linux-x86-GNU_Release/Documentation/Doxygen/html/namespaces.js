var namespaces =
[
    [ "DigimarcLabelEmbedder", "namespaceDigimarcLabelEmbedder.html", null ]
];