// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _TOOLTIP_H_
#define _TOOLTIP_H_

#include "util/CommonHeader.h"
#include "Control.h"

//
// Abstract tooltip class
//

class Tooltip
{
public:
  Tooltip();
  virtual ~Tooltip();

  virtual void showTooltip(Control *control) = 0;

  virtual void setText(const TCHAR *text) = 0;
  virtual void setTitle(const TCHAR *caption) = 0;

  virtual void getText(StringStorage *text) const = 0;
  virtual void getTitle(StringStorage *title) const = 0;

  virtual void setIconType(int iconType) = 0;
  virtual int getIconType() const = 0;
};

#endif
