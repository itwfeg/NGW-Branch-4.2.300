var searchData=
[
  ['width',['Width',['../structDSM__DATADESC.html#a6514151f7ceb0e472bf701112d06bfe0',1,'DSM_DATADESC::Width()'],['../structDSM__KEEP__OUT__REGION.html#a30bb79e10cd737848fc7994cbed2af37',1,'DSM_KEEP_OUT_REGION::Width()']]]
];
