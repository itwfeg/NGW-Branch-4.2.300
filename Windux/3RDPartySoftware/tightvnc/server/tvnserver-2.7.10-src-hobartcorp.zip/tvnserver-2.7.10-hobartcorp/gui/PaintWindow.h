// Copyright (C) 2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef _PAINT_WINDOW_H_
#define _PAINT_WINDOW_H_

#include "BaseWindow.h"
#include "drawing/DeviceContext.h"

class PaintWindow: public BaseWindow
{
public:
  PaintWindow();
  virtual ~PaintWindow();

private:
  HDC getHDCPaint();

  friend class DeviceContext;

protected:
  virtual void onPaint(DeviceContext *dc, PAINTSTRUCT *paintStruct);

  bool wndProc(UINT message, WPARAM wParam, LPARAM lParam);

  bool m_bIsDraw;
  PAINTSTRUCT m_paintStruct;
  HDC m_hdc;

};

#endif
