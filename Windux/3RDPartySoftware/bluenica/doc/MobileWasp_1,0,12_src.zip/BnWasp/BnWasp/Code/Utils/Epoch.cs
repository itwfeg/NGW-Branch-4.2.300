﻿using System;

namespace BnWasp
{
	public static class Epoch
	{

		/// <summary>
		/// Function converts Unix time (epoch) to UTC
		/// </summary>
		/// <param name="epochSeconds"></param>
		/// <returns></returns>
		public static DateTime EpochToUTC(UInt32 epochSeconds)
		{
			DateTime epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			DateTime converted = epoch.AddSeconds(epochSeconds);

			return converted;
		}

		/// <summary>
		/// Function returns specified UTC time as Unix epoch
		/// </summary>
		/// <returns></returns>
		public static UInt32 UTCToEpoch(DateTime utc)
		{
			DateTime epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			TimeSpan ts = utc - epoch;
			UInt32 epochSeconds = (UInt32)ts.TotalSeconds;

			return epochSeconds;
		}

		/// <summary>
		/// Function returns current UTC time as Unix epoch
		/// </summary>
		/// <returns></returns>
		public static UInt32 GetCurrentEpoch()
		{
			DateTime epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			TimeSpan ts = DateTime.UtcNow - epoch;
			UInt32 epochSeconds = (UInt32)ts.TotalSeconds;

			return epochSeconds;
		}
	}
}

