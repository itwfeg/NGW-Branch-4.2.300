// Copyright (C) 2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __SCREENDRIVERFACTORY_H__
#define __SCREENDRIVERFACTORY_H__

#include "ScreenDriver.h"
#include "UpdateKeeper.h"
#include "UpdateListener.h"
#include "log-writer/LogWriter.h"

class ScreenDriverFactory
{
public:
  virtual ScreenDriver *createScreenDriver(UpdateKeeper *updateKeeper,
                                             UpdateListener *updateListener,
                                             FrameBuffer *fb,
                                             LocalMutex *fbLocalMutex,
                                             LogWriter *log) = 0;
private:
};

#endif // __SCREENDRIVERFACTORY_H__
