// Copyright (C) 2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __CLIENTINPUTEVENTLISTENER_H__
#define __CLIENTINPUTEVENTLISTENER_H__

#include "util/inttypes.h"

class ClientInputEventListener
{
public:
  virtual void onKeyboardEvent(UINT32 keySym, bool down) = 0;
  virtual void onMouseEvent(UINT16 x, UINT16 y, UINT8 buttonMask) = 0;
};

#endif // __CLIENTINPUTEVENTLISTENER_H__
