var AssetsCtrl = function($scope, lpApi, $http) {
  Debug.log('Loaded AssetsCtrl','assets');
  // Preperations
  lpApi.assetList().assetTypeListall();

  $('#loading').show();
  $('#content-container').addClass('ng-cloak');
  Debug.log('Loading display '+$('#loading').css('display'));
  $http.post(lpApi.getUrl(''), lpApi.getPayload())
    .error($scope.errorCallback).success(function (a,b,c,d) { $scope.successCallback(a,b,c,d); });

  // Properties
  $scope.mainActions = [{
    id : 'main-action-addAsset',
    href: "#/addAsset",
    aClasses: "gray-button",
    text: "Add an asset"
  }];

  // Functions
  $scope.createAsset = function(){
    if ($scope.asset.name == undefined || String($scope.asset.name).length==0) {
      $scope.postError({'errorMessage': ['Name is required.']});
    }
    else if ($scope.asset.type == undefined || String($scope.asset.type).length==0) {
      $scope.postError({'errorMessage': ['Type is required.']});
    }
    else {
      lpApi.assetCreate($scope.asset.name, $scope.asset.type, $scope.asset.properties);
      $http.post(lpApi.getUrl(''), lpApi.getPayload())
        .error($scope.postError).success(function(a,b,c,d){ if (!a.assetCreate.success) { a.errorMessage = a.assetCreate.errorMessage; $scope.postError(a,b,c,d) } else { $scope.successCallback(a,b,c,d); $scope.setRoute('/assets') }});
    }
  };

  $scope.deleteAsset = function(asset) {
    if (confirm("Do you REALLY want to delete the asset with the name '" + asset.name + "'?")) {
      lpApi.assetDelete(asset.name);
      $http.post(lpApi.getUrl(''), lpApi.getPayload())
        .error($scope.postError).success(function(a,b,c,d){ if (!a.assetDelete.success) { a.errorMessage = a.assetDelete.errorMessage; $scope.postError(a,b,c,d) } else { $scope.successCallback(a,b,c,d); $scope.setRouteReload('/assets') }});
    }

    return false;
  };

  $scope.showAssets = function() {
    if ($scope.assetList != undefined && $scope.assetList.params != undefined && $scope.assetList.params.assets.length > 0) {
      return true;
    }
    return false;
  };

  $scope.showNoAssets = function() {
    if ($scope.assetList != undefined && $scope.assetList.params != undefined && $scope.assetList.params.assets.length == 0) {
      return true;
    }
    return false;
  };

  // Executions
  $scope.clearSystemMsg();

  $scope.assertAuthentication();

  $scope.menuItemSelect($scope, 'assets');

  $scope.showAssets();

  $scope.showNoAssets();
};

AssetsCtrl.$inject = ['$scope', 'lpApi', '$http'];

AssetsCtrl.prototype.ctrlActions = {
  items : [{
    href : '',
    template : ''
  }]
};

AssetsCtrl.prototype.mainActions = {
  items : [{
    href : '/addAsset',
    template : 'partials/addAsset.html'
  }]
};

AssetsCtrl.prototype.secondaryActions = {
  items : [{
    href : '',
    template : ''
  }]
};
