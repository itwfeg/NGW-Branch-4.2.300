// Copyright (C) 2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef SOCKET_EXCEPTION_H
#define SOCKET_EXCEPTION_H

#include "util/Exception.h"

#include "sockdefs.h"

class SocketException : public Exception
{
public:
  // Creates socket exception object with error value eq to current value
  // of WSAGetLastError().
  // Error string generates automaticly;
  SocketException();
  // Creates socket exception object with specified error numner.
  // Error string generates automaticly;
  SocketException(int error);
  // Creates socket exception object with specified message.
  // Error number is sets to zero.
  SocketException(const TCHAR *message);
  // Destructor.
  virtual ~SocketException();

  // Returns error number.
  int errno();

protected:
  // Sets m_errno and generates error description string.
  void setErrno(int error);

protected:
  int m_errno;
};

#endif
