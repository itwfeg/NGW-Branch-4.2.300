// - - - - - - - - - - - - - - - - - - - -
//
// Digimarc Confidential
// Copyright Digimarc Corporation, 2019
//
// - - - - - - - - - - - - - - - - - - - -
#ifndef PAYLOADHELPERRETAILTOKEN_H
#define PAYLOADHELPERRETAILTOKEN_H

#include <stdio.h>
#include <string.h>

#include "dsmsdk.h"
#include "PayloadHelper.h"
#include "StringFormatting.h"
#include "StringUtils.h"

#if defined( __cplusplus )
extern "C" {
#endif // __cplusplus

/**************************************************************************************************
 * VERSION INFORMATION
 * ------------------
 * Version: 1.6.1
 * Build: 20190807143243
 *
 *
 * INSTALLATION NOTES
 * ------------------
 *
 * To use the Retail Token feature:
 *	1) Place this header in your DL SDK include folder.
 *	2) Add #include <PayloadHelperRetailToken.h> to your source file.
 *	3) DSM_GetExpandedFreshJson_WithRetailToken() is now callable, similarly to the other
 *		PayloadHelper functions.
 *************************************************************************************************/

static const unsigned int DSM_TOKEN_LENGTH = 8;

/**
 * @brief Converts an ASCII Decimal string representing a GTIN-13 with valid check digit (for example, 8525960043024) and certain combinations of the other parameters
 * to a JSON string that is usable by the underlying encoder.
 *
 * @note SellbyDate
 *	- Allowable range:
		- **January 01, 2016** through **May 08, 2106**.
 *		- If it is provided, then it **Must have 6 digits**.
 *	- Use NULL or 0 or "0" to specify unused.
 *	- Input format:
 *		- YYMMDD See [GS1 General Specification: Sell by date: AI (16)](https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf).
 *		- 6 character string, null terminated.
 *	- Example:
 *		- "170415" = April 15, 2017.
 *
 * @note RetailToken
 *	- Allowable range:
 *		- 1 to 99999999.
 *	- Use NULL or 0 or "0" to specify unused
 *	- Input format:
 *		- ASCII decimal string of digits.
 *	- Example:
 *		- "123456"
 *
 * @param[in] Gtin13 An ASCII Decimal string representing a GTIN-13 (i.e. 0852596004050). Value provided **Must include valid check digit**.
 * @param[in] SellbyDate The day the item must be sold by (YYMMDD). See [GS1 General Specification: Sell by date: AI (16)](https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf) for further details.
 * @param[in] RetailToken An application defined token (1 to 99999999).
 * @param[out] PayloadOut A pointer to a buffer to place the generated JSON string in, for use with the encoder.
 * @return @link DSM_RESULT @endlink enumeration. If @link DSM_OK @endlink is returned, The PayloadOut buffer is ready for use in the DLSDK. Buffer length must be as long as @ref MAX_PAYLOAD_OUT_BUFFER.
 */
DSM_API_METHOD DSM_RESULT DSM_GetExpandedFreshJson_WithRetailToken(const char* Gtin13, const char* SellbyDate, const char* RetailToken, char* PayloadOut) {
	// validate output pointer
	if (!PayloadOut) {
		return DSM_PAYLOAD_BUFFER_NULL;
	}

	// validate gtin13 string
	if(!Gtin13 || (strlen(Gtin13) != DSM_GTIN_13_LENGTH)) {
		return(DSM_INVALID_PAYLOAD_DATA);
	}
	if(!StringUtils::MyStringOnlyContainsDigits(Gtin13)) {
		return(DSM_INVALID_PAYLOAD_DATA);
	}

	// validate (optional) sellby string
	if(SellbyDate) {
		if(DSM_SELLBY_DATE_LENGTH != strlen(SellbyDate) ||
			!StringUtils::MyStringOnlyContainsDigits(SellbyDate)) {
			return(DSM_INVALID_PAYLOAD_DATA);
		}
	}
	// validate (optional) token
	if (RetailToken) {
		if(strlen(RetailToken) > DSM_TOKEN_LENGTH ||
			!StringUtils::MyStringOnlyContainsDigits(RetailToken)) {
			return(DSM_INVALID_PAYLOAD_DATA);
		}
	}

	// generate serialized representation for required fields
	DSM_RESULT convertResult = StringFormatting::MySnprintf(PayloadOut
															, MAX_PAYLOAD_OUT_BUFFER
															, "{\"Path\":\"GC41.KE.WOM1.v9\",\"SubType\":\"2\",\"Variation\":\"4\",\"GTIN\":\"%s\",\"SellbyDate\":\"%s\",\"Token\":\"%s\"}"
															, Gtin13
															, SellbyDate
															, RetailToken
															);

	return convertResult;
}



#if defined( __cplusplus )
}
#endif // __cplusplus

#endif
