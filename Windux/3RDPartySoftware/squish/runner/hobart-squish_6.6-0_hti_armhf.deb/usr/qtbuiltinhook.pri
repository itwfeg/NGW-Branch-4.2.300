
SQUISH_PREFIX = $$PWD
INCLUDEPATH += $$SQUISH_PREFIX/include
DEFINES += HAVE_SQUISH

SQUISH_HAVE_PLATFORM_WAYLAND = 
SQUISH_HAVE_PLATFORM_X11 = 1

QT *= core gui network widgets

message("Squish: including builtin-hook in $$TARGET build/deployment")

boot2qt {
    # Hardcoded installation prefix to deploy Squish
    # together with the application
    SQUISH_INSTALL_PREFIX = "/data/user/qt/squish"

    # Define used in qtbuiltinhook.h when integrating
    # the hook into own application code (for the Qt plugin the above
    # squish installation prefix is mandatory!)
    DEFINES += SQUISH_INSTALL_PREFIX=\\\"$$SQUISH_INSTALL_PREFIX\\\"

    squish_etc.path = $$SQUISH_INSTALL_PREFIX/etc
    squish_etc.files = \
        $$SQUISH_PREFIX/etc/qtwrapper.ini
    INSTALLS += squish_etc

    squish_lib.path = $$SQUISH_INSTALL_PREFIX/lib
    squish_lib.files = \
        $$files($$SQUISH_PREFIX/lib/libsquish*.so) \
        $$SQUISH_PREFIX/lib/libtracelib.so
    INSTALLS += squish_lib

    # qtwrapper extensions
    squish_ext_qt.path = $$SQUISH_INSTALL_PREFIX/lib/extensions/qt
    squish_ext_qt.files = \
        $$files($$SQUISH_PREFIX/lib/extensions/qt/*.ext) \
        $$files($$SQUISH_PREFIX/lib/extensions/qt/lib*.so)
    INSTALLS += squish_ext_qt

    # qtquick 1.x squish qml extensions
    contains(QT, declarative) {
        squish_ext_qt_qml.path = $$SQUISH_INSTALL_PREFIX/lib/extensions/qt/qml
        squish_ext_qt_qml.files = \
            $$files($$SQUISH_PREFIX/lib/extensions/qt/qml/*.qml)
        INSTALLS += squish_ext_qt_qml
    }

    # qtquick 2.x squish qml extensions
    contains(QT, quick) {
        squish_ext_qt_qtquick.path = $$SQUISH_INSTALL_PREFIX/lib/extensions/qt/qtquick
        squish_ext_qt_qtquick.files = \
            $$files($$SQUISH_PREFIX/lib/extensions/qt/qtquick/*.qml)
        INSTALLS += squish_ext_qt_qtquick
    }

    # qt plugin
    squish_qtplugins.path = $$SQUISH_INSTALL_PREFIX/plugins/generic
    squish_qtplugins.files = \
        $$SQUISH_PREFIX/plugins/generic/libsquishplugin.so
    INSTALLS += squish_qtplugins

} else:android {

    lessThan(QT_MINOR_VERSION, 4) {
        error("Squish: Need Qt 5.4 or newer for Qt on Android")
    }

    isEmpty(SQUISH_ATTACH_PORT) {
        error("Squish: Please set SQUISH_ATTACH_PORT before including qtbuiltinhook.pri")
    }
    write_file("$$OUT_PWD/squishqtattach_port", SQUISH_ATTACH_PORT)

    squish_assets.path = /assets/squish
    squish_assets.files = \
        $$SQUISH_PREFIX/etc/qtwrapper.ini \
        $$files($$SQUISH_PREFIX/lib/extensions/qt/*.ext) \
        $$OUT_PWD/squishqtattach_port
    INSTALLS += squish_assets

    contains(QT, declarative) {
        squish_assets_qtquick1.path = /assets/squish/qml
        squish_assets_qtquick1.files = \
            $$files($$SQUISH_PREFIX/lib/extensions/qt/qml/*.qml)
        INSTALLS += squish_assets_qtquick1
    }

    contains(QT, quick) {
        squish_assets_qtquick2.path = /assets/squish/qtquick
        squish_assets_qtquick2.files = \
            $$files($$SQUISH_PREFIX/lib/extensions/qt/qtquick/*.qml)
        INSTALLS += squish_assets_qtquick2
    }

    squish_libs.path = /libs/$$ANDROID_TARGET_ARCH
    squish_libs.files = \
        $$files($$SQUISH_PREFIX/lib/libsquish*.so) \
        $$files($$SQUISH_PREFIX/lib/extensions/qt/*.so)
    INSTALLS += squish_libs

    ANDROID_EXTRA_LIBS += $$SQUISH_PREFIX/lib/libsquishqtattach.so

} else:static {

    DEFINES += SQUISH_QT_AS_STATICLIB

    unix:!macx:!ios:!wasm {

        isEmpty(SQUISH_PLATFORM_PLUGINS) {
            lessThan(QT_MAJOR_VERSION, 5) {
                _QT_PLATFORM_PLUGINS = qxcb
            } else {
                _QT_PLATFORM_PLUGINS = $${QTPLUGIN} $${QT_DEFAULT_QPA_PLUGIN}
                !isEmpty(QT_PLUGIN.platforms) {
                   _QT_PLATFORM_PLUGINS += $${QT_PLUGIN.platforms}
                } else {
                    _QT_PLATFORM_PLUGINS += $${QT_PLUGINS}
                }
            }

            contains(_QT_PLATFORM_PLUGINS, qxcb):equals(SQUISH_HAVE_PLATFORM_X11, 1) {
                SQUISH_PLATFORM_PLUGINS += xlib
            }

            contains(_QT_PLATFORM_PLUGINS, qwayland-(egl|generic)):equal(SQUISH_HAVE_PLATFORM_WAYLAND, 1) {
                SQUISH_PLATFORM_PLUGINS += wayland
            }

            unset(_QT_PLATFORM_PLUGINS)
        }
        message("Squish: selected platform plugins: $${SQUISH_PLATFORM_PLUGINS}")

        contains(SQUISH_PLATFORM_PLUGINS, xlib) {
            LIBS += $${SQUISH_PREFIX}/lib/$${QMAKE_PREFIX_STATICLIB}squishxlib.$${QMAKE_EXTENSION_STATICLIB}
            LIBS += -lX11 -lXtst # Needed by native replay
            LIBS += -lXdamage -lXfixes # Needed by screen recording
            LIBS += -lXrandr -lXft # Needed by X11WidgetHighlighter
            QMAKE_LFLAGS += -u xlibSquishPlugin
        }

        contains(SQUISH_PLATFORM_PLUGINS, wayland) {
            LIBS += $${SQUISH_PREFIX}/lib/$${QMAKE_PREFIX_STATICLIB}squishwayland.$${QMAKE_EXTENSION_STATICLIB}
            LIBS += -lwayland-client
            LIBS += -lxkbcommon # Optional, we may need to detect its presence
            QMAKE_LFLAGS += -u waylandSquishPlugin
        }
    }

    LIBS += $${SQUISH_PREFIX}/lib/$${QMAKE_PREFIX_STATICLIB}squishqtwrapper.$${QMAKE_EXTENSION_STATICLIB}
    LIBS += $${SQUISH_PREFIX}/lib/$${QMAKE_PREFIX_STATICLIB}squishhook.$${QMAKE_EXTENSION_STATICLIB}

    ios|macx {
        LIBS += -liconv # needed by Squish encoding conversions
    }

    ios {
        squish_assets.path = squish
        squish_assets.files = \
            $$SQUISH_PREFIX/etc/qtwrapper.ini
        QMAKE_BUNDLE_DATA += squish_assets

        squish_extensions.path = squish
        squish_extensions.files =
        QMAKE_BUNDLE_DATA += squish_extensions

        squish_assets_qtquick1.path = squish/qml
        squish_assets_qtquick1.files = \
            $$files($$SQUISH_PREFIX/lib/extensions/qt/qml/*.qml)

        squish_assets_qtquick2.path = squish/qtquick
        squish_assets_qtquick2.files = \
            $$files($$SQUISH_PREFIX/lib/extensions/qt/qtquick/*.qml)
    } else {
        RESOURCES += $$SQUISH_PREFIX/qtbuiltinhook.qrc
        exists($$SQUISH_PREFIX/lib/extensions/qt/qml/ext.qrc) {
            RESOURCES += $$SQUISH_PREFIX/lib/extensions/qt/qml/ext.qrc
        }
        exists($$SQUISH_PREFIX/lib/extensions/qt/qtquick/ext.qrc) {
            RESOURCES += $$SQUISH_PREFIX/lib/extensions/qt/qtquick/ext.qrc
        }
    }

    wasm {
        SQUISH_QT_EXTENSION_INIT_DECLARATIONS=""
        SQUISH_QT_EXTENSION_INIT_REGISTRATIONS=""
    }

    # Compile user selected extensions into AUT
    for (extension, SQUISH_WRAPPER_EXTENSIONS) {
        LIBS += $$SQUISH_PREFIX/lib/extensions/qt/$${QMAKE_PREFIX_STATICLIB}$${extension}.$${QMAKE_EXTENSION_STATICLIB}

        equals(extension, "squishqtquick")|equals(extension, "squishqtquickwidgets") {
            LIBS += $$SQUISH_PREFIX/lib/$${QMAKE_PREFIX_STATICLIB}squishqtquickcommon.$${QMAKE_EXTENSION_STATICLIB}
        }

        win32-msvc* {
            QMAKE_LFLAGS += /INCLUDE:_registerInitFunction_$${extension}
        } else:linux-g++ {
            QMAKE_LFLAGS += -u registerInitFunction_$${extension}
        } else:wasm {
            SQUISH_QT_EXTENSION_INIT_DECLARATIONS="$${SQUISH_QT_EXTENSION_INIT_DECLARATIONS}\
                void squish_qt_extension_register_init_$${extension}();\n"
            SQUISH_QT_EXTENSION_INIT_REGISTRATIONS="$${SQUISH_QT_EXTENSION_INIT_REGISTRATIONS}\
                squish_qt_extension_register_init_$${extension}();\n"
        } else {
            QMAKE_LFLAGS += -u _registerInitFunction_$${extension}
        }

        ios {
            squish_extensions.files += $$SQUISH_PREFIX/lib/extensions/qt/$${extension}.ext

            equals(extension, "squishdeclarative") {
                QMAKE_BUNDLE_DATA += squish_assets_qtquick1
            }
            equals(extension, "squishqtquick") {
                QMAKE_BUNDLE_DATA += squish_assets_qtquick2
            }
        } else {
            RESOURCES += $$SQUISH_PREFIX/lib/extensions/qt/$${extension}.qrc
        }
    }

    wasm {
        message("Squish: Adding wasm-specific options to the project")
        # Use configuration files bundled as resources
        SQUISH_INSTALL_PREFIX = ":/"
        # Define used in qtbuiltinhook.h when integrating
        # the hook into own application code
        DEFINES += SQUISH_INSTALL_PREFIX=\\\"$$SQUISH_INSTALL_PREFIX\\\"

        SQUISH_QT_EXTENSION_INIT_REGISTRATIONS_SOURCE=$$escape_expand( \
            $${SQUISH_QT_EXTENSION_INIT_DECLARATIONS}\n\n \
            void squish_register_qt_extensions() {\n$${SQUISH_QT_EXTENSION_INIT_REGISTRATIONS}} )
        write_file($${OUT_PWD}/squish_register_qt_extensions_init.cpp, SQUISH_QT_EXTENSION_INIT_REGISTRATIONS_SOURCE)
        SOURCES+=$${OUT_PWD}/squish_register_qt_extensions_init.cpp
        !isEmpty(SQUISH_SOURCE_MAP_URL) {
            QMAKE_LFLAGS += -g4 --source-map-base $${SQUISH_SOURCE_MAP_URL} -s ASSERTIONS=2 -s DEMANGLE_SUPPORT=1
        }
    }

}
