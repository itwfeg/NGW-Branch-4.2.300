try:
    import pexpect
except Exception as err:
    print 'Pexpect Installation not found in Python Path'
    print err

timeout_minute = 60
timeout_hour = timeout_minute * 60
timeout_day = timeout_hour * 24

SCP_DOWNLOAD = 'scp -o ConnectTimeout=30 -o StrictHostKeyChecking=no -v {user}@{host}:{remote} {local}'
SCP_UPLOAD   = 'scp -o ConnectTimeout=30 -o StrictHostKeyChecking=no -v {local} {user}@{host}:{remote}'

class ScpError(Exception):
    def __init__(self, data, exit_code):
        self.data = data
        self.exit_code = exit_code

    def __str__(self):
        return self.data

    def __repr__(self):
        return str(self)

class ScpClient():

    """Initializer, this Class is basically just for organization
    of Pexpect versus Chilkat based on the OS."""
    def __init__(self, hostname, username, password):
        #Class Attribute Declarations.
        self.hostname = hostname
        self.username = username
        self.password = password

    def getTimeout(self, type='Day'):
        return timeout_day

    def runScp(self, command, timeout=None):
        if not timeout:
            timeout = self.getTimeout('Day')

        scpProc = pexpect.spawn(command, timeout=timeout)

        #Waits for the process to prompt for password and inputs it.
        try:
            i = scpProc.expect(['assword:', r"yes/no"])
#
        except pexpect.EOF as err:
            raise ScpError(str(err), 1)
#
        if i == 0:
            scpProc.sendline(self.password)
        elif i == 1:
            scpProc.sendline('yes')
            scpProc.expect('assword')
            scpProc.sendline(self.password)

        scpProc.timeout = timeout

        data = scpProc.read()
        scpProc.close()

        try:
            exitCode = scpProc.signalstatus
        except AttributeError as err:
            exitCode = scpProc.exitstatus

        if not exitCode:
            exitCode = scpProc.exitstatus

        error = self.checkForErrors(process=scpProc, data=data)

        if error:
            raise ScpError(data, exitCode)
        else:
            exitCode = 0
        return data, exitCode


    def checkForErrors(self, process, data):
        success_message = 'Exit status 0'
        lines = data.split('\n')[:-1]
        if any(success_message in line.strip() for line in lines):
            return False

        return True



    """Downloads filepath serverFileName to filePath localFileName
    on the current machine."""
    def downloadFile(self, serverFileName, localFileName, message_callback = None):
        data = ''

        #Spawn an SCP Shell process.
        command = SCP_DOWNLOAD.format(user=self.username,
                                      host=self.hostname,
                                      remote=serverFileName,
                                      local=localFileName)

        try:
            status = 'success'
            data, exit_code = self.runScp(command=command)

        except ScpError as err:
            status = 'failed'
            data = err.data
            exit_code = err.exit_code

        status = 'success'

        return '{status}|{data}|{exitCode}'.format(data=data, exitCode=exit_code, status=status)

    """Uploads filepath localFileName to filepath serverFileName
    on the remote machine."""
    def uploadFile(self, serverFileName, localFileName):
        data = ''
        #Spawn an SCP shell process.
        command = SCP_UPLOAD.format(user=self.username,
                                      host=self.hostname,
                                      remote=serverFileName,
                                      local=localFileName)

        try:
            data, exit_code = self.runScp(command=command)
            status = 'success'

        except ScpError as err:
            status = 'failed'
            data = err.data
            exit_code = err.exit_code

        return '{status}|{data}|{exitCode}'.format(data=data,
            exitCode=exit_code, status=status)


def test_download(client):
    dl_results = client.downloadFile('./projectDirs.txt', 'projectDirs.txt')
    tokens = dl_results.split('|')

    print dl_results

    if tokens[0] != 'success':
        print 'Download Test Failed'
    else:
        print 'Download Test Successful'

    print '------------------------------'


def test_upload(client):
    ul_results = client.uploadFile('./projectDirs.txt', './projectDirs.txt')
    tokens = ul_results.split('|')

    print ul_results

    if tokens[0] != 'success':
        print 'Upload Test Failed'
    else:
        print 'Upload Test Successful'

    print '------------------------------'


def run_tests():
    client = ScpClient('10.3.177.117', 'smuser', 'sm1user')
    test_download(client)
    test_upload(client)


if __name__=='__main__':
    run_tests()
