/**
 *
 *  DIGIMARC CORPORATION PROPRIETARY INFORMATION
 *  Copyright, Digimarc Corporation.  All Rights Reserved.
 *
 *  This software contains confidential information, including trade secrets, 
 *  of Digimarc that is protected by the confidentiality agreement entered into 
 *  between you and Digimarc.  It is important that this information be used only
 *  in accordance with your agreement with Digimarc.  Receipt of this software 
 *  conveys no license under Digimarc's patent, trademark, trade secret, or 
 *  copyright rights.  Use of this software - and the technology detailed therein - 
 *  requires a license from Digimarc. The technology embodied in this software is 
 *  protected by US and International Patents.
 *
 */
 
package com.digimarc.LabelEmbedder.example;

import com.digimarc.DLSDK.*;
import java.io.*;
 
public class JniExampleOneBitPerPixel {

	static {
		System.loadLibrary("dlsdkjava");
	}

	static void save(String filename, byte[] img, int width, int height) {
		// We use 0 for black and 1 for white
		// .pbm use 1 for black and 0 for white
		// So flip the bits before write to the file
		for (int i = 0; i < img.length; i++)
		{
			img[i] = (byte)(~img[i]);
		}
		try {
			FileOutputStream outfile = new FileOutputStream(filename);
			PrintWriter writer = new PrintWriter(outfile);
			writer.format("P4\n%d %d\n", width, height);
			writer.flush();
			outfile.write(img);
			outfile.close();
		} catch(FileNotFoundException ex) {
		} catch(IOException ex) {
		}
	}
	
	public static void main(String[] args) {
	
		// User specified Expanded Fresh data
		String gtin13 = "1234567890128";
		String sellByDate = "181231";
		String price = "12345";
		String weightInPounds = "";
		String weightInKilograms = "";
		String count = "98";
		
		// User specified options
		String outputFile = "JniExampleOneBitPerPixelOut.pbm";
		DSM_DATADESC_TYPE dataDescType = DSM_DATADESC_TYPE.DSM_DATADESC_ONE_BPP;
		int imageResolution = 203;
		int imageWidth = 406;
		int imageHeight = 406;
		int imageStride = (imageWidth + 7 ) / 8; // 1 bit per pixel padded to full byte at the end of each row
		int dotDensity = 35;
		int dotSize = 1;
		int watermarkResolution = 150;
		DSM_IMAGE_BLEND_MODE imageBlendMode = DSM_IMAGE_BLEND_MODE.DSM_IMAGE_BLEND_MODE_OVERWRITE;
		int numKeepOutRegions = 0;
	
		// Create a LabelEmbedder object
		// Instead of instantiating LabelEmbedder object each time you embed a label,
		// we recommend that you instantiate the LabelEmbedder only once.
		// And then you can embed as many labels as you want, 
		// This helps reduce the overhead of setting up the embedder and is more efficient,
		// especially if you are printing multiple labels at the same label settings.
		LabelEmbedder le = new LabelEmbedder();
		
		// Initialize the LabelEmbedder
		DSM_RESULT result = le.initialize();
		if (result != DSM_RESULT.DSM_OK) {
			System.out.println("Error initializing!");
			System.exit(1);
		}
		
		// Create an ImageDescriptor object
		ImageDescriptor imgDesc = new ImageDescriptor();
		
		// Assign user specified data to image descriptions
		imgDesc.setBytesPerRow(imageStride);
		imgDesc.setDataType(dataDescType);
		imgDesc.setWidth(imageWidth);
		imgDesc.setHeight(imageHeight);
		imgDesc.setResolution(imageResolution);
		
		// Create an EmbedderOptions object
		EmbedderOptions embedopts = new EmbedderOptions();
		
		// Assign user specified options to embedder options
		embedopts.setDotDensity(dotDensity);
		embedopts.setDotSize(dotSize);
		embedopts.setWatermarkResolution(watermarkResolution);
		embedopts.setImageBlendMode(imageBlendMode);
		embedopts.setNumKeepOutRegions(numKeepOutRegions);
		
		// Get a converted JSON string payload from user specified Expanded Fresh data
		String json = le.getExpandedFreshJson(gtin13, sellByDate, price, weightInPounds, weightInKilograms, count);
		
		// Set the payload in embedder options
		embedopts.setPayload(json);
		
		// Create image buffer
		byte[] buffer = new byte[imageStride * imageHeight];
		
		// Embed the Label
		result = le.embed(imgDesc, embedopts, buffer);
		
		// Check embed result
		if (result == DSM_RESULT.DSM_OK) {
			save(outputFile, buffer, imageWidth, imageHeight);
			System.out.println("Embed successful");
			System.out.println("Output image saved as " + outputFile);
		} else {
			System.out.println("Embed failed with result code " + result);
		}
	}
}
