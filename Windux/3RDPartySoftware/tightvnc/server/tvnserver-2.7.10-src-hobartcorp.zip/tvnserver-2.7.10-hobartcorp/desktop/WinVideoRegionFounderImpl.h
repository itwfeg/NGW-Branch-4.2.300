// Copyright (C) 2013 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef __WINVIDEOREGIONFOUNDERIMPL_H__
#define __WINVIDEOREGIONFOUNDERIMPL_H__

#include "util/DateTime.h"
#include "region/Region.h"
#include "ScreenDriver.h"

class WinVideoRegionFounderImpl : public ScreenDriver
{
public:
  WinVideoRegionFounderImpl();
  virtual ~WinVideoRegionFounderImpl();

private:
  virtual void getVideoRegion(Region *dstVidRegion);

  void updateVideoRegion();

  DateTime m_lastVidUpdTime;
  Region m_vidRegion;
};

#endif // __WINVIDEOREGIONFOUNDERIMPL_H__
