// Copyright (C) 2008,2009,2010,2011,2012 GlavSoft LLC.
// All rights reserved.
//
//-------------------------------------------------------------------------
// This source code is licensed to ITW Food Equipment Group LLC. and
// may not be distributed except as permitted by the License Agreement
// between GlavSoft LLC and ITW Food Equipment Group LLC.
//-------------------------------------------------------------------------
//

#ifndef SOCKET_STREAM_H
#define SOCKET_STREAM_H

#include "io-lib/Channel.h"

#include "../socket/SocketAddressIPv4.h"
#include "../socket/SocketIPv4.h"
#include "../socket/SocketAddressIPv4.h"

#include "io-lib/IOException.h"

class SocketStream : public Channel
{
public:
  SocketStream(SocketIPv4 *);
  virtual ~SocketStream();

  //
  // Inherited from Channel.
  //

  virtual size_t read(void *, size_t) throw(IOException);

  virtual size_t write(const void *, size_t) throw(IOException);

  // Closes connection and break all blocked operation.
  // @throw Exception on error.
  virtual void close();

protected:
  SocketIPv4 *m_socket;

  friend class SocketIPv4;
};

#endif
